data:extend{
  {
    type = "recipe",
    name = "power-armor-mk3",
    enabled = false,
    energy_required = 40,
    ingredients = {
	  {"effectivity-module-3", 20},
	  {"speed-module-3", 20},
	  {"advanced-circuit", 50},
	  {"processing-unit", 100},
	  {"steel-plate", 100},
	  {"alien-artifact", 200},
	},
    result = "power-armor-mk3",
    requester_paste_multiplier = 1
  }
}  