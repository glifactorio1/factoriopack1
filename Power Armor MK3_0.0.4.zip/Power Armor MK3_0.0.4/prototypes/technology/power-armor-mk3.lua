data:extend{
  {
    type = "technology",
    name = "power-armor-3",
    icon = "__Power Armor MK3__/graphics/technology/power-armor-mk3.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "power-armor-mk3"
      }
    },
    prerequisites = {"power-armor-2", "military-4"},
    unit =
    {
      count = 200,
      ingredients = {{"science-pack-1", 1}, {"science-pack-2", 1}, {"science-pack-3", 2}, {"alien-science-pack", 4}},
      time = 60
    },
    order = "g-c-c"
  }
}  