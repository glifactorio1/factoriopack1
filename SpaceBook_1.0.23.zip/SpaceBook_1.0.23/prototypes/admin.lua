data:extend(
{
	----------------------------------------------------------------------------------
	{
		type = "player",
		name = "spbook-avatar",
		icon = "__SpaceBook__/graphics/avatar-icon.png",
		flags = {"pushable", "placeable-player", "placeable-off-grid", "not-repairable", "not-on-map"},
		max_health = 1000,
		healing_per_tick = 1000,
		alert_when_damaged = false,
		collision_box = {{0,0}, {0, 0}},
		collision_mask = {},
 		render_layer = "air-object", 
		final_render_layer = "air-object",
		crafting_categories = {"crafting"},
		mining_categories = {"basic-solid"},
		damage_hit_tint = {r = 1, g = 0, b = 0, a = 0},
		inventory_size = 100,
		build_distance = 1000,
		drop_item_distance = 40,
		reach_distance = 10000,
		item_pickup_distance = 40,
		loot_pickup_distance = 40,
		reach_resource_distance = 40,
		ticks_to_keep_gun = 0,
		ticks_to_keep_aiming_direction = 0,
		running_speed = 0.15*admin_speed_factor,
		distance_per_frame = 2,
		maximum_corner_sliding_distance = 0,
		subgroup = "creatures",
		order="z",
		eat =
		{
			{
				filename = "__SpaceBook__/sound/empty.ogg",
				volume = 0,
				}
		},
		heartbeat =
		{
			{
				filename = "__SpaceBook__/sound/empty.ogg",
				volume = 0,
			}
		},
		animations =
		{
			level1 = avatar_level, 
			level2addon = avatar_level, 
			level3addon = avatar_level,
		},
		light =
		{
			{
				minimum_darkness = 0.25,
				intensity = 0.8,
				size = 100,
			},
		},
		mining_speed = 1,
		mining_with_hands_particles_animation_positions = {0, 0},
		mining_with_tool_particles_animation_positions = {0},
		running_sound_animation_positions = {0, 0},
	},

}
)



