----------------------------------------------------------------------------------
avatar8still =
{ 
	filename = "__SpaceBook__/graphics/avatar-anim8run.png",
	priority = "medium",
	width = 32,
	height = 32,
	direction_count = 8,
	frame_count = 8,
	line_length = 8,
	animation_speed = 5/60,
	shift = {0, 0},
	axially_symmetrical = false
}

avatar8run =
{ 
	filename = "__SpaceBook__/graphics/avatar-anim8run.png",
	priority = "medium",
	width = 32,
	height = 32,
	direction_count = 8,
	frame_count = 8,
	line_length = 8,
	animation_speed = 5/60,
	shift = {0, 0},
	axially_symmetrical = false
}

avatar18run =
{ 
	filename = "__SpaceBook__/graphics/avatar-anim18run.png",
	priority = "medium",
	width = 32,
	height = 32,
	direction_count = 18,
	frame_count = 1,
	line_length = 1,
	animation_speed = 2/60,
	shift = {0, 0},
	axially_symmetrical = false
}

avatar_level = 
{
	idle = avatar8still,
	idle_mask = avatar8still,
	idle_with_gun = avatar8still,
	idle_with_gun_mask = avatar8still,
	mining_with_hands = avatar8still,
	mining_with_hands_mask = avatar8still,
	mining_with_tool = avatar8still,
	mining_with_tool_mask = avatar8still,
	running_with_gun = avatar18run,
	running_with_gun_mask = avatar18run,
	running = avatar8run,
	running_mask = avatar8run
}
