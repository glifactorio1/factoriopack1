-- debug_status = 1
debug_mod_name = "SpaceBook"
debug_file = debug_mod_name .. "-debug.txt"
require("util")
require("utils")
require("config")
require("sha2")

local band, bor, bxor = bit32.band, bit32.bor, bit32.bxor

-- player rights
local rights = 	{ banned = 1, guest = 2, engineer = 3, officer = 4, admin = 5, owner = 6,
					{name={"sblocr-banned"}, style="spbook_button_rights_banned_style", color = colors.red}, 
					{name={"sblocr-guest"}, style="spbook_button_rights_guest_style", color = colors.white}, 
					{name={"sblocr-engineer"}, style="spbook_button_rights_engineer_style", color = colors.green}, 
					{name={"sblocr-officer"}, style="spbook_button_rights_officer_style", color = colors.lightblue}, 
					{name={"sblocr-admin"}, style="spbook_button_rights_admin_style", color = colors.orange}, 
					{name={"sblocr-owner"}, style="spbook_button_rights_owner_style", color = colors.yellow} 
				}

-- infos types
local infos = 	{ none = 1, error = 2, ok = 3, confirm = 4,   duplic = 5, all = 6,
					{color=colors.lightgrey, sprite="sprite_spbook_info_none"},
					{color=colors.red, sprite="sprite_spbook_info_error"},
					{color=colors.green, sprite="sprite_spbook_info_ok"},
					{color=colors.pink, sprite="sprite_spbook_info_confirm"},
				}

-- describes if action is a cheat or not
local cheat = {  
	no = 0, -- not a cheat, can be used even with cheats off
	yes = 1, -- definitely a cheat, cannot be used while cheats off
	unless_officer = 2, -- a cheat for everyone else than officer in the force (like changing force stance)
}

-- which part of gui to refresh
local refr = { frame = 0x01, common = 0x02, you = 0x04, forces = 0x08, players = 0x20, info = 0x80,
				all_inside = 0xFE, all = 0xFF }
				
				
--------------------------------------------------------------------------------------
local function player_position(player)
	return( math.floor(player.position.x) .. "," .. math.floor(player.position.y) )
end

--------------------------------------------------------------------------------------
local function force_position(force)
	local pos = force.get_spawn_position("nauvis")
	return( math.floor(pos.x) .. "," .. math.floor(pos.y) )
end

--------------------------------------------------------------------------------------
local function clean_gui(gui)
	for _, guiname in pairs( gui.children_names ) do
		gui[guiname].destroy()
	end
end

--------------------------------------------------------------------------------------
local function close_windows(player, except_pwd)
	if player.connected then
		if player.gui.left.frame_spbook ~= nil then 
			player.gui.left.frame_spbook.destroy()
		end
		if player.gui.left.frame_spbook_scanner ~= nil then 
			player.gui.left.frame_spbook_scanner.destroy()
		end
		if player.gui.left.frame_spbook_tools ~= nil then 
			player.gui.left.frame_spbook_tools.destroy()
		end
		if player.gui.center.frame_spbook_colors ~= nil then
			player.gui.center.frame_spbook_colors.destroy()
		end
		if not except_pwd and player.gui.center.frame_spbook_pwd ~= nil then
			player.gui.center.frame_spbook_pwd.destroy()
		end
		if player.gui.center.frame_spbook_for_new ~= nil then
			player.gui.center.frame_spbook_for_new.destroy()
		end
	end
end

--------------------------------------------------------------------------------------
local function close_all_windows()
	for _, player in pairs(game.players) do
		close_windows(player, false)
	end
end

--------------------------------------------------------------------------------------
local function test_confirm( player, player_mem, element )
	if player_mem.confirm_but == nil or player_mem.confirm_but ~= element then
		-- new confirmation demand
		element.style.font_color = colors.pink
		player_mem.confirm_but = element
		player_mem.confirm_tick = game.tick + 60 * confirm_timeout
				
		info(player, player_mem, {"sbloci-confirm-press"}, infos.confirm )
		return( false )
	else
		if player_mem.confirm_but == element then
			-- confirmation done
			player_mem.confirm_but.style.font_color = player_mem.confirm_color
			player_mem.confirm_but = nil
			info(player, player_mem, "", infos.none )
			return( true )
		else
			-- confirm canceled (switch on other button...)
			return( false )
		end
	end
end

--------------------------------------------------------------------------------------
local function check_valid_player_mem( player_mem )
	-- check that current player's selection are valid
	
	if player_mem.force_sel and not player_mem.force_sel.valid then
		player_mem.n_force_sel = 1
		player_mem.force_sel = game.forces.player
	end

	if player_mem.player_sel and not player_mem.player_sel.valid then
		player_mem.n_player_sel = 0
		player_mem.player_sel = nil
	end

	if player_mem.force_filter and not player_mem.force_filter.valid then
		player_mem.force_filter = nil
	end

	if global.force_autojoin and not global.force_autojoin.valid then
		global.force_autojoin = nil
	end
end

--------------------------------------------------------------------------------------
local function check_rights(player, player_mem, rights_level, is_cheat, force)
	-- not authenticated
	if not player_mem.authen then
		info(player, player_mem, {"sbloci-chk-noid"} , infos.error )
		return(false)
	end
	
	-- close banned interfaces, in case...
	if player_mem.rights == rights.banned then 
		close_windows(player, false)
		return(false)
	end
	
	-- test cheat disabled
	if not global.cheats_enabled then
		if is_cheat == cheat.yes then
			info(player, player_mem, {"sbloci-chk-nocht"} , infos.error )
			return(false)
		elseif is_cheat == cheat.unless_officer and force ~= player.force then
			info(player, player_mem, {"sbloci-chk-chtoff"} , infos.error )
			return(false)		
		end
	end
	
	-- here cheat exceptions has been verified
	
	-- test mod disabled
	if not global.mod_enabled and player_mem.rights < rights.owner then
		info(player, player_mem, {"sbloci-chk-moddis"} , infos.error )
		return(false)
	end
	
	-- test rights level
	if player_mem.rights < rights_level then 
		info(player, player_mem, {"sbloci-chk-norig"} , infos.error )
		return(false)
	end

	-- admin can do anything
	if player_mem.rights >= rights.admin then return(true) end
	
	-- if force condition and force is same as player then ok, except force guests that cannot be "officiered"
	if force then
		if force == player.force then 
			if force == global.force_guests then
				info(player, player_mem, {"sbloci-chk-nogst"} , infos.error )
				return(false)
			end
			return(true) 
		else
			-- officer can only modif within their own force
			info(player, player_mem, {"sbloci-chk-ownfor"} , infos.error )
			return(false)
		end
	end
	
	return(true)
end

--------------------------------------------------------------------------------------
local function update_main_bar(player, player_mem )
	if not player.connected then return end
	
	local flo = player.gui.top.flow_spbook_main
	-- if player.gui.top.flow_spbook_main then player.gui.top.flow_spbook_main.destroy() end
	
	if flo == nil then flo = player.gui.top.add({type = "flow", name = "flow_spbook_main", style = "spbook_flow_main_style"}) end
	clean_gui(flo)
	
	if player.character and player.character.valid and not player.character.destructible then
		flo.add({type = "sprite-button", name = "but_spbook_main", sprite = "sprite_spbook_main_shd", style = "spbook_sprite_main_style"})	
	else
		flo.add({type = "sprite-button", name = "but_spbook_main", sprite = "sprite_spbook_main", style = "spbook_sprite_main_style"})	
	end
	
	if player_mem.rights >= rights.admin and global.cheats_enabled then
		if player_mem.avatar then
			flo.add({type = "sprite-button", name = "but_spbook_ava", sprite = "sprite_spbook_main_ava", style = "spbook_sprite_main_style"})				
		else
			flo.add({type = "sprite-button", name = "but_spbook_ava", sprite = "sprite_spbook_main_hum", style = "spbook_sprite_main_style"})				
		end
		flo.add({type = "sprite-button", name = "but_spbook_tel", sprite = "sprite_spbook_main_tel", style = "spbook_sprite_main_style"})				
	end
end

--------------------------------------------------------------------------------------
local function window_opened(player_cur)
	return( player_cur.gui.left.frame_spbook ~= nil )
end

--------------------------------------------------------------------------------------
local function update_window(player_cur, refresh)
	local gui1, gui2, gui3, gui4, gui5, gui6, gui7
	local but_pagecur, frame_nb
	local player_cur_mem = global.player_mem[player_cur.index]
	local player_mem
	local force, player, name, i, i1, i2
	local force_cur = player_cur.force
	local rights_cur = player_cur_mem.rights
	local is_admin = (rights_cur >= rights.admin)
	local has_rights = (rights_cur >= rights.officer)
	local has_rights_cheat = has_rights and global.cheats_enabled
	local s, caption, color, style, player_color
	local n_col = 0
	local refresh_frame = band(refresh,refr.frame)
	
	check_valid_player_mem( player_cur_mem )
	
	local n_force_sel = player_cur_mem.n_force_sel
	local force_sel = player_cur_mem.force_sel

	local n_player_sel = player_cur_mem.n_player_sel
	local player_sel = player_cur_mem.player_sel
	-- if player is selected, but no number, then we will find the number
	local look_n_player_sel = (n_player_sel == 0 and player_sel)
	-- if n_player , but no player_sel, then we will find the luaplayer
	local look_player_sel = (n_player_sel ~= 0 and not player_sel)

	local force_filter = player_cur_mem.force_filter
	local filter_online = player_cur_mem.filter_online
	local filter_noban = player_cur_mem.filter_noban

	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
	local function add_button( gui, name, caption, rights_level, color, is_big, is_name )
		local style

		is_big = is_big or false
		is_name = is_name or false

		if is_name then
			style = "spbook_button_name_style"
		elseif is_big then
			style = "spbook_button_style"
		else
			style = "spbook_button_small_style"
		end
		
		local but = gui.add({type = "button", name = name, caption = caption, style = style})
		if but == player_cur_mem.confirm_but then
			but.style.font_color = colors.pink
		else
			color = color or "white"
			but.style.font_color = iif( rights_cur >= rights_level, colors[color], lightcolors[color] )
		end
		return(but)
	end

	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
	local function add_column( gui, prefix, caption )
		n_col = n_col + 1
		gui.add({type = "label", name = prefix .. n_col, caption = caption, style = "spbook_label_style"})
	end
		
	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
	
	if refresh_frame then
		gui1 = player_cur.gui.left.frame_spbook
		
		if gui1 then
			gui1.destroy()
		end
		
		gui1 = player_cur.gui.left.add({type = "frame", name = "frame_spbook", caption = "", direction = "vertical", style = "spbook_frame_main_style"})
		gui1 = gui1.add({type = "flow", name = "flow_spbook", direction = "vertical", style = "spbook_flow_style"})
		gui1.add({type = "label", caption = "SPACEBOOK", style = "spbook_label_title_style"})

		-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

		gui2 = gui1.add({type = "frame", name = "frame_spbook_common", caption = "", direction = "vertical", style = "spbook_frame_style"})
	else
		gui1 = player_cur.gui.left.frame_spbook
		gui2 = gui1.frame_spbook_common
	end

	if band(refresh,refr.common) then
		-- common tools subwindow
		
		clean_gui(gui2)
		-- gui1.flow_spbook_common1.destroy()
		-- if gui1.flow_spbook_common2 then gui1.flow_spbook_common2.destroy() end
		
		gui3 = gui2.add({type = "flow", name = "flow_spbook_common1", direction = "horizontal", style = "spbook_flow_line_style"})
		if game.surfaces.nauvis.peaceful_mode then
			caption = {"sblocc-peace"}
			color = "green"
		else
			caption = {"sblocc-agr"}
			color = "red"
		end
		gui4 = add_button( gui3, "but_spbook_peace", caption, rights.admin, color, true )
		
		if not global.timetools then
			s = iif( game.surfaces.nauvis.always_day, {"sblocc-alwdays"}, {"sblocc-ninday"} )
			gui4 = add_button( gui3, "but_spbook_day", s, rights.admin, "white", true )
			
			s = iif( global.frozen, {"sblocc-timfrz"}, {"sblocc-timrun"})
			color = iif( global.frozen, "red", "green" )
			gui4 = add_button( gui3, "but_spbook_frozen", s, rights.admin, color, true )
		end
		if global.mod_enabled then
			color = "green"
			s = "Mod ON"
		else
			color = "red"
			s = "Mod OFF"
		end
		add_button( gui3, "but_spbook_mod_ena", s, rights.admin, color, true ) 
		if global.cheats_enabled then
			color = "red"
			s = {"sblocc-chton"}
		else
			color = "yellow"
			s = {"sblocc-chtoff"}
		end
		add_button( gui3, "but_spbook_cht_ena", s, rights.admin, color, true ) 
		if global.pwd_enabled then
			color = "green"
			s = {"sblocc-pwdon"}
		else
			color = "yellow"
			s = {"sblocc-pwdoff"}
		end
		add_button( gui3, "but_spbook_pwd_ena", s, rights.admin, color, true ) 
		add_button( gui3, "but_spbook_refresh", {"sblocc-refresh"}, rights.guest, "white", true )
		if debug_status then
			add_button( gui3, "but_spbook_test", "Test", rights.guest, "white", true )
		end

		if is_admin then
			gui3 = gui2.add({type = "flow", name = "flow_spbook_common2", direction = "horizontal", style = "spbook_flow_line_style"})
			add_button( gui3, "but_spbook_save", {"sblocc-servsav"}, rights.admin, "white" )
			add_button( gui3, "but_spbook_clean", {"sblocc-del-offlines"}, rights.admin )  -- dangerous
			
			if rights_cur == rights.owner then
				if global.noOwnerYet then
					color = "yellow"
					s = {"sblocc-owner-wait"}
				else
					color = "white"
					s = {"sblocc-owner-rst"}
				end
				add_button( gui3, "but_spbook_own_rst", s, rights.owner, color )
				add_button( gui3, "but_spbook_cln_con", {"sblocc-clr-con"}, rights.owner, "white" )
			end
			add_button( gui3, "but_spbook_zoom", {"sblocc-zoom"}, rights.admin, "white" )
		end
	end
	
	--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --
	
	if refresh_frame then
		gui2 = gui1.add({type = "frame", name = "frame_spbook_you", direction = "vertical", style = "spbook_frame_style"})
	else
		gui2 = gui1.frame_spbook_you
	end
	
	if band(refresh,refr.you) then
		-- "you" player subwindow
		clean_gui(gui2)
		
		gui3 = gui2.add({type = "flow", name = "flow_spbook_you", direction = "vertical", style = "spbook_flow_style"})
		gui3.add({type = "label", caption = {"sblocc-you-title", player_cur.name, force_cur.name} , style = "spbook_label_title_style"})

		gui4 = gui3.add({type = "flow", name = "flow_spbook_ycm", direction = "horizontal", style = "spbook_flow_style"})
		gui4.add({type = "label", name = "lab_spbook_you_rigt", caption = {"sblocc-you-rights"}, style = "spbook_label_style"})
		gui5 = gui4.add({type = "label", name = "lab_spbook_you_rigv", caption = rights[rights_cur].name, style = "spbook_label_center_style"})
		gui5.style.minimal_width = 50
		gui5.style.font_color = rights[rights_cur].color
		gui4.add({type = "label", name = "lab_spbook_you_pos", caption = {"sblocc-you-pos", player_position(player_cur) }, style = "spbook_label_style"})
		if has_rights_cheat then 
			add_button( gui4, "but_spbook_you_utp", {"sblocc-you-utp"}, rights.admin )
		end
		
		color = iif( player_cur_mem.pwd_hash == "", "red", "white" )
		add_button( gui4, "but_spbook_you_pwd", {"sblocc-you-pwd"}, rights.guest, color )
		if rights_cur >= rights.engineer then
			add_button( gui4, "but_spbook_you_quit", {"sblocc-you-quit"}, rights.engineer )
			add_button( gui4, "but_spbook_you_color", {"sblocc-you-col"}, rights.guest )
		end
		add_button( gui4, "but_spbook_you_scanner", {"sblocc-you-sca"}, rights.guest )
		gui4.add({type = "label", name = "lab_spbook_you_sel", caption = {"sblocc-you-sel"}, style = "spbook_label_style"})
		add_button( gui4, "but_spbook_you_sly", {"sblocc-you-sly"}, rights.guest )
		add_button( gui4, "but_spbook_you_slf", {"sblocc-you-slf"}, rights.guest )
	end
	
	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	if refresh_frame then
		gui2 = gui1.add({type = "flow", name = "flow_spbook_main", direction = "horizontal", style = "spbook_flow_style"})
		
		-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

		gui3 = gui2.add({type = "flow", name = "flow_spbook_forces_all", direction = "vertical", style = "spbook_flow_style"})

		-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

		gui4 = gui3.add({type = "frame", name = "frame_spbook_forces", direction = "vertical", style = "spbook_frame_style"})
	else
		gui2 = gui1.flow_spbook_main
		gui3 = gui2.flow_spbook_forces_all
		gui4 = gui3.frame_spbook_forces
	end
	
	if band(refresh,refr.forces) then
		-- forces subwindow
		
		clean_gui(gui4)
		
		gui5 = gui4.add({type = "flow", name = "flow_spbook_for_arrows", direction = "horizontal", style = "spbook_flow_style"})
		--frame_nb = gui5.add({type = "label", caption = "F...", style = "spbook_label_title_style"})
		frame_nb = gui5.add({type = "label", style = "spbook_label_title_style"})
		add_button( gui5, "but_spbook_for_pageleft", "<", rights.guest, "white", true  )
		but_pagecur = add_button( gui5, "but_spbook_for_pagecur", "", rights.guest, "white", true  )
		add_button( gui5, "but_spbook_for_pageright", ">", rights.guest, "white", true  )
		if is_admin then
			add_button( gui5, "but_spbook_for_new", {"sblocc-fos-new"}, rights.admin, "white", true  )
		end
		
		gui4 = gui3.add({type = "frame", name = "frame_spbook_for_list", direction = "vertical", style = "spbook_frame_list_style"})
		gui5 = gui4.add({type = "table", name = "table_spbook_for_lines", colspan = 4 + iif(is_admin and global.cheats_enabled,1,0), style = "spbook_table_style"})
		n_col = 0
		add_column( gui5, "lab_spbook_for_col", "" )
		add_column( gui5, "lab_spbook_for_col", {"sblocc-fos-nam"} )
		add_column( gui5, "lab_spbook_for_col", {"sblocc-fos-nb"} )
		add_column( gui5, "lab_spbook_for_col", {"sblocc-fos-sta"} )
		if is_admin and global.cheats_enabled then
			add_column( gui5, "lab_spbook_for_col", {"sblocc-fos-stp"} )
		end

		i = 1
		i1 = 1 + (player_cur_mem.forces_page_cur-1) * lines_per_page
		i2 = player_cur_mem.forces_page_cur * lines_per_page
		
		for name, force in pairs(game.forces) do
			if i <= i2 and i >= i1 then
				gui5.add({type = "checkbox", name = "chk_spbook_for_sel" .. i, caption = "", state = (n_force_sel == i), style = "spbook_checkbox_style"})

				if force == player_cur.force then
					color = "green"
				elseif force == global.force_guests then
					color = "lightblue"
				elseif i <= 3 then
					color =	"lightgrey"
				else
					color = "white"
				end
				gui6 = add_button(gui5, "but_spbook_for_nam" .. i, force.name, rights.guest, color, true, true)

				if global.nb_players_force[force.name] == nil then global.nb_players_force[force.name] = 0 end
				gui6 = gui5.add({type = "label", name = "lab_spbook_for_nbp" .. i, caption = global.nb_players_force[force.name], style = "spbook_label_center_style"})
				gui6.style.minimal_width = 50

				gui6 = gui5.add({type = "flow", name = "flow_spbook_for_war" .. i, direction = "horizontal", style = "spbook_flow_line_style"})
				
				if global.cheats_enabled or force_sel == force_cur then
					if force_sel and i ~= n_force_sel then
						local attacking = not force_sel.get_cease_fire(force.name)
						s = iif( attacking, "sprite_spbook_enemy" , "sprite_spbook_friend" )
					else
						s = "sprite_spbook_neutral"
					end
				else
					s = "sprite_spbook_neutral"
				end
				gui6.add({type = "sprite-button", name = "but_spbook_for_wra" .. i, sprite = s, style = "spbook_sprite_butin_style"})

				if global.cheats_enabled then
					if force_sel and i ~= n_force_sel then
						local attacked = not force.get_cease_fire(force_sel.name)	
						s = iif( attacked, "sprite_spbook_enemy2" , "sprite_spbook_friend2" )
					else
						s = "sprite_spbook_neutral"
					end
				else
					s = "sprite_spbook_neutral"
				end
				gui6.add({type = "sprite-button", name = "but_spbook_for_wrb" .. i, sprite = s, style = "spbook_sprite_butin_style"})
				
				if is_admin and global.cheats_enabled then
					gui5.add({type = "button", name = "but_spbook_for_pxy" .. i, caption = force_position(force), style = "spbook_button_xy_style"})
				end
			end
			
			i=i+1
		end
		
		player_cur_mem.nb_forces = i-1
		player_cur_mem.forces_page_max = 1 + math.floor( (player_cur_mem.nb_forces-1) / lines_per_page )
		but_pagecur.caption = player_cur_mem.forces_page_cur .. "/" .. player_cur_mem.forces_page_max 
		frame_nb.caption = {"sblocc-fos-title",player_cur_mem.nb_forces}
	end

	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	if refresh_frame then
		if has_rights_cheat then
			gui4 = gui3.add({type = "frame", name = "frame_spbook_force", direction = "vertical", style = "spbook_frame_edit_style"})
			gui4 = gui4.add({type = "flow", name = "flow_spbook_force", direction = "vertical", style = "spbook_flow_style"})
		else
			gui4 = gui3.add({type = "frame", name = "frame_spbook_force", caption = " ", direction = "vertical", style = "spbook_frame_edit_style"})
			gui4 = gui4.add({type = "flow", name = "flow_spbook_force", direction = "vertical", style = "spbook_flow_style"})
		end
	else
		gui4 = gui3.frame_spbook_force.flow_spbook_force
	end
		
	if has_rights_cheat and band(refresh,refr.forces) then
		-- force edit subwindow
		
		clean_gui(gui4)
		
		if force_sel then
			s = {"sblocc-for-title", force_sel.name}
		else
			s = ""
		end
		
		gui4.add({type = "label", caption = s, style = "spbook_label_title_style"})

		gui5 = gui4.add({type = "flow", name = "flow_spbook_for_com_stp", direction = "horizontal", style = "spbook_flow_line_style"})
		gui5.add({type = "label", name = "lab_spbook_for_spt", caption = {"sblocc-for-spt"}, style = "spbook_label_style"})
		add_button( gui5, "but_spbook_for_sps", {"sblocc-for-sps"}, rights.officer, "white", false  )
		add_button( gui5, "but_spbook_for_spg", {"sblocc-for-spg"}, rights.officer, "white", false  )

		if is_admin then
			if global.rso_ok then
				add_button( gui5, "but_spbook_for_rso", {"sblocc-for-rso"}, rights.admin, "white", false  )
			end
			gui5 = gui4.add({type = "flow", name = "flow_spbook_for_com_sta", direction = "horizontal", style = "spbook_flow_line_style"})
			gui5.add({type = "label", name = "lab_spbook_for_sta", caption = {"sblocc-for-sta"}, style = "spbook_label_style"})
			add_button( gui5, "but_spbook_for_fri", {"sblocc-for-fri"}, rights.admin, "white", false  )
			add_button( gui5, "but_spbook_for_enn", {"sblocc-for-enn"}, rights.admin, "white", false  )
			gui5 = gui4.add({type = "flow", name = "flow_spbook_for_com_res", direction = "horizontal", style = "spbook_flow_line_style"})
			gui5.add({type = "label", name = "lab_spbook_for_res", caption = {"sblocc-for-res"}, style = "spbook_label_style"})
			add_button( gui5, "but_spbook_for_rse", {"sblocc-for-rse"}, rights.admin, "white", false  )
			add_button( gui5, "but_spbook_for_rsd", {"sblocc-for-rsd"}, rights.admin, "white", false  )
			gui5 = gui4.add({type = "flow", name = "flow_spbook_for_com_tec", direction = "horizontal", style = "spbook_flow_line_style"})
			gui5.add({type = "label", name = "lab_spbook_for_tec", caption = {"sblocc-for-tec"}, style = "spbook_label_style"})
			add_button( gui5, "but_spbook_for_tca", {"sblocc-for-tca"}, rights.admin, "white", false  )
			add_button( gui5, "but_spbook_for_tcr", {"sblocc-for-tcr"}, rights.admin, "white", false  )
		end
		
		gui5 = gui4.add({type = "flow", name = "flow_spbook_for_com_kil", direction = "horizontal", style = "spbook_flow_line_style"})
		gui5.add({type = "label", name = "lab_spbook_for_cln", caption = {"sblocc-for-cln"}, style = "spbook_label_style"})
		add_button( gui5, "but_spbook_for_kip", {"sblocc-for-kip"}, rights.officer, "white", false  )
		add_button( gui5, "but_spbook_for_kia", {"sblocc-for-kia"}, rights.officer, "white", false  )
		add_button( gui5, "but_spbook_for_kib", {"sblocc-for-kib"}, rights.officer, "white", false  )
		
		if is_admin then
			gui5 = gui4.add({type = "flow", name = "flow_spbook_for_com_mrg", direction = "horizontal", style = "spbook_flow_line_style"})
			gui5.add({type = "checkbox", name = "chk_spbook_for_aut", caption = {"sblocc-for-aut"}, state = (force_sel == global.force_autojoin), style = "spbook_checkbox_style"})
			add_button( gui5, "but_spbook_for_mrg", {"sblocc-for-mrg"}, rights.admin, "white", false  )
			gui5 = gui4.add({type = "flow", name = "flow_spbook_for_com_del", direction = "horizontal", style = "spbook_flow_line_style"})
			add_button( gui5, "but_spbook_for_del", {"sblocc-for-del"}, rights.admin, "white", false  )
			color = iif( player_cur_mem.avatar == nil, "white", "grey" )
			add_button( gui5, "but_spbook_for_ava", {"sblocc-for-ava"}, rights.admin, color, false  )
		end
	end

	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	if refresh_frame then
		gui3 = gui2.add({type = "flow", name = "flow_spbook_players_all", direction = "vertical", style = "spbook_flow_style"})

	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

		gui4 = gui3.add({type = "frame", name = "frame_spbook_players", direction = "vertical", style = "spbook_frame_style"})
	else
		gui3 = gui2.flow_spbook_players_all
		gui4 = gui3.frame_spbook_players
	end
	
	if band(refresh,refr.players) then
		-- players subwindow
		
		gui5 = gui4.add({type = "flow", name = "flow_spbook_pla_arrows", direction = "horizontal", style = "spbook_flow_style"})
		-- frame_nb = gui5.add({type = "label", caption = "P...", style = "spbook_label_title_style"})
		frame_nb = gui5.add({type = "label", style = "spbook_label_title_style"})
		add_button( gui5, "but_spbook_pla_pagefirst", "[", rights.guest, "white", true )
		add_button( gui5, "but_spbook_pla_pageleft", "<", rights.guest, "white", true )
		but_pagecur = add_button( gui5, "but_spbook_pla_pagecur", "1/1", rights.guest, "white", true )
		add_button( gui5, "but_spbook_pla_pageright", ">", rights.guest, "white", true )
		add_button( gui5, "but_spbook_pla_pagelast", "]", rights.guest, "white", true )

		gui5.add({type = "label", name = "lab_spbook_pla_fil", caption = {"sblocc-pls-fil"}, style = "spbook_label_style"})
		color = iif( force_filter == nil, "white", "green" )
		add_button( gui5, "but_spbook_pla_fil_for", {"sblocc-pls-for"}, rights.guest, color, true )
		color = iif( filter_online, "green", "white" )
		add_button( gui5, "but_spbook_pla_fil_onl", {"sblocc-pls-onl"}, rights.guest, color, true )
		color = iif( filter_noban, "green", "white" )
		add_button( gui5, "but_spbook_pla_fil_nob", {"sblocc-pls-nob"}, rights.guest, color, true )
		
		gui4 = gui3.add({type = "frame", name = "frame_spbook_pla_list", direction = "vertical", style = "spbook_frame_list_style"})
		gui5 = gui4.add({type = "table", name = "table_spbook_pla_lines", colspan = 5+iif(is_admin,1,0)+iif(has_rights_cheat,2,0), style = "spbook_table_style"})
		n_col = 0
		add_column( gui5, "lab_spbook_pla_col", "" )
		add_column( gui5, "lab_spbook_pla_col", {"sblocc-pls-nam"} )
		add_column( gui5, "lab_spbook_pla_col", {"sblocc-pls-for"} )
		add_column( gui5, "lab_spbook_pla_col", {"sblocc-pls-con"} )
		add_column( gui5, "lab_spbook_pla_col", {"sblocc-pls-rig"} )
		if is_admin then add_column( gui5, "lab_spbook_pla_col", {"sblocc-pls-pwd"} ) end
		if has_rights_cheat then 
			add_column( gui5, "lab_spbook_pla_col", {"sblocc-pls-shi"} )
			add_column( gui5, "lab_spbook_pla_col", {"sblocc-pls-pos"} )
		end

		local players_filtered = {}
		
		i = 1
		
		for _, player in pairs(game.players) do
			player_mem = global.player_mem[player.index]
			
			if (force_filter == nil or player.force == force_filter) and (player.connected or not filter_online) and (player_mem.rights > rights.banned or not filter_noban) then
				table.insert(players_filtered,player)
				
				if look_player_sel then
					if i == n_player_sel then
						player_cur_mem.player_sel = player
						player_sel = player
					end
				elseif look_n_player_sel then
					if player == player_sel then
						player_cur_mem.n_player_sel = i
						n_player_sel = i
					end
				end

				i = i + 1
			end
		end
		
		player_cur_mem.nb_players = #players_filtered
		player_cur_mem.players_page_max = math.max(1,1 + math.floor( (player_cur_mem.nb_players-1) / lines_per_page ))
		if player_cur_mem.players_page_cur > player_cur_mem.players_page_max then
			player_cur_mem.players_page_cur = player_cur_mem.players_page_max
		end
		but_pagecur.caption = player_cur_mem.players_page_cur .. "/" .. player_cur_mem.players_page_max 
		frame_nb.caption = {"sblocc-pls-title", #players_filtered}

		i = 1
		i1 = 1 + (player_cur_mem.players_page_cur-1) * lines_per_page
		i2 = player_cur_mem.players_page_cur * lines_per_page
		
		if #players_filtered ==  0 then
			gui5.add({type = "checkbox", name = "chk_spbook_pla_0sel", state = false, style = "spbook_checkbox_style"})
			add_button( gui5, "but_spbook_pla_0nam", "---", rights.guest, "white", true, true )
			add_button( gui5, "but_spbook_pla_0for", "---", rights.guest, "white", true, true )
			gui5.add({type = "sprite-button", name = "but_spbook_pla_0con", sprite = "sprite_spbook_deco", style = "spbook_sprite_icon_style"})
			gui6 = gui5.add({type = "label", name = "lab_spbook_pla_0rig", caption = rights[rights.guest].name, style = "spbook_label_center_style"})
			gui6.style.minimal_width = 50
			gui6.style.font_color = rights[rights.guest].color

			if is_admin then
				s = {"sblocc-pls-pwe"} 
				color = colors.red
				gui6 = gui5.add({type = "label", name = "lab_spbook_pla_0pwd", caption = s, style = "spbook_label_center_style"})
				gui6.style.minimal_width = 40
				gui6.style.font_color = color
			end
					
			if has_rights_cheat then
				gui5.add({type = "sprite-button", name = "but_spbook_pla_0shi", sprite = "sprite_spbook_shd_deco", style = "spbook_sprite_icon_style"})
				gui5.add({type = "button", name = "but_spbook_pla_0pxy", caption = "0,0", style = "spbook_button_xy_style"})
			end
		else
			for _, player in pairs(players_filtered) do
				if i <= i2 and i >= i1 then
					player_mem = global.player_mem[player.index]
					
					gui5.add({type = "checkbox", name = "chk_spbook_pla_sel" .. i, state = (player_sel == player), style = "spbook_checkbox_style"})
				
					if player_cur == player then
						color = "green"
					elseif player.connected then
						color = "white"
					else
						color = "lightgrey" 
					end
					gui6 = add_button( gui5, "but_spbook_pla_nam" .. i, player.name, rights.guest, color, true, true )
					
					gui6 = add_button( gui5, "but_spbook_pla_for" .. i, player.force.name, rights.guest, "white", true, true )

					if player.connected then
						s = "sprite_spbook_conn"
					else
						s = "sprite_spbook_deco"
					end
					
					gui6 = gui5.add({type = "sprite-button", name = "but_spbook_pla_con" .. i, sprite = s, style = "spbook_sprite_icon_style"})

					gui6 = gui5.add({type = "label", name = "lab_spbook_pla_rig" .. i, caption = rights[player_mem.rights].name, style = "spbook_label_center_style"})
					gui6.style.minimal_width = 50
					gui6.style.font_color = rights[player_mem.rights].color

					if is_admin then
						if player_mem.pwd_hash == "" then
							s = {"sblocc-pls-pwe"} 
							color = colors.red
						else
							s = {"sblocc-pls-pwk"} 
							color = colors.green
						end
						gui6 = gui5.add({type = "label", name = "lab_spbook_pla_pwd" .. i, caption = s, style = "spbook_label_center_style"})
						gui6.style.minimal_width = 40
						gui6.style.font_color = color
					end
					
					if has_rights_cheat then
						if player.connected then
							if player_mem.avatar == nil then
								if player.character and player.character.destructible then
									s = "sprite_spbook_shd_off"
								else 
									s = "sprite_spbook_shd_on"
								end
							else
								if player_mem.character_destructible then
									s = "sprite_spbook_shd_off"
								else 
									s = "sprite_spbook_shd_on"
								end
							end
						else
							s = "sprite_spbook_shd_deco"
						end
						gui6 = gui5.add({type = "sprite-button", name = "but_spbook_pla_shi" .. i, sprite = s, style = "spbook_sprite_icon_style"})

						gui6 = gui5.add({type = "button", name = "but_spbook_pla_pxy" .. i, caption = player_position(player), style = "spbook_button_xy_style"})
					end
				end
				i=i+1
			end
		end
	end

	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 

	if refresh_frame then
		if player_sel then
			s = {"sblocc-pla-title", player_sel.name, player_sel.force.name}
		else
			s = {"sblocc-pla-title", "...", "..."}
		end
		gui4 = gui3.add({type = "frame", name = "frame_spbook_player", direction = "vertical", style = "spbook_frame_edit_style"})
		gui4 = gui4.add({type = "flow", name = "flow_spbook_player", direction = "vertical", style = "spbook_flow_style"})
	else
		gui4 = gui3.frame_spbook_player.flow_spbook_player
	end
	
	if band(refresh,refr.players) then
		-- player edit subwindow
		
		gui4.add({type = "label", caption = s, style = "spbook_label_title_style"})
		
		if player_sel then
			player_mem = global.player_mem[player_sel.index]
			
			if has_rights then
				gui5 = gui4.add({type = "flow", name = "flow_spbook_pla_com_for", direction = "horizontal", style = "spbook_flow_line_style"})
				gui5.add({type = "label", name = "lab_spbook_pla_for", caption = {"sblocc-pla-for"}, style = "spbook_label_style"})
				if is_admin then
					add_button( gui5, "but_spbook_pla_joi", {"sblocc-pla-jos"} , rights.admin )
				else
					add_button( gui5, "but_spbook_pla_joi", {"sblocc-pla-joo"}, rights.officer )
				end
				add_button( gui5, "but_spbook_pla_kic", {"sblocc-pla-kic"} , rights.officer )
			end
			
			gui5 = gui4.add({type = "flow", name = "flow_spbook_pla_com_rig", direction = "horizontal", style = "spbook_flow_line_style"})
			gui5.add({type = "label", name = "lab_spbook_pla_rig", caption = {"sblocc-pla-rig"} , style = "spbook_label_style"})
			gui6 = gui5.add({type = "label", name = "lab_spbook_pla_rig" .. i, caption = rights[player_mem.rights].name, style = "spbook_label_center_style"})
			gui6.style.minimal_width = 50
			gui6.style.font_color = rights[player_mem.rights].color
			
			if has_rights then
				add_button( gui5, "but_spbook_pla_rim", " - ", rights.officer )
				add_button( gui5, "but_spbook_pla_rip", " + ", rights.officer )
			end
			
			if player_mem.promoter then
				s = player_mem.promoter.name
			else
				s = "SYSTEM"
			end
			gui5.add({type = "label", name = "lab_spbook_pla_pro", caption = {"sblocc-pla-pro", s}, style = "spbook_label_style"})

			if has_rights_cheat then		
				gui5 = gui4.add({type = "flow", name = "flow_spbook_pla_com_pos", direction = "horizontal", style = "spbook_flow_line_style"})
				gui5.add({type = "label", name = "lab_spbook_pla_pos", caption = {"sblocc-pla-pos"}, style = "spbook_label_style"})
				gui5.add({type = "button", name = "but_spbook_pla_pos", caption = player_position(player_sel), style = "spbook_button_xy_style"})
				gui5.add({type = "label", name = "lab_spbook_pla_tel", caption = {"sblocc-pla-tel"} , style = "spbook_label_style"})
				add_button( gui5, "but_spbook_pla_tls", {"sblocc-pla-tls"}, rights.officer )
				add_button( gui5, "but_spbook_pla_tly", {"sblocc-pla-tly"}, rights.officer )
			end
			
			if has_rights_cheat then
				gui5 = gui4.add({type = "flow", name = "flow_spbook_pla_com_lif", direction = "horizontal", style = "spbook_flow_line_style"})
				gui5.add({type = "label", name = "lab_spbook_pla_lif", caption = {"sblocc-pla-lif"}, style = "spbook_label_style"})
				add_button( gui5, "but_spbook_pla_kil", {"sblocc-pla-kil"}, rights.officer )
				
				if is_admin then
					if player_sel.connected then
						if player_mem.avatar == nil then
							if player_sel.character and player_sel.character.destructible then
								s = "sprite_spbook_shd_off"
							else 
								s = "sprite_spbook_shd_on"
							end
						else
							if player_mem.character_destructible then
								s = "sprite_spbook_shd_off"
							else 
								s = "sprite_spbook_shd_on"
							end
						end
					else
						s = "sprite_spbook_shd_deco"
					end
					gui6 = gui5.add({type = "sprite-button", name = "but_spbook_pla_shi", sprite = s, style = "spbook_sprite_icon_style"})
					add_button( gui5, "but_spbook_pla_shs", {"sblocc-pla-shs"}, rights.admin )
				end
			end

			if has_rights then
				gui5 = gui4.add({type = "flow", name = "flow_spbook_pla_com_del", direction = "horizontal", style = "spbook_flow_line_style"})
				add_button( gui5, "but_spbook_pla_del", {"sblocc-pla-del"}, rights.officer  )
				add_button( gui5, "but_spbook_pla_pwd", {"sblocc-pla-pwd"}, rights.officer  )
			end
		else
			gui4.add({type = "label", name = "lab_spbook_pla_empty", caption = {"sblocc-pla-emp"} , style = "spbook_label_style"})
		end
	end

	-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
	
	if refresh_frame then
		gui2 = gui1.add({type = "frame", name = "frame_spbook_info", direction = "vertical", style = "spbook_frame_style"})
		gui3 = gui2.add({type = "flow", name = "flow_spbook_info", direction = "horizontal", style = "spbook_flow_style"})
	else
		gui3 = gui1.frame_spbook_info.flow_spbook_info
	end

	if band(refresh,refr.info) then
		-- info subwindow
		
		style = infos[player_cur_mem.info_info].style
		color = infos[player_cur_mem.info_info].color
		player_cur_mem.info_gui_icon = gui3.add({type = "sprite-button", name = "but_spbook_info", sprite = "sprite_spbook_info_none", style = "spbook_sprite_icon_style"})
		gui4 = gui3.add({type = "label", name = "lab_spbook_info", caption = player_cur_mem.info_text, style = "spbook_label_center_style"})
		gui4.style.font_color = color
		player_cur_mem.info_gui_text = gui4
	end
	
	return(true)
end

--------------------------------------------------------------------------------------
local function update_windows(refresh,update_bar_too)
	local cancel
	
	for _, player in pairs(game.players) do
		if player.connected then
			local player_mem = global.player_mem[player.index]
			
			if player.gui.left.frame_spbook then
				if player_mem.confirm_but ~= nil then
					player_mem.confirm_but.style.font_color = player_mem.confirm_color
					player_mem.confirm_but = nil
					player_mem.confirm_tick = 0
					cancel = true
				else
					cancel = false
				end
				
				update_window(player,refresh)
				
				if cancel then
					info(player, player_mem, {"sbloci-act-cancel"} , infos.error )
				end
			end
			
			if update_bar_too then
				update_main_bar(player,player_mem)
			end			
		end
	end
end

--------------------------------------------------------------------------------------
function info( player, player_mem, s, type, update, console )
	player_mem.info_text = s
	player_mem.info_info = type
	
	if type ~= infos.confirm then
		player_mem.info_tick = game.tick + 60 * info_timeout
	else
		player_mem.info_tick = 0
	end
		
	if player.gui.left.frame_spbook then
		local sprite, color, gui_ok
		update = update or false
		
		sprite = infos[type].sprite
		color = infos[type].color
	
		if update or player_mem.info_gui_icon == nil or player_mem.info_gui_text == nil then
			update_window( player, refr.all_inside )
		end
	
		if player_mem.info_gui_icon then
			player_mem.info_gui_icon.sprite = sprite
		end
		
		if player_mem.info_gui_text then
			player_mem.info_gui_text.caption = s
			player_mem.info_gui_text.style.font_color = color
		end

		if console == infos.duplic then
			player.print(s)
		elseif console == infos.all then
			for _, player2 in pairs(game.players) do
				if player2.connected and player2 ~= player then player.print(s) end
			end
		end
	else
		if s ~= "" then	player.print(s) end
	end
end

--------------------------------------------------------------------------------------
local function ask_password(player, player_mem, force_new_pwd)
	local guif = player.gui.center.frame_spbook_pwd
	-- if guif then guif.destroy()	end
	if guif then 
		return 
	end
	
	if player_mem.pwd_hash == "" then force_new_pwd = true end
	
	local action = iif( force_new_pwd, {"sblocc-pwd-new"},{"sblocc-pwd-verify"} )
	
	player_mem.pwd_tick = game.tick + 60 * (password_timeout)
	
	guif = player.gui.center.add({type = "frame", name = "frame_spbook_pwd", caption = {"sblocc-pwd-window"}, direction = "horizontal", style = "spbook_frame_style"})
	guif = guif.add({type = "flow", name = "flow_spbook_pwd", direction = "horizontal", style = "spbook_flow_style"})
	guif.add({type = "sprite-button", name = "but_spbook_pwd_log", sprite = "sprite_spbook_main", style = "spbook_sprite_main_style"})	
	local gui1 = guif.add({type = "flow", name = "flow_spbook_pwds", direction = "vertical", style = "spbook_flow_style"})
	local gui2, gui3
	if force_new_pwd and player_mem.pwd_hash ~= "" then
		gui2 = gui1.add({type = "flow", name = "flow_spbook_old", direction = "horizontal", style = "spbook_flow_style"})
		gui3 = gui2.add({type = "label", name = "lab_spbook_old", caption = {"sblocc-pwd-old"}, style = "spbook_label_style"})
		gui3.style.minimal_width = 100
		player_mem.pwd_gui_old = gui2.add({type = "textfield", name = "textfield_spbook_old", text = "", style = "spbook_textfield_style"})
	end
	gui2 = gui1.add({type = "flow", name = "flow_spbook_new", direction = "horizontal", style = "spbook_flow_style"})
	gui3 = gui2.add({type = "label", name = "lab_spbook_new", caption = action, style = "spbook_label_style"})
	gui3.style.minimal_width = 100
	player_mem.pwd_gui_new = gui2.add({type = "textfield", name = "textfield_spbook_new", text = "", style = "spbook_textfield_style"})
	
	gui2.add({type = "button", name = "but_spbook_pwd_ok", caption = {"sblocc-ok"}, style = "spbook_button_style"})
	gui2.add({type = "button", name = "but_spbook_pwd_cancel", caption = {"sblocc-cancel"}, style = "spbook_button_style"})
end

--------------------------------------------------------------------------------------
local function get_random_pwd()	
	math.randomseed( game.tick )
	return( "factorio" .. math.random(1000,9999) )
end

--------------------------------------------------------------------------------------
local function show_new_force(player, force)
	local guif = player.gui.center.frame_spbook_for_new
	local player_mem = global.player_mem[player.index]
	
	if guif == nil then
		guif = player.gui.center.add({type = "frame", name = "frame_spbook_for_new", caption = {"sblocc-fos-new"}, direction = "horizontal", style = "spbook_frame_style"})
		guif.add({type = "label", name = "lab_spbook_for_new", caption = {"sblocc-fos-na2"}, style = "spbook_label_style"})
		guif.add({type = "textfield", name = "textfield_spbook_for_new", text = player_mem.new_force_name, style = "spbook_textfield_style"})
		guif.add({type = "button", name = "but_spbook_for_new_erase", caption = "X", style = "spbook_button_style"})
		guif.add({type = "button", name = "but_spbook_for_new_ok", caption = {"sblocc-ok"}, style = "spbook_button_style"})
		guif.add({type = "button", name = "but_spbook_for_new_cancel", caption = {"sblocc-cancel"}, style = "spbook_button_style"})
	end
	
	player_mem.new_force_gui = guif
end

--------------------------------------------------------------------------------------
local function show_color_picker(player)
	local guif = player.gui.center.frame_spbook_colors
	
	if guif == nil then
		guif = player.gui.center.add({type = "frame", name = "frame_spbook_colors", caption = {"sblocc-col-title"}, direction = "horizontal", style = "spbook_frame_style"})
		for k, col in pairs(colors) do
			local but = guif.add({type = "button", name = "but_spbook_col_sel" .. k , caption = "@", style = "spbook_button_style"})
			but.style.font_color = col
		end
		guif.add({type = "button", name = "but_spbook_col_close", caption = {"sblocc-close"}, style = "spbook_button_style"})
	end
end

--------------------------------------------------------------------------------------
local function show_scanner(player, player_mem)
	local gui1 = player.gui.left.frame_spbook_scanner
	
	if gui1 == nil then
		local is_admin = (player_mem.rights >= rights.admin)
		local gui2, gui3
		
		player_mem.selected = nil
		
		gui1 = player.gui.left.add({type = "frame", name = "frame_spbook_scanner", caption = {"sblocc-sca-title"}, direction = "vertical", style = "spbook_frame_style"})
		gui1 = gui1.add({type = "flow", name = "flow_spbook_scanner", direction = "vertical", style = "spbook_flow_style"})
		gui1.add({type = "label", name = "lab_spbook_sca_hlp", caption = {"sblocc-sca-hlp"}, style = "spbook_label_style"})
		player_mem.scanner_typ_gui = gui1.add({type = "label", name = "lab_spbook_sca_typ", caption = {"sblocc-sca-typ",""}, style = "spbook_label_style"})
		
		gui2 = gui1.add({type = "flow", name = "flow_spbook_sca_nam", direction = "horizontal", style = "spbook_flow_style"})
		gui2.add({type = "label", name = "lab_spbook_sca_nam", caption = {"sblocc-sca-nam"}, style = "spbook_label_style"})
		gui3 = gui2.add({type = "textfield", name = "txt_spbook_sca_nam", text = "", style = "spbook_textfield_style"})
		gui3.style.minimal_width = 150
		player_mem.scanner_nam_gui = gui3
		if is_admin then
			gui2.add({type = "button", name = "but_spbook_sca_ren", caption = {"sblocc-sca-ren"}, style = "spbook_button_style"})
		end
		
		gui2 = gui1.add({type = "flow", name = "flow_spbook_sca_for", direction = "horizontal", style = "spbook_flow_style"})
		player_mem.scanner_for_gui = gui2.add({type = "label", name = "lab_spbook_sca_for", caption = {"sblocc-sca-for",""}, style = "spbook_label_style"})
		if is_admin then
			gui2.add({type = "button", name = "but_spbook_sca_for", caption = {"sblocc-sca-fos"}, style = "spbook_button_style"})
		end
		
		gui1.add({type = "button", name = "but_spbook_sca_close", caption = {"sblocc-close"}, style = "spbook_button_style"})
	end
end

--------------------------------------------------------------------------------------
local function show_tools(player, player_mem)
	local gui1 = player.gui.left.frame_spbook_tools
	
	if gui1 == nil then
		local gui2, gui3
		
		gui1 = player.gui.left.add({type = "frame", name = "frame_spbook_tools", caption = {"sblocc-too-title"}, direction = "vertical", style = "spbook_frame_style"})
		gui1 = gui1.add({type = "flow", name = "flow_spbook_tools", direction = "vertical", style = "spbook_flow_style"})
		
		gui2 = gui1.add({type = "flow", direction = "horizontal", style = "spbook_flow_style"})
		gui2.add({type = "label", name = "lab_spbook_too_current", caption = {"sblocc-too-current"}, style = "spbook_label_style"})
		player_mem.but_spbook_too_cur = gui2.add({type = "sprite-button", name = "but_spbook_too_cur" , sprite = "", tooltip = "", style = "spbook_sprite_main_style"})	

		gui2 = gui1.add({type = "flow", direction = "horizontal", style = "spbook_flow_style"})
		gui2.add({type = "sprite-button", name = "but_spbook_too_delresources", sprite = "sprite_spbook_too_delresources", tooltip = {"sblocc-too-tt-delresources"}, style = "spbook_sprite_main_style"})	
		gui2.add({type = "sprite-button", name = "but_spbook_too_deltrees", sprite = "sprite_spbook_too_deltrees", tooltip = {"sblocc-too-tt-deltrees"}, style = "spbook_sprite_main_style"})	
		gui2.add({type = "sprite-button", name = "but_spbook_too_killaliens", sprite = "sprite_spbook_too_killaliens", tooltip = {"sblocc-too-tt-killaliens"}, style = "spbook_sprite_main_style"})	
		
		local n = 0
		
		for name, proto in pairs(global.resources_solid) do
			if n == 0 then
				gui2 = gui1.add({type = "flow", direction = "horizontal", style = "spbook_flow_style"})
				n = 5
			end
			gui2.add({type = "sprite-button", name = "but_spbook_too_ore" .. name, sprite = "item/" .. name, tooltip = proto.localised_name, style = "spbook_sprite_main_style"})	
			n = n - 1
		end
		
		for name, proto in pairs(global.resources_fluid) do
			if n == 0 then
				gui2 = gui1.add({type = "flow", direction = "horizontal", style = "spbook_flow_style"})
				n = 5
			end
			gui2.add({type = "sprite-button", name = "but_spbook_too_flu" .. name, sprite = "fluid/" .. name, tooltip = proto.localised_name, style = "spbook_sprite_main_style"})	
			n = n - 1
		end
	end
end

--------------------------------------------------------------------------------------
local function find_force(n)
	local i = 1
	for _, force in pairs(game.forces) do
		if i == n then 
			return( force )
		end
		i=i+1
	end
	return(nil)
end

--------------------------------------------------------------------------------------
local function find_n_force(force_find)
	local i = 1
	for _, force in pairs(game.forces) do
		if force == force_find then 
			return( i )
		end
		i=i+1
	end
	return(0)
end

--------------------------------------------------------------------------------------
local function update_nb_players_force()
	for _, force in pairs(game.forces) do
		global.nb_players_force[force.name] = 0
	end
	
	for _, player in pairs(game.players) do
		local force = player.force
		local nb = global.nb_players_force[force.name]
		if nb == nil then
			global.nb_players_force[force.name] = 1
		else
			global.nb_players_force[force.name] = nb+1
		end
	end
end

--------------------------------------------------------------------------------------
local function guests_force_peace()
	local guests_force = global.force_guests
	
	if guests_force ~= nil then
		for _, force in pairs(game.forces) do
			if force == game.forces.enemy then
				force.set_cease_fire(guests_force.name, false)
				guests_force.set_cease_fire(force.name, false)
			else
				force.set_cease_fire(guests_force.name, true)
				guests_force.set_cease_fire(force.name, true)
			end
		end
	end
end
	
--------------------------------------------------------------------------------------
local function force_stances_all(force, friend_or_enemy)
	for _, force2 in pairs(game.forces) do
		if force2 == game.forces.enemy then
			force.set_cease_fire(force2.name, false)
			force2.set_cease_fire(force.name, false)
		else
			force.set_cease_fire(force2.name, friend_or_enemy)
			force2.set_cease_fire(force.name, friend_or_enemy)
		end
	end
end
	
--------------------------------------------------------------------------------------
local function kill_all_players(force)
	local nb = 0
	
	for _, player in pairs(game.players) do
		local player_mem = global.player_mem[player.index]
		if player.connected and player.character and player.character.valid and (force == nil or player.force == force) and (player_mem.avatar == nil) then
			player.character.die()
			nb = nb + 1
		end
	end
	
	return( nb )
end

--------------------------------------------------------------------------------------
local function players_uncheat()
	for _, player in pairs(game.players) do
		local player_mem = global.player_mem[player.index]
		
		if player.connected and player.character and player.character.valid then
			if 	player_mem.avatar ~= nil then
				player_mem.avatar = player.character -- get a valid version in case of intermediary deco/reco
				player.force = player_mem.force
				player.character = player_mem.character
				if player_mem.avatar and player_mem.avatar.valid then
					player_mem.avatar.destroy()
				end
				player_mem.avatar = nil
				update_main_bar(player,player_mem)
			end
			player.character.destructible = true
		end
	end
end

--------------------------------------------------------------------------------------
local function destroy_all_buildings(force)
	local nb = 0
	
	for _, surf in pairs(game.surfaces) do
		for chunk in surf.get_chunks() do
			local area = {{chunk.x * 32, chunk.y * 32}, {chunk.x * 32 + 32, chunk.y * 32 + 32}}
			if force then
				local ents = surf.find_entities_filtered({area=area, force=force})
				for _, ent in pairs(ents) do
					if ent.name ~= "player" and ent.type ~= "unit" then
						ent.destroy()
					end
					nb = nb + 1
				end
			else
				local ents = surf.find_entities(area)
				for _, ent in pairs(ents) do
					if ent.name ~= "player" and ent.type ~= "unit" and ent.force ~= game.forces.neutral then -- neutral are resources, trees, rocks, etc...
						ent.destroy()
					end
					nb = nb + 1
				end
			end
				
		end
	end
	
	return( nb )
end

--------------------------------------------------------------------------------------
local function debug_forces_and_players()
	for i,force in pairs(game.forces) do
		debug_print( "force(", i, ")=", force.name )
	end
	for i,player in pairs(game.players) do
		debug_print( "player(", i, ")=", player.name, " rights=", global.player_mem[player.index].rights )
	end
end

--------------------------------------------------------------------------------------
local function debug_error(err)
	local s = "SpaceBook / ERROR : [" .. err .. "]. Please transmit the message and a eventual screencopy to the mod developper BinbinHfr on the Factorio forum. Thanks."
	-- message_force( s )
	-- global.mod_enabled = false
	-- global.error = true
	-- close_all_windows()
	-- script.on_event(defines.events.on_tick, nil )
	-- script.on_event(defines.events.on_player_created, nil )
	-- script.on_event(defines.events.on_gui_click, nil )
	-- if debug_status then error( err ) end -- call the normal error handler that stops the game
	-- error( err ) -- call the normal error handler that stops the game
	error( s ) -- call the normal error handler that stops the game
end

--------------------------------------------------------------------------------------
local function init_globals()
	-- initialize or update general globals of the mod
	debug_print( "init_globals " )

	global.ticks = global.ticks or 0
	global.bigticks = global.bigticks or 0
	
	if global.noOwnerYet == nil then global.noOwnerYet = true end
	global.player_mem = global.player_mem or {}
	global.nb_players_force = global.nb_players_force or {}
	if global.frozen == nil then global.frozen = false end
	global.timetools = remote.interfaces.timetools
	if global.mod_enabled == nil then global.mod_enabled = true end
	if global.cheats_enabled == nil then global.cheats_enabled = true end
	if global.pwd_enabled == nil then global.pwd_enabled = false end
	-- if global.pwd_enabled == nil then global.pwd_enabled = (debug_status == nil) end
	global.force_autojoin = global.force_autojoin or nil -- eventual force to autojoin a player if no admin is connected
	global.error = false
	
	-- game.surfaces.nauvis.peaceful_mode = true
	
	global.force_guests = global.force_guests or (game.forces[guest_force_name] or game.create_force( guest_force_name ))
	global.force_guests.disable_research() 
	global.force_guests.quickbar_count = 4  -- not to lose items during force quit 	
	global.force_guests.character_inventory_slots_bonus = 100 -- not to lose items during force quit 	
	guests_force_peace()
	
	if global.rso_ok == nil then global.rso_ok = false end
	
	global.resources_solid = {}
	global.resources_fluid = {}
	
	for name, ent in pairs(game.entity_prototypes) do
		if ent.type == "resource" then 
			local min_prop = ent.mineable_properties
			if min_prop.minable then 
				for _, prod in pairs(min_prop.products) do
					local proto = game.fluid_prototypes[prod.name]
					if proto == nil then
						-- proto = game.item_prototypes[prod.name]
						proto = game.entity_prototypes[name]
						if proto then
							global.resources_solid[prod.name] = proto
						end
					else
						proto = game.entity_prototypes[name]
						if proto then
							global.resources_fluid[prod.name] = proto
						end
					end
				end
			end
		end
	end
end

--------------------------------------------------------------------------------------
local function init_player(player)
	if global.player_mem == nil then return end
	
	local player_mem
	
	debug_print( "init_player ", player.name, " connected=", player.connected )
	
	local is_new = (global.player_mem[player.index] == nil) -- used later to finalize initialisation of player, because player not always updated in player-create... (bug reported)
	if is_new then global.player_mem[player.index] = {} end
	player_mem = global.player_mem[player.index]
	player_mem.is_new = is_new
		
	player_mem.authen = not global.pwd_enabled  -- reset authentication if conn or deco -- no authentication if pwd disabled
	player_mem.rights = player_mem.rights or rights.guest
	player_mem.promoter = player_mem.promoter or nil  -- who made the last rights change
	
	player_mem.pwd_hash = player_mem.pwd_hash or ""
	player_mem.pwd_tick = 1
	player_mem.pwd_gui_old = nil
	player_mem.pwd_gui_new = nil
	
	player_mem.avatar = player_mem.avatar or nil -- avatar to fly on the map, managing things
	player_mem.character = player_mem.character or nil -- to memorize character before flying
	player_mem.character_destructible = player_mem.character_destructible or true -- memorize character destructible status
	player_mem.force = player_mem.force or nil -- used to memorize force before going avatar, to allow avatar force change
	
	player_mem.forces_per_page = lines_per_page
	player_mem.forces_page_cur = 1
	player_mem.forces_page_max = 1
	player_mem.nb_forces = 1

	player_mem.n_force_sel = 1
	player_mem.force_sel = game.forces.player

	player_mem.players_per_page = lines_per_page
	player_mem.players_page_cur = 1
	player_mem.players_page_max = 1
	player_mem.nb_players = 0
	
	player_mem.n_player_sel = 0
	player_mem.player_sel = nil
	
	player_mem.force_filter = nil
	player_mem.filter_online = false
	player_mem.filter_noban = false
	
	player_mem.confirm_but = nil -- button gui to confirm
	player_mem.confirm_color = colors.white -- color before click
	player_mem.confirm_tick = 0 -- tick to timeout
	
	player_mem.info_gui_text = nil
	player_mem.info_gui_icon = nil
	player_mem.info_text = ""
	player_mem.info_info = infos.none
	player_mem.info_tick = 1 -- to clear info at next timeout

	player_mem.gui_new_force = nil
	player_mem.new_force_name = player_mem.new_force_name or "New"

	player_mem.scanner_typ_gui = player_mem.scanner_typ_gui or nil -- scanner gui if opened
	player_mem.scanner_nam_gui = player_mem.scanner_nam_gui or nil 
	player_mem.scanner_for_gui = player_mem.scanner_for_gui or nil
	player_mem.selected = player_mem.selected or nil -- scanner selection
	
	player_mem.last_tp = player_mem.last_tp or nil
	
	player_mem.autojoin_tick = game.tick + 60 * autojoin_delay

	-- the player is often not connected in this call !  (can make a crash, bug reported)
	
	if player.connected then
		if is_new then  -- affect to guest, unless already in a force (already existing game ?) or autopvp installed 
			if player.force == game.forces.player and not game.item_prototypes["soul-1"] then
				player.force = global.force_guests 
				player_mem.force = player.force
			else
				player_mem.rights = rights.engineer
				player_mem.promoter = nil
			end
		end
							
		-- look for a new owner of the map
		if global.noOwnerYet and player_mem.rights < rights.owner then
			player.print( {"sbloci-you-owner"} )
			player_mem.rights = rights.owner
			player_mem.promoter = nil
			global.noOwnerYet = false
			update_main_bar(player,player_mem)
			update_nb_players_force()
			update_windows(refr.all_inside)
		end
							
		if global.force_autojoin ~= nil and player_mem.rights == rights.guest then
			player.print( {"sbloci-pla-autowarn", global.force_autojoin.name, autojoin_delay} )
		end
		
		update_nb_players_force()
		update_windows(refr.all_inside)

		if player.gui.top.but_spbook then player.gui.top.but_spbook.destroy() end -- old button
		if player.gui.top.but_spbook_main then player.gui.top.but_spbook_main.destroy() end -- old button
	
		update_main_bar( player, player_mem )
		
		close_windows( player, false ) -- close windows in case of config change, to refresh them
	
		local character = player.character
		
		if player_mem.authen then
			if character and character.valid then character.active = true end
		else
			if character and character.valid then character.active = false end
			close_windows(player, true)
			ask_password(player, player_mem, false)
		end
	end
end

--------------------------------------------------------------------------------------
local function init_players()
	for _, player in pairs(game.players) do
		init_player(player)
	end
end

--------------------------------------------------------------------------------------
local function on_init() 
	-- called once, the first time the mod is loaded on a game (new or existing game)
	debug_print( "on_init" )
	init_globals()
	init_players()
end

script.on_init(on_init)

--------------------------------------------------------------------------------------
local function on_configuration_changed(data)
	-- detect any mod or game version change
	if data.mod_changes ~= nil then
		close_all_windows() -- precaution...
			
		local changes = data.mod_changes[debug_mod_name]
		if changes ~= nil then
			debug_print( "update mod: ", debug_mod_name, " ", tostring(changes.old_version), " to ", tostring(changes.new_version) )
			

			-- migrate old global
			if global.players_mem ~= nil then
				global.player_mem = table.deepcopy(global.players_mem)
				global.players_mem = nil
			end
			
			if changes.old_version and older_version(changes.old_version, "1.0.13") then
				debug_print( "migration" )
				for _, player in pairs(game.players) do
					if player.gui.top.flow_spbook_main then
						player.gui.top.flow_spbook_main.destroy()
					end
				end
			end
			
			init_globals()
			init_players() 
		end
		
		global.rso_ok = (remote.interfaces["RSO"] and remote.interfaces["RSO"]["addStartLocation"] == true)
	end
end

script.on_configuration_changed(on_configuration_changed)

--------------------------------------------------------------------------------------
local function on_force_created(event)
	-- called at player creation
	local force = event.force
	debug_print( "on_force_created ", force.name )
	
	if global.ticks ~= nil then -- in case another mod creates a force before spacebook initialisation
		guests_force_peace()
		update_windows(refr.all)
	end
end

script.on_event(defines.events.on_force_created, on_force_created )

--------------------------------------------------------------------------------------
local function on_forces_merging(event)
	-- called at player creation
	local source = event.source
	local destination = event.destination
	debug_print( "force merging ", source.name, " into ", destination.name )

	if global.ticks ~= nil then -- in case another mod creates a force before spacebook initialisation
		update_windows(refr.all)
	end
end

script.on_event(defines.events.on_forces_merging, on_forces_merging )

--------------------------------------------------------------------------------------
local function on_player_created(event)
	-- called where new player is created
	-- local player = game.players[event.player_index] -- this one contains an old player !!! bug reported
	local player = game.players[event.player_index]
	debug_print( "on_player_created ", player.name, " connected=", player.connected )
	
	init_player(player)
	update_nb_players_force()
end

script.on_event(defines.events.on_player_created, on_player_created )

--------------------------------------------------------------------------------------
local function on_player_joined_game(event)
	local player = game.players[event.player_index]
	debug_print( "player joined ", player.name )
	
	init_player(player)
end

script.on_event(defines.events.on_player_joined_game, on_player_joined_game )

--------------------------------------------------------------------------------------
local function on_player_died(event)
	local player = game.players[event.player_index]
	debug_print( "player died ", player.name )
end

script.on_event(defines.events.on_player_died, on_player_died )

--------------------------------------------------------------------------------------
local function on_player_left_game(event)
	local player = game.players[event.player_index]
	debug_print( "player left ", player.name )
	
	update_nb_players_force()
	update_windows(refr.all_inside)
end

script.on_event(defines.events.on_player_left_game, on_player_left_game )

--------------------------------------------------------------------------------------
local function on_tick(event)
	if global.ticks > 44 then
		global.ticks = 0
		global.bigticks = global.bigticks + 1	
		local modulo = global.bigticks % 3
		
		--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --
		if modulo == 1 then
			-- manage players late init, empty passwords, autojoin and banneds
			local refresh = false
			
			for _, player in pairs(game.players) do
				local player_mem = global.player_mem[player.index]
				
				if player.connected then
					-- test for newly initialized players that finally connects (on_init & on_config does not guaranty connexion of players at the moment
					-- and even pointing to a valid player, because game.players is not correctly updated at the moment, only get_player works.)
					if player_mem.is_new then
						player.force = global.force_guests
						player.color = colors.lightgrey 
						player_mem.is_new = false
						refresh = true
					end
			
					-- warn empty password
					if global.pwd_enabled and player_mem.pwd_hash == "" and player_mem.pwd_gui_new == nil and game.tick > player_mem.pwd_tick then
						info(player, player_mem, {"sbloci-empty-pwd"}, infos.error, false, infos.duplic )
						ask_password(player, player_mem, true)
						player_mem.pwd_tick = game.tick + 60 * (password_timeout) 
					end
					
					-- inactivate banned players (for those who were banned while deco...)
					if player_mem.rights == rights.banned then
						if player_mem.info_tick == 0 then player_mem.info_tick = 1 end -- start repeted messages on timeout
						local character = player.character
						if character and character.valid and player_mem.rights == rights.banned and player.character.active then
							player.character.active = false 
							--player.character.die() 
						end
					end
					
					-- autojoin player into autojoin force
					if global.force_autojoin ~= nil and player_mem.rights == rights.guest and player_mem.autojoin_tick > 0 and game.tick > player_mem.autojoin_tick then
						if global.force_autojoin.valid then
							player.force = global.force_autojoin
							player_mem.rights = rights.engineer
							player_mem.promoter = nil
							player_mem.autojoin_tick = 0
							message_all({"sbloci-pla-autojoin", player.name,global.force_autojoin.name})
							refresh = true
						else
							global.force_autojoin = nil
						end
					end
				end
			end
			
			if refresh then
				update_nb_players_force()
				update_windows(refr.all_inside)
			end
			
		--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --
		elseif modulo == 2 then
			-- manage display timeouts & scanner
			for _, player in pairs(game.players) do
				local player_mem = global.player_mem[player.index]
				
				-- reset confirms after timeout
				if player_mem.confirm_but ~= nil and game.tick > player_mem.confirm_tick then
					player_mem.confirm_but.style.font_color = player_mem.confirm_color
					player_mem.confirm_but = nil
					if player.gui.left.frame_spbook then
						info(player, player_mem, "", infos.none, true)
					end
				end
				
				-- reset info after timeout
				if player_mem.info_tick ~= 0 and game.tick > player_mem.info_tick then
					if player_mem.rights == rights.banned then
						player.print( {"sbloci-you-banned"} )
						player_mem.info_tick = game.tick + 60*message_banned_timeout
					else
						-- if player.gui.left.frame_spbook then
						info(player, player_mem, "", infos.none, true)
						-- end
						player_mem.info_tick = 0
					end
				end
				
				-- look for scanner
				if player_mem.scanner_typ_gui then
					local selected = player.selected
					
					if selected and selected ~= player_mem.selected then -- refresh scanner only if new object pointed
						player_mem.selected = selected
						
						if selected.type == "entity-ghost" then
							s = selected.ghost_localised_name
							player_mem.scanner_typ_gui.caption = { "sblocc-sca-typg", s }
						else
							s = selected.localised_name
							player_mem.scanner_typ_gui.caption = { "sblocc-sca-typ", s }
						end
						
						if selected.supports_backer_name() then
							debug_print("backer=",selected.backer_name)
							player_mem.scanner_nam_gui.text = selected.backer_name
						else
							player_mem.scanner_nam_gui.text = ""
						end
						
						player_mem.scanner_for_gui.caption = { "sblocc-sca-for", selected.force.name }
					end
				end
			end
		end
	else
		global.ticks = global.ticks + 1
	end
end

script.on_event(defines.events.on_tick, on_tick)

--------------------------------------------------------------------------------------
local function on_gui_click(event)
	local player = game.players[event.player_index]
	local player_mem = global.player_mem[player.index]
	local event_name = event.element.name
	local event_name_prefix = string.sub(event_name,1,18)
	local event_name_suffix = string.sub(event_name,19)
	local s
	
	--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --
	
	if player_mem.confirm_but ~= nil and event.element ~= player_mem.confirm_but then
		-- cancel confirm because click on another gui
		player_mem.confirm_but.style.font_color = player_mem.confirm_color
		player_mem.confirm_but = nil
	end

	if event_name == "but_spbook_main" then -- main button
		if player_mem.authen then
			if player.gui.left.frame_spbook then
				player.gui.left.frame_spbook.destroy()
			else
				if player_mem.rights > rights.banned then
					update_window(player,refr.all)
				end
			end
		else
			ask_password(player, player_mem, false)
		end
		
	elseif event_name == "but_spbook_ava" then -- avatar button
		if player_mem.avatar == nil then
			-- go into flying avatar, only if on body
			if check_rights(player, player_mem, rights.admin, cheat.yes) then
				if player.character and player.character.valid and player.character.name == "player" then 
					local avatar = player.surface.create_entity({ name = "spbook-avatar", force = player.force, position = player.position })
					
					player_mem.character = player.character
					player_mem.character_destructible = player.character.destructible
					player_mem.force = player.force
					
					player.character.destructible = false
					player_mem.avatar = avatar
					avatar.destructible = false
					
					player.character = avatar
					event.element.sprite = "sprite_spbook_main_ava"
					
					info(player, player_mem, {"sbloci-in-avatar", player.name}, infos.ok, true, infos.all )
				else
					info(player, player_mem, {"sbloci-not-body"} , infos.error )
				end
			end
		else
			-- go back into body
			if player.character and player.character.valid and player.character.name == "spbook-avatar" then 
				if player_mem.force and player_mem.force.valid then
					player.force = player_mem.force
				else
					player.force = global.force_guests 
				end
				player_mem.avatar = player.character -- get a valid version in case of intermediary deco/reco
				player.character = player_mem.character
				player.character.destructible = player_mem.character_destructible
				if player_mem.avatar and player_mem.avatar.valid then
					player_mem.avatar.destroy()
				end
				player_mem.avatar = nil
				event.element.sprite = "sprite_spbook_main_hum"
				
				info(player, player_mem, {"sbloci-leave-avatar", player.name}, infos.ok, true, infos.all )
			else
				info(player, player_mem, {"sbloci-not-avatar"} , infos.error )
			end
		end
		
	elseif event_name == "but_spbook_tel" then -- avatar teleport button
		if player_mem.avatar == nil then
			info(player, player_mem, {"sbloci"}, infos.error )
		else
			if player.character and player.character.valid and player.character.name == "spbook-avatar" then 
				-- go back into body and teleport
				local pos = player.character.position
				local surf = player.character.surface
				player_mem.avatar = player.character -- get a valid version in case of intermediary deco/reco
				if player_mem.force and player_mem.force.valid then
					player.force = player_mem.force
				else
					player.force = global.force_guests 
				end
				player.character = player_mem.character
				player.character.destructible = player_mem.character_destructible
				if player_mem.avatar and player_mem.avatar.valid then
					player_mem.avatar.destroy()
				end
				player_mem.avatar = nil
				player_mem.last_tp = player.position
				player.teleport(pos,surf)
				player.gui.top.flow_spbook_main.but_spbook_ava.sprite = "sprite_spbook_main_hum"
				
				if player.gui.left.frame_spbook then
					update_window(player,refr.you)
				end
				update_windows(refr.players)
				info(player, player_mem, {"sbloci-pla-telx", player.name}, infos.ok, false, infos.all )
			else
				info(player, player_mem, {"sbloci-not-avatar"}, infos.error )
			end
		end
		
	elseif event_name == "but_spbook_peace" then -- peaceful
		if check_rights(player, player_mem, rights.admin, cheat.yes) then
			if test_confirm( player, player_mem, event.element ) then
				game.surfaces.nauvis.peaceful_mode = not game.surfaces.nauvis.peaceful_mode
				update_windows(refr.common)
				if game.surfaces.nauvis.peaceful_mode then
					s = {"sbloci-mod-pea"}
				else
					s = {"sbloci-mod-agr"}
				end
				info(player, player_mem, s, infos.ok, false, infos.all )
			end
		end
		
	elseif event_name == "but_spbook_day" then -- day mode
		if check_rights(player, player_mem, rights.admin, cheat.yes) then
			if test_confirm( player, player_mem, event.element ) then
				game.surfaces.nauvis.always_day = not game.surfaces.nauvis.always_day
				update_windows(refr.common)
				if game.surfaces.nauvis.always_day then
					s = {"sbloci-mod-aday"} 
				else
					s = {"sbloci-mod-nnd"}
				end
				info(player, player_mem, s, infos.ok, false, infos.all )
			end
		end
		
	elseif event_name == "but_spbook_frozen" then -- freeze time
		if check_rights(player, player_mem, rights.admin, cheat.yes) then
			global.frozen = not global.frozen
			game.surfaces.nauvis.freeze_daytime( global.frozen )
			update_windows(refr.common)
			if global.frozen then
				s = {"sbloci-mod-timf"} 
			else
				s = {"sbloci-mod-timr"}
			end
			info(player, player_mem, s, infos.ok, false, infos.all )
		end
		
	elseif event_name == "but_spbook_save" then -- server save
		if check_rights(player, player_mem, rights.admin, cheat.no) then
			if test_confirm( player, player_mem, event.element ) then
				info(player, player_mem, {"sbloci-serv-sav"} , infos.ok, true )
				pcall(game.server_save)
				-- refresh gui before the save, to avoid crash (bug reported, will be corrected)
				-- if pcall(game.server_save) then
					-- info(player, player_mem, "Server saved.", infos.ok, true )
				-- else
					-- info(player, player_mem, "Solo mode, no server to save !", infos.error, true )
				-- end
			end
		end
		
	elseif event_name == "but_spbook_clean" then -- delete offline players
		if check_rights(player, player_mem, rights.admin, cheat.no) then
			if test_confirm( player, player_mem, event.element ) then
				pcall(game.remove_offline_players)
				update_windows(refr.all_inside)
				info(player, player_mem, {"sbloci-del-offls"} , infos.ok )
				-- if pcall(game.remove_offline_players) then
					-- update_windows()
					-- info(player, player_mem, "Offline players removed.", infos.ok )
				-- else
					-- info(player, player_mem, "Error !", infos.error, true )
				-- end
			end
		end
		
	elseif event_name == "but_spbook_mod_ena" then -- toggle mod on/off
		if check_rights(player, player_mem, rights.owner, cheat.no) then
			global.mod_enabled = not global.mod_enabled
			update_windows(refr.all)
			if global.mod_enabled then
				s = {"sbloci-sb-ena"} 
			else
				s = {"sbloci-sb-dis"} 
			end
			info(player, player_mem, s, infos.ok, false, infos.all )
		end
		
	elseif event_name == "but_spbook_cht_ena" then -- spacebook cheats on/off
		if check_rights(player, player_mem, rights.admin, cheat.no) then
			global.cheats_enabled = not global.cheats_enabled
			update_windows(refr.all,true)
			if global.cheats_enabled then
				s = {"sbloci-cht-ena"} 
			else
				s = {"sbloci-cht-dis"} 
				players_uncheat()
			end
			info(player, player_mem, s, infos.ok, false, infos.all )
		end
		
	elseif event_name == "but_spbook_pwd_ena" then -- login password check on/off
		if check_rights(player, player_mem, rights.admin, cheat.no) then
			global.pwd_enabled = not global.pwd_enabled
			update_windows(refr.all,true)
			if global.pwd_enabled then
				s = {"sbloci-pwd-ena"} 
			else
				s = {"sbloci-pwd-dis"} 
			end
			info(player, player_mem, s, infos.ok, false, infos.all )
		end
		
	elseif event_name == "but_spbook_refresh" then -- display refresh
		update_nb_players_force()
		update_window(player, refr.all)
		info(player, player_mem, {"sbloci-refresh"} , infos.ok )
		
	elseif event_name == "but_spbook_own_rst" then -- owner wait
		if check_rights(player, player_mem, rights.owner, cheat.no) then
			global.noOwnerYet = not global.noOwnerYet
			update_window(player, refr.common)
			if global.noOwnerYet then
				s = {"sbloci-own-wait"} 
			else
				s = {"sbloci-own-blk"}
			end
			info(player, player_mem, s, infos.ok )
		end
		
	elseif event_name == "but_spbook_cln_con" then -- clear all consoles
		if check_rights(player, player_mem, rights.owner, cheat.no) then
			if test_confirm( player, player_mem, event.element ) then
				for _, p in pairs(game.players) do
					if p.connected then p.clear_console() end
				end
				info(player, player_mem, {"sbloci-cln-cons"} , infos.ok )
			end
		end
		
	elseif event_name == "but_spbook_zoom" then -- large zoom
		if check_rights(player, player_mem, rights.admin, cheat.yes) then
			player.zoom = admin_zoom
		end
		
	elseif event_name == "but_spbook_test" then -- test button
		-- local test = 0
		-- if(hash256("The quick brown fox jumps over the lazy dog") == "d7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592") then test = test + 1 end
		-- if(hash256("The quick brown fox jumps over the lazy cog") == "e4c4d8f3bf76b692de791a173e05321150f7a345b46484fe427f6acc7ecc81be") then test = test + 1 end
		-- if(hash256("") == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855") then test = test + 1 end
		-- if(hash256("123456") == "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92") then test = test + 1 end
		-- debug_print( "good hash nb=", test )

		for _, player2 in pairs(game.players) do
			local player_mem2 = global.player_mem[player2.index]
			debug_print( "noban filter ", player2.name, " ", player_mem2.filter_noban )
		end	

		game.check_consistency()
	--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --

	elseif event_name == "but_spbook_you_utp" then -- undo last tp
		if check_rights(player, player_mem, rights.officer, cheat.yes, force) then
			local pos = player_mem.last_tp
			if pos ~= nil then
				player_mem.last_tp = player.position
				player.teleport(pos)
				s = {"sbloci-pla-telx", player.name}
				update_windows(refr.you+refr.players)
				info(player, player_mem, s, infos.ok, false, infos.all )
			end
		end
		
	elseif event_name == "but_spbook_you_pwd" then -- ask for change password
		if check_rights(player, player_mem, rights.guest, cheat.no) then
			ask_password(player, player_mem, true)
		end

	elseif event_name== "but_spbook_pwd_ok" then -- pwd window ok
		local pwd_old = ""
		local pwd_new = ""
		local verif = true
		if player_mem.pwd_gui_old then
			pwd_old = player_mem.pwd_gui_old.text
		end
		if player_mem.pwd_gui_new then
			pwd_new = player_mem.pwd_gui_new.text
		end

		local character = player.character

		if pwd_new == "" and not debug_status then
		-- if pwd_new == "" then
			info(player,player_mem,{"sbloci-pwd-nul"} , infos.error, false, infos.duplic)
			verif = false
		else
			if player_mem.authen or player_mem.pwd_hash == "" then
				if player_mem.pwd_hash ~= "" then
					-- test old pwd
					if player_mem.pwd_hash ~= hash256(pwd_old) then
						info(player,player_mem,{"sbloci-pwd-badold"} , infos.error)
						verif = false
					end
				end
				
				if verif then
					-- set new password
					player_mem.pwd_hash = hash256(pwd_new)
					player_mem.authen = true
					if character and character.valid then character.active = true end
					update_windows(refr.players)
					info(player,player_mem,{"sbloci-pwd-rec"} , infos.ok)
				end
			else
				-- simply check password
				if player_mem.pwd_hash == hash256(pwd_new) then
					info(player,player_mem,{"sbloci-pwd-ver"}, infos.ok)
					player_mem.authen = true
					if character and character.valid then character.active = true end
				else
					info(player,player_mem,{"sbloci-pwd-bad"} , infos.error, false, infos.duplic)
					verif = false
				end
			end
		end
		if verif then
			player.gui.center.frame_spbook_pwd.destroy()
			player_mem.pwd_gui_old = nil
			player_mem.pwd_gui_new = nil
		end
		
	elseif event_name== "but_spbook_pwd_cancel" then -- pwd window cancel
		if player.gui.center.frame_spbook_pwd ~= nil then
			player.gui.center.frame_spbook_pwd.destroy()
		end
		player_mem.pwd_gui_old = nil
		player_mem.pwd_gui_new = nil

	elseif event_name == "but_spbook_you_quit" then -- player quit force
		if check_rights(player, player_mem, rights.engineer, cheat.no) then
			if player_mem.avatar ~= nil then
				info(player,player_mem, {"sbloci-qui-ava"} , infos.error)
			elseif player.force == global.force_guests then
				info(player,player_mem, {"sbloci-qui-gst"} , infos.error)
			elseif test_confirm( player, player_mem, event.element ) then
				s = player.force.name
				player.force = global.force_guests
				-- if player_mem.rights < rights.admin then player_mem.rights = rights.guest end
				update_nb_players_force()
				update_windows(refr.all_inside)
				info(player,player_mem,{"sbloci-pla-quit",player.name, s }, infos.ok, false, infos.all)
			end
		end
		
	elseif event_name == "but_spbook_you_color" then -- color
		show_color_picker(player)

	elseif event_name_prefix == "but_spbook_col_sel" then -- color select
		debug_print( "col=", event_name_suffix )
		local col = colors[event_name_suffix]
		player.color = col

	elseif event_name == "but_spbook_col_close" then -- color close
		if player.gui.center.frame_spbook_colors then
			player.gui.center.frame_spbook_colors.destroy()
		end

	elseif event_name == "but_spbook_you_scanner" then -- scanner
		show_scanner(player, player_mem )

	elseif event_name == "but_spbook_sca_ren" then -- scanner rename backer
		if player_mem.scanner_nam_gui and player_mem.selected.supports_backer_name() then
			player_mem.selected.backer_name = player_mem.scanner_nam_gui.text
		end

	elseif event_name == "but_spbook_sca_for" then -- scanner change force
		if player_mem.selected and player_mem.selected.valid and player_mem.force_sel then
			player_mem.selected.force = player_mem.force_sel
			player_mem.scanner_for_gui.caption = { "sblocc-sca-for", player_mem.selected.force.name }
		end

	elseif event_name == "but_spbook_sca_close" then -- scanner close
		if player.gui.left.frame_spbook_scanner then
			player.gui.left.frame_spbook_scanner.destroy()
			player_mem.scanner_typ_gui = nil
		end

	elseif event_name == "but_spbook_you_sly" then -- select you
		player_mem.n_player_sel = 0
		player_mem.player_sel = player
		player_mem.force_filter = nil
		player_mem.filter_online = false
		player_mem.filter_noban = false
		-- update_window will find the n_player_sel
		update_window(player,refr.players)
		
		-- change page
		if player_mem.n_player_sel ~= 0 then
			player_mem.players_page_cur = 1+math.floor((player_mem.n_player_sel -1) / lines_per_page )
			update_window(player,refr.players)
		end

	elseif event_name == "but_spbook_you_slf" then -- select your force
		player_mem.force_sel = player.force
		player_mem.n_force_sel = find_n_force(player.force)
		if player_mem.n_force_sel ~= 0 then
			player_mem.forces_page_cur = 1+math.floor((player_mem.n_force_sel -1) / lines_per_page )
		end
		update_window(player, refr.forces)
		
	--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --

	elseif event_name == "but_spbook_for_pageleft" then
		player_mem.forces_page_cur = math.max( 1, player_mem.forces_page_cur - 1 )
		update_window(player, refr.forces)
		
	elseif event_name == "but_spbook_for_pageright" then
		player_mem.forces_page_cur = math.min( player_mem.forces_page_max, player_mem.forces_page_cur + 1 )
		update_window(player, refr.forces)

	elseif event_name == "but_spbook_for_pagecur" then
		player_mem.forces_page_cur = 1+math.floor((player_mem.n_force_sel -1) / lines_per_page )
		update_window(player, refr.forces)
		
	elseif event_name == "but_spbook_for_new" then -- new force
		if check_rights(player, player_mem, rights.admin, cheat.no) then
			show_new_force( player )
		end

	elseif event_name== "but_spbook_for_new_erase" then -- new force erase name field
		player_mem.new_force_gui.textfield_spbook_for_new.text = ""

	elseif event_name== "but_spbook_for_new_ok" then -- new force ok
		if check_rights(player, player_mem, rights.admin, cheat.no) then
			s = player_mem.new_force_gui.textfield_spbook_for_new.text
			if s == "" then
				info(player, player_mem, {"sbloci-for-nonam"} , infos.error)
			elseif game.forces[s] then
				info(player, player_mem, {"sbloci-for-exist", s}, infos.error)
			else
				player_mem.new_force_name = s
				local force = game.create_force( s )
				if force then
					player_mem.force_sel = force
					player_mem.n_force_sel = find_n_force(force)
					guests_force_peace()
					update_windows(refr.forces)
					info(player,player_mem,{"sbloci-for-creat", s}, infos.ok)
				else
					info(player,player_mem,{"sbloci-for-err"} , infos.error, true)
				end
				player_mem.new_force_gui.destroy()
			end
		end
		
	elseif event_name== "but_spbook_for_new_cancel" then -- new force cancel
		if player_mem.new_force_gui ~= nil then
			player_mem.new_force_gui.destroy()
		end

	elseif event_name_prefix == "chk_spbook_for_sel" then -- select force by checkbox
		player_mem.n_force_sel = tonumber(event_name_suffix)
		player_mem.force_sel = game.forces[event.element.parent["but_spbook_for_nam" .. player_mem.n_force_sel].caption]
		update_window(player,refr.forces)

	elseif event_name_prefix == "but_spbook_for_nam" then -- select force by name
		player_mem.n_force_sel = tonumber(event_name_suffix)
		player_mem.force_sel = game.forces[event.element.caption]
		if player_mem.force_filter then	player_mem.force_filter = player_mem.force_sel end
		update_window(player,refr.forces)

	elseif event_name_prefix == "but_spbook_for_wra" then -- stance of selected force toward other force
		check_valid_player_mem( player_mem )
		local n_force = tonumber(event_name_suffix)
		local force = find_force(n_force)		
		
		if player_mem.force_sel and check_rights(player, player_mem, rights.officer, cheat.unless_officer, player_mem.force_sel) and n_force ~= player_mem.n_force_sel then
			local cease = not player_mem.force_sel.get_cease_fire(force.name)
			
			-- peace or war ?
			player_mem.force_sel.set_cease_fire(force.name, cease)
			
			-- if war declaration, automatically protect the other force
			if not cease then
				force.set_cease_fire(player_mem.force_sel.name, cease)
			end

			update_windows(refr.forces)
			if cease then
				s = {"sbloci-for-friend",player_mem.force_sel.name,force.name}
			else
				s = {"sbloci-for-enemies",player_mem.force_sel.name,force.name}
			end
			info(player, player_mem, s, infos.ok)
			message_force(player_mem.force_sel,s)
			message_force(force,s)
		end

	elseif event_name_prefix == "but_spbook_for_wrb" then -- stance of others toward selected force
		check_valid_player_mem( player_mem )
		local n_force = tonumber(event_name_suffix)
		local force = find_force(n_force)		
		
		if player_mem.force_sel and check_rights(player, player_mem, rights.admin, cheat.yes) and n_force ~= player_mem.n_force_sel then
			local cease = not force.get_cease_fire(player_mem.force_sel.name)	
			
			-- peace or war ?
			force.set_cease_fire(player_mem.force_sel.name, cease)

			update_windows(refr.forces)
			if cease then
				s = {"sbloci-for-friend",force.name,player_mem.force_sel.name}
			else
				s = {"sbloci-for-enemy",force.name,player_mem.force_sel.name}
			end
			info(player, player_mem, s, infos.ok)
			message_force(player_mem.force_sel,s)
			message_force(force,s)
		end

	elseif event_name_prefix == "but_spbook_for_pxy" then -- teleport to force start point
		check_valid_player_mem( player_mem )
		local n_force = tonumber(event_name_suffix)
		local force = find_force(n_force)		
		
		if force and check_rights(player, player_mem, rights.officer, cheat.yes, force) then
			player_mem.last_tp = player.position
			player.teleport(force.get_spawn_position("nauvis"))
			s = {"sbloci-pla-tels", player.name, force.name}
			update_windows(refr.you+refr.players)
			info(player, player_mem, s, infos.ok, false, infos.all )
		end

	elseif event_name == "chk_spbook_for_aut" then -- define autojoin force
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel

		if check_rights(player, player_mem, rights.admin, cheat.no) then
			if force and n_force > 3 and force ~= global.force_guests then
				if event.element.state then
					global.force_autojoin = force
					update_windows(refr.forces)
					info(player,player_mem,{"sbloci-for-aut", force.name}, infos.ok)
				else
					global.force_autojoin = nil
					update_windows(refr.forces)
					info(player,player_mem,{"sbloci-for-naut"}, infos.ok)
				end
			else
				info(player,player_mem,{"sbloci-for-def"} , infos.error)
			end
		end	

	elseif event_name == "but_spbook_for_mrg" then -- merge force into sel player force
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel

		if check_rights(player, player_mem, rights.admin, cheat.no) then
			if force and n_force > 3 and force ~= global.force_guests then
				if player_mem.player_sel ~= nil then
					if test_confirm( player, player_mem, event.element ) then
						s = force.name
						game.merge_forces( s, player_mem.player_sel.force.name )
						player_mem.n_force_sel = 3
						player_mem.force_sel = global.force_guests
						update_nb_players_force()
						update_windows(refr.all_inside)
						info(player,player_mem,{"sbloci-for-del", s}, infos.ok)
					end
				else
					info(player,player_mem,{"sblocc-pla-emp"} , infos.error)
				end
			else
				info(player,player_mem,{"sbloci-for-def"} , infos.error)
			end
		end

	elseif event_name == "but_spbook_for_del" then -- delete force
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel

		if check_rights(player, player_mem, rights.admin, cheat.no) then
			if force and n_force > 3 and force ~= global.force_guests then
				if test_confirm( player, player_mem, event.element ) then
					force.reset()
					s = force.name
					game.merge_forces( s, global.force_guests.name )
					player_mem.n_force_sel = 3
					player_mem.force_sel = global.force_guests
					update_nb_players_force()
					update_windows(refr.all_inside)
					info(player,player_mem,{"sbloci-for-del", s}, infos.ok)
				end
			else
				info(player,player_mem,{"sbloci-for-def"} , infos.error)
			end
		end	

	elseif event_name == "but_spbook_for_ava" then -- avatar adopt selected force
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel

		if player_mem.avatar == nil then
			info(player,player_mem,{"sbloci-not-avatar"}, infos.error)
		elseif check_rights(player, player_mem, rights.admin, cheat.no) then
			player_mem.force = player.force
			player.force = force
			info(player, player_mem, {"sbloci-for-ava", player.name , force.name}, infos.ok, true, infos.all )
		end	

	elseif event_name == "but_spbook_for_sps" then -- set starting point
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force and check_rights(player, player_mem, rights.officer, cheat.yes, force) then
			if test_confirm( player, player_mem, event.element ) then
				force.set_spawn_position( player.position, "nauvis" )
				update_windows(refr.forces)
				info(player, player_mem, {"sbloci-for-sps", force.name}, infos.ok )
			end
		end

	elseif event_name == "but_spbook_for_spg" then -- teleport to starting point
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force and check_rights(player, player_mem, rights.officer, cheat.yes, force) then
			player_mem.last_tp = player.position
			player.teleport(force.get_spawn_position("nauvis"))
			s = {"sbloci-pla-tels", player.name, force.name}
			update_windows(refr.you+refr.players)
			info(player, player_mem, s, infos.ok, false, infos.all )
		end

	elseif event_name == "but_spbook_for_rso" then -- generate resources with RSO
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force and check_rights(player, player_mem, rights.admin, cheat.yes, force) then
			local pos = force.get_spawn_position("nauvis")
			s = {"sbloci-pla-rso", player.name, force.name}
			info(player, player_mem, s, infos.ok, false, infos.all )
			force.chart(game.surfaces.nauvis, {left_top = {x = pos.x-500, y = pos.y-500}, right_bottom = {x = pos.x+500, y = pos.y+500}})
			remote.call("RSO", "addStartLocation", pos, player)
		end

	elseif event_name == "but_spbook_for_rsd" then -- research off
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force then
			if force == global.force_guests then
				info(player,player_mem,{"sbloci-for-nogst"}, infos.error)
			elseif check_rights(player, player_mem, rights.admin, cheat.yes) then
				if test_confirm( player, player_mem, event.element ) then
					force.disable_research()
					s = {"sbloci-for-research-dis",force.name}
					info(player, player_mem, s, infos.ok, true)
					message_force(force,s)
				end
			end
		end

	elseif event_name == "but_spbook_for_rse" then -- research on
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force then
			if force == global.force_guests then
				info(player,player_mem,{"sbloci-for-nogst"}, infos.error)
			elseif check_rights(player, player_mem, rights.admin, cheat.yes) then
				if test_confirm( player, player_mem, event.element ) then
					force.enable_research()
					s = {"sbloci-for-research-ena",force.name}
					info(player, player_mem, s, infos.ok, true)
					message_force(force,s)
				end
			end
		end

	elseif event_name == "but_spbook_for_tca" then -- technos all on
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force then
			if force == global.force_guests then
				info(player,player_mem,{"sbloci-for-nogst"}, infos.error)
			elseif check_rights(player, player_mem, rights.admin, cheat.yes) then
				if test_confirm( player, player_mem, event.element ) then
					force.research_all_technologies()
					s = {"sbloci-for-technos-all",force.name}
					info(player, player_mem, s, infos.ok, true)
					message_force(force,s)
				end
			end
		end

	elseif event_name == "but_spbook_for_tcr" then -- technos all off
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force then
			if force == global.force_guests then
				info(player,player_mem,{"sbloci-for-nogst"}, infos.error)
			elseif check_rights(player, player_mem, rights.admin, cheat.yes) then
				if test_confirm( player, player_mem, event.element ) then
					force.reset()
					s = {"sbloci-for-technos-rst",force.name}
					info(player, player_mem, s, infos.ok, true)
					message_force(force,s)
				end
			end
		end

	elseif event_name == "but_spbook_for_fri" then -- force friend with all
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force and check_rights(player, player_mem, rights.admin, cheat.yes) then
			force_stances_all(force, true)
			update_windows(refr.forces)
			s = {"sbloci-for-friall",force.name}
			info(player, player_mem, s, infos.ok)
			message_force(force,s)
		end

	elseif event_name == "but_spbook_for_enn" then -- force enemy with all
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force and check_rights(player, player_mem, rights.admin, cheat.yes) then
			force_stances_all(force, false)
			update_windows(refr.forces)
			s = {"sbloci-for-ennall",force.name}
			info(player, player_mem, s, infos.ok)
			message_force(force,s)
		end

	elseif event_name == "but_spbook_for_kip" then -- kill players
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force and check_rights(player, player_mem, rights.officer, cheat.yes, force) then
			if test_confirm( player, player_mem, event.element ) then
				kill_all_players(force)
				info(player, player_mem, {"sbloci-for-kip", force.name}, infos.ok, true )
			end
		end

	elseif event_name == "but_spbook_for_kia" then -- kill aliens
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
				
		if force and check_rights(player, player_mem, rights.officer, cheat.yes, force) then
			if test_confirm( player, player_mem, event.element ) then
				force.kill_all_units()
				info(player, player_mem, {"sbloci-for-kia", force.name}, infos.ok, true )
			end
		end

	elseif event_name == "but_spbook_for_kib" then -- destroy buildings
		check_valid_player_mem( player_mem )
		local n_force = player_mem.n_force_sel
		local force = player_mem.force_sel
		
		if force == game.forces.neutral then
			info(player,player_mem,{"sbloci-for-neu"} , infos.error)
		elseif force and check_rights(player, player_mem, rights.officer, cheat.yes, force) then
			if test_confirm( player, player_mem, event.element ) then
				destroy_all_buildings(force)
				info(player, player_mem, {"sbloci-for-kib", force.name}, infos.ok,true )
			end
		end

	--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --

	elseif event_name == "but_spbook_pla_pagefirst" then
		player_mem.players_page_cur = 1
		update_window(player,refr.players)
		
	elseif event_name == "but_spbook_pla_pageleft" then
		player_mem.players_page_cur = math.max( 1, player_mem.players_page_cur - 1 )
		update_window(player,refr.players)
		
	elseif event_name == "but_spbook_pla_pagecur" then
		if player_mem.n_player_sel ~= 0 then
			player_mem.players_page_cur = 1+math.floor((player_mem.n_player_sel -1) / lines_per_page )
			update_window(player,refr.players)
		end
		
	elseif event_name == "but_spbook_pla_pageright" then
		player_mem.players_page_cur = math.min( player_mem.players_page_max, player_mem.players_page_cur + 1 )
		update_window(player,refr.players)

	elseif event_name == "but_spbook_pla_pagelast" then
		player_mem.players_page_cur = player_mem.players_page_max
		update_window(player,refr.players)

	elseif event_name == "but_spbook_pla_fil_for" then -- filter by force
		check_valid_player_mem( player_mem )

		if player_mem.force_filter then
			if player_mem.force_filter == player_mem.force_sel then
				player_mem.force_filter = nil
			else
				player_mem.force_filter = player_mem.force_sel
			end
		else
			player_mem.force_filter = player_mem.force_sel
		end
		update_window(player,refr.players)

	elseif event_name == "but_spbook_pla_fil_onl" then -- filter by online
		check_valid_player_mem( player_mem )
		player_mem.filter_online = not player_mem.filter_online
		update_window(player,refr.players)

	elseif event_name == "but_spbook_pla_fil_nob" then -- filter by no banned
		check_valid_player_mem( player_mem )
		player_mem.filter_noban = not player_mem.filter_noban
		update_window(player,refr.players)

	elseif event_name_prefix == "chk_spbook_pla_sel" then -- select player by chkbox and number (read the name of the player on the button next)
		local n_player = tonumber(event_name_suffix)
		player_mem.n_player_sel = n_player
		player_mem.player_sel = game.players[event.element.parent["but_spbook_pla_nam" .. n_player].caption]
		if player_mem.player_sel == nil then
			player_mem.n_player_sel = 0
		end
		update_window(player,refr.players)

	elseif event_name_prefix == "but_spbook_pla_nam" then -- select player (read the name of the player on the button)
		local n_player = tonumber(event_name_suffix)
		player_mem.n_player_sel = n_player
		player_mem.player_sel = game.players[event.element.caption]
		if player_mem.player_sel == nil then
			player_mem.n_player_sel = 0
		end
		update_window(player,refr.players)

	elseif event_name_prefix == "but_spbook_pla_for" then -- select player and his force (read the name of the player on the button next)
		local n_player = tonumber(event_name_suffix)
		player_mem.n_player_sel = n_player
		player_mem.player_sel = game.players[event.element.parent["but_spbook_pla_nam" .. n_player].caption]
		
		if n_player ~= 0 then
			local player_sel = player_mem.player_sel
			player_mem.n_force_sel = find_n_force(player_sel.force)
			player_mem.force_sel = player_sel.force
			player_mem.forces_page_cur = 1+math.floor((player_mem.n_force_sel -1) / lines_per_page )
			update_window(player,refr.forces+refr.players)
		end
		
	elseif event_name_prefix == "but_spbook_pla_pxy" then -- teleport on player
		local n_player = tonumber(event_name_suffix)
		
		if n_player ~= 0  then
			local player_sel = game.players[event.element.parent["but_spbook_pla_nam" .. n_player].caption]
			
			if check_rights(player, player_mem, rights.officer, cheat.yes, player_sel.force) then
				player_mem.last_tp = player.position
				player.teleport( player_sel.position, player_sel.surface )
				update_window(player,refr.you+refr.players)
				info(player,player_mem, {"sbloci-pla-telp", player.name, player_sel.name}, infos.ok, false, infos.all)
			end
		end

	elseif event_name == "but_spbook_pla_joi" then -- change player's force
		check_valid_player_mem( player_mem )
		local n_player = player_mem.n_player_sel
		
		if n_player ~= 0 and check_rights(player, player_mem, rights.officer, cheat.no) then
			local player_sel = player_mem.player_sel
			local n_force = find_n_force(player_sel.force)
			local player_mem_sel = global.player_mem[player_sel.index]
			local force_cond = player_sel.force
			if force_cond == global.force_guests or n_force <= 3 then force_cond = player.force end -- allow an officer to group a player who is in default or guests force

			if player_mem_sel.avatar ~= nil then
				info(player,player_mem, {"sbloci-in-ava-err", player_sel.name}, infos.error)
			else
				if player_mem.rights == rights.officer then
					if n_force > 3 and player_sel.force ~= global.force_guests then
						-- an officer can only group a player in his own force if this one is in a default force or guests
						info(player,player_mem,{"sbloci-pla-alr", player_sel.name}, infos.error)
					elseif player_sel.force == player.force then
						info(player,player_mem, {"sbloci-pla-idm", player_sel.name}, infos.error)
					else
						if test_confirm( player, player_mem, event.element ) then
							player_sel.force = player.force
							if player_mem_sel.rights < rights.engineer then 
								player_mem_sel.rights = rights.engineer -- promote if guest or banned
								player_mem_sel.promoter = player
							end	
							update_nb_players_force()
							update_windows(refr.all_inside)
							s = {"sbloci-pla-join",player_sel.name,player_sel.force.name}
							info(player,player_mem,s, infos.ok, false)
							message_force(player_sel.force,s)
						end
					end
				else
					-- an admin can group into any selected force
					if player_sel.force == player_mem.force_sel then
						info(player,player_mem, {"sbloci-pla-idm", player_sel.name}, infos.error)
					elseif player_mem.force_sel == game.forces.neutral then
						info(player,player_mem, {"sbloci-for-neu"}, infos.error)
					elseif player_mem.force_sel and test_confirm( player, player_mem, event.element ) then
						player_sel.force = player_mem.force_sel
						if player_sel.force ~= global.force_guests and player_mem_sel.rights < rights.engineer then 
							player_mem_sel.rights = rights.engineer -- promote if guest or banned
							player_mem_sel.promoter = player
						end
						update_nb_players_force()
						update_windows(refr.all_inside)
						s = {"sbloci-pla-join",player_sel.name,player_sel.force.name}
						info(player,player_mem,s, infos.ok, false)
						message_force(player_sel.force,s)
					end
				end
			end
		end
		
	elseif event_name == "but_spbook_pla_kic" then -- kick from force
		check_valid_player_mem( player_mem )
		local n_player = player_mem.n_player_sel
		
		if n_player ~= 0  then
			local player_sel = player_mem.player_sel
			local player_mem_sel = global.player_mem[player_sel.index]

			if check_rights(player, player_mem, rights.officer, cheat.no, player_sel.force) then
				if player_mem_sel.avatar ~= nil then
					info(player,player_mem, {"sbloci-in-ava-err",player_sel.name}, infos.error)
				elseif test_confirm( player, player_mem, event.element ) then
					player_sel.force = global.force_guests
					-- if player_mem_sel.rights < rights.admin then player_mem_sel.rights = rights.guest end
					update_nb_players_force()
					update_windows(refr.all_inside)
					info(player,player_mem,{"sbloci-pla-kic", player_sel.name,player_sel.force.name}, infos.ok, false, infos.all)
				end
			end
		end
		
	elseif event_name == "but_spbook_pla_del" then -- delete offline player
		check_valid_player_mem( player_mem )
		local n_player = player_mem.n_player_sel
		
		if n_player ~= 0  then
			local player_sel = player_mem.player_sel
			
			if check_rights(player, player_mem, rights.officer, cheat.no, player_sel.force) then
				if player_sel.connected then
					info(player, player_mem, {"sbloci-pla-nodel"} , infos.error )
				elseif test_confirm( player, player_mem, event.element ) then
					global.player_mem[player_sel.index] = nil
					s = player_sel.name
					local ret =  game.remove_offline_players({s})
					update_nb_players_force()
					update_windows(refr.all_inside)
					info(player,player_mem,{"sbloci-pla-del", s}, infos.ok)
				end
			end
		end

	elseif event_name == "but_spbook_pla_pwd" then -- reset pwd
		check_valid_player_mem( player_mem )
		local n_player = player_mem.n_player_sel
		
		if n_player ~= 0  then
			local player_sel = player_mem.player_sel
			
			if check_rights(player, player_mem, rights.officer, cheat.no, player_sel.force) then
				if test_confirm( player, player_mem, event.element ) then
					local player_mem_sel = global.player_mem[player_sel.index]
					player_mem_sel.pwd_hash = ""
					update_windows(refr.players)
					info(player,player_mem,{"sbloci-pla-pwdrst"} , infos.ok)
				end
			end
		end

	elseif event_name == "but_spbook_pla_rim" then -- retrograde
		check_valid_player_mem( player_mem )
		local n_player = player_mem.n_player_sel
		
		if n_player ~= 0  then
			local player_sel = player_mem.player_sel
			local force_cond = player_sel.force
			if force_cond == global.force_guests then force_cond = player.force end -- allow an officer to ban a guest if necessary
			
			if check_rights(player, player_mem, rights.officer, cheat.no, force_cond) then
				local player_mem_sel = global.player_mem[player_sel.index]
				
				if player_mem.rights < rights.owner and player_mem.rights + iif(player==player_mem_sel.promoter, 1, 0) <= player_mem_sel.rights then
					-- cannot retrograde if same rights, unless you are last promoter or owner
					info(player,player_mem,{"sbloci-pla-noretro"} , infos.error)
				elseif player == player_sel then
					info(player,player_mem,{"sbloci-pla-noretyou"} , infos.error)
				else
					-- ask for confirm if retrograde to guest or banned
					if player_mem_sel.rights > rights.engineer or test_confirm( player, player_mem, event.element ) then
						local rights_old = player_mem_sel.rights
						player_mem_sel.rights = math.max(rights.banned,player_mem_sel.rights - 1)

						if player_mem_sel.rights ~= rights_old then
							player_mem_sel.promoter = player
							
							if player_mem_sel.rights == rights.guest then
								player_sel.force = global.force_guests
								player_sel.color = colors.lightgrey 
							elseif player_mem_sel.rights == rights.banned then
								player_sel.force = global.force_guests
								player_sel.color = colors.black

								if player_sel.connected then		
									if player_sel.character and player_sel.character.valid then
										player_sel.character.active = false
									end
									close_windows(player_sel,false)
								end
								s = {"sbloci-pla-banned",player_sel.name}
								message_all( s )
							end
							
							update_main_bar(player_sel,player_mem_sel)
							update_nb_players_force()
							update_windows(refr.all_inside, true)
							s = {"sbloci-pla-retrograde", player_sel.name, rights[player_mem_sel.rights].name}
							info(player,player_mem, s, infos.ok)
							player_sel.print(s)
						end
					end
				end
			end
		end

	elseif event_name == "but_spbook_pla_rip" then -- promote
		check_valid_player_mem( player_mem )
		local n_player = player_mem.n_player_sel
		
		if n_player ~= 0  then
			local player_sel = player_mem.player_sel
			local force_cond = player_sel.force
			-- if force_cond == global.force_guests then force_cond = player.force end -- allow an officer to promote a banned to guest if necessary
			
			if check_rights(player, player_mem, rights.officer, cheat.no, force_cond) then
				local player_mem_sel = global.player_mem[player_sel.index]
				
				if player == player_sel then
					info(player,player_mem,{"sbloci-pla-noproyou"}, infos.error)
				elseif player_mem.rights < player_mem_sel.rights then
					info(player,player_mem,{"sbloci-pla-nopro"} , infos.error)
				-- elseif player_mem_sel.rights == rights.engineer and player_sel.force == global.force_guests then
					-- info(player,player_mem,{"sbloci-pla-noprogst"} , infos.error)
				else
					local rights_old = player_mem_sel.rights
					player_mem_sel.rights = math.min(math.min(player_mem.rights,rights.admin),player_mem_sel.rights + 1)
					
					if player_mem_sel.rights ~= rights_old then
						player_mem_sel.promoter = player
						
						if player_mem_sel.rights == rights.guest and player_sel.connected then		
							if player_sel.character and player_sel.character.valid then
								player_sel.character.active = true
							end
						end
						
						update_main_bar(player_sel,player_mem_sel)
						update_nb_players_force()
						update_windows(refr.all_inside)
						s = {"sbloci-pla-promote", player_sel.name, rights[player_mem_sel.rights].name}
						info(player,player_mem, s, infos.ok)
						player_sel.print(s)
					end
				end
			end
		end

	elseif event_name == "but_spbook_pla_pos" then -- teleport to player
		check_valid_player_mem( player_mem )
		local player_sel = player_mem.player_sel
		
		if player_sel and check_rights(player, player_mem, rights.officer, cheat.yes, player_sel.force) then
			player_mem.last_tp = player.position
			player.teleport( player_sel.position, player_sel.surface )
			s = {"sbloci-pla-telp", player.name, player_sel.name}
			update_windows(refr.you+refr.players)
			info(player,player_mem, s, infos.ok, false, infos.all)
		end

	elseif event_name == "but_spbook_pla_tls" then -- teleport player to selected force starting point
		check_valid_player_mem( player_mem )
		local n_player = player_mem.n_player_sel
		
		if n_player ~= 0  then
			local player_sel = player_mem.player_sel
			local player_mem_sel = global.player_mem[player_sel.index]
			
			if check_rights(player, player_mem, rights.officer, cheat.yes, player_sel.force) then
				if player_mem_sel.avatar ~= nil then
				info(player,player_mem, {"sbloci-in-ava-err", player_sel.name}, infos.error)
				elseif not player_sel.connected then
					info(player,player_mem, {"sbloci-pla-deco", player_sel.name}, infos.error)
				else
					player_mem_sel.last_tp = player_sel.position
					player_sel.teleport( player_sel.force.get_spawn_position("nauvis") )
					s = {"sbloci-pla-tels", player_sel.name, player_sel.force.name}
					update_windows(refr.you+refr.players)
					info(player,player_mem, s, infos.ok, false, infos.all)
				end
			end
		end

	elseif event_name == "but_spbook_pla_tly" then -- teleport selected player to you
		check_valid_player_mem( player_mem )
		local n_player = player_mem.n_player_sel
		
		if n_player ~= 0  then
			local player_sel = player_mem.player_sel
			local player_mem_sel = global.player_mem[player_sel.index]

			if check_rights(player, player_mem, rights.officer, cheat.yes, player_sel.force) then
				if player_mem_sel.avatar ~= nil then
					info(player,player_mem, {"sbloci-in-ava-err", player_sel.name }, infos.error)
				elseif not player_sel.connected then
					info(player,player_mem, {"sbloci-pla-deco", player_sel.name}, infos.error)
				else
					player_mem_sel.last_tp = player_sel.position
					player_sel.teleport( player.position )
					s = {"sbloci-pla-telp", player_sel.name, player.name}
					update_windows(refr.players)
					info(player,player_mem, s, infos.ok, false, infos.all)
				end
			end
		end
		
	elseif event_name == "but_spbook_pla_kil" then -- kill player
		check_valid_player_mem( player_mem )
		local n_player = player_mem.n_player_sel
		
		if n_player ~= 0  then
			local player_sel = player_mem.player_sel
			local player_mem_sel = global.player_mem[player_sel.index]

			if check_rights(player, player_mem, rights.officer, cheat.yes, player_sel.force) then
				if player_mem_sel.avatar ~= nil then
					info(player,player_mem, {"sbloci-in-ava-err", player_sel.name}, infos.error)
				elseif test_confirm( player, player_mem, event.element ) then
					update_window(player,refr.players)
					if player_sel.connected then
						player_sel.character.die()
						s = {"sbloci-pla-kill", player_sel.name, player.name}
						info(player,player_mem,s, infos.ok)
						player_sel.print(s)
					else
						info(player,player_mem,{"sbloci-pla-deco",player_sel.name}, infos.error)
					end
				end
			end
		end

	elseif event_name == "but_spbook_pla_shs" then -- shield player
		check_valid_player_mem( player_mem )
		local n_player = player_mem.n_player_sel
		
		if n_player ~= 0  then
			local player_sel = player_mem.player_sel
			local player_mem_sel = global.player_mem[player_sel.index]

			if check_rights(player, player_mem, rights.admin, cheat.yes) then
				if not player_sel.connected then
					info(player,player_mem, {"sbloci-pla-deco",player_sel.name}, infos.error)
				elseif player_mem_sel.avatar ~= nil then
					info(player,player_mem, {"sbloci-in-ava-err", player_sel.name}, infos.error)
				elseif player_sel.character == nil then
					info(player,player_mem, {"sbloci-pla-nochar", player_sel.name}, infos.error)
				else
					player_sel.character.destructible = not player_sel.character.destructible
					if player_sel.character.destructible then
						s = {"sbloci-pla-noshi", player_sel.name }
					else
						s = {"sbloci-pla-shi", player_sel.name} 
					end
					update_windows(refr.players)
					update_main_bar(player_sel,player_mem_sel)
					info(player,player_mem, s, infos.ok, false, infos.all)
				end
			end
		end
		
	elseif event_name_prefix == "but_spbook_too_ore" then -- tools ore
		
		player_mem.but_spbook_too_cur.sprite = event.element.sprite
		player_mem.but_spbook_too_cur.tooltip = event.element.tooltip
		player_mem.tool_action = "ore"
		player_mem.tool_param = event_name_suffix
		
	elseif event_name_prefix == "but_spbook_too_flu" then -- tools fluids
		local resource = event_name_suffix
		
		player_mem.but_spbook_too_cur.sprite = event.element.sprite
		player_mem.but_spbook_too_cur.tooltip = event.element.tooltip
		player_mem.tool_action = "fluid"
		player_mem.tool_param = event_name_suffix
		
	elseif event_name == "but_spbook_too_delresources" then -- tools
		player_mem.but_spbook_too_cur.sprite = event.element.sprite
		player_mem.but_spbook_too_cur.tooltip = event.element.tooltip
		player_mem.tool_action = "delresources"
		
	elseif event_name == "but_spbook_too_deltrees" then -- tools
		player_mem.but_spbook_too_cur.sprite = event.element.sprite
		player_mem.but_spbook_too_cur.tooltip = event.element.tooltip
		player_mem.tool_action = "deltrees"
		
	elseif event_name == "but_spbook_too_killaliens" then -- tools
		player_mem.but_spbook_too_cur.sprite = event.element.sprite
		player_mem.but_spbook_too_cur.tooltip = event.element.tooltip
		player_mem.tool_action = "killaliens"
	end
end

script.on_event(defines.events.on_gui_click, on_gui_click )

--------------------------------------------------------------------------------------
local function on_player_selected_area(event)
	if event.item == "spacebook-tool" then
		local player = game.players[event.player_index]
		local player_mem = global.player_mem[event.player_index]
		
		if check_rights(player, player_mem, rights.admin, cheat.yes) then
			local area = event.area
			local pos1 = area.left_top
			local pos2 = area.right_bottom
			local x1 = math.floor(pos1.x)
			local y1 = math.floor(pos1.y)
			local x2 = math.floor(pos2.x)
			local y2 = math.floor(pos2.y)
			local xc = (x1+x2)/2
			local yc = (y1+y2)/2
			
			-- local s = x1 .. "," .. y1 .. " > " .. x2 .. "," .. y2
			-- info(player,player_mem, s, infos.ok)
			
			local act = player_mem.tool_action
			local par = player_mem.tool_param
			local surf = player.surface
			
			local function dist_oval(pos)
				return( math.sqrt(((pos.x-xc)/(x2-xc))^2 + ((pos.y-yc)/(y2-yc))^2) )
			end
			
			if act == "ore" then
				par = global.resources_solid[par].name
				for x = x1,x2 do
					for y= y1,y2 do
						local pos = {x=x+0.5,y=y+0.5}
						local dist = dist_oval(pos)
						if dist <= 1 then
							local ents = surf.find_entities_filtered({area = square_area(pos,0.4), type = "resource"})
							for _,ent in pairs(ents) do
								ent.destroy()
							end
							dist = 1.5-dist
							if dist > 1 then dist = 1 end
							surf.create_entity({name = par, amount=math.floor(dist*math.random(tool_ore_min_amount,tool_ore_max_amount)) , position=pos})
						end
					end
				end
				
			elseif act == "fluid" then
				par = global.resources_fluid[par].name
				local pos = {x=xc+0.5,y=yc+0.5}
				local ents = surf.find_entities_filtered({area = square_area(pos,1.4), type = "resource"})
				for _,ent in pairs(ents) do
					ent.destroy()
				end
				surf.create_entity({name = par, amount = 75 * math.random(tool_oil_min_yield,tool_oil_max_yield) , position=pos})
				
			elseif act == "delresources" then
				if x1 ~= x2 or y1 ~= y2 then
					local ents = surf.find_entities_filtered({area = area, type = "resource"})
					for _,ent in pairs(ents) do
						local dist = dist_oval(ent.position)
						if dist < 0.75 then
							rand = 1
						else
							rand = (1-dist)/0.25
						end
							
						if math.random() <= rand then
							ent.destroy()
						end
					end
				end
				
			elseif act == "deltrees" then
				if x1 ~= x2 or y1 ~= y2 then
					local ents = surf.find_entities_filtered({area = area, type = "tree"})
					for _,ent in pairs(ents) do
						local dist = dist_oval(ent.position)
						if dist < 0.75 then
							rand = 1
						else
							rand = (1-dist)/0.25
						end
							
						if math.random() <= rand then
							ent.destroy()
						end
					end
				end
				
			elseif act == "killaliens" then
				function kill_aliens(ents)
					for _, ent in pairs(ents) do
						ent.destroy()
					end
				end
				
				kill_aliens( surf.find_entities_filtered({area = area, type = "unit"}) )
				kill_aliens( surf.find_entities_filtered({area = area, type = "turret"}) )
				kill_aliens( surf.find_entities_filtered({area = area, type = "unit-spawner"}) )
			end
		end
	end
end

script.on_event(defines.events.on_player_selected_area, on_player_selected_area )

--------------------------------------------------------------------------------------
local function on_player_cursor_stack_changed(event)
	local player = game.players[event.player_index]
	local player_mem = global.player_mem[event.player_index]
	local stack = player.cursor_stack
				
	if stack and stack.valid_for_read and stack.name == "spacebook-tool" then
		debug_print( "grabbed" )
		
		if check_rights(player, player_mem, rights.admin, cheat.yes) then
			show_tools(player, player_mem)
		else
			player_mem.tool_action = nil
		end
	else
		-- close spacebook tools menu
		debug_print( "dropped" )
		if player.gui.left.frame_spbook_tools then
			player.gui.left.frame_spbook_tools.destroy()
		end
		player_mem.tool_action = nil
	end
end

script.on_event(defines.events.on_player_cursor_stack_changed, on_player_cursor_stack_changed )

--------------------------------------------------------------------------------------
-- set the new owner, looking for the first connected player it finds,
-- so you'd better be alone on the game.

local interface = {}

function interface.setowner()
	debug_print( "setowner " )
	
	for _, player in pairs(game.players) do
		if player.connected then
			local player_mem = global.player_mem[player.index]
			player_mem.rights = rights.owner
			player_mem.promoter = nil
			global.noOwnerYet = false
			player.print( {"sbloci-new-owner", player.name} )
			break
		end
	end

end

remote.add_interface( "spacebook", interface )


-- /c remote.call( "spacebook", "setowner" )
