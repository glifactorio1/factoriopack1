data:extend(
  {
    {
      type = "recipe",
      name = "farl",
      enabled = "false",
      ingredients =
      {
        {"diesel-locomotive", 1},
        {"fast-inserter", 2},
        {"steel-plate", 5},
      },
      result = "farl"
    }
  })
