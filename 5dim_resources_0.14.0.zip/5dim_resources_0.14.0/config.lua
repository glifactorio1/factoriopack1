--Define if resources is installed
resources = true --Default: True