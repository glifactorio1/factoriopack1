
game.reload_script()

for _, force in pairs(game.forces) do

	local technologies = force.technologies;
	local recipes = force.recipes;
	
	force.reset_recipes()
	force.reset_technologies()
	
	if technologies["cannon-turret"].researched then
		recipes["cannon-turret"].enabled = true
		recipes["cannon-turret"].reload()
		recipes["rapid-cannon-turret"].enabled = true
		recipes["rapid-cannon-turret"].reload()
	end
	if technologies["rocket-turret"].researched then
		recipes["rocket-turret"].enabled = true
		recipes["rocket-turret"].reload()
		recipes["rapid-rocket-turret"].enabled = true
		recipes["rapid-rocket-turret"].reload()
	end
	if technologies["turret-mk2"].researched then
		recipes["cannon-turret-mk2"].enabled = true
		recipes["cannon-turret-mk2"].reload()
		recipes["rocket-turret-mk2"].enabled = true
		recipes["rocket-turret-mk2"].reload()
		recipes["laser-advanced"].enabled = true
		recipes["laser-advanced"].reload()
	end
	if technologies["artillery-set"].researched then
		recipes["Artillery_mk1"].enabled = true
		recipes["Artillery_mk1"].reload()
		recipes["Artillery_mk2_area"].enabled = true
		recipes["Artillery_mk2_area"].reload()
		recipes["artillery-turret"].enabled = true
		recipes["artillery-turret"].reload()
		recipes["artillery-test-shell"].enabled = true
		recipes["artillery-test-shell"].reload()
		recipes["Artillery_mk2_Ammo"].enabled = true
		recipes["Artillery_mk2_Ammo"].reload()
		recipes["artillery-shell"].enabled = true
		recipes["artillery-shell"].reload()
		recipes["target-capsule"].enabled = true
		recipes["target-capsule"].reload()
	end
	if technologies["small-shells"].researched then
		recipes["small-cannon-shell"].enabled = true
		recipes["small-cannon-shell"].reload()
		recipes["small-explosive-cannon-shell"].enabled = true
		recipes["small-explosive-cannon-shell"].reload()
		recipes["explosion-wall"].enabled = true
		recipes["explosion-wall"].reload()
		recipes["explosion-gate"].enabled = true
		recipes["explosion-gate"].reload()
	end
	if technologies["small-rockets"].researched then
		recipes["small-rocket"].enabled = true
		recipes["small-rocket"].reload()
		recipes["small-explosive-rocket"].enabled = true
		recipes["small-explosive-rocket"].reload()
	end
	if technologies["upgrade-shells-1"].researched then
		recipes["cluster-cannon-shell"].enabled = true
		recipes["cluster-cannon-shell"].reload()
		recipes["explosive-multiple-rocket"].enabled = true
		recipes["explosive-multiple-rocket"].reload()
		recipes["acidthrower-turret"].enabled = true
		recipes["acidthrower-turret"].reload()
		recipes["beam-turret-mk1"].enabled = true
		recipes["beam-turret-mk1"].reload()
		recipes["laser-wall"].enabled = true
		recipes["laser-wall"].reload()
		recipes["laser-gate"].enabled = true
		recipes["laser-gate"].reload()
	end
	if technologies["upgrade-shells-2"].researched then
		recipes["piranha-core"].enabled = true
		recipes["piranha-core"].reload()
		recipes["piranha-solution"].enabled = true
		recipes["piranha-solution"].reload()
		recipes["fire-cannon-shell"].enabled = true
		recipes["fire-cannon-shell"].reload()
		recipes["acid-rocket"].enabled = true
		recipes["acid-rocket"].reload()
		recipes["acid-thrower-ammo"].enabled = true
		recipes["acid-thrower-ammo"].reload()
		recipes["acid-wall"].enabled = true
		recipes["acid-wall"].reload()
		recipes["acid-gate"].enabled = true
		recipes["acid-gate"].reload()
	end
	if technologies["upgrade-shells-3"].researched then
		recipes["fire-cluster-cannon-shell"].enabled = true
		recipes["fire-cluster-cannon-shell"].reload()
		recipes["acid-multiple-rocket"].enabled = true
		recipes["acid-multiple-rocket"].reload()
		recipes["all-wall"].enabled = true
		recipes["all-wall"].reload()
		recipes["all-gate"].enabled = true
		recipes["all-gate"].reload()
		recipes["beam-turret-mk2"].enabled = true
		recipes["beam-turret-mk2"].reload()
	end
end