function conditional_return(value, data)
	if not value then
		return nil
	else
		return data
	end
end

-- color
local explosion_tint =	{r=0.7, g=0.2, b=0.2, a=1}
local acid_tint =		{r=0.8, g=0.5, b=0.9, a=1}
local laser_tint =		{r=0.1, g=0.7, b=0.7, a=1}
local all_tint =		{r=0.6, g=0.6, b=0.2, a=1}



-- resistances
local explosion_wall_resistances = {
	{
		type = "physical",
		decrease = 5,
		percent = 30
	},
	{
		type = "impact",
		decrease = 50,
		percent = 70
	},
	{
		type = "explosion",
		decrease = 45,
		percent = 90
	},
	{
		type = "fire",
		decrease = 35,
		percent = 50
	},
}

local acid_wall_resistances = {
	{
		type = "physical",
		decrease = 5,
		percent = 30
	},
	{
		type = "impact",
		decrease = 35,
		percent = 50
	},
	{
		type = "fire",
		decrease = 20,
		percent = 30
	},
	{
		type = "acid",
		decrease = 15,
		percent = 75
	}
}

local laser_wall_resistances = {
	{
		type = "physical",
		decrease = 5,
		percent = 30
	},
	{
		type = "impact",
		decrease = 50,
		percent = 65
	},
	{
		type = "fire",
		decrease = 35,
		percent = 60
	},
	{
		type = "laser",
		decrease = 55,
		percent = 90
	},
}

local all_wall_resistances = {
	{
		type = "physical",
		decrease = 15,
		percent = 60
	},
	{
		type = "impact",
		decrease = 50,
		percent = 95
	},
	{
		type = "explosion",
		decrease = 50,
		percent = 95,
	},
	{
		type = "fire",
		percent = 100
	},
	{
		type = "laser",
		decrease = 50,
		percent = 95
	},
	{
		type = "acid",
		decrease = 50,
		percent = 95
	}
}



function additional_wall(inputs)
return
{
	type = "wall",
	name = inputs.name,
	icon = inputs.icon,
	flags = {"placeable-neutral", "player-creation"},
	collision_box = {{-0.29, -0.29}, {0.29, 0.29}},
	selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
	minable = {mining_time = 0.5, result = inputs.name},
	fast_replaceable_group = "wall",
	max_health = inputs.health,
	repair_speed_modifier = 2,
	corpse = inputs.corpse,
	repair_sound = { filename = "__base__/sound/manual-repair-simple.ogg" },
	mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },
	vehicle_impact_sound =	{ filename = "__base__/sound/car-stone-impact.ogg", volume = 1.0 },
	-- this kind of code can be used for having walls mirror the effect
	-- there can be multiple reaction items
	--attack_reaction =
	--{
		--{
			---- how far the mirroring works
			--range = 2,
			---- what kind of damage triggers the mirroring
			---- if not present then anything triggers the mirroring
			--damage_type = "physical",
			---- caused damage will be multiplied by this and added to the subsequent damages
			--reaction_modifier = 0.1,
			--action =
			--{
				--type = "direct",
				--action_delivery =
				--{
					--type = "instant",
					--target_effects =
					--{
						--type = "damage",
						---- always use at least 0.1 damage
						--damage = {amount = 0.1, type = "physical"}
					--}
				--}
			--},
		--}
	--},
	connected_gate_visualization =
	{
		filename = "__core__/graphics/arrows/underground-lines.png",
		priority = "high",
		width = 64,
		height = 64,
		scale = 0.5
	},
	resistances = inputs.resistances,
	pictures =
	{
		single =
		{
			layers =
			{
				{
					filename = "__base__/graphics/entity/stone-wall/wall-single.png",
					priority = "extra-high",
					tint = inputs.tint,
					width = 22,
					height = 42,
					shift = {0, -0.15625}
				},
				{
					filename = "__base__/graphics/entity/stone-wall/wall-single-shadow.png",
					priority = "extra-high",
					width = 47,
					height = 32,
					shift = {0.359375, 0.5},
					draw_as_shadow = true
				}
			}
		},
		straight_vertical =
		{
			{
				layers =
				{
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-vertical-1.png",
						priority = "extra-high",
						tint = inputs.tint,
						width = 22,
						height = 42,
						shift = {0, -0.15625}
					},
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-vertical-shadow.png",
						priority = "extra-high",
						width = 47,
						height = 60,
						shift = {0.390625, 0.625},
						draw_as_shadow = true
					}
				}
			},
			{
				layers =
				{
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-vertical-2.png",
						priority = "extra-high",
						tint = inputs.tint,
						width = 22,
						height = 42,
						shift = {0, -0.15625}
					},
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-vertical-shadow.png",
						priority = "extra-high",
						width = 47,
						height = 60,
						shift = {0.390625, 0.625},
						draw_as_shadow = true
					}
				}
			},
			{
				layers =
				{
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-vertical-3.png",
						priority = "extra-high",
						tint = inputs.tint,
						width = 22,
						height = 42,
						shift = {0, -0.15625}
					},
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-vertical-shadow.png",
						priority = "extra-high",
						width = 47,
						height = 60,
						shift = {0.390625, 0.625},
						draw_as_shadow = true
					}
				}
			}
		},
		straight_horizontal =
		{
			{
				layers =
				{
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-horizontal-1.png",
						priority = "extra-high",
						tint = inputs.tint,
						width = 32,
						height = 42,
						shift = {0, -0.15625}
					},
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-horizontal-shadow.png",
						priority = "extra-high",
						width = 59,
						height = 32,
						shift = {0.421875, 0.5},
						draw_as_shadow = true
					}
				}
			},
			{
				layers =
				{
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-horizontal-2.png",
						priority = "extra-high",
						tint = inputs.tint,
						width = 32,
						height = 42,
						shift = {0, -0.15625}
					},
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-horizontal-shadow.png",
						priority = "extra-high",
						width = 59,
						height = 32,
						shift = {0.421875, 0.5},
						draw_as_shadow = true
					}
				}
			},
			{
				layers =
				{
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-horizontal-3.png",
						priority = "extra-high",
						tint = inputs.tint,
						width = 32,
						height = 42,
						shift = {0, -0.15625}
					},
					{
						filename = "__base__/graphics/entity/stone-wall/wall-straight-horizontal-shadow.png",
						priority = "extra-high",
						width = 59,
						height = 32,
						shift = {0.421875, 0.5},
						draw_as_shadow = true
					}
				}
			}
		},
		corner_right_down =
		{
			layers =
			{
				{
					filename = "__base__/graphics/entity/stone-wall/wall-corner-right-down.png",
					priority = "extra-high",
					tint = inputs.tint,
					width = 27,
					height = 42,
					shift = {0.078125, -0.15625}
				},
				{
					filename = "__base__/graphics/entity/stone-wall/wall-corner-right-down-shadow.png",
					priority = "extra-high",
					width = 53,
					height = 61,
					shift = {0.484375, 0.640625},
					draw_as_shadow = true
				}
			}
		},
		corner_left_down =
		{
			layers =
			{
				{
					filename = "__base__/graphics/entity/stone-wall/wall-corner-left-down.png",
					priority = "extra-high",
					tint = inputs.tint,
					width = 27,
					height = 42,
					shift = {-0.078125, -0.15625}
				},
				{
					filename = "__base__/graphics/entity/stone-wall/wall-corner-left-down-shadow.png",
					priority = "extra-high",
					width = 53,
					height = 60,
					shift = {0.328125, 0.640625},
					draw_as_shadow = true
				}
			}
		},
		t_up =
		{
			layers =
			{
				{
					filename = "__base__/graphics/entity/stone-wall/wall-t-down.png",
					priority = "extra-high",
					tint = inputs.tint,
					width = 32,
					height = 42,
					shift = {0, -0.15625}
				},
				{
					filename = "__base__/graphics/entity/stone-wall/wall-t-down-shadow.png",
					priority = "extra-high",
					width = 71,
					height = 61,
					shift = {0.546875, 0.640625},
					draw_as_shadow = true
				}
			}
		},
		ending_right =
		{
			layers =
			{
				{
					filename = "__base__/graphics/entity/stone-wall/wall-ending-right.png",
					priority = "extra-high",
					tint = inputs.tint,
					width = 27,
					height = 42,
					shift = {0.078125, -0.15625}
				},
				{
					filename = "__base__/graphics/entity/stone-wall/wall-ending-right-shadow.png",
					priority = "extra-high",
					width = 53,
					height = 32,
					shift = {0.484375, 0.5},
					draw_as_shadow = true
				}
			}
		},
		ending_left =
		{
			layers =
			{
				{
					filename = "__base__/graphics/entity/stone-wall/wall-ending-left.png",
					priority = "extra-high",
					tint = inputs.tint,
					width = 27,
					height = 42,
					shift = {-0.078125, -0.15625}
				},
				{
					filename = "__base__/graphics/entity/stone-wall/wall-ending-left-shadow.png",
					priority = "extra-high",
					width = 53,
					height = 32,
					shift = {0.328125, 0.5},
					draw_as_shadow = true
				}
			}
		}
	},

	wall_diode_green = conditional_return(not data.is_demo,
			{
				filename = "__base__/graphics/entity/gate/wall-diode-green.png",
				width = 21,
				height = 22,
				shift = {0, -0.78125}
			}),
	wall_diode_green_light = conditional_return(not data.is_demo,
			{
				minimum_darkness = 0.3,
				color = {g=1},
				shift = {0, -0.78125},
				size = 1,
				intensity = 0.3
			}),
	wall_diode_red = conditional_return(not data.is_demo,
	{
		filename = "__base__/graphics/entity/gate/wall-diode-red.png",
		width = 21,
		height = 22,
		shift = {0, -0.78125}
	}),
	wall_diode_red_light = conditional_return(not data.is_demo,
	{
		minimum_darkness = 0.3,
		color = {r=1},
		shift = {0, -0.78125},
		size = 1,
		intensity = 0.3
	}),

	circuit_wire_connection_point =
	{
		shadow =
		{
			red = {0.890625, 0.828125},
			green = {0.890625, 0.703125}
		},
		wire =
		{
			red = {-0.28125, -0.71875},
			green = {-0.28125, -0.84375}
		}
	},
	circuit_wire_max_distance = 7.5,
	circuit_connector_sprites = get_circuit_connector_sprites({0, -0.59375}, nil, 6),
	default_output_signal = data.is_demo and "signal-green" or "signal-G"
}
end





function additional_wall_corpse(inputs)
return
{
	type = "corpse",
	name = inputs.name,
	icon = "__base__/graphics/icons/wall-remnants.png",
	flags = {"placeable-neutral", "not-on-map"},
	subgroup="remnants",
	order="d[remnants]-c[wall]",
	collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
	selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
	selectable_in_game = false,
	time_before_removed = 60 * 60 * 15, -- 15 minutes
	final_render_layer = "remnants",
	animation =
	{
		{
			tint = inputs.tint,
			width = 36,
			height = 36,
			frame_count = 1,
			direction_count = 1,
			filename = "__base__/graphics/entity/stone-wall/remains/wall-remain-01.png"
		},
		{
			tint = inputs.tint,
			width = 38,
			height = 35,
			frame_count = 1,
			direction_count = 1,
			filename = "__base__/graphics/entity/stone-wall/remains/wall-remain-02.png"
		},
		{
			tint = inputs.tint,
			width = 35,
			height = 36,
			frame_count = 1,
			direction_count = 1,
			filename = "__base__/graphics/entity/stone-wall/remains/wall-remain-03.png"
		},
		{
			tint = inputs.tint,
			width = 41,
			height = 36,
			frame_count = 1,
			direction_count = 1,
			filename = "__base__/graphics/entity/stone-wall/remains/wall-remain-04.png"
		},
		{
			tint = inputs.tint,
			width = 35,
			height = 35,
			frame_count = 1,
			direction_count = 1,
			filename = "__base__/graphics/entity/stone-wall/remains/wall-remain-05.png"
		},
		{
			tint = inputs.tint,
			width = 50,
			height = 37,
			frame_count = 1,
			direction_count = 1,
			filename = "__base__/graphics/entity/stone-wall/remains/wall-remain-06.png"
		},
		{
			tint = inputs.tint,
			width = 54,
			height = 40,
			frame_count = 1,
			direction_count = 1,
			filename = "__base__/graphics/entity/stone-wall/remains/wall-remain-07.png"
		},
		{
			tint = inputs.tint,
			width = 43,
			height = 45,
			frame_count = 1,
			direction_count = 1,
			filename = "__base__/graphics/entity/stone-wall/remains/wall-remain-08.png"
		}
	}
}
end




function additional_gate(inputs)
return
{
	type = "gate",
	name = inputs.name,
	icon = inputs.icon,
	flags = {"placeable-neutral","placeable-player", "player-creation"},
	fast_replaceable_group = "wall",
	minable = {hardness = 0.2, mining_time = 0.5, result = inputs.name},
	max_health = inputs.health,
	corpse = "small-remnants",
	collision_box = {{-0.29, -0.29}, {0.29, 0.29}},
	selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
	opening_speed = 0.0666666,
	activation_distance = 3,
	timeout_to_close = 5,
	resistances = inputs.resistances,
	vertical_animation =
	{
		layers =
		{
			{
				filename = "__base__/graphics/entity/gate/gate-vertical.png",
				line_length = 8,
				tint = inputs.tint,
				width = 21,
				height = 60,
				frame_count = 16,
				shift = {0.015625, -0.40625}
			},
			{
				filename = "__base__/graphics/entity/gate/gate-vertical-shadow.png",
				line_length = 8,
				width = 41,
				height = 50,
				frame_count = 16,
				shift = {0.328125, 0.3},
				draw_as_shadow = true
			}
		}
	},
	horizontal_animation =
	{
		layers =
		{
			{
				filename = "__base__/graphics/entity/gate/gate-horizontal.png",
				line_length = 8,
				tint = inputs.tint,
				width = 32,
				height = 36,
				frame_count = 16,
				shift = {0, -0.21875}
			},
			{
				filename = "__base__/graphics/entity/gate/gate-horizontal-shadow.png",
				line_length = 8,
				width = 62,
				height = 28,
				frame_count = 16,
				shift = {0.4375, 0.46875},
				draw_as_shadow = true
			}
		}
	},
	vertical_base =
	{
		layers =
		{
			{
				filename = "__base__/graphics/entity/gate/gate-base-vertical.png",
				width = 32,
				height = 32
			},
			{
				filename = "__base__/graphics/entity/gate/gate-base-vertical-mask.png",
				tint = inputs.tint,
				width = 32,
				height = 32,
				apply_runtime_tint = true
			}
		}
	},
	horizontal_rail_animation_left =
	{
		layers =
		{
			{
				filename = "__base__/graphics/entity/gate/gate-rail-horizontal-left.png",
				line_length = 8,
				tint = inputs.tint,
				width = 32,
				height = 47,
				frame_count = 16,
				shift = {0, -0.140625 + 0.125}
			},
			{
				filename = "__base__/graphics/entity/gate/gate-rail-horizontal-shadow-left.png",
				line_length = 8,
				width = 73,
				height = 27,
				frame_count = 16,
				shift = {0.078125, 0.171875 + 0.125},
				draw_as_shadow = true
			}
		}
	},
	horizontal_rail_animation_right =
	{
		layers =
		{
			{
				filename = "__base__/graphics/entity/gate/gate-rail-horizontal-right.png",
				line_length = 8,
				tint = inputs.tint,
				width = 32,
				height = 43,
				frame_count = 16,
				shift = {0, -0.203125 + 0.125}
			},
			{
				filename = "__base__/graphics/entity/gate/gate-rail-horizontal-shadow-right.png",
				line_length = 8,
				width = 73,
				height = 28,
				frame_count = 16,
				shift = {0.60938, 0.2875 + 0.125},
				draw_as_shadow = true
			}
		}
	},
	vertical_rail_animation_left =
	{
		layers =
		{
			{
				filename = "__base__/graphics/entity/gate/gate-rail-vertical-left.png",
				line_length = 8,
				tint = inputs.tint,
				width = 22,
				height = 54,
				frame_count = 16,
				shift = {0, -0.46875}
			},
			{
				filename = "__base__/graphics/entity/gate/gate-rail-vertical-shadow-left.png",
				line_length = 8,
				width = 47,
				height = 48,
				frame_count = 16,
				shift = {0.27, -0.16125 + 0.5},
				draw_as_shadow = true
			}
		}
	},
	vertical_rail_animation_right =
	{
		layers =
		{
			{
				filename = "__base__/graphics/entity/gate/gate-rail-vertical-right.png",
				line_length = 8,
				tint = inputs.tint,
				width = 22,
				height = 55,
				frame_count = 16,
				shift = {0, -0.453125}
			},
			{
				filename = "__base__/graphics/entity/gate/gate-rail-vertical-shadow-right.png",
				line_length = 8,
				width = 47,
				height = 47,
				frame_count = 16,
				shift = {0.27, 0.803125 - 0.5},
				draw_as_shadow = true
			}
		}
	},
	vertical_rail_base =
	{
		filename = "__base__/graphics/entity/gate/gate-rail-base-vertical.png",
		line_length = 8,
		width = 64,
		height = 64,
		frame_count = 16,
		shift = {0, 0},
	},
	horizontal_rail_base =
	{
		filename = "__base__/graphics/entity/gate/gate-rail-base-horizontal.png",
		line_length = 8,
		width = 64,
		height = 45,
		frame_count = 16,
		shift = {0, -0.015625 + 0.125},
	},
	vertical_rail_base_mask =
	{
		filename = "__base__/graphics/entity/gate/gate-rail-base-mask-vertical.png",
		tint = inputs.tint,
		width = 63,
		height = 39,
		shift = {0.015625, -0.015625},
		apply_runtime_tint = true
	},
	horizontal_rail_base_mask =
	{
		filename = "__base__/graphics/entity/gate/gate-rail-base-mask-horizontal.png",
		tint = inputs.tint,
		width = 53,
		height = 45,
		shift = {0.015625, -0.015625 + 0.125},
		apply_runtime_tint = true
	},
	horizontal_base =
	{
		layers =
		{
			{
				filename = "__base__/graphics/entity/gate/gate-base-horizontal.png",
				width = 32,
				height = 23,
				shift = {0, 0.125}
			},
			{
				filename = "__base__/graphics/entity/gate/gate-base-horizontal-mask.png",
				tint = inputs.tint,
				width = 32,
				height = 23,
				apply_runtime_tint = true,
				shift = {0, 0.125}
			}
		}
	},
	wall_patch =
	{
		north =
		{
			layers =
			{
				{
					filename = "__base__/graphics/entity/gate/wall-patch-north.png",
					tint = inputs.tint,
					width = 22,
					height = 35,
					shift = {0, -0.62 + 1}
				},
				{
					filename = "__base__/graphics/entity/gate/wall-patch-north-shadow.png",
					width = 46,
					height = 31,
					shift = {0.3, 0.20 + 1},
					draw_as_shadow = true
				}
			}
		},
		east =
		{
			layers =
			{
				{
					filename = "__base__/graphics/entity/gate/wall-patch-east.png",
					tint = inputs.tint,
					width = 11,
					height = 40,
					shift = {0.328125 - 1, -0.109375}
				},
				{
					filename = "__base__/graphics/entity/gate/wall-patch-east-shadow.png",
					width = 38,
					height = 32,
					shift = {0.8125 - 1, 0.46875},
					draw_as_shadow = true
				}
			}
		},
		south =
		{
			layers =
			{
				{
					filename = "__base__/graphics/entity/gate/wall-patch-south.png",
					tint = inputs.tint,
					width = 22,
					height = 40,
					shift = {0, -0.125}
				},
				{
					filename = "__base__/graphics/entity/gate/wall-patch-south-shadow.png",
					width = 48,
					height = 25,
					shift = {0.3, 0.95},
					draw_as_shadow = true
				}
			}
		},
		west =
		{
			layers =
			{
				{
					filename = "__base__/graphics/entity/gate/wall-patch-west.png",
					tint = inputs.tint,
					width = 11,
					height = 40,
					shift = {-0.328125 + 1, -0.109375}
				},
				{
					filename = "__base__/graphics/entity/gate/wall-patch-west-shadow.png",
					width = 46,
					height = 32,
					shift = {0.1875 + 1, 0.46875},
					draw_as_shadow = true
				}
			}
		}
	},
	vehicle_impact_sound =	{ filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
	open_sound =
	{
		variations = { filename = "__base__/sound/gate1.ogg", volume = 0.5 },
		aggregation =
		{
			max_count = 1,
			remove = true
		}
	},
	close_sound =
	{
		variations = { filename = "__base__/sound/gate1.ogg", volume = 0.5 },
		aggregation =
		{
			max_count = 1,
			remove = true
		}
	}
}
end





data:extend({
additional_wall{name = "explosion-wall", icon = "__Additional-Turret__/graphics/icon/wall-explosion.png", health = 700, corpse = "explosion-wall-remnants", resistances = explosion_wall_resistances, tint = explosion_tint},
additional_wall{name = "acid-wall", icon = "__Additional-Turret__/graphics/icon/wall-acid.png", health = 700, corpse = "acid-wall-remnants", resistances = acid_wall_resistances, tint = acid_tint},
additional_wall{name = "laser-wall", icon = "__Additional-Turret__/graphics/icon/wall-laser.png", health = 700, corpse = "laser-wall-remnants", resistances = laser_wall_resistances, tint = laser_tint},
additional_wall{name = "all-wall", icon = "__Additional-Turret__/graphics/icon/wall-all.png", health = 900, corpse = "all-wall-remnants", resistances = all_wall_resistances, tint = all_tint},

additional_wall_corpse{name = "explosion-wall-remnants", tint = explosion},
additional_wall_corpse{name = "acid-wall-remnants", tint = acid},
additional_wall_corpse{name = "laser-wall-remnants", tint = laser},
additional_wall_corpse{name = "all-wall-remnants", tint = all},

additional_gate{name = "explosion-gate", icon = "__Additional-Turret__/graphics/icon/gate-explosion.png", health = 700, resistances = explosion_wall_resistances, tint = explosion_tint},
additional_gate{name = "acid-gate", icon = "__Additional-Turret__/graphics/icon/gate-acid.png", health = 700, resistances = acid_wall_resistances, tint = acid_tint},
additional_gate{name = "laser-gate", icon = "__Additional-Turret__/graphics/icon/gate-laser.png", health = 700, resistances = laser_wall_resistances, tint = laser_tint},
additional_gate{name = "all-gate", icon = "__Additional-Turret__/graphics/icon/gate-all.png", health = 900, resistances = all_wall_resistances, tint = all_tint},
})





--item
function wall_item(inputs)
return
{
	type = "item",
	name = inputs.name,
	icon = inputs.icon,
	flags = {"goes-to-quickbar"},
	subgroup = "defensive-structure",
	order = inputs.order,
	place_result = inputs.name,
	stack_size = 50
}
end





data:extend({
wall_item{name = "explosion-wall", icon = "__Additional-Turret__/graphics/icon/wall-explosion.png", order = "a[wall]-a[stone-wall]-a[at-wall]"},
wall_item{name = "acid-wall", icon = "__Additional-Turret__/graphics/icon/wall-acid.png", order = "a[wall]-a[stone-wall]-c[at-wall]"},
wall_item{name = "laser-wall", icon = "__Additional-Turret__/graphics/icon/wall-laser.png", order = "a[wall]-a[stone-wall]-b[at-wall]"},
wall_item{name = "all-wall", icon = "__Additional-Turret__/graphics/icon/wall-all.png", order = "a[wall]-a[stone-wall]-d[at-wall]"},

wall_item{name = "explosion-gate", icon = "__Additional-Turret__/graphics/icon/gate-explosion.png", order = "a[wall]-b[gate]-a[at-gate]"},
wall_item{name = "acid-gate", icon = "__Additional-Turret__/graphics/icon/gate-acid.png", order = "a[wall]-b[gate]-c[at-gate]"},
wall_item{name = "laser-gate", icon = "__Additional-Turret__/graphics/icon/gate-laser.png", order = "a[wall]-b[gate]-b[at-gate]"},
wall_item{name = "all-gate", icon = "__Additional-Turret__/graphics/icon/gate-all.png", order = "a[wall]-b[gate]-d[at-gate]"},
})





--recipe
data:extend({
{
	type = "recipe",
	name = "explosion-wall",
	enabled = false,
	ingredients = {{"stone-wall", 3}, {"iron-plate", 15}},
	result = "explosion-wall",
	requester_paste_multiplier = 10
},
{
	type = "recipe",
	name = "acid-wall",
	enabled = false,
	ingredients = {{"stone-wall", 3}, {"plastic-bar", 8}},
	result = "acid-wall",
	requester_paste_multiplier = 10
},
{
	type = "recipe",
	name = "laser-wall",
	enabled = false,
	ingredients = {{"stone-wall", 3}, {"steel-plate", 4}},
	result = "laser-wall",
	requester_paste_multiplier = 10
},
{
	type = "recipe",
	name = "all-wall",
	enabled = false,
	ingredients = {{"stone-wall", 5},{"explosion-wall", 5},{"acid-wall", 5},{"laser-wall", 5}},
	result = "all-wall",
	requester_paste_multiplier = 10
},





{
	type = "recipe",
	name = "explosion-gate",
	enabled = false,
	ingredients = {{"gate", 3}, {"iron-plate", 15}},
	result = "explosion-gate",
},
{
	type = "recipe",
	name = "acid-gate",
	enabled = false,
	ingredients = {{"gate", 3}, {"plastic-bar", 8}},
	result = "acid-gate",
},
{
	type = "recipe",
	name = "laser-gate",
	enabled = false,
	ingredients = {{"gate", 3}, {"steel-plate", 4}},
	result = "laser-gate",
},
{
	type = "recipe",
	name = "all-gate",
	enabled = false,
	ingredients = {{"gate", 5},{"explosion-gate", 5},{"acid-gate", 5},{"laser-gate", 5}},
	result = "all-gate",
},
})