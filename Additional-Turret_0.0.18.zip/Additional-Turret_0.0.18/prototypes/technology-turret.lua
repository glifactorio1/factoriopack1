data:extend({
{
  type = "technology",
  name = "cannon-turret",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/cannonturret-tech.png",
  effects =
  {
    {
      type = "unlock-recipe",
      recipe = "cannon-turret"
    },
    {
      type = "unlock-recipe",
      recipe = "rapid-cannon-turret"
    }
  },
  prerequisites = {"tanks"},
  unit =
  {
    count = 40,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 30
  },
  order = "e-c-c"
},
{
  type = "technology",
  name = "rocket-turret",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/rocketturret-tech.png",
  effects =
  {
    {
      type = "unlock-recipe",
      recipe = "rocket-turret"
    },
    {
      type = "unlock-recipe",
      recipe = "rapid-rocket-turret"
    }
  },
  prerequisites = {"rocketry"},
  unit =
  {
    count = 60,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 30
  },
  order = "e-g-a"
},
{
  type = "technology",
  name = "turret-mk2",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/mk2-tech.png",
  effects =
  {
    {
      type = "unlock-recipe",
      recipe = "cannon-turret-mk2"
    },
    {
      type = "unlock-recipe",
      recipe = "rocket-turret-mk2"
    },
    {
      type = "unlock-recipe",
      recipe = "laser-advanced"
    }
  },
  prerequisites = {"cannon-turret-damage-4", "rocket-turret-damage-4"},
  unit =
  {
    count = 100,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 30
  },
  order = "e-c-e"
},
{
  type = "technology",
  name = "artillery-set",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/artillery-tech.png",
  effects =
  {
    {
      type = "unlock-recipe",
      recipe = "Artillery_mk1"
    },
	{
      type = "unlock-recipe",
      recipe = "Artillery_mk2_area"
    },
    {
      type = "unlock-recipe",
      recipe = "artillery-turret"
    },
	{
      type = "unlock-recipe",
      recipe = "artillery-test-shell"
    },
	{
      type = "unlock-recipe",
      recipe = "Artillery_mk2_Ammo"
    },
	{
      type = "unlock-recipe",
      recipe = "artillery-shell"
    },
	{
      type = "unlock-recipe",
      recipe = "target-capsule"
    }
  },
  prerequisites = {"upgrade-shells-3"},
  unit =
  {
    count = 1000,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 60
  },
  order = "e-c-f"
},

})