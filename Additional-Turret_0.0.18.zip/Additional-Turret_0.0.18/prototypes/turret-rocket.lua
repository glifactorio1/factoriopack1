function rocket_turret_sheet_1(inputs)
return
{
  layers = 
  {
    {
      filename = "__Additional-Turret__/graphics/entity/rocket-sheet.png",
      priority = "medium",
      scale = 1,
      width = 72,
      height = 80,
      direction_count = inputs.direction_count and inputs.direction_count or 64,
      frame_count = 1,
      line_length = inputs.line_length and inputs.line_length or 16,
      axially_symmetrical = false,
	  run_mode = inputs.run_mode and inputs.run_mode or "forward",
      shift = { 0.25, -0.5 },  
    
    }
  }
}
end

function rocket_turret_sheet_2(inputs)
return
{
  layers = 
  {
    {
      filename = "__Additional-Turret__/graphics/entity/rocket-rapid-sheet.png",
      priority = "medium",
      scale = 1,
      width = 88,
      height = 80,
      direction_count = inputs.direction_count and inputs.direction_count or 64,
      frame_count = 1,
      line_length = inputs.line_length and inputs.line_length or 16,
      axially_symmetrical = false,
	  run_mode = inputs.run_mode and inputs.run_mode or "forward",
      shift = { 0.1, -0.15 },  
    }
  }
}
end

function rocket_mk2_place(inputs)
return
{
  layers = 
  {
    {
      filename = "__Additional-Turret__/graphics/entity/rocket-mk2-sheet.png",
      priority = "medium",
      width = 80,
      height = 72,
      frame_count = inputs.frame_count and inputs.frame_count or 5,
      line_length = inputs.line_length and inputs.line_length or 0,
      run_mode = inputs.run_mode and inputs.run_mode or "forward",
      direction_count = 4,
      axially_symmetrical = false,
      shift = { 0.3125, -0.375 },
    }
  }
}
end

function rocket_mk2_attack(inputs)
return
{
  layers = 
  {
    {
      filename = "__Additional-Turret__/graphics/entity/rocket-mk2-attack.png",
      priority = "medium",
      width = 80,
      height = 72,
      frame_count = 1,
      direction_count = 4,
      axially_symmetrical = false,
      shift = { 0.3125, -0.375 },
    }
  }
}
end


data:extend({
{
  type = "ammo-turret",
  name = "rocket-turret",
  icon = "__Additional-Turret__/graphics/icon/rocket-turret-2.png",
  flags = {"placeable-player", "player-creation"},
  minable = {mining_time = 0.7, result = "rocket-turret"},
  max_health = 700,
  resistances =
  {
    { type = "physical", decrease = 4, percent = 30, },
    { type = "explosion", decrease = 4, percent = 20, },
  },  
  corpse = "small-remnants",
  collision_box = {{-0.7, -0.7 }, {0.7, 0.7}},
  selection_box = {{-1, -1 }, {1, 1}},
  rotation_speed = 0.008,
  preparing_speed = 0.04,
  folding_speed = 0.04,
  dying_explosion = "medium-explosion",
  inventory_size = 1,
  automated_ammo_count = 10,
  attacking_speed = 0.1,
  
  folded_animation = rocket_turret_sheet_1{direction_count = 4, line_length = 1},
  preparing_animation = rocket_turret_sheet_1{direction_count = 4, line_length = 1},
  prepared_animation = rocket_turret_sheet_1{},
  attacking_animation = rocket_turret_sheet_1{},
  folding_animation = rocket_turret_sheet_1{direction_count = 4, line_length = 1, run_mode = "backward"},
  
  vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
  
  attack_parameters =
  {
    type = "projectile",
    ammo_category = "rocket",
    cooldown = 300,
    projectile_creation_distance = 1.2,
    projectile_center = {-0.15625, -0.07812},
    damage_modifier = 2,
    shell_particle =
    {
      name = "shell-particle",
      direction_deviation = 0.1,
      speed = 0.1,
      speed_deviation = 0.03,
      center = {0, 0},
      creation_distance = -1.925,
      starting_frame_speed = 0.2,
      starting_frame_speed_deviation = 0.1
    },
    range = 52,
    min_range = 23,
    sound =
    {
      {
        filename = "__base__/sound/fight/rocket-launcher.ogg",
        volume = 1
      }
    },
  },

  call_for_help_radius = 104
},
{
  type = "ammo-turret",
  name = "rapid-rocket-turret",
  icon = "__Additional-Turret__/graphics/icon/rocket-turret-1.png",
  flags = {"placeable-player", "player-creation"},
  minable = {mining_time = 1, result = "rapid-rocket-turret"},
  max_health = 1000,
  resistances =
  {
    { type = "physical", decrease = 6, percent = 30, },
    { type = "explosion", decrease = 6, percent = 35, },
  },  
  corpse = "small-remnants",
  collision_box = {{-0.7, -0.7 }, {0.7, 0.7}},
  selection_box = {{-1, -1 }, {1, 1}},
  rotation_speed = 0.012,
  preparing_speed = 0.08,
  folding_speed = 0.08,
  dying_explosion = "medium-explosion",
  inventory_size = 1,
  automated_ammo_count = 20,
  attacking_speed = 0.1,
  
  folded_animation = rocket_turret_sheet_2{direction_count = 4, line_length = 1},
  preparing_animation = rocket_turret_sheet_2{direction_count = 4, line_length = 1},
  prepared_animation = rocket_turret_sheet_2{},
  attacking_animation = rocket_turret_sheet_2{},
  folding_animation = rocket_turret_sheet_2{direction_count = 4, line_length = 1, run_mode = "backward"},
  
  vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
  
  attack_parameters =
  {
    type = "projectile",
    ammo_category = "rocket",
    cooldown = 30,
    projectile_creation_distance = 1.2,
    projectile_center = {-0.15625, -0.07812},
    damage_modifier = 1,
    shell_particle =
    {
      name = "shell-particle",
      direction_deviation = 0.1,
      speed = 0.1,
      speed_deviation = 0.03,
      center = {0, 0},
      creation_distance = -1.925,
      starting_frame_speed = 0.2,
      starting_frame_speed_deviation = 0.1
    },
    range = 25,
    min_range = 10,
    sound =
    {
      {
        filename = "__base__/sound/fight/rocket-launcher.ogg",
        volume = 0.7
      }
    },
  },
  call_for_help_radius = 50
},
{
  type = "ammo-turret",
  name = "rocket-turret-mk2",
  icon = "__Additional-Turret__/graphics/icon/rocket-turret-3.png",
  flags = {"placeable-player", "player-creation"},
  minable = {mining_time = 1.3, result = "rocket-turret-mk2"},
  max_health = 900,
  resistances =
  {
    { type = "physical", decrease = 8, percent = 15, },
    { type = "explosion", decrease = 8, percent = 15, },
  },
  corpse = "small-remnants",
  collision_box = {{-0.7, -0.7 }, {0.7, 0.7}},
  selection_box = {{-1, -1 }, {1, 1}},
  rotation_speed = 0.008,
  preparing_speed = 0.01,
  folding_speed = 0.01,
  dying_explosion = "medium-explosion",
  inventory_size = 1,
  automated_ammo_count = 10,
  attacking_speed = 0.1,

  folded_animation = rocket_mk2_place{},
  preparing_animation = rocket_mk2_place{},
  prepared_animation = rocket_mk2_attack{},
  attacking_animation = rocket_mk2_attack{},
  folding_animation = rocket_mk2_place{run_mode = "backward"},
  
  
  vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
  
  attack_parameters =
  {
    type = "projectile",
    ammo_category = "rocket",
    cooldown = 300,
    projectile_creation_distance = 0.1,
    projectile_center = {-0.15625, -0.07812},
    damage_modifier = 3,
    shell_particle =
    {
      name = "shell-particle",
      direction_deviation = 0.1,
      speed = 0.1,
      speed_deviation = 0.03,
      center = {0, 0},
      creation_distance = -1.925,
      starting_frame_speed = 0.2,
      starting_frame_speed_deviation = 0.1
    },
    range = 150,
    min_range = 40,
    turn_range = 1/6,
    sound =
    {
      {
        filename = "__base__/sound/fight/rocket-launcher.ogg",
        volume = 1
      }
    },
  },
  call_for_help_radius = 150
},
})


--item
data:extend({
{
  type = "item",
  name = "rapid-rocket-turret",
  icon = "__Additional-Turret__/graphics/icon/rocket-turret-1.png",
  flags = {"goes-to-quickbar"},
  subgroup = "defensive-structure",
  order = "b[turret]-d[rokcet]-a[rapid-rocket-turret]",
  place_result = "rapid-rocket-turret",
  stack_size = 50,
},
{
  type = "item",
  name = "rocket-turret",
  icon = "__Additional-Turret__/graphics/icon/rocket-turret-2.png",
  flags = {"goes-to-quickbar"},
  subgroup = "defensive-structure",
  order = "b[turret]-d[rokcet]-b[rocket-turret]",
  place_result = "rocket-turret",
  stack_size = 30,
},
{
  type = "item",
  name = "rocket-turret-mk2",
  icon = "__Additional-Turret__/graphics/icon/rocket-turret-3.png",
  flags = {"goes-to-quickbar"},
  subgroup = "defensive-structure",
  order = "b[turret]-d[rokcet]-c[rocket-mk2]",
  place_result = "rocket-turret-mk2",
  stack_size = 20,
},
})  


--recipe
data:extend({
{
  type = "recipe",
  name = "rapid-rocket-turret",
  enabled = false,
  energy_required = 10,
  ingredients =
  {
    {"gun-turret", 2},
    {"steel-plate", 2},
    {"electronic-circuit", 2}
  },
  result = "rapid-rocket-turret",
},
{
  type = "recipe",
  name = "rocket-turret",
  enabled = false,
  energy_required = 10,
  ingredients =
  {
    {"gun-turret", 1},
    {"steel-plate", 4},
    {"electronic-circuit", 3}
  },
  result = "rocket-turret",
},
{
  type = "recipe",
  name = "rocket-turret-mk2",
  enabled = false,
  energy_required = 15,
  ingredients =
  {
    {"gun-turret", 1},
    {"rocket-turret", 1},
    {"rapid-rocket-turret", 1},
    {"processing-unit", 3}
  },
  result = "rocket-turret-mk2",
},
})