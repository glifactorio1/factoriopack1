data:extend({
{
  type = "technology",
  name = "small-shells",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/cannonturret-rof.png",
  effects =
  {
    {
      type = "unlock-recipe",
      recipe = "small-cannon-shell"
    },
    {
      type = "unlock-recipe",
      recipe = "small-explosive-cannon-shell"
    },
	{
      type = "unlock-recipe",
      recipe = "explosion-wall"
    },
	{
      type = "unlock-recipe",
      recipe = "explosion-gate"
    },
  },
  prerequisites = {"cannon-turret"},
  unit =
  {
    count = 80,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 30
  },
  order = "e-c-d"
},

{
  type = "technology",
  name = "small-rockets",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/rocketturret-rof.png",
  effects =
  {
    {
      type = "unlock-recipe",
      recipe = "small-rocket"
    },
    {
      type = "unlock-recipe",
      recipe = "small-explosive-rocket"
    }
  },
  prerequisites = {"rocket-turret"},
  unit =
  {
    count = 120,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 30
  },
  order = "e-g-b"
},

{
  type = "technology",
  name = "upgrade-shells-1",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/ammo-upgrade.png",
  effects =
  {
	{
      type = "unlock-recipe",
      recipe = "cluster-cannon-shell"
    },
    {
      type = "unlock-recipe",
      recipe = "explosive-multiple-rocket"
    },
	{
      type = "unlock-recipe",
      recipe = "acidthrower-turret"
    },
	{
      type = "unlock-recipe",
      recipe = "beam-turret-mk1"
	},
	{
      type = "unlock-recipe",
      recipe = "laser-wall"
    },
	{
      type = "unlock-recipe",
      recipe = "laser-gate"
    },

  },
  prerequisites = {"turret-mk2"},
  unit =
  {
    count = 200,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 30
  },
  order = "e-c-f"
},
{
  type = "technology",
  name = "upgrade-shells-2",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/ammo-upgrade.png",
  effects =
  {
    {
      type = "unlock-recipe",
      recipe = "piranha-core"
    },
	{
      type = "unlock-recipe",
      recipe = "piranha-solution"
    },
    {
      type = "unlock-recipe",
      recipe = "fire-cannon-shell"
    },
    {
      type = "unlock-recipe",
      recipe = "acid-rocket"
    },
	{
      type = "unlock-recipe",
      recipe = "acid-thrower-ammo"
	},
	{
      type = "unlock-recipe",
      recipe = "acid-wall"
    },
	{
      type = "unlock-recipe",
      recipe = "acid-gate"
    },
  },
  prerequisites = {"upgrade-shells-1"},
  unit =
  {
    count = 250,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 45
  },
  order = "e-c-g"
},
{
  type = "technology",
  name = "upgrade-shells-3",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/ammo-upgrade.png",
  effects =
  {
    {
      type = "unlock-recipe",
      recipe = "fire-cluster-cannon-shell"
    },
    {
      type = "unlock-recipe",
      recipe = "acid-multiple-rocket"
    },
	{
      type = "unlock-recipe",
      recipe = "all-wall"
    },
	{
      type = "unlock-recipe",
      recipe = "all-gate"
    },
	{
      type = "unlock-recipe",
      recipe = "beam-turret-mk2"
	},
  },
  prerequisites = {"upgrade-shells-2"},
  unit =
  {
    count = 300,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 60
  },
  order = "e-c-g"
},


})