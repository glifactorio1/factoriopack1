function cannon_turret_sheet_1(inputs)
return
{
  layers = 
  {
    {
      filename = "__Additional-Turret__/graphics/entity/cannon-sheet.png",
      priority = "medium",
      scale = 1.5,
      width = 100,
      height = 75,
      direction_count = inputs.direction_count and inputs.direction_count or 64,
      frame_count = 1,
      line_length = inputs.line_length and inputs.line_length or 8,
      axially_symmetrical = false,
      run_mode = inputs.run_mode and inputs.run_mode or "forward",
      shift = { 0.75, -0.75 }, --{ 0.375, -0.25 },
    }
  }
}
end

function cannon_turret_sheet_2(inputs)
return
{
  layers = 
  {
    {
      filename = "__Additional-Turret__/graphics/entity/cannon-rapid-sheet.png",
      priority = "medium",
      scale = 0.75,
      width = 128,
      height = 128,
      direction_count = inputs.direction_count and inputs.direction_count or 64,
      frame_count = 1,
      line_length = inputs.line_length and inputs.line_length or 8,
      axially_symmetrical = false,
      run_mode = inputs.run_mode and inputs.run_mode or "forward",
    shift = { 0.35, -0.5 },
    }
  }
}
end

function cannon_mk2_place(inputs)
return
{
  layers = 
  {
    {
      filename = "__Additional-Turret__/graphics/entity/cannon-mk2-set-sheet.png",
      priority = "medium",
      scale = 1,
      width = 128,
      height = 128,
      frame_count = inputs.frame_count and inputs.frame_count or 8,
      line_length = inputs.line_length and inputs.line_length or 0,
      run_mode = inputs.run_mode and inputs.run_mode or "forward",
      direction_count = 4,
      axially_symmetrical = false,
      shift = { 0.4375, -0.375},
    },
  },
}

end

function cannon_mk2_sheet(inputs)
return
{
  layers = 
  {
    {
      filename = "__Additional-Turret__/graphics/entity/cannon-mk2-sheet.png",
      priority = "medium",
      scale = 1,
      width = 128,
      height = 128,
      frame_count = 1,
      direction_count = 64,
      line_length = 8,
      axially_symmetrical = false,
      shift = { 0.4375, -0.375},
    }
  }
}
end



data:extend({
{
  type = "ammo-turret",
  name = "cannon-turret",
  icon = "__Additional-Turret__/graphics/icon/cannon-turret-2.png",
  flags = {"placeable-player", "player-creation"},
  minable = {mining_time = 0.7, result = "cannon-turret"},
  max_health = 700,
  resistances =
  {
    { type = "physical", decrease = 4, percent = 30, },
    { type = "explosion", decrease = 4, percent = 20, },
  },  
  corpse = "small-remnants",
  collision_box = {{-0.7, -0.7 }, {0.7, 0.7 }},
  selection_box = {{-1, -1 }, {1, 1}},
  rotation_speed = 0.008,
  preparing_speed = 0.04,
  folding_speed = 0.04,
  dying_explosion = "medium-explosion",
  inventory_size = 1,
  automated_ammo_count = 10,
  attacking_speed = 0.1,
  
  folded_animation = cannon_turret_sheet_1{direction_count = 8, line_length = 1},
  preparing_animation = cannon_turret_sheet_1{direction_count = 8, line_length = 1},
  prepared_animation = cannon_turret_sheet_1{},
  attacking_animation = cannon_turret_sheet_1{},
  folding_animation = cannon_turret_sheet_1{direction_count = 8, line_length = 1, run_mode = "backward"},
  
  vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
  
  attack_parameters =
  {
    type = "projectile",
    ammo_category = "cannon-shell",
    cooldown = 180,
    projectile_creation_distance = 2.45,
    projectile_center = {0, 0.45}, --{0, 0.375},
    damage_modifier = 3,
    shell_particle =
    {
      name = "shell-particle",
      direction_deviation = 0.1,
      speed = 0.1,
      speed_deviation = 0.03,
      center = {0, 0},
      creation_distance = -1.925,
      starting_frame_speed = 0.2,
      starting_frame_speed_deviation = 0.1
    },
    range = 45,
    min_range = 22,
    sound =
    {
      {
        filename = "__base__/sound/fight/tank-cannon.ogg",
        volume = 1.0
      }
    },
  },

  call_for_help_radius = 90
},
{
  type = "ammo-turret",
  name = "rapid-cannon-turret",
  icon = "__Additional-Turret__/graphics/icon/cannon-turret-1.png",
  flags = {"placeable-player", "player-creation"},
  minable = {mining_time = 1, result = "rapid-cannon-turret"},
  max_health = 1000,
  resistances =
  {
    { type = "physical", decrease = 6, percent = 30, },
    { type = "explosion", decrease = 6, percent = 35, },
  },
  corpse = "medium-remnants",
  collision_box = {{-0.7, -0.7 }, {0.7, 0.7}},
  selection_box = {{-1, -1 }, {1, 1}},
  rotation_speed = 0.012,
  preparing_speed = 0.08,
  folding_speed = 0.08,
  dying_explosion = "medium-explosion",
  inventory_size = 1,
  automated_ammo_count = 20,
  attacking_speed = 0.5,
  
  folded_animation = cannon_turret_sheet_2{direction_count = 8, line_length = 1},
  preparing_animation = cannon_turret_sheet_2{direction_count = 8, line_length = 1},
  prepared_animation = cannon_turret_sheet_2{},
  attacking_animation = cannon_turret_sheet_2{},
  folding_animation = cannon_turret_sheet_2{direction_count = 8, line_length = 1, run_mode = "backward"},
  
  
  vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
  
  attack_parameters =
  {
    type = "projectile",
    ammo_category = "cannon-shell",
    cooldown = 30,
    projectile_creation_distance = 1.75,
    projectile_center = {0, 0},
    damage_modifier = 1,
    shell_particle =
    {
      name = "shell-particle",
      direction_deviation = 0.1,
      speed = 0.1,
      speed_deviation = 0.03,
      center = {0, 0},
      creation_distance = -1.925,
      starting_frame_speed = 0.2,
      starting_frame_speed_deviation = 0.1
    },
    range = 23,
    min_range = 10,
    sound =
    {
      {
        filename = "__base__/sound/fight/tank-cannon.ogg",
        volume = 0.7
      }
    },
  },
  call_for_help_radius = 46
},
{
  type = "ammo-turret",
  name = "cannon-turret-mk2",
  icon = "__Additional-Turret__/graphics/icon/cannon-turret-3.png",
  flags = {"placeable-player", "player-creation"},
  minable = {mining_time = 2.5, result = "cannon-turret-mk2"},
  max_health = 1500,
  resistances =
  {
    { type = "physical", decrease = 12, percent = 35, },
    { type = "explosion", decrease = 12, percent = 55, },
  },  
  corpse = "big-remnants",
  collision_box = {{-1.2, -1.2 }, {1.2, 1.2 }},
  selection_box = {{-1.5, -1.5 }, {1.5, 1.5}},
  rotation_speed = 0.008,
  preparing_speed = 0.04,
  folding_speed = 0.04,
  dying_explosion = "big-explosion",
  inventory_size = 2,
  automated_ammo_count = 20,
  attacking_speed = 0.5,
    
  folded_animation = cannon_mk2_place{frame_count=1, line_length = 1},
  preparing_animation = cannon_mk2_place{},
  prepared_animation = cannon_mk2_sheet{},
  attacking_animation = cannon_mk2_sheet{},
  folding_animation = cannon_mk2_place{run_mode = "backward"},
  
  vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
  
  attack_parameters =
  {
    type = "projectile",
    ammo_category = "cannon-shell",
    cooldown = 12,
    projectile_creation_distance = 2,
    projectile_center = {0, -0.0625},
    damage_modifier = 2,
    shell_particle =
    {
      name = "shell-particle",
      direction_deviation = 0.1,
      speed = 0.1,
      speed_deviation = 0.03,
      center = {0, 0},
      creation_distance = -1.925,
      starting_frame_speed = 0.2,
      starting_frame_speed_deviation = 0.1
    },
    range = 55,
    min_range = 13,
    turn_range = 1/6,
    sound =
    {
      {
        filename = "__base__/sound/fight/tank-cannon.ogg",
        volume = 1.0
      }
    },
  },

  call_for_help_radius = 100
},
})


--item
data:extend({
{
  type = "item",
  name = "rapid-cannon-turret",
  icon = "__Additional-Turret__/graphics/icon/cannon-turret-1.png",
  flags = {"goes-to-quickbar"},
  subgroup = "defensive-structure",
  order = "b[turret]-c[cannon]-a[rapid-cannon-turret]",
  place_result = "rapid-cannon-turret",
  stack_size = 50,
},
{
  type = "item",
  name = "cannon-turret",
  icon = "__Additional-Turret__/graphics/icon/cannon-turret-2.png",
  flags = {"goes-to-quickbar"},
  subgroup = "defensive-structure",
  order = "b[turret]-c[cannon]-b[cannon-turret]",
  place_result = "cannon-turret",
  stack_size = 30,
},
{
  type = "item",
  name = "cannon-turret-mk2",
  icon = "__Additional-Turret__/graphics/icon/cannon-turret-3.png",
  flags = {"goes-to-quickbar"},
  subgroup = "defensive-structure",
  order = "b[turret]-c[cannon]-c[cannon-mk2]",
  place_result = "cannon-turret-mk2",
  stack_size = 20,
},
})  


--recipe
data:extend({
{
  type = "recipe",
  name = "rapid-cannon-turret",
  enabled = false,
  energy_required = 10,
  ingredients =
  {
    {"gun-turret", 2},
    {"steel-plate", 2},
    {"electronic-circuit", 2}
  },
  result = "rapid-cannon-turret",
},
{
  type = "recipe",
  name = "cannon-turret",
  enabled = false,
  energy_required = 10,
  ingredients =
  {
    {"gun-turret", 1},
    {"steel-plate", 4},
    {"electronic-circuit", 3}
  },
  result = "cannon-turret",
},
{
  type = "recipe",
  name = "cannon-turret-mk2",
  enabled = false,
  energy_required = 15,
  ingredients =
  {
    {"gun-turret", 1},
    {"cannon-turret", 1},
    {"rapid-cannon-turret", 1},
    {"processing-unit", 3}
  },
  result = "cannon-turret-mk2",
},
})