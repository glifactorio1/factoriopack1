data:extend({

-- cannon turret damage
{
  type = "technology",
  name = "cannon-turret-damage-1",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/cannonturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret",
      modifier = "0.2"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-cannon-turret",
      modifier = "0.2"
    }
  },
  prerequisites = {"cannon-turret"},
  unit =
  {
    count = 50,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 30
  },
  upgrade = true,
  order = "e-o-q-a"
},
{
  type = "technology",
  name = "cannon-turret-damage-2",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/cannonturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret",
      modifier = "0.2"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-cannon-turret",
      modifier = "0.2"
    }
  },
  prerequisites = {"cannon-turret-damage-1"},
  unit =
  {
    count = 100,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 30
  },
  upgrade = true,
  order = "e-o-q-b"
},
{
  type = "technology",
  name = "cannon-turret-damage-3",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/cannonturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret",
      modifier = "0.4"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-cannon-turret",
      modifier = "0.4"
    }
  },
  prerequisites = {"cannon-turret-damage-2"},
  unit =
  {
    count = 200,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 45
  },
  upgrade = true,
  order = "e-o-q-c"
},
{
  type = "technology",
  name = "cannon-turret-damage-4",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/cannonturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret",
      modifier = "0.4"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-cannon-turret",
      modifier = "0.4"
    }
  },
  prerequisites = {"cannon-turret-damage-3"},
  unit =
  {
    count = 100,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 60
  },
  upgrade = true,
  order = "e-o-q-d"
},
{
  type = "technology",
  name = "cannon-turret-damage-5",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/cannonturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret",
      modifier = "0.4"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-cannon-turret",
      modifier = "0.4"
    }
  },
  prerequisites = {"cannon-turret-damage-4"},
  unit =
  {
    count = 200,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 60
  },
  upgrade = true,
  order = "e-o-q-e"
},
{
  type = "technology",
  name = "cannon-turret-damage-6",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/cannonturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret",
      modifier = "0.8"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-cannon-turret",
      modifier = "0.8"
    }
  },
  prerequisites = {"cannon-turret-damage-5"},
  unit =
  {
    count = 300,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 60
  },
  upgrade = true,
  order = "e-o-q-f"
},


-- rocket turret damage
{
  type = "technology",
  name = "rocket-turret-damage-1",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/rocketturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "rocket-turret",
      modifier = "0.2"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-rocket-turret",
      modifier = "0.2"
    }
  },
  prerequisites = {"rocket-turret"},
  unit =
  {
    count = 50,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 30
  },
  upgrade = true,
  order = "e-o-q-a"
},
{
  type = "technology",
  name = "rocket-turret-damage-2",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/rocketturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "rocket-turret",
      modifier = "0.2"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-rocket-turret",
      modifier = "0.2"
    }
  },
  prerequisites = {"rocket-turret-damage-1"},
  unit =
  {
    count = 100,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 30
  },
  upgrade = true,
  order = "e-o-q-b"
},

{
  type = "technology",
  name = "rocket-turret-damage-3",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/rocketturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "rocket-turret",
      modifier = "0.4"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-rocket-turret",
      modifier = "0.4"
    }
  },
  prerequisites = {"rocket-turret-damage-2"},
  unit =
  {
    count = 200,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 45
  },
  upgrade = true,
  order = "e-o-q-c"
},
{
  type = "technology",
  name = "rocket-turret-damage-4",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/rocketturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "rocket-turret",
      modifier = "0.4"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-rocket-turret",
      modifier = "0.4"
    }
  },
  prerequisites = {"rocket-turret-damage-3"},
  unit =
  {
    count = 100,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 60
  },
  upgrade = true,
  order = "e-o-q-d"
},
{
  type = "technology",
  name = "rocket-turret-damage-5",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/rocketturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "rocket-turret",
      modifier = "0.4"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-rocket-turret",
      modifier = "0.4"
    }
  },
  prerequisites = {"rocket-turret-damage-4"},
  unit =
  {
    count = 200,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 60
  },
  upgrade = true,
  order = "e-o-q-e"
},
{
  type = "technology",
  name = "rocket-turret-damage-6",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/rocketturret-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "rocket-turret",
      modifier = "0.8"
    },
    {
      type = "turret-attack",
      turret_id = "rapid-rocket-turret",
      modifier = "0.8"
    }
  },
  prerequisites = {"rocket-turret-damage-5"},
  unit =
  {
    count = 300,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 60
  },
  upgrade = true,
  order = "e-o-q-f"
},


-- mk2 turret damage
{
  type = "technology",
  name = "turret-mk2-damage-1",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/mk2-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret-mk2",
      modifier = "0.2"
    },
    {
      type = "turret-attack",
      turret_id = "rocket-turret-mk2",
      modifier = "0.2"
    }
  },
  prerequisites = {"turret-mk2"},
  unit =
  {
    count = 100,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 60
  },
  upgrade = true,
  order = "e-o-q-a"
},
{
  type = "technology",
  name = "turret-mk2-damage-2",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/mk2-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret-mk2",
      modifier = "0.2"
    },
    {
      type = "turret-attack",
      turret_id = "rocket-turret-mk2",
      modifier = "0.2"
    }
  },
  prerequisites = {"turret-mk2-damage-1"},
  unit =
  {
    count = 200,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 60
  },
  upgrade = true,
  order = "e-o-q-b"
},
{
  type = "technology",
  name = "turret-mk2-damage-3",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/mk2-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret-mk2",
      modifier = "0.4"
    },
    {
      type = "turret-attack",
      turret_id = "rocket-turret-mk2",
      modifier = "0.4"
    }
  },
  prerequisites = {"turret-mk2-damage-2"},
  unit =
  {
    count = 400,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 75
  },
  upgrade = true,
  order = "e-o-q-c"
},
{
  type = "technology",
  name = "turret-mk2-damage-4",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/mk2-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret-mk2",
      modifier = "0.4"
    },
    {
      type = "turret-attack",
      turret_id = "rocket-turret-mk2",
      modifier = "0.4"
    }
  },
  prerequisites = {"turret-mk2-damage-3"},
  unit =
  {
    count = 400,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 90
  },
  upgrade = true,
  order = "e-o-q-d"
},
{
  type = "technology",
  name = "turret-mk2-damage-5",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/mk2-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret-mk2",
      modifier = "0.4"
    },
    {
      type = "turret-attack",
      turret_id = "rocket-turret-mk2",
      modifier = "0.4"
    }
  },
  prerequisites = {"turret-mk2-damage-4"},
  unit =
  {
    count = 500,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 120
  },
  upgrade = true,
  order = "e-o-q-e"
},
{
  type = "technology",
  name = "turret-mk2-damage-6",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/mk2-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "cannon-turret-mk2",
      modifier = "0.8"
    },
    {
      type = "turret-attack",
      turret_id = "rocket-turret-mk2",
      modifier = "0.8"
    }
  },
  prerequisites = {"turret-mk2-damage-5"},
  unit =
  {
    count = 600,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 150
  },
  upgrade = true,
  order = "e-o-q-f"
},




-- thrower turret damage
{
  type = "technology",
  name = "thrower-turret-damage-1",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/thrower-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "acidthrower-turret",
      modifier = "0.2"
    },
  },
  prerequisites = {"upgrade-shells-1"},
  unit =
  {
    count = 75,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 45
  },
  upgrade = true,
  order = "e-c-f-a"
},
{
  type = "technology",
  name = "thrower-turret-damage-2",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/thrower-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "acidthrower-turret",
      modifier = "0.2"
    },
  },
  prerequisites = {"thrower-turret-damage-1"},
  unit =
  {
    count = 125,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 45
  },
  upgrade = true,
  order = "e-o-q-b"
},
{
  type = "technology",
  name = "thrower-turret-damage-3",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/thrower-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "acidthrower-turret",
      modifier = "0.2"
    },
  },
  prerequisites = {"thrower-turret-damage-2"},
  unit =
  {
    count = 250,
    ingredients =
    {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 70
  },
  upgrade = true,
  order = "e-o-q-c"
},
{
  type = "technology",
  name = "thrower-turret-damage-4",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/thrower-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "acidthrower-turret",
      modifier = "0.2"
    },
  },
  prerequisites = {"thrower-turret-damage-3"},
  unit =
  {
    count = 250,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 80
  },
  upgrade = true,
  order = "e-o-q-d"
},
{
  type = "technology",
  name = "thrower-turret-damage-5",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/thrower-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "acidthrower-turret",
      modifier = "0.2"
    },
  },
  prerequisites = {"thrower-turret-damage-4"},
  unit =
  {
    count = 400,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 80
  },
  upgrade = true,
  order = "e-o-q-e"
},
{
  type = "technology",
  name = "thrower-turret-damage-6",
  icon_size = 128,
  icon = "__Additional-Turret__/graphics/technology/thrower-damage.png",
  effects =
  {
    {
      type = "turret-attack",
      turret_id = "acidthrower-turret",
      modifier = "0.2"
    },
  },
  prerequisites = {"thrower-turret-damage-5"},
  unit =
  {
    count = 500,
    ingredients =
    {
      {"alien-science-pack", 1},
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1}
    },
  time = 80
  },
  upgrade = true,
  order = "e-o-q-f"
},
})