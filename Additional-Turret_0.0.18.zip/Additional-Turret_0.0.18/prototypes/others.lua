-- fluid
data:extend({
{
    type = "fluid",
    name = "piranha-solution",
    default_temperature = 25,
    heat_capacity = "1KJ",
    base_color = {r=0, g=0.4, b=0.2},
    flow_color = {r=0, g=0.5, b=0.3},
    max_temperature = 100,
    icon = "__Additional-Turret__/graphics/icon/piranha-solution.png",
    pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
    order = "a[fluid]-g[piranha-solution]"
},
{
  type = "item",
  name = "piranha-core",
  icon = "__Additional-Turret__/graphics/icon/piranha-core-icon.png",
  flags = {"goes-to-main-inventory"},
  subgroup = "intermediate-product",
  order = "g[plastic-bar]-a[piranha-core]",
  stack_size = 10
},
})

--category
data:extend({
  {
    type = "ammo-category",
    name = "artillery-test-shell"
  },
  {
    type = "ammo-category",
    name = "artillery-shell"
  },
  {
    type = "ammo-category",
    name = "artillery"
  },
})


--recipe
data:extend({
{
	type = "recipe",
	name = "piranha-solution",
	category = "chemistry",
	energy_required = 6,
	subgroup = "fluid-recipes",
	enabled = false,
	ingredients =
	{
		{type="item", name="piranha-core", amount=4},
		{type="item", name="alien-artifact", amount=2},
		{type="fluid", name="water", amount=50},
	},
	results=
	{
		{type="fluid", name="piranha-solution", amount=50},
	},
},

{
  type = "recipe",
  name = "piranha-core",
  category = "chemistry",	
  energy_required = 10,
  subgroup = "intermediate-product",
  order = "g[plastic-bar]-a[piranha-core]",
  enabled = false,
  icon = "__Additional-Turret__/graphics/icon/piranha-core-icon.png",
  ingredients =
  {
    {type="item", name="sulfur", amount=30},
    {type="item", name="coal", amount=3},
    {type="item", name="stone", amount=5},
    {type="fluid", name="water", amount=5},
	{type="fluid", name="sulfuric-acid", amount=1}
  },
  results=
  {
    {type="fluid", name="petroleum-gas", amount=1},
    {type="item", name="piranha-core", amount=2},
  },
},
})