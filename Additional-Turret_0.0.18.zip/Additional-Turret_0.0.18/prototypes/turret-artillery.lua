local Artillery_mk1_shift = {0.5, -2.25}
local Artillery_mk2_shift = {0.5, -2.25}

function artillery_turret_sheet(inputs)
return
{
	layers = 
	{
		{
			filename = "__Additional-Turret__/graphics/entity/artillery-sheet.png",
			priority = "medium",
			scale = 1,
			width = 168,
			height = 168,
			direction_count = inputs.direction_count and inputs.direction_count or 64,
			frame_count = 1,
			line_length = inputs.line_length and inputs.line_length or 8,
			axially_symmetrical = false,
			run_mode = inputs.run_mode and inputs.run_mode or "forward",
			shift = { 0, -1.5 },
		}
	}
}
end



function Artillery_mk1_sheet(inputs)
return
{
	layers = 
	{
		{
			filename = "__Additional-Turret__/graphics/entity/artillery-test-sheet.png",
			priority = "medium",
			width = 260,
			height = 295,
			direction_count = 1,
			frame_count = 42,
			line_length = 7,
			axially_symmetrical = false,
			run_mode = inputs.run_mode and inputs.run_mode or "forward",
			shift = Artillery_mk1_shift,
		},
	}
}
end

function Artillery_mk1_attack_sheet(inputs)
return
{
	layers = 
	{
		{
			filename = "__Additional-Turret__/graphics/entity/artillery-test-attack-sheet.png",
			priority = "medium",
			width = 260,
			height = 295,
			direction_count = 1,
			frame_count = 11,
			line_length = 7,
			axially_symmetrical = false,
			-- run_mode = "forward",
			shift = Artillery_mk1_shift,
		},
	}
}
end

function Artillery_mk1_attack(inputs)
return
{
	layers = 
	{
		{
			filename = "__Additional-Turret__/graphics/entity/artillery-test-attack.png",
			priority = "medium",
			width = 260,
			height = 295,
			direction_count = 1,
			frame_count = 1,
			axially_symmetrical = false,
			shift = Artillery_mk1_shift,
		}
	}
}
end

function Artillery_mk2_attack(inputs)
return
{
	layers = 
	{
		{
			filename = "__Additional-Turret__/graphics/entity/artillery-test-attack-2.png",
			priority = "medium",
			width = 260,
			height = 295,
			direction_count = 1,
			frame_count = 1,
			axially_symmetrical = false,
			shift = Artillery_mk2_shift,
		}
	}
}
end

function blank(inputs)
return
{
	layers = 
	{
		{
			filename = "__base__/graphics/terrain/blank.png",
			priority = "medium",
			width = 1,
			height = 1,
			direction_count = 1,
			frame_count = 1,
			axially_symmetrical = false,
			shift = Artillery_mk2_shift,
		}
	}
}
end



data:extend({
{
	type = "ammo-turret",
	name = "artillery-turret",
	icon = "__Additional-Turret__/graphics/icon/artillery-turret-1.png",
	flags = {"placeable-player", "player-creation"},
	minable = {mining_time = 2, result = "artillery-turret"},
	max_health = 700,
	resistances =
	{
		{ type = "physical", decrease = 6, percent = 30, },
	},	
	corpse = "small-remnants",
	collision_box = {{-0.7, -0.7 }, {0.7, 0.7 }},
	selection_box = {{-1, -1 }, {1, 1}},
	rotation_speed = 0.008,
	preparing_speed = 0.04,
	folding_speed = 0.04,
	dying_explosion = "medium-explosion",
	inventory_size = 1,
	automated_ammo_count = 10,
	attacking_speed = 0.1,
	
	folded_animation = artillery_turret_sheet{direction_count = 8, line_length = 1},
	preparing_animation = artillery_turret_sheet{direction_count = 8, line_length = 1},
	prepared_animation = artillery_turret_sheet{},
	attacking_animation = artillery_turret_sheet{},
	folding_animation = artillery_turret_sheet{direction_count = 8, line_length = 1, run_mode = "backward"},

	
	vehicle_impact_sound =	{ filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
	
	-- prepare_range = 160,
	-- shoot_in_prepare_state = true,
	
	attack_parameters =
	{
		type = "projectile",
		-- warmup = 160,
		ammo_category = "artillery-shell",
		cooldown = 600,
		projectile_creation_distance = 2.5,
		projectile_center = {0, -1.5},
		damage_modifier = 1,
		shell_particle =
		{
			name = "shell-particle",
			direction_deviation = 0.1,
			speed = 0.1,
			speed_deviation = 0.03,
			center = {0, 0},
			creation_distance = -1.925,
			starting_frame_speed = 0.2,
			starting_frame_speed_deviation = 0.1
		},
		range = 150,
		min_range = 70,
		sound =
		{
			{
				filename = "__base__/sound/fight/tank-cannon.ogg",
				volume = 1.0
			}
		},
	},

	call_for_help_radius = 300,
},

{
	type = "ammo-turret",
	name = "Artillery_mk1",
	icon = "__Additional-Turret__/graphics/icon/artillery-turret-2.png",
	flags = { "placeable-player", "player-creation"},
	minable = { mining_time = 10, result = "Artillery_mk1" },
	max_health = 3500,
	resistances =
	{
		{ type = "physical", decrease = 20, percent = 60, },
	},
	corpse = "big-remnants",
	collision_box = {{ -3.7, -2.7}, {3.7, 2.7}},
	selection_box = {{ -4, -3}, {4, 3}},
	
	rotation_speed = 1,
	preparing_speed = 0.004,
	folding_speed = 0.004,
	attacking_speed = 1,
	-- ending_attack_speed = 0.01,
	
	dying_explosion = "big-explosion",
	inventory_size = 1,
	automated_ammo_count = 10,
    -- attacking_animation_fade_out = 10,
	
	folded_animation = Artillery_mk1_sheet{},
	preparing_animation = Artillery_mk1_sheet{},
	prepared_animation = Artillery_mk1_attack{},
	attacking_animation = Artillery_mk1_attack{},
	-- ending_attack_animation = Artillery_mk1_attack_sheet{},
	folding_animation = Artillery_mk1_sheet{run_mode = "backward"},

	vehicle_impact_sound =	{ filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },

	attack_parameters =
	{
		type = "projectile",
		ammo_category = "artillery-test-shell",
		cooldown = 1800, --3600
		projectile_creation_distance = 0,
		projectile_center = {0, -5.625}, -- -2.25 -> 3.625
		damage_modifier = 1,
		range = 500,
		min_range = 100,
		sound =
		{
			{
				filename = "__base__/sound/fight/tank-cannon.ogg",
				volume = 1.0
			}
		},
	},
	call_for_help_radius = 1000,
},

--Range Overlay
{
	type = "ammo-turret",
	name = "Artillery_mk2_area",
	icon = "__Additional-Turret__/graphics/icon/artillery-turret-3.png",
	flags = {"placeable-neutral", "placeable-player", "player-creation"},
	open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
	close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
	order = "b[turret]-c[artillery-turret]-c[experimental]",
	max_health = 3500,
	resistances =
	{
		{ type = "physical", decrease = 20, percent = 60, },
	},
	corpse = "big-remnants",
	dying_explosion = "massive-explosion",
	
	collision_box = {{ -3.7, -2.7}, {3.7, 2.7}},
	selection_box = {{ -4, -3}, {4, 3}},
	
	folding_speed = 0.04,
	inventory_size = 1,
	automated_ammo_count = 10,
	
	folded_animation = Artillery_mk2_attack{},
	folding_animation = Artillery_mk2_attack{},

	attack_parameters =
	{
		type = "projectile",
		ammo_category = "artillery",
		cooldown = 360,
		range = 500,
		min_range = 100,
		projectile_creation_distance = 1.8,
		action ={},
	},
	call_for_help_radius = 40
},

--Artillery
{
	type = "container",
	name = "Artillery_mk2",
	icon = "__Additional-Turret__/graphics/icon/artillery-turret-3.png",
	flags = {"placeable-neutral", "player-creation", "placeable-off-grid", "not-repairable"},
	minable = { mining_time = 10, result = "Artillery_mk2_area" },
	selectable_in_game = false,
	open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
	close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
	max_health = 3500,
	resistances =
	{
		{ type = "physical", decrease = 20, percent = 60, },
	},
	corpse = "big-remnants",
	dying_explosion = "big-explosion",
	collision_box = {{ 0, 0}, {0, 0}},
	selection_box = {{ 0, 0}, {0, 0}},
	order = "b[turret]-c[artillery-turret]-c[experimental]",
	inventory_size = 1,
	
	picture = blank{},

	call_for_help_radius = 40
},

--Inventory
{
	type = "ammo-turret",
	name = "Artillery_mk2i",
	icon = "__Additional-Turret__/graphics/icon/artillery-turret-3.png",
	flags = {"placeable-neutral", "placeable-player", "player-creation"},
	open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
	close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
	minable = { mining_time = 10, result = "Artillery_mk2_area" },
	order = "b[turret]-c[artillery-turret]-c[experimental]",
	max_health = 3500,
	resistances =
	{
		{ type = "physical", decrease = 20, percent = 60, },
	},
	corpse = "big-remnants",
	dying_explosion = "massive-explosion",
	collision_box = {{ -3.7, -2.7}, {3.7, 2.7}},
	selection_box = {{ -4, -3}, {4, 3}},
	folding_speed = 0.04,
	inventory_size = 1,
	automated_ammo_count = 10,
	
	folded_animation = Artillery_mk2_attack{},
	folding_animation = Artillery_mk2_attack{},
	
	vehicle_impact_sound =	{ filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },

	attack_parameters =
	{
		type = "projectile",
		ammo_category = "artillery",
		cooldown = 1500,
		range = 0,
		projectile_creation_distance = 1.8,
		action ={},
	},
	call_for_help_radius = 40
},

--Radar
{
	type = "radar",
	name = "Artillery_mk2r",
	icon = "__Additional-Turret__/graphics/icon/artillery-turret-3.png",
	flags = {"placeable-neutral", "player-creation", "placeable-off-grid", "not-repairable"},
	selectable_in_game = false,
	minable = {mining_time = 10, result = "Artillery_mk2_area"},
	max_health = 3500,
	resistances =
	{
		{ type = "physical", decrease = 20, percent = 60, },
	},
	corpse = "big-remnants",
	dying_explosion = "massive-explosion",
	collision_box = {{ 0, 0}, {0, 0}},
	selection_box = {{ 0, 0}, {0, 0}},
	order = "b[turret]-c[artillery-turret]-c[experimental]",
	energy_per_sector = "100MJ",
	max_distance_of_nearby_sector_revealed = 7,
	max_distance_of_sector_revealed = 20,
	energy_per_nearby_scan = "1MW",
	energy_source =
	{
		type = "electric",
		usage_priority = "secondary-input"
	},
	energy_usage = "10MW",
	pictures = blank{},

},

--------target capsule entity
{
	type = "smoke-with-trigger",
	name = "target-cloud",
	flags = {"not-on-map"},
	show_when_smoke_off = true,
	animation =
	{
		filename = "__core__/graphics/shoot-cursor-red.png",
		priority = "low",
		width = 258,
		height = 183,
		frame_count = 1,
		animation_speed = 1,
		line_length = 1,
		scale = 1,
	},
	slow_down_factor = 0,
	affected_by_wind = false,
	cyclic = true,
	duration = 60 * 15, --15sec
	fade_away_duration = 2 * 60,
	spread_duration = 10,
	color = { r = 0.9, g = 0.2, b = 0.2 },
},
{
	type = "projectile",
	name = "target-capsule",
	flags = {"not-on-map"},
	acceleration = 0.005,
	action =
	{
		type = "direct",
		action_delivery =
		{
			type = "instant",
			target_effects =
			{
				type = "create-entity",
				trigger_created_entity = true,
				entity_name = "target-cloud"
			}
		}
	},
	light = {intensity = 0.5, size = 4},
	animation =
	{
		filename = "__base__/graphics/entity/poison-capsule/poison-capsule.png",
		frame_count = 1,
		width = 32,
		height = 32,
		priority = "high",
		tint = {r=1.0, g=0.2, b=0.2},
	},
	shadow =
	{
		filename = "__base__/graphics/entity/poison-capsule/poison-capsule-shadow.png",
		frame_count = 1,
		width = 32,
		height = 32,
		priority = "high"
	},
	smoke = capsule_smoke,
},
})




------------recipe
data:extend({
{
	type = "recipe",
	name = "artillery-turret",
	enabled = false,
	energy_required = 20,
	ingredients = 
	{
		{"cannon-turret", 3},
		{"advanced-circuit", 5},
		{"steel-plate", 10},
	},
	result = "artillery-turret",
},
{
	type = "recipe",
	name = "Artillery_mk1",
	enabled = false,
	energy_required = 40,
	ingredients = 
	{
		{"steel-plate", 700},
		{"concrete", 300},
		{"pipe", 100},
		{"processing-unit", 100},
		{"engine-unit", 200},
		{"radar", 20},
	},
	result = "Artillery_mk1",
},
{
	type = "recipe",
	name = "artillery-test-shell",
	enabled = false,
	energy_required = 20,
	ingredients =
	{
		{"artillery-shell", 5},
		{"piranha-core", 6},
		{"explosives", 5},
		{"steel-plate", 5},
		
	},
	result = "artillery-test-shell",
},
{
	type = "recipe",
	name = "artillery-shell",
	enabled = false,
	energy_required = 12,
	ingredients =
	{
		{"piranha-core", 5},
		{"steel-plate", 5},
		{"explosives", 4},
		{"plastic-bar", 3},
	},
	result = "artillery-shell",
},
{
	type = "recipe",
	name = "Artillery_mk2_area",
	enabled = false,
	energy_required = 60,
	ingredients = 
	{
		{"Artillery_mk1", 1},
		{"battery", 10},
		{"radar", 20},
		{"processing-unit", 30},
		{"alien-artifact", 50}
	},
	result = "Artillery_mk2_area",
},
{
	type = "recipe",
	name = "Artillery_mk2_Ammo",
	enabled = false,
	energy_required = 20,
	ingredients = 
	{
		{"artillery-test-shell", 5},
		{"explosives", 7},
		{"steel-plate", 5},
		{"alien-artifact", 10}
	},
	result = "Artillery_mk2_Ammo",
},
{
	type = "recipe",
	name = "target-capsule",
	enabled = false,
	energy_required = 12,
	ingredients = 
	{
		{"poison-capsule", 1},
		{"slowdown-capsule", 1},
		{"explosives", 5},
		{"alien-artifact", 5}
	},
	result = "target-capsule",
},
})




---------------item
data:extend({
{
	type = "item",
	name = "artillery-turret",
	icon = "__Additional-Turret__/graphics/icon/artillery-turret-1.png",
	flags = {"goes-to-quickbar"},
	subgroup = "defensive-structure",
	order = "b[turret]-c[artillery-turret]-a[light]",
	place_result = "artillery-turret",
	stack_size = 20,
},
{
	type = "item",
	name = "Artillery_mk1",
	icon = "__Additional-Turret__/graphics/icon/artillery-turret-2.png",
	flags = {"goes-to-quickbar"},
	subgroup = "defensive-structure",
	order = "b[turret]-c[artillery-turret]-b[heavy]",
	place_result = "Artillery_mk1",
	stack_size = 1,
},
{
	type = "item",
	name = "Artillery_mk2_area",
	icon = "__Additional-Turret__/graphics/icon/artillery-turret-3.png",
	flags = {"goes-to-quickbar"},
	subgroup = "defensive-structure",
	order = "b[turret]-c[artillery-turret]-c[experimental]",
	place_result = "Artillery_mk2_area",
	stack_size = 1,
},
{
	type = "ammo",
	name = "Artillery_mk2_Ammo",
	icon = "__Additional-Turret__/graphics/icon/artillery-shell-3.png",
	flags = {"goes-to-main-inventory"},
	ammo_type =
	{
		category = "artillery",
		target_type = "direction",
		action =
		{
			type = "direct",
			action_delivery =
			{
				type = "projectile",
				projectile = "Artillery_mk2_Ammo",
				starting_speed = 0.5,
				source_effects =
				{
					type = "create-explosion",
					entity_name = "explosion"
				}
			}
		},
	},
	subgroup = "ammo",
	order = "e[artillery-shell]-c[experimental]",
	stack_size = 10
},
{
	type = "capsule",
	name = "target-capsule",
	icon = "__Additional-Turret__/graphics/icon/target-capsule.png",
	flags = {"goes-to-quickbar"},
	capsule_action =
	{
		type = "throw",
		attack_parameters =
		{
			type = "projectile",
			ammo_category = "capsule",
			cooldown = 60*10,
			projectile_creation_distance = 0.6,
			range = 40,
			ammo_type =
			{
				category = "capsule",
				target_type = "position",
				action =
				{
					type = "direct",
					action_delivery =
					{
						type = "projectile",
						projectile = "target-capsule",
						starting_speed = 0.3
					}
				}
			}
		}
	},
	subgroup = "capsule",
	order = "g[target-capsule]",
	stack_size = 20
},
})



