require ("util")
require ("libs/util_ext")
require ("libs/event")

local loaded



--------------------------------------------------------------------
script.on_load(function()

	if global.Artillery_Table ~= nil then
		Event.register(defines.events.on_tick, function(event) end)
	end
	
end)

script.on_init(function()
	
end)

script.on_configuration_changed(function()
	
	if global.Artillery_Table ~= nil then
		Event.register(defines.events.on_tick, function(event) end)
	end
	
end)
---------------------------------------------------------------------



script.on_event({defines.events.on_built_entity,}, function(event) On_Built(event) end)
script.on_event({defines.events.on_robot_built_entity,}, function(event) On_Built(event) end)

script.on_event(defines.events.on_player_created, function(event)
	local player = game.players[event.player_index]
end)

---------------------------------------------
function On_Built(event)
		local entity = event.created_entity
	--- Artillery has been built
	if entity.name == "Artillery_mk2_area" then
	
	local New_Artillery
	local New_ArtilleryI
	local New_ArtilleryR
	
	--writeDebug("Artillery has been built")				
		local surface = entity.surface
		local force = entity.force
		local position = entity.position
		
		if global.Artillery_Table == nil then
			global.Artillery_Table = {}
			Event.register(defines.events.on_tick, function(event) end)
		end
		
		if #global.Artillery_Table > 9 then
			event.created_entity.destroy()
			writeDebug("Not built over 10")
			local player = game.players[event.player_index]
			player.insert({name = "Artillery_mk2_area"})
		else
			New_Artillery	= surface.create_entity({name = "Artillery_mk2", position = position, direction = event.created_entity.direction, force = force})
			New_ArtilleryI = surface.create_entity({name = "Artillery_mk2".."i", position = position, direction = event.created_entity.direction, force = force})
			New_ArtilleryR = surface.create_entity({name = "Artillery_mk2".."r", position = position, direction = event.created_entity.direction, force = force})
			
			New_ArtilleryI.health = event.created_entity.health
			
			event.created_entity.destroy()
			
			New_Artillery.destructible = false
			New_Artillery.operable = false
			New_Artillery.minable = false
			
			New_ArtilleryI.operable = true
			New_ArtilleryI.minable = true
			
			New_ArtilleryR.operable = false
			New_ArtilleryR.destructible = false
			New_ArtilleryR.minable = false
			
			table.insert(global.Artillery_Table, {New_Artillery,New_ArtilleryI,New_ArtilleryR,10,10,0})
		end
	end
end

----- Artillery Stuff
 Event.register(defines.events.on_tick, function(event)	 

	if global.Artillery_Table ~= nil then
		if global.Artillery_Counter == 0 or global.Artillery_Counter == nil then
			global.Artillery_Counter = 60		
			for ix, vx in pairs(global.Artillery_Table) do
				if vx[1].valid and vx[2].valid and vx[3].valid then
					-- writeDebug("vx4.1 = " .. vx[4])
					vx[4]=vx[4]-1
					-- writeDebug("vx4.2 = " .. vx[4])
					if global.listTarget~= nil and vx[4] > 30 then
						vx[4] = 5
					end
					if vx[4] <=0 then
						-- writeDebug("Start Attack")
						Artillery_Check(vx)
						-- writeDebug("Finish Attack")
					end
				else
					if vx[1].valid then
						vx[1].destroy()
					end
					if vx[2].valid then
						vx[2].destroy()
					end	
					if vx[3].valid then
						vx[3].destroy()
					end	
					table.remove(global.Artillery_Table, ix)
					if #global.Artillery_Table == 0 then
						global.Artillery_Table = nil
					end
				end
				
			end		
		else
			global.Artillery_Counter = global.Artillery_Counter - 1
		end
	end
	
end)


function Artillery_Check(Artillery_List)
	
	local Artillery=Artillery_List[1]
	local Artilleryi=Artillery_List[2]
	
	local inventory_1 = Artilleryi.get_inventory(1)
	local inventoryContent_1 = inventory_1.get_contents()
	local AmmoName_1
	local ammo_1 = 0
	local spawner
	local worm
	local marks
	local target
	local delay = 5
	local ammo_cannon = {"small-cannon-shell", "small-explosive-cannon-shell", "cluster-cannon-shell", "fire-cannon-shell", "fire-cluster-cannon-shell"}
	local ammo_rocket = {"small-rocket", "small-explosive-rocket", "explosive-multiple-rocket", "acid-rocket", "acid-multiple-rocket"}
	

	-- writeDebug("Artillery.name : " .. Artillery.name)
	
	if Artillery.name == "Artillery_mk2" then
	
		if inventoryContent_1 ~= nil then
			for n,a in pairs(inventoryContent_1) do
				AmmoName_1=n
				ammo_1=a
			end
		end
		
		if ammo_1 > 0 and Artillery_List[3].energy > 0 then	
				
			local maxrange = 500
			local minrange = 100
			local grid = 300
			local gap = 200
			local pos = Artillery.position
			local area
			local nnn
			local mmm
			local x1
			local y1
			local x2
			local y2
			
			-- nnn = 10 11 20 21 30 31 40 41
			-- nnn = 100 110 120 130 200 210 220 230 200 310 320 330 400 410 420 430
			-- counting -> mmm(level) = 0 1 or 0 1 2 3 / nnn(direction) = 1 2 3 4
			
			if Artillery_List[5] == nil and Artillery_List[6] == nil then
				Artillery_List[5] = 10
				Artillery_List[6] = 0
			end
			-- writeDebug("Count : " .. Artillery_List[6])
			if Artillery_List[6] > 16 then
				if Artillery_List[5] < 100 then
					Artillery_List[5] = 100
					Artillery_List[6] = 0
				else
					Artillery_List[5] = 10
					Artillery_List[6] = 0
				end
			end
			
			nnn = Artillery_List[5]
			-- writeDebug("nnn(o) : " .. nnn)
			
			if nnn < 100 then
				
				mmm = nnn%10
				nnn = math.floor(nnn/10)
				
				if nnn == 1 then
					x1 = - grid + gap * mmm
					y1 = - grid
				elseif nnn == 2 then
					x1 = minrange
					y1 = - grid + gap * mmm
				elseif nnn == 3 then
					x1 = minrange - gap * mmm
					y1 = minrange
				elseif nnn == 4 then
					x1 = - grid
					y1 = minrange - gap * mmm
				end
				
				if mmm == 0 then
					Artillery_List[5] = Artillery_List[5] + 1
				else--if mmm == 1 then
					Artillery_List[5] = Artillery_List[5] + 9
				end
				
				if Artillery_List[5] == 50 then
					Artillery_List[5] = 10
				end
				
			else--if nnn >= 100 then
				
				mmm = (nnn/10)%10
				nnn = math.floor(nnn/100)
				
				if nnn == 1 then
					x1 = - maxrange + gap * mmm
					y1 = - maxrange
				elseif nnn == 2 then
					x1 = grid
					y1 = - maxrange + gap * mmm
				elseif nnn == 3 then
					x1 = grid - gap * mmm
					y1 = grid
				elseif nnn == 4 then
					x1 = - maxrange
					y1 = grid - gap * mmm
				end
				
				if mmm == 0 or  mmm == 1 or  mmm == 2 then
					Artillery_List[5] = Artillery_List[5] + 10
				else--if mmm == 3 then
					Artillery_List[5] = Artillery_List[5] + 70
				end
				
				if Artillery_List[5] == 500 then
					Artillery_List[5] = 10
				end
				
			end
			
			x2 = x1 + gap
			y2 = y1 + gap
			
			area = {{pos.x + x1, pos.y + y1}, {pos.x + x2, pos.y + y2}}
			
			-- writeDebug("nnn = " .. nnn)
			-- writeDebug("mmm = " .. mmm)
			-- writeDebug("x1 / y1 = " .. x1 .. " / " .. y1)
			-- writeDebug("x2 / y2 = " .. x2 .. " / " .. y2)
			
			
			marks = {}
			if global.listTarget ~= nil then
				marks = global.listTarget
			end
			--writeDebug("marks = " .. #marks)
			-- Check Marks
			if #marks > 0 then
				for k,enemy in pairs(marks) do
					if enemy.valid == false then
						table.remove(global.listTarget, k)
						if #global.Artillery_Table == 0 then
							global.listTarget = nil
						end
						break
					end
					target={enemy}
				end
			end
			
			--Find Spawner And Worm Target
			if target == nil then
				
				spawner = Artillery.surface.find_entities_filtered({area = area, type = "unit-spawner"})
				-- writeDebug("The Number of Spawners are: " .. #spawner)
				if #spawner > 0 then
				
					target = {spawner[math.random(#spawner)]}
					-- writeDebug("Finish Find Spawner Enemy")
					
				else
					
					worm = Artillery.surface.find_entities_filtered({area = area, type = "turret"})
					-- writeDebug("The Number of Worms are: " .. #worm)
					if #worm > 0 then
						target = {worm[math.random(#worm)]}
					end
					-- writeDebug("Finish Find Worm Enemy")
					
				end
			end
			

			--Fire at Enemy
			if target ~= nil then
				Artillery_List[6] = 0
				if #marks > 0 then
					offsetR = 10
				else
					offsetR = 5
				end
				local offset1 = math.random(0,offsetR) * math.sin(math.random()*(math.pi*2))
				local offset2 = math.random(0,offsetR) * math.sin(math.random()*(math.pi*2))
				local offsetX = target[1].position.x + offset1
				local offsetY = target[1].position.y + offset2
				-- local toleranceX = math.abs(pos.x - target[1].position.x) + offset1
				-- local toleranceY = math.abs(pos.y - target[1].position.y) + offset2
				
				local newtarget = {offsetX, offsetY}
				--writeDebug("Set Random Target")
				local speed = (((math.abs(pos.x - target[1].position.x) + offset1)^2 + (math.abs(pos.y - target[1].position.y) + offset2)^2)^0.5) / 240
				
				
				
				--writeDebug("Start Fire")
				Artillery.surface.create_entity({name="ammo-action", position = {x = pos.x, y = pos.y - 5.625}, force = Artillery.force, target = {x = pos.x, y = pos.y - 100}, speed= 2})
				Artillery.surface.create_entity({name="ammo-shadow", position = {x = pos.x, y = pos.y}, force = Artillery.force, target = newtarget, speed = speed})
				Artillery.surface.create_entity({name="muzzle-flash", position = {x = pos.x, y = pos.y - 5.625}, force = Artillery.force, target = {x = pos.x, y = pos.y - 5.25}, speed= 0.01})
				Artillery.surface.create_entity({name=AmmoName_1, position = {x = offsetX, y = offsetY - 240}, force = Artillery.force, target = newtarget, speed= 1})
				
				
				Artillery.surface.pollute(Artillery.position,5000)
				
				local units = Artillery.surface.find_enemy_units(newtarget, 30)
				for _, unit in pairs(units) do
					unit.set_command({type=defines.command.attack, target=Artillery})
				end
				
				--Reduce Ammo
				ammo_1 = ammo_1-1
				inventory_1.clear()
				if ammo_1 > 0 then
					inventory_1.insert({name = AmmoName_1, count = ammo_1})
				end
				
				--Delay between shots
				if #marks > 0 then
					delay = 10
				else
					delay = 25 --25
				end
				
			else
				if Artillery_List[5] < 100 then
					Artillery_List[6] = Artillery_List[6] + 1
					delay = 2
				else
					Artillery_List[6] = Artillery_List[6] + 1
					delay = 10
				end
			end
		end
		
	elseif Artillery.name == "capsule_laser_turret" then
		
		--only create and destroy
		
	elseif Artillery.name == "cannon_rocket_turret" then
		
		--ammo solt
		--check ammo and energy
		--scan enemy
		--attack enemy
		--agro and pollute
		--ammo count
		--delay
		
	end
	Artillery_List[4]=delay
end


--- DeBug Messages 
function writeDebug(message)
	for i, player in pairs(game.players) do
		player.print(tostring(message))
	end
end


local function AddMark(event)
--writeDebug("Making Target")
	if event.entity.name == 'target-cloud' then
		if global.listTarget == nil then
			global.listTarget = {}
		end
		table.insert(global.listTarget, event.entity)
		--writeDebug("Insert Target")
	end
end

script.on_event(defines.events.on_trigger_created_entity, AddMark)