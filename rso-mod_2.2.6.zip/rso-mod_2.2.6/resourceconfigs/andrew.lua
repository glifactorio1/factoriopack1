function fillAndrewConfig()
   
	config["bauxite-ore"] = {
		type="resource-ore",
		
		allotment=50,
		spawns_per_region={min=1, max=1},
		richness=12000,
		size={min=8, max=15},
		min_amount = 1000,
		
        starting={richness=7000, size=10, probability=1},
	}
   
    config["clay"] = 
	{
        type="resource-ore",
       
        allotment=50,
        spawns_per_region={min=1, max=1},
        richness=10000,
        size={min=8, max=15},
        min_amount = 250,
       
        starting={richness=4000, size=10, probability=1},
    }

end