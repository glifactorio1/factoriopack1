data:extend({
  {
    type = "technology",
    name = "Bergius-Process",
    icon = "__Bergius_Process__/graphics/bergius-technology.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "bergius-process"
      },
	  {
        type = "unlock-recipe",
        recipe = "coal-liquefaction"
      },
	  
     
    },
    prerequisites = {"oil-processing"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1}
      },
      time = 30
    },
    order = "d-a-c",
  },
  }
  )
  