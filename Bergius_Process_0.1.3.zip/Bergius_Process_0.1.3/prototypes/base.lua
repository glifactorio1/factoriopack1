data:extend(
{
		{
			type = "fluid",
			name = "liquefied-coal",
			default_temperature = 25,
			max_temperature = 100,
			heat_capacity = "11.1KJ",
			base_color = {r=0, g=0.25, b=0.6},
			flow_color = {r=0, g=0, b=0},
			icon = "__Bergius_Process__/graphics/liquified-coal-6.png",
			order = "liquified-coal",
			pressure_to_speed_ratio = 0.4,
			flow_to_energy_ratio = 0.6
		},
	})
	

