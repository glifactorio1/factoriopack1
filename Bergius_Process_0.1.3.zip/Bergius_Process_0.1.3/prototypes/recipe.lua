data:extend(
{ 
  
  {
    type = "recipe",
    name = "bergius-process",
    energy_required = 5,
    enabled = "false",
	order = "a[oil-processing]-c[burgius-process]",
    category = "oil-processing",
    ingredients =
    {

		{type="fluid", name="heavy-oil", amount=2},
		{type="fluid", name="liquefied-coal", amount=8},

    },
      results=
    {
      {type="fluid", name="heavy-oil", amount=3},
      {type="fluid", name="light-oil", amount=1},
      {type="fluid", name="petroleum-gas", amount=2}
    },
	  main_product= "",
	  icon = "__Bergius_Process__/graphics/bergius-process-2.png",
    subgroup = "fluid-recipes"
	  },
	  
	  
	 
  
    {
    type = "recipe",
    name = "coal-liquefaction",
	category = "chemistry",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {type="fluid", name="water", amount=6},
	  {type="item", name="coal", amount=6}
    },
    results=
    {
      {type="fluid", name="liquefied-coal", amount=6}
    },
    main_product= "",
    icon = "__Bergius_Process__/graphics/liquefied-coal-2.png",
    subgroup = "fluid-recipes",
    order = "b[fluid-chemistry]-h"
  },
}
)
--Thanks to BlakeMW/FreeER for this method of enabling productivity modules
for k, v in pairs(data.raw.module) do
  if v.name:find("productivity%-module") and v.limitation then
    for _, recipe in ipairs({"bergius-process", "coal-liquefaction"}) do
      table.insert(v.limitation, recipe)
    end
  end
end