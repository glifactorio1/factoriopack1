data:extend(
{  -- you can change, our increase things if you want--
	{
		type = "recipe",
		name = "compra-01",				
		energy_required = 3.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=20},
        },		
		result = "alien-artifact",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/alien-artifact.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-02",				
		energy_required = 4.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=15},
        },		
		result = "advanced-circuit",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/advanced-circuit.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-03",				
		energy_required = 6.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=50},
        },		
		result = "processing-unit",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/processing-unit.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-04",				
		energy_required = 5.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=20},
        },		
		result = "battery",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/battery.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-05",				
		energy_required = 6.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=30},
        },		
		result = "engine-unit",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/engine-unit.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-06",				
		energy_required = 6.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=50},
        },		
		result = "electric-engine-unit",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/electric-engine-unit.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-07",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=8},
        },		
		result = "firearm-magazine",
		result_count = 15,
		category = "buy",
		icon = "__base__/graphics/icons/firearm-magazine.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-08",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=13},
        },		
		result = "piercing-rounds-magazine",
		result_count = 15,
		category = "buy",
		icon = "__base__/graphics/icons/piercing-rounds-magazine.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-09",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=8},
        },		
		result = "shotgun-shell",
		result_count = 10,
		category = "buy",
		icon = "__base__/graphics/icons/shotgun-shell.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-10",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=16},
        },		
		result = "piercing-shotgun-shell",
		result_count = 15,
		category = "buy",
		icon = "__base__/graphics/icons/piercing-shotgun-shell.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-11",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=40},
        },		
		result = "cannon-shell",
		result_count = 10,
		category = "buy",
		icon = "__base__/graphics/icons/cannon-shell.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-12",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=55},
        },		
		result = "explosive-cannon-shell",
		result_count = 10,
		category = "buy",
		icon = "__base__/graphics/icons/explosive-cannon-shell.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-13",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=40},
        },		
		result = "rocket",
		result_count = 10,
		category = "buy",
		icon = "__base__/graphics/icons/rocket.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-14",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=60},
        },		
		result = "explosive-rocket",
		result_count = 10,
		category = "buy",
		icon = "__base__/graphics/icons/explosive-rocket.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-15",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=15},
        },		
		result = "flame-thrower-ammo",
		result_count = 10,
		category = "buy",
		icon = "__base__/graphics/icons/flame-thrower-ammo.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-16",				
		energy_required = 5.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=85},
        },		
		result = "combat-shotgun",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/combat-shotgun.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-17",				
		energy_required = 5.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=100},
        },		
		result = "rocket-launcher",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/rocket-launcher.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-18",				
		energy_required = 5.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=120},
        },		
		result = "flame-thrower",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/flame-thrower.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-19",				
		energy_required = 10.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=250},
        },		
		result = "car",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/car.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "compra-20",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="cryamond", amount=400},
        },		
		result = "tank",
		result_count = 1,
		category = "buy",
		icon = "__base__/graphics/icons/tank.png",
	    order = "0", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "venda-01",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="alien-artifact", amount=1},
        },		
		result = "cryamond",
		result_count = 10,
		category = "buy",
		icon = "__NPUtils__/graphics/icon/cryamond-icon.png",
	    order = "2", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "venda-02",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="advanced-circuit", amount=1},
        },		
		result = "cryamond",
		result_count = 6,
		category = "buy",
		icon = "__NPUtils__/graphics/icon/cryamond-icon.png",
	    order = "2", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "venda-03",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="processing-unit", amount=1},
        },		
		result = "cryamond",
		result_count = 20,
		category = "buy",
		icon = "__NPUtils__/graphics/icon/cryamond-icon.png",
	    order = "2", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "venda-04",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="battery", amount=1},
        },		
		result = "cryamond",
		result_count = 8,
		category = "buy",
		icon = "__NPUtils__/graphics/icon/cryamond-icon.png",
	    order = "2", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "venda-05",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="engine-unit", amount=1},
        },		
		result = "cryamond",
		result_count = 12,
		category = "buy",
		icon = "__NPUtils__/graphics/icon/cryamond-icon.png",
	    order = "2", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "venda-06",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="electric-engine-unit", amount=1},
        },		
		result = "cryamond",
		result_count = 21,
		category = "buy",
		icon = "__NPUtils__/graphics/icon/cryamond-icon.png",
	    order = "2", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "venda-07",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="explosives", amount=1},
        },		
		result = "cryamond",
		result_count = 5,
		category = "buy",
		icon = "__NPUtils__/graphics/icon/cryamond-icon.png",
	    order = "2", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "venda-08",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="science-pack-1", amount=10},
        },		
		result = "cryamond",
		result_count = 2,
		category = "buy",
		icon = "__NPUtils__/graphics/icon/cryamond-icon.png",
	    order = "2", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "venda-09",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="science-pack-2", amount=5},
        },		
		result = "cryamond",
		result_count = 6,
		category = "buy",
		icon = "__NPUtils__/graphics/icon/cryamond-icon.png",
	    order = "2", group = "NPUtils", subgroup = "market",
	},
	{
		type = "recipe",
		name = "venda-10",				
		energy_required = 15.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="science-pack-3", amount=1},
        },		
		result = "cryamond",
		result_count = 18,
		category = "buy",
		icon = "__NPUtils__/graphics/icon/cryamond-icon.png",
	    order = "2", group = "NPUtils", subgroup = "market",
	},
	
}
)


