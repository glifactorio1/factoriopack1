data:extend(
{
  { type="item-group", name="NPUtils", icon="__NPUtils__/graphics/icon/NPU.png", inventory_order="f", order="f" },

  {type = "item-subgroup",name = "electric-blast-furnace",group = "NPUtils",order = "c"},
  {type = "item-subgroup",name = "blast-furnace",group = "NPUtils",order = "d"},
  {type = "item-subgroup",name = "alientuff",group = "NPUtils",order = "z"},
  {type = "item-subgroup",name = "fuel",group = "NPUtils",order = "b"},
  {type = "item-subgroup",name = "market",group = "NPUtils",order = "x"},
  
------------------------------------------------------------------------------------------------------------------------
  { type="item-group", name="NPUtils-War", icon="__NPUtils__/graphics/war/icon/NPU-War.png", inventory_order="g", order="g" },
  
  {type = "item-subgroup",name = "n-ammunition",group = "NPUtils-War",order = "a"},
  {type = "item-subgroup",name = "n-machine-2",group = "NPUtils-War",order = "b"},
  {type = "item-subgroup",name = "n-machine",group = "NPUtils-War",order = "c"},
  {type = "item-subgroup",name = "n-car",group = "NPUtils-War",order = "d"},
  
-------------------------------------------------------------------------------------------------------------------------  
  {type = "recipe-category",name = "blast-furnace"},
  {type = "recipe-category",name = "purification-chamber"},
  {type = "recipe-category",name = "washer-chamber"},
  {type = "recipe-category",name = "enrichment-chamber"},
  {type = "recipe-category",name = "casting-chamber"},
  {type = "recipe-category",name = "forge-chamber"},
  {type = "recipe-category",name = "stilling"},
  {type = "recipe-category",name = "chunk-miner"},
  {type = "recipe-category",name = "oil-burner"},
  {type = "recipe-category",name = "alienplant"},
  {type = "recipe-category",name = "air-purification"},
  {type = "recipe-category",name = "crystalisation"},
  {type = "recipe-category",name = "buy"},
  {type = "recipe-category",name = "artifact-maker"},
  {type = "recipe-category",name = "farm-alien"},
  {type = "recipe-category",name = "alien-processing"},
  {type = "recipe-category",name = "n-ammo-maker"},
}
)

