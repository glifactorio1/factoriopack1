

data:extend(
{
  --Item
  {
    type = "item",
    name = "copper-boiler",
    icon = "__NPUtils__/graphics/icon/copper-boiler-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electric-blast-furnace",
    order = "b",
    place_result = "copper-boiler",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "copper-boiler",
    enabled = "true",
    ingredients = 
    {
      {"copper-plate", 20},
	  {"iron-plate", 10},
	  {"pipe", 2},
    },
    result = "copper-boiler"
  },
  --Technology

  --Entity
    {
		type = "boiler",
		name = "copper-boiler",
		icon = "__NPUtils__/graphics/icon/copper-boiler-icon.png",
		flags = {"placeable-player", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "copper-boiler"},
		max_health = 250,
		corpse = "small-remnants",
		resistances = 
		{
			{
				type = "fire",
				percent = 80
			}
		},
		working_sound =
        {
        sound =
        {
        filename = "__base__/sound/boiler.ogg",
        volume = 0.8
        },
        },
		fast_replaceable_group = "pipe",
		collision_box = {{-0.29, -0.29}, {0.29, 0.29}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		fluid_box =
		{
			base_area = 1,
			pipe_connections =
			{
				{ position = {0, -1.0} },
				{ position = {1, 0} },
				{ position = {0, 1.0} },
				{ position = {-1.0, 0} }
			},
		},
		energy_consumption = "600kW",
		burner =
		{
			effectivity = 0.7,
			fuel_inventory_size = 2,
			emissions = 0.012,
			smoke =
			{
				{
					name = "smoke",
					deviation = {0.1, 0.1},
					frequency = 1
				}
			}
		},
		structure =
		{
			left =
			{filename = "__NPUtils__/graphics/entity/copper-boiler.png",priority = "extra-high",width = 50,height = 50,shift = {0.1875, 0.1875},},
			down =
			{filename = "__NPUtils__/graphics/entity/copper-boiler.png",priority = "extra-high",width = 50,height = 50,shift = {0.1875, 0.1875},},
			left_down =
			{filename = "__NPUtils__/graphics/entity/copper-boiler.png",priority = "extra-high",width = 50,height = 50,shift = {0.1875, 0.1875},},
			right_down =
			{filename = "__NPUtils__/graphics/entity/copper-boiler.png",priority = "extra-high",width = 50,height = 50,shift = {0.1875, 0.1875},},
			left_up =
			{filename = "__NPUtils__/graphics/entity/copper-boiler.png",priority = "extra-high",width = 50,height = 50,shift = {0.1875, 0.1875},},
			right_up =
			{filename = "__NPUtils__/graphics/entity/copper-boiler.png",priority = "extra-high",width = 50,height = 50,shift = {0.1875, 0.1875},},
			t_down =
			{filename = "__NPUtils__/graphics/entity/copper-boiler.png",priority = "extra-high",width = 50,height = 50,shift = {0.1875, 0.1875},},
			t_up =
			{filename = "__NPUtils__/graphics/entity/copper-boiler.png",priority = "extra-high",width = 50,height = 50,shift = {0.1875, 0.1875},}
		},
		fire =
		{},
		burning_cooldown = 20,
		pictures = pipepictures()
	},
 }
)


