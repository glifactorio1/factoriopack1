

data:extend(
{
  --Item
  {
    type = "item",
    name = "space-market",
    icon = "__NPUtils__/graphics/icon/space-market-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "blast-furnace",
    order = "z",
    place_result = "space-market",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "space-market",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 20},
	  {"copper-plate", 12},
	  {"electronic-circuit", 12},
	  {"cryamond", 12}
    },
    result = "space-market"
  },
  --Technology

  --Entity
    {
    type = "assembling-machine",
    name = "space-market",
    icon = "__NPUtils__/graphics/icon/space-market-icon.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "space-market"},
    max_health = 800,
    corpse = "medium-remnants",
    collision_box = {{-1.3, -1.3}, {1.3, 1.3}},
	selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    crafting_categories = {"buy"},
    energy_usage = "820kW",
    ingredient_count = 4,
    crafting_speed = 1,
    energy_source = {type = "electric", input_priority = "secondary", usage_priority = "secondary-input", emissions = 0.003, },
	fast_replaceable_group = "assembling-machine",
	open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
	module_specification =
		{
			module_slots = 2
		},
		allowed_effects = {"consumption", "speed", "productivity", "pollution"},
    working_sound =
    {
    sound = {
    {
    filename = "__base__/sound/radar.ogg",
    volume = 0.8
    },
    },
    idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
    apparent_volume = 1.5,
    },
    animation =
		{
			south = { filename = "__NPUtils__/graphics/entity/space-market.png", width = 128, height = 128, shift = {0.3, -0}, frame_count = 16, line_length = 16, animation_speed=0.5, }	,							
			west  = { filename = "__NPUtils__/graphics/entity/space-market.png", width = 128, height = 128, shift = {0.3, -0}, frame_count = 16, line_length = 16, animation_speed=0.5, }	,					
			north = { filename = "__NPUtils__/graphics/entity/space-market.png", width = 128, height = 128, shift = {0.3, -0}, frame_count = 16, line_length = 16, animation_speed=0.5, }	,							
			east  = { filename = "__NPUtils__/graphics/entity/space-market.png", width = 128, height = 128, shift = {0.3, -0}, frame_count = 16, line_length = 16, animation_speed=0.5, }	,							
		},	
    },
 }
)


