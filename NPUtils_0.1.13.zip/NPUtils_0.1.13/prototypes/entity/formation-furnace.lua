

data:extend(
{
  --Item
  {
    type = "item",
    name = "formation-furnace",
    icon = "__NPUtils__/graphics/icon/formation-furnace-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "blast-furnace",
    order = "b",
    place_result = "formation-furnace",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "formation-furnace",
    enabled = "true",
    ingredients = 
    {
      {"stone-furnace", 1},
      {"iron-plate", 5},
      {"steel-plate", 8}
    },
    result = "formation-furnace"
  },
  --Technology

  --Entity
    {
    type = "assembling-machine",
    name = "formation-furnace",
    icon = "__NPUtils__/graphics/icon/formation-furnace-icon.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "formation-furnace"},
    max_health = 200,
    corpse = "medium-remnants",
	open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
    working_sound =
    {
      sound = { filename = "__base__/sound/furnace.ogg" }
    },
    resistances = 
    {
      {
        type = "fire",
        percent = 100
      }
    },
    collision_box = {{-0.7, -0.7}, {0.7, 0.7}},
    selection_box = {{-0.8, -1}, {0.8, 1}},
    crafting_categories = {"blast-furnace"},
    energy_usage = "480kW",
    ingredient_count = 2,
    crafting_speed = 1,
    energy_source =
    {
      type = "burner",
      effectivity = 1,
      fuel_inventory_size = 1,
      emissions = 0.007,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 0.5,
          position = {0, 0},
          starting_vertical_speed = 0.05
        }
      }
    },

    animation =
    {
      filename = "__NPUtils__/graphics/entity/formation-furnace.png",
      priority = "extra-high",
      width = 96,
      height = 64,
      frame_count = 1,
      shift = {0.3, 0 }
    },
    working_visualisations =
    {
      {
        north_position = { 0.078125, 0.5234375},
        west_position = { 0.078125, 0.5234375},
        south_position = { 0.078125, 0.5234375},
        east_position = { 0.078125, 0.5234375},
        animation =
        {
          filename = "__NPUtils__/graphics/entity/formation-furnace-fire.png",
          width = 23,
          height = 38,
          frame_count = 12,
        }
      },
    },
    fast_replaceable_group = "furnace"
  },
}
)


