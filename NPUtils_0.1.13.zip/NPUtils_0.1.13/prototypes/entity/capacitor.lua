

data:extend(
{
  --Item
  {
    type = "item",
    name = "capacitor",
    icon = "__NPUtils__/graphics/icon/capacitor-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electric-blast-furnace",
    order = "z",
    place_result = "capacitor",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "capacitor",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 10},
	  {"copper-plate", 30},
	  {"electronic-circuit", 4},
	  {"pure-carbon", 16},
	  {"cryamond", 4}
    },
    result = "capacitor"
  },
  --Technology

  --Entity
    {
		type = "accumulator",
		name = "capacitor",
		icon = "__NPUtils__/graphics/icon/capacitor-icon.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "capacitor"},
		max_health = 400,
		corpse = "medium-remnants",
		collision_box = {{-0.8, -0.8}, {0.8, 0.8}},
		selection_box = {{-1.1, -1.1}, {1.1, 1.1}},
		energy_source =
		{
			type = "electric",
			buffer_capacity = "15MJ",
			usage_priority = "terciary",
			input_flow_limit = "500kW",
			output_flow_limit = "600kW"
		},
		picture ={filename = "__NPUtils__/graphics/entity/capacitor-stop.png",priority = "extra-high",width = 90,height = 100,line_length = 1,frame_count = 1,	shift = {0, 0}	},
		charge_animation ={filename = "__NPUtils__/graphics/entity/capacitor-in.png",width = 90,height = 100,line_length = 8,frame_count = 8,shift = {0, 0},animation_speed = 0.2,},
		charge_cooldown = 30,
		charge_light = {intensity = 0.3, size = 11},
		discharge_animation ={filename = "__NPUtils__/graphics/entity/capacitor-out.png",width = 90,height = 100,line_length = 8,frame_count = 8,shift = {0, 0},animation_speed = 0.2,},
		discharge_cooldown = 60,
		discharge_light = {intensity = 0.7, size = 11},		
		circuit_wire_connection_point =
		{
		    shadow =
			{
				red = {0.984375, 1.10938},
				green = {0.890625, 1.10938}
			},
			wire =
			{
				red = {0.6875, 0.59375},
				green = {0.6875, 0.71875}
			}
		},
		circuit_connector_sprites = get_circuit_connector_sprites({0.46875, 0.5}, {0.46875, 0.8125}, 26),
		circuit_wire_max_distance = 15.5,
		default_output_signal = "signal-A"
	},  
 }
)


