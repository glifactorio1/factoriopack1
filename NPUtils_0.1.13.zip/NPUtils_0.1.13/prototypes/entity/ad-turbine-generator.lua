

data:extend(
{
  --Item
  {
    type = "item",
    name = "ad-turbine-generator",
    icon = "__NPUtils__/graphics/icon/ad-turbine-generator-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electric-blast-furnace",
    order = "b",
    place_result = "ad-turbine-generator",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "ad-turbine-generator",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 32},
	  {"iron-gear-wheel", 22},
	  {"copper-cable", 40},
	  {"processing-unit", 2}
    },
    result = "ad-turbine-generator"
  },
  --Technology

  --Entity
    {
    type = "generator",
		name = "ad-turbine-generator",
		icon = "__NPUtils__/graphics/icon/ad-turbine-generator-icon.png",
		flags = {"placeable-neutral","player-creation"},
		minable = {mining_time = 1, result = "ad-turbine-generator"},
		max_health = 500,
		corpse = "small-remnants",
		effectivity = 0.88,
		fluid_usage_per_tick = 1.560,
		collision_box = {{-1.3, -0.9}, {1.3, 0.9}},
		selection_box = {{-1.5, -1.0}, {1.5, 1.0}},
		fluid_box =
		{
			base_area = 1,			
			pipe_connections =
			{
				{ position = { 0,  1.5} },
				{ position = { 0, -1.5} },
			},
		},
		energy_source =
		{
			type = "electric",
			usage_priority = "secondary-output",
		},
		horizontal_animation =
		{filename = "__NPUtils__/graphics/entity/ad-turbine-generator-h.png",width = 80,height = 112,frame_count = 16,line_length = 16,shift = {0.15625, -0.1875}},
		vertical_animation =
		{filename = "__NPUtils__/graphics/entity/ad-turbine-generator-v.png",width = 112,height = 80,frame_count = 16,line_length = 16,shift = {0.3, 0.0}},		
	},
 }
)


