

data:extend(
{
  --Item
  {
    type = "item",
    name = "blast-boiler",
    icon = "__NPUtils__/graphics/icon/blast-boiler-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electric-blast-furnace",
    order = "b",
    place_result = "blast-boiler",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "blast-boiler",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 10},
	  {"copper-plate", 40},
	  {"pipe", 5}
    },
    result = "blast-boiler"
  },
  --Technology

  --Entity
    {
		type = "boiler",
		name = "blast-boiler",
		icon = "__NPUtils__/graphics/icon/blast-boiler-icon.png",
		flags = {"placeable-player", "player-creation"},
		minable = {hardness = 0.3, mining_time = 0.5, result = "blast-boiler"},
		max_health = 350,
		corpse = "small-remnants",
		resistances = 
		{
			{
				type = "fire",
				percent = 80
			}
		},
		working_sound =
        {
        sound =
        {
        filename = "__base__/sound/boiler.ogg",
        volume = 1.5
        },
		},
		collision_box = {{-1.3, -1.3}, {1.3, 1.3}},
		selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
		fluid_box =
		{
			base_area = 5,
			pipe_connections =
			{
				{ position = { 0, -2.0} },
				{ position = { 2,    0} },
				{ position = { 0,  2.0} },
				{ position = {-2,    0} }
			},
		},
		energy_consumption = "1800kW",
		burner =
		{
			effectivity = 0.8,
			fuel_inventory_size = 3,
			fuel_inventory_count = 20,
			emissions = 0.009,
			smoke =
			{
				{
					name = "smoke",
					deviation = {1.5, 1.5},
					frequency = 7,
				}
			}
		},
		structure =
		{
			left =
			{filename = "__NPUtils__/graphics/entity/blast-boiler.png",priority = "extra-high",width = 128,height = 128,shift = {0.25, -0.1},},
			down =
			{filename = "__NPUtils__/graphics/entity/blast-boiler.png",priority = "extra-high",width = 128,height = 128,shift = {0.25, -0.1},},
			left_down =
			{filename = "__NPUtils__/graphics/entity/blast-boiler.png",priority = "extra-high",width = 128,height = 128,shift = {0.25, -0.1},},
			right_down =
			{filename = "__NPUtils__/graphics/entity/blast-boiler.png",priority = "extra-high",width = 128,height = 128,shift = {0.25, -0.1},},
			left_up =
			{filename = "__NPUtils__/graphics/entity/blast-boiler.png",priority = "extra-high",width = 128,height = 128,shift = {0.25, -0.1},},
			right_up =
			{filename = "__NPUtils__/graphics/entity/blast-boiler.png",priority = "extra-high",width = 128,height = 128,shift = {0.25, -0.1},},
			t_down =
			{filename = "__NPUtils__/graphics/entity/blast-boiler.png",priority = "extra-high",width = 128,height = 128,shift = {0.25, -0.1},},
			t_up =
			{filename = "__NPUtils__/graphics/entity/blast-boiler.png",priority = "extra-high",width = 128,height = 128,shift = {0.25, -0.1},}
		},
		fire =
		{},
		burning_cooldown = 20,
		pictures = pipepictures()
	},
 }
)


