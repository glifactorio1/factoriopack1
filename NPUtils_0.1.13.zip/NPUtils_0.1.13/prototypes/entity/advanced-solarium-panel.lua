

data:extend(
{
  --Item
  {
    type = "item",
    name = "advanced-solarium-panel",
    icon = "__NPUtils__/graphics/icon/advanced-solarium-panel-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electric-blast-furnace",
    order = "c",
    place_result = "advanced-solarium-panel",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "advanced-solarium-panel",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 15},
	  {"cryamond", 30},
	  {"advanced-circuit", 5}
    },
    result = "advanced-solarium-panel"
  },
  --Technology

  --Entity
    {
    type = "solar-panel",
    name = "advanced-solarium-panel",
    icon = "__NPUtils__/graphics/icon/advanced-solarium-panel-icon.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "advanced-solarium-panel"},
    max_health = 100,
    corpse = "big-remnants",
    collision_box = {{-1.9, -1.9}, {1.9, 1.9}},
    selection_box = {{-2.0, -2.0}, {2.0, 2.0}},
    energy_source =
    {
      type = "electric",
      usage_priority = "solar"
    },
    picture =
    {
      filename = "__NPUtils__/graphics/entity/advanced-solarium-panel.png",
      priority = "high",
      width = 128,
      height = 123
    },
    production = "640kW",
    fast_replaceable_group = "solar-panel",
  },
 }
)


