

data:extend(
{
  --Item
  {
    type = "item",
    name = "half-npassemble",
    icon = "__NPUtils__/graphics/icon/half-npassemble-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "blast-furnace",
    order = "b",
    place_result = "half-npassemble",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "half-npassemble",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 10},
	  {"iron-gear-wheel", 16},
	  {"electronic-circuit", 5}
    },
    result = "half-npassemble"
  },
  --Technology

  --Entity
    {
    type = "assembling-machine",
    name = "half-npassemble",
    icon = "__NPUtils__/graphics/icon/half-npassemble-icon.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "half-npassemble"},
    max_health = 200,
    corpse = "medium-remnants",
    collision_box = {{-0.7, -0.7}, {0.7, 0.7}},
    selection_box = {{-1, -1}, {1, 1}},
    crafting_categories = {"crafting"},
    energy_usage = "280kW",
    ingredient_count = 1,
    crafting_speed = 2,
    energy_source = {type = "electric", input_priority = "secondary", usage_priority = "secondary-input", emissions = 0.003, },
	fast_replaceable_group = "assembling-machine",
	open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
	module_specification =
		{
			module_slots = 2
		},
		allowed_effects = {"consumption", "speed", "productivity", "pollution"},
    working_sound =
    {
    sound = {
    {
    filename = "__base__/sound/assembling-machine-t1-1.ogg",
    volume = 0.8
    },
    {
    filename = "__base__/sound/assembling-machine-t1-2.ogg",
    volume = 0.8
    },
    },
    idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
    apparent_volume = 1.5,
    },
    animation =
		{
			south = { filename = "__NPUtils__/graphics/entity/half-npassemble.png", width = 96, height = 64, shift = {0.40625, 0}, frame_count = 16, line_length = 16, animation_speed=0.5, }	,							
			west  = { filename = "__NPUtils__/graphics/entity/half-npassemble.png", width = 96, height = 64, shift = {0.40625, 0}, frame_count = 16, line_length = 16, animation_speed=0.5, }	,					
			north = { filename = "__NPUtils__/graphics/entity/half-npassemble.png", width = 96, height = 64, shift = {0.40625, 0}, frame_count = 16, line_length = 16, animation_speed=0.5, }	,							
			east  = { filename = "__NPUtils__/graphics/entity/half-npassemble.png", width = 96, height = 64, shift = {0.40625, 0}, frame_count = 16, line_length = 16, animation_speed=0.5, }	,							
		},	
    },
 }
)


