

data:extend(
{
  --Item
  {
    type = "item",
    name = "electric-formation-furnace",
    icon = "__NPUtils__/graphics/icon/electric-formation-furnace-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "blast-furnace",
    order = "a",
    place_result = "electric-formation-furnace",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "electric-formation-furnace",
    enabled = "true",
    ingredients = 
    {
      {"formation-furnace", 1},
      {"advanced-circuit", 5},
      {"copper-plate", 45}
    },
    result = "electric-formation-furnace"
  },
  --Technology

  --Entity
    {
    type = "assembling-machine",
    name = "electric-formation-furnace",
    icon = "__NPUtils__/graphics/icon/electric-formation-furnace-icon.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "electric-formation-furnace"},
    max_health = 200,
    corpse = "medium-remnants",
	open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
	module_specification =
		{
			module_slots = 3
		},
		allowed_effects = {"consumption", "speed", "productivity", "pollution"},
    working_sound =
    {
      sound = { filename = "__base__/sound/furnace.ogg" }
    },
    resistances = 
    {
      {
        type = "fire",
        percent = 100
      }
    },
    collision_box = {{-0.7, -0.7}, {0.7, 0.7}},
    selection_box = {{-0.8, -1}, {0.8, 1}},
    crafting_categories = {"smelting", "blast-furnace"},
    energy_usage = "280kW",
    ingredient_count = 2,
    crafting_speed = 2,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.005
    },

    animation =
    {
      filename = "__NPUtils__/graphics/entity/electric-formation-furnace.png",
      priority = "extra-high",
      width = 96,
      height = 64,
      frame_count = 1,
      shift = {0.25, 0 }
    },
    working_visualisations =
    {
      {
        north_position = { 0.078125, 0.5234375},
        west_position = { 0.078125, 0.5234375},
        south_position = { 0.078125, 0.5234375},
        east_position = { 0.078125, 0.5234375},
        animation =
        {
      filename = "__NPUtils__/graphics/entity/electric-formation-furnace-fire.png",
      priority = "extra-high",
      width = 8,
      height = 11,
      frame_count = 12,
      shift = {-0.102005, 0.125625}
    },
      },
    },
    fast_replaceable_group = "furnace"
  },
}
)


