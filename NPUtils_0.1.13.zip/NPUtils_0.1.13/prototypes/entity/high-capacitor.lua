

data:extend(
{
  --Item
  {
    type = "item",
    name = "high-capacitor",
    icon = "__NPUtils__/graphics/icon/high-capacitor-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electric-blast-furnace",
    order = "z",
    place_result = "high-capacitor",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "high-capacitor",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 20},
	  {"copper-plate", 40},
	  {"advanced-circuit", 5},
	  {"clean-carbon", 5},
	  {"cryamond", 9}
    },
    result = "high-capacitor"
  },
  --Technology

  --Entity
    {
		type = "accumulator",
		name = "high-capacitor",
		icon = "__NPUtils__/graphics/icon/high-capacitor-icon.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "high-capacitor"},
		max_health = 600,
		corpse = "medium-remnants",
		collision_box = {{-1.3, -1.3}, {1.3, 1.3}},
		selection_box = {{-1.6, -1.6}, {1.6, 1.6}},
		energy_source =
		{
			type = "electric",
			buffer_capacity = "45MJ",
			usage_priority = "terciary",
			input_flow_limit = "600kW",
			output_flow_limit = "900kW"
		},
		picture ={filename = "__NPUtils__/graphics/entity/high-capacitor-stop.png",priority = "extra-high",width = 128,height = 128,shift = {-0.1875, -0.1875}},
		charge_animation ={filename = "__NPUtils__/graphics/entity/high-capacitor-in.png",width = 128,height = 128,line_length = 8,frame_count = 8,shift = {-0.1875, -0.1875},animation_speed = 0.2,},
		charge_cooldown = 30,
		charge_light = {intensity = 0.3, size = 25},
		discharge_animation ={filename = "__NPUtils__/graphics/entity/high-capacitor-out.png",width = 128,height = 128,line_length = 8,frame_count = 8,shift = {-0.1875, -0.1875},animation_speed = 0.2,},
		discharge_cooldown = 60,
		discharge_light = {intensity = 0.7, size = 25},		
		circuit_wire_connection_point =
		{
			shadow =
			{
				red = {0.984375, 1.10938},
				green = {0.890625, 1.10938}
			},
			wire =
			{
				red = {0.6875, 0.59375},
				green = {0.6875, 0.71875}
			}
		},
		circuit_connector_sprites = get_circuit_connector_sprites({0.46875, 0.5}, {0.46875, 0.8125}, 26),
		circuit_wire_max_distance = 15.5,
		default_output_signal = "signal-A"
	},  
 }
)


