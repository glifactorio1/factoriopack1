

data:extend(
{
  --Item
  {
    type = "item",
    name = "alien-farm",
    icon = "__NPUtils__/graphics/icon/alien-farm-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "alientuff",
    order = "b",
    place_result = "alien-farm",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "alien-farm",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 40},
	  {"stone", 20},
	  {"iron-stick", 40},
	  {"advanced-circuit", 4}
    },
    result = "alien-farm"
  },
  --Technology

  --Entity
    {
    type = "assembling-machine",
		name = "alien-farm",
		icon = "__NPUtils__/graphics/icon/alien-farm-icon.png",
		flags = {"placeable-neutral","placeable-player", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "alien-farm"},
		max_health = 300,
		corpse = "big-remnants",
		resistances = {{type = "fire",percent = 70}},
		fluid_boxes =
		{
			{
				production_type = "input",

				base_area = 10,
				base_level = -1,
				pipe_connections = {{ type="input", position = {0, -3} }}
			},
			{
				production_type = "output",

				base_area = 10,
				base_level = 1,
				pipe_connections = {{ type="output", position = {0, 3} }}
			},
			off_when_no_fluid_recipe = true
		},
		collision_box = {{-2.2, -2.2}, {2.3, 2.2}},
		selection_box = {{-2.5, -2.5}, {2.5, 2.5}},
		crafting_categories = {"farm-alien"},
		energy_usage = "170kW",
        ingredient_count = 4,
        crafting_speed = 1,
		open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
        close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
        energy_source = {type = "electric", input_priority = "secondary", usage_priority = "secondary-input", emissions = 0.001, },
		fast_replaceable_group = "assembling-machine",
		module_specification =
		{
			module_slots = 2
		},
		allowed_effects = {"consumption", "speed", "productivity", "pollution"},
		working_sound =
        {
        sound = {
        {
        filename = "__base__/sound/chemical-plant.ogg",
        volume = 0.8
        },       
        },
        idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
        apparent_volume = 1.5,
        },
		animation =
		{			
			north = { filename = "__NPUtils__/graphics/entity/alien-farm.png", width = 192, height = 192, shift = {0.09375, -0.28125}, frame_count = 36, line_length = 9, animation_speed=0.2, },						
			south = { filename = "__NPUtils__/graphics/entity/alien-farm.png", width = 192, height = 192, shift = {0.09375, -0.28125}, frame_count = 36, line_length = 9, animation_speed=0.2, },						
			east = { filename = "__NPUtils__/graphics/entity/alien-farm.png", width = 192, height = 192, shift = {0.09375, -0.28125}, frame_count = 36, line_length = 9, animation_speed=0.2, }	,								
			west = { filename = "__NPUtils__/graphics/entity/alien-farm.png", width = 192, height = 192, shift = {0.09375, -0.28125}, frame_count = 36, line_length = 9, animation_speed=0.2, }	,					
		},

	},
        
 }
)


