

data:extend(
{
  --Item
  {
    type = "item",
    name = "dynamo-generator",
    icon = "__NPUtils__/graphics/icon/dynamo-generator-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electric-blast-furnace",
    order = "b",
    place_result = "dynamo-generator",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "dynamo-generator",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 8},
	  {"iron-gear-wheel", 25},
	  {"copper-plate", 40},
	  {"electronic-circuit", 6}
    },
    result = "dynamo-generator"
  },
  --Technology

  --Entity
    {
    type = "generator",
		name = "dynamo-generator",
		icon = "__NPUtils__/graphics/icon/dynamo-generator-icon.png",
		flags = {"placeable-neutral","player-creation"},
		minable = {mining_time = 1, result = "dynamo-generator"},
		max_health = 500,
		corpse = "small-remnants",
		effectivity = 1.2,
		fluid_usage_per_tick = 0.460,
		collision_box = {{-1.3, -0.9}, {1.3, 0.9}},
		selection_box = {{-1.5, -1.0}, {1.5, 1.0}},
		fluid_box =
		{
			base_area = 1,			
			pipe_connections =
			{
				{ position = { 0,  1.5} },
				{ position = { 0, -1.5} },
			},
		},
		energy_source =
		{
			type = "electric",
			usage_priority = "secondary-output",
		},
		horizontal_animation =
		{filename = "__NPUtils__/graphics/entity/dynamo-generator-h.png",width = 80,height = 112,frame_count = 16,line_length = 16,shift = {0.15625, -0.1875}},
		vertical_animation =
		{filename = "__NPUtils__/graphics/entity/dynamo-generator-v.png",width = 112,height = 80,frame_count = 16,line_length = 16,shift = {0.3, 0.0}},		
	},
 }
)


