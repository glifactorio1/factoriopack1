

data:extend(
{
  --Item
  {
    type = "item",
    name = "alienplant-farm",
    icon = "__NPUtils__/graphics/icon/alienplant-farm-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "blast-furnace",
    order = "z",
    place_result = "alienplant-farm",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "alienplant-farm",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 24},
	  {"iron-gear-wheel", 8},
	  {"science-pack-2", 30},
	  {"electronic-circuit", 8},
	  {"pipe", 12},
	  {"engine-unit", 1}
    },
    result = "alienplant-farm"
  },
  --Technology

  --Entity
    {
    type = "assembling-machine",
		name = "alienplant-farm",
		icon = "__NPUtils__/graphics/icon/alienplant-farm-icon.png",
		flags = {"placeable-neutral","placeable-player", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "alienplant-farm"},
		max_health = 300,
		corpse = "big-remnants",
		fluid_boxes =
		{
			off_when_no_fluid_recipe = true,			
			{
				production_type = "input",
				base_area = 5,
				base_level = -1,
				pipe_connections = {
					{type="input", position = {2,-3}},								
				}
			},							
			{
				production_type = "input",
				base_area = 5,
				base_level = -1,
				pipe_connections = {
					{type="input", position = {-2, 3}},								
				}
			},										
		},
		collision_box = {{-2.2, -2.2}, {2.2, 2.2}},
		selection_box = {{-2.5, -2.5}, {2.5, 2.5}},
		crafting_categories = {"alienplant"},
		energy_usage = "160kW",
        ingredient_count = 4,
        crafting_speed = 1,
        energy_source = {type = "electric", input_priority = "secondary", usage_priority = "secondary-input", emissions = 0.001, },
		fast_replaceable_group = "assembling-machine",
		module_specification =
		{
			module_slots = 2
		},
		allowed_effects = {"consumption", "speed", "productivity", "pollution"},
		working_sound =
        {
        sound = {
        {
        filename = "__base__/sound/chemical-plant.ogg",
        volume = 0.8
        },       
        },
        idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
        apparent_volume = 1.5,
        },
		animation =
		{
			north = { filename = "__NPUtils__/graphics/entity/alienplant-farm.png", width = 180, height = 180, shift = {0.1875, 0.1875}, frame_count = 27, line_length = 9, animation_speed=0.3, },						
			east = { filename = "__NPUtils__/graphics/entity/alienplant-farm.png", width = 180, height = 180, shift = {0.1875, 0.1875}, frame_count = 27, line_length = 9, animation_speed=0.3, }	,					
			south = { filename = "__NPUtils__/graphics/entity/alienplant-farm.png", width = 180, height = 180, shift = {0.1875, 0.1875}, frame_count = 27, line_length = 9, animation_speed=0.3, },						
			west = { filename = "__NPUtils__/graphics/entity/alienplant-farm.png", width = 180, height = 180, shift = {0.1875, 0.1875}, frame_count = 27, line_length = 9, animation_speed=0.3, }	,					
		},
		

	},
        
 }
)


