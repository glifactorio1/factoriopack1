

data:extend(
{
  --Item
  {
    type = "item",
    name = "solarium-panel",
    icon = "__NPUtils__/graphics/icon/solarium-panel-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electric-blast-furnace",
    order = "c",
    place_result = "solarium-panel",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "solarium-panel",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 16},
	  {"cryamond", 15},
	  {"electronic-circuit", 8}
    },
    result = "solarium-panel"
  },
  --Technology

  --Entity
    {
    type = "solar-panel",
    name = "solarium-panel",
    icon = "__NPUtils__/graphics/icon/solarium-panel-icon.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "solarium-panel"},
    max_health = 100,
    corpse = "big-remnants",
    collision_box = {{-0.9, -0.9}, {0.9, 0.9}},
    selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
    energy_source =
    {
      type = "electric",
      usage_priority = "solar"
    },
    picture =
    {
      filename = "__NPUtils__/graphics/entity/solarium-panel.png",
      priority = "high",
      width = 71,
      height = 66
    },
    production = "220kW",
    fast_replaceable_group = "solar-panel",
  },
 }
)


