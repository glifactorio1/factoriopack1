

data:extend(
{
  --Item
  {
    type = "item",
    name = "n-excavator",
    icon = "__NPUtils__/graphics/icon/n-excavator-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "blast-furnace",
    order = "t",
    place_result = "n-excavator",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "n-excavator",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 45},
	  {"stone-brick", 20},
	  {"iron-stick", 40},
	  {"electronic-circuit", 5}
    },
    result = "n-excavator"
  },
  --Technology

  --Entity
    {
    type = "assembling-machine",
		name = "n-excavator",
		icon = "__NPUtils__/graphics/icon/n-excavator-icon.png",
		flags = {"placeable-neutral","placeable-player", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "n-excavator"},
		max_health = 300,
		corpse = "big-remnants",
		collision_box = {{-1.7, -1.7}, {1.7, 1.7}},
		selection_box = {{-2, -2}, {2, 2}},
		crafting_categories = {"chunk-miner"},
		energy_usage = "440kW",
        ingredient_count = 4,
        crafting_speed = 1,
		open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
        close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
        energy_source = {type = "electric", input_priority = "secondary", usage_priority = "secondary-input", emissions = 0.08, },
		module_specification =
		{
			module_slots = 2
		},
		allowed_effects = {"consumption", "speed", "productivity", "pollution"},
		working_sound =
        {
        sound = {
        {
        filename = "__base__/sound/burner-mining-drill.ogg",
        volume = 0.8
        },       
        },
        idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
        apparent_volume = 1.5,
        },
		animation =
		{			
			north = { filename = "__NPUtils__/graphics/entity/n-excavator.png", width = 192, height = 224, shift = {0.8125, -1.46875}, frame_count = 36, line_length = 9, animation_speed=0.6, },						
			south = { filename = "__NPUtils__/graphics/entity/n-excavator.png", width = 192, height = 224, shift = {0.8125, -1.46875}, frame_count = 36, line_length = 9, animation_speed=0.6, },						
			east = { filename = "__NPUtils__/graphics/entity/n-excavator.png", width = 192, height = 224, shift = {0.8125, -1.46875}, frame_count = 36, line_length = 9, animation_speed=0.6, }	,								
			west = { filename = "__NPUtils__/graphics/entity/n-excavator.png", width = 192, height = 224, shift = {0.8125, -1.46875}, frame_count = 36, line_length = 9, animation_speed=0.6, }	,					
		},

	},
        
 }
)


