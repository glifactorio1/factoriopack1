

data:extend(
{
  --Fluids

  {
	type = "fluid", 
	name = "npsteam", 
	icon = "__NPUtils__/graphics/icon/steam-icon.png", 
	default_temperature = 100, 
	max_temperature = 300, 
	heat_capacity = "5KJ", 
	base_color = { r=189, g=189, b=189 }, 
	flow_color = { r=130, g=130, b=130 }, 
	pressure_to_speed_ratio = 0.460, 
	flow_to_energy_ratio = 0.500, 
	order = "z", 
	subgroup = "fuel", 
    },
	{
	type = "fluid", 
	name = "molten-copper", 
	icon = "__NPUtils__/graphics/icon/molten-copper-icon.png", 
	default_temperature = 110, 
	max_temperature = 150, 
	heat_capacity = "1KJ", 
	base_color = { r=85, g=28, b=12 }, 
	flow_color = { r=65, g=13, b=10 }, 
	pressure_to_speed_ratio = 0.200, 
	flow_to_energy_ratio = 0.200, 
	order = "x", 
	subgroup = "fuel", 
    },
	{
	type = "fluid", 
	name = "molten-iron", 
	icon = "__NPUtils__/graphics/icon/molten-iron-icon.png", 
	default_temperature = 110, 
	max_temperature = 150, 
	heat_capacity = "1KJ", 
	base_color = { r=20, g=23, b=62 }, 
	flow_color = { r=65, g=68, b=109 }, 
	pressure_to_speed_ratio = 0.200, 
	flow_to_energy_ratio = 0.200, 
	order = "x", 
	subgroup = "fuel", 
    },
	{
	type = "fluid", 
	name = "alienol-oil", 
	icon = "__NPUtils__/graphics/icon/alienol-icon.png", 
	default_temperature = 25, 
	max_temperature = 200, 
	heat_capacity = "2KJ", 
	base_color = { r=196, g=247, b=165 }, 
	flow_color = { r=161, g=181, b=149 }, 
	pressure_to_speed_ratio = 0.200, 
	flow_to_energy_ratio = 0.200, 
	order = "x", 
	subgroup = "fuel", 
    },
	{
	type = "fluid", 
	name = "a-alien-blood", 
	icon = "__NPUtils__/graphics/icon/a-alien-blood-icon.png", 
	default_temperature = 15, 
	max_temperature = 100, 
	heat_capacity = "1KJ", 
	base_color = { r=187, g=28, b=255 }, 
	flow_color = { r=145, g=0, b=220 }, 
	pressure_to_speed_ratio = 0.160, 
	flow_to_energy_ratio = 0.160, 
	order = "z", 
	subgroup = "alientuff", 
    },
  

}
)


