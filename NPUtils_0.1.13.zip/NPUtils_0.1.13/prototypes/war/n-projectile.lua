
data:extend(
{
  {
    type = "projectile",
    name = "n-thunder-laser",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action =
    {
      type = "direct",
      action_delivery =
      {
      type = "instant",
      target_effects =
      {
        {
          type = "create-entity",
          entity_name = "laser-bubble"
        },
        {
          type = "damage",
          damage = { amount = 20, type = "laser"}
        }
        }
      }
    },
    light = {intensity = 0.8, size = 10},
    animation =
    {
      filename = "__NPUtils__/graphics/war/projectile/n-thunder-laser.png",
      tint = {r=1.0, g=1.0, b=0.9},
      frame_count = 1,
      width = 8,
      height = 28,
      priority = "high",
      blend_mode = "additive"
    },
    speed = 0.25
  },
--------------------------------------------------------------
  {
      type = "projectile",
      name = "n-flame-rocket",
      flags = {"not-on-map"},
      acceleration = 0.005,
      action =
      {
        type = "direct",
        action_delivery =
        {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "n-flame-explosion"
          },
          {
            type = "damage",
            damage = {amount = 80, type = "explosion"}
          },
		  {
            type = "damage",
            damage = {amount = 50, type = "fire"}
          },
          {
            type = "damage",
            damage = {amount = 50, type = "physical"}
          },
          {
            type = "create-entity",
            entity_name = "small-scorchmark",
            check_buildability = true
          },
        }
      }
	  
    },
      light = {intensity = 0.5, size = 4},
      animation =
      {
        filename = "__NPUtils__/graphics/war/projectile/n-flame-rocket.png",
        frame_count = 8,
        line_length = 8,
        width = 9,
        height = 35,
        shift = {0, 0},
        priority = "high"
      },
      shadow =
      {
        filename = "__NPUtils__/graphics/war/projectile/n-flame-rocket-shadow.png",
        frame_count = 1,
        width = 7,
        height = 24,
        priority = "high",
        shift = {0, 0}
      },
      smoke =
      {
        {
          name = "smoke-fast",
          deviation = {0.15, 0.15},
          frequency = 1,
          position = {0, -1},
          slow_down_factor = 1,
          starting_frame = 3,
          starting_frame_deviation = 5,
          starting_frame_speed = 0,
          starting_frame_speed_deviation = 5
        }
      }
    },
---------------------------------------------------------------------------------------------
{
      type = "projectile",
      name = "n-sulfur-rocket",
      flags = {"not-on-map"},
      acceleration = 0.005,
      action =
      {
        type = "direct",
        action_delivery =
        {
        type = "instant",
        target_effects =
        {
          {
            type = "create-entity",
            entity_name = "n-sulfur-explosion"
          },
          {
            type = "damage",
            damage = {amount = 80, type = "explosion"}
          },
		  {
            type = "damage",
            damage = {amount = 50, type = "poison"}
          },
          {
            type = "damage",
            damage = {amount = 50, type = "physical"}
          },
          {
            type = "create-entity",
            entity_name = "small-scorchmark",
            check_buildability = true
          },
        }
      }
	  
    },
      light = {intensity = 0.5, size = 4},
      animation =
      {
        filename = "__NPUtils__/graphics/war/projectile/n-sulfur-rocket.png",
        frame_count = 8,
        line_length = 8,
        width = 9,
        height = 35,
        shift = {0, 0},
        priority = "high"
      },
      shadow =
      {
        filename = "__NPUtils__/graphics/war/projectile/n-sulfur-rocket-shadow.png",
        frame_count = 1,
        width = 7,
        height = 24,
        priority = "high",
        shift = {0, 0}
      },
      smoke =
      {
        {
          name = "smoke-fast",
          deviation = {0.15, 0.15},
          frequency = 1,
          position = {0, -1},
          slow_down_factor = 1,
          starting_frame = 3,
          starting_frame_deviation = 5,
          starting_frame_speed = 0,
          starting_frame_speed_deviation = 5
        }
      }
    },
---------------------------------------------------------------------------------------------------
{
      type = "projectile",
      name = "n-sulfur-cannon-shell",
      flags = {"not-on-map"},

      acceleration = 0,
      direction_only = false,
      piercing_damage = 100,
      action =
      {
        type = "direct",
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "damage",
              damage = { amount = 150 , type = "physical"}
            },
            {
              type = "damage",
              damage = { amount = 50 , type = "explosion"}
            },
			{
              type = "damage",
              damage = { amount = 50 , type = "poison"}
            }
          }
        }
      },
      final_action =
      {
        type = "direct",
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-entity",
              entity_name = "small-scorchmark",
              check_buildability = true
            }
          }
        }
      },
      animation =
      {
        filename = "__base__/graphics/entity/bullet/bullet.png",
        frame_count = 1,
        width = 3,
        height = 50,
        priority = "high"
      },
    },
------------------------------------------------------------------------------------------------------
{
      type = "projectile",
      name = "n-flame-cannon-shell",
      flags = {"not-on-map"},

      acceleration = 0,
      direction_only = false,
      piercing_damage = 100,
      action =
      {
        type = "direct",
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "damage",
              damage = { amount = 150 , type = "physical"}
            },
            {
              type = "damage",
              damage = { amount = 50 , type = "explosion"}
            },
			{
              type = "damage",
              damage = { amount = 50 , type = "fire"}
            }
          }
        }
      },
      final_action =
      {
        type = "direct",
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
              type = "create-entity",
              entity_name = "small-scorchmark",
              check_buildability = true
            }
          }
        }
      },
      animation =
      {
        filename = "__base__/graphics/entity/bullet/bullet.png",
        frame_count = 1,
        width = 3,
        height = 50,
        priority = "high"
      },
    },
---------------------------------------------Explosion Entity--------------------------
   {
    type = "explosion",
    name = "n-sulfur-explosion",
    flags = {"not-on-map"},
    animation_speed = 0.1,
    animations =
    { 
      {
        filename = "__NPUtils__/graphics/war/projectile/n-sulfur-explosion.png",
        priority = "low",
        width = 54,
        height = 84,
        frame_count = 32,
        line_length = 8,
        --[[scale = 1.25,]]
      },
    },
	smoke = "smoke-fast",
    duration = 60*20,
    light = {intensity = 2, size = 15},
	sound =
    {
      aggregation =
      {
        max_count = 1,
        remove = true
      },
      variations =
      {
        {
          filename = "__base__/sound/fight/small-explosion-1.ogg",
          volume = 0.75
        },
        {
          filename = "__base__/sound/fight/small-explosion-2.ogg",
          volume = 0.75
        }
      }
    }
  },
--------------------------------------
{
    type = "explosion",
    name = "n-flame-explosion",
    flags = {"not-on-map"},
    animation_speed = 0.1,
    animations =
    { 
      {
        filename = "__NPUtils__/graphics/war/projectile/n-flame-explosion.png",
        priority = "low",
        width = 54,
        height = 84,
        frame_count = 32,
        line_length = 8,
        --[[scale = 1.25,]]
      },
    },
	smoke = "smoke-fast",
    duration = 60*20,
    light = {intensity = 2, size = 15},
	sound =
    {
      aggregation =
      {
        max_count = 1,
        remove = true
      },
      variations =
      {
        {
          filename = "__base__/sound/fight/small-explosion-1.ogg",
          volume = 0.75
        },
        {
          filename = "__base__/sound/fight/small-explosion-2.ogg",
          volume = 0.75
        }
      }
    }
  },
  

  
  
  
})
