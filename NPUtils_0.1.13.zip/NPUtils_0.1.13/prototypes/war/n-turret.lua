	n_sniper_turret =
	{
		filename = "__NPUtils__/graphics/war/n-sniper-turret-idle.png",
		priority = "medium",
		width = 256,
		height = 256,
		direction_count = 8,
		frame_count = 1,
		axially_symmetrical = false,
		shift = { 0, -1.25},
	    scale = 0.75
	}
	n_gatling_turret =
	{
		filename = "__NPUtils__/graphics/war/n-gatling-turret-idle.png",
		priority = "medium",
		width = 256,
		height = 256,
		direction_count = 8,
		frame_count = 1,
		axially_symmetrical = false,
		shift = { 0, -1.25},
        scale = 0.75
	}
    n_rocket_turret =
	{
		filename = "__NPUtils__/graphics/war/n-rocket-turret-idle.png",
		priority = "medium",
		width = 256,
		height = 256,
		direction_count = 8,
		frame_count = 1,
		axially_symmetrical = false,
		shift = { 0, -1.25},
        scale = 0.75
	}	
	n_cannon_turret =
	{
		filename = "__NPUtils__/graphics/war/n-cannon-turret-idle.png",
		priority = "medium",
		width = 256,
		height = 256,
		direction_count = 8,
		frame_count = 1,
		axially_symmetrical = false,
		shift = { 0, -1.25},
        scale = 0.75
	}

data:extend(
	{
        --Item
        {
        type = "item",
        name = "n_sniper_turret",
        icon = "__NPUtils__/graphics/war/icon/n-sniper-turret-icon.png",
        flags = {"goes-to-quickbar"},
        subgroup = "n-machine",
        order = "a",
        place_result = "n_sniper_turret",
        stack_size = 50
        },
        --Recipe
        {
        type = "recipe",
        name = "n_sniper_turret",
        enabled = "true",
        ingredients = 
        {
          {"steel-plate", 50},
	      {"iron-gear-wheel", 20},
	      {"electronic-circuit", 5},
	      {"engine-unit", 1}
        },
        result = "n_sniper_turret"
        },
        --Technology

        --Entity	
		{
			type = "ammo-turret",
			name = "n_sniper_turret",
			icon = "__NPUtils__/graphics/war/icon/n-sniper-turret-icon.png",
			flags = {"placeable-player", "player-creation"},
			minable = {mining_time = 0.5, result = "n_sniper_turret"},
			max_health = 950,
			resistances =
			{
				{ type = "fire", percent = 40, },
				{ type = "acid", percent = 40, },
			},						
			corpse = "small-remnants",
			collision_box = {{ -0.7, -0.7}, {0.7, 0.7}},
			selection_box = {{ -1.0, -1.0}, {1.0, 1.0}},
			rotation_speed = 0.020,
			preparing_speed = 0.08,
			dying_explosion = "medium-explosion",
			folding_speed = 0.08,
			inventory_size = 3,
			automated_ammo_count = 20,			
			circuit_wire_max_distance = 7.5,			
			folded_animation = (function()
			local res = util.table.deepcopy(n_sniper_turret)
			res.frame_count = 1
			res.line_length = 1
			return res
			end)(),
			preparing_animation = n_sniper_turret,			
			prepared_animation =
			{
				filename = "__NPUtils__/graphics/war/n-sniper-turret.png",
				priority = "medium",width = 256,height = 256,shift = { 0, -1.25},
				direction_count = 64,
				frame_count = 1,
				line_length = 8,
				axially_symmetrical = false,
                scale = 0.75				
			},				
			folding_animation = (function()
			local res = util.table.deepcopy(n_sniper_turret)
			res.run_mode = "backward"
			return res
			end)(),				
			attack_parameters =
		    {
				type="projectile",
				ammo_category = "bullet",
				cooldown = 80,
				projectile_center = {0, 0},
				projectile_creation_distance = 1.4,
				damage_modifier = 5,
				range = 50,
				shell_particle = 
				{
					name = "shell-particle",
					direction_deviation = 0.1,
					speed = 0.1,
					speed_deviation = 0.03,
					center = {0, 0.6},
					creation_distance = -1.925,
					starting_frame_speed = 0.2,
					starting_frame_speed_deviation = 0.1
				},
				sound =
				{
					{
						filename = "__base__/sound/fight/heavy-gunshot-1.ogg",
						volume = 0.6
					}
				}
			},
			call_for_help_radius = 30,
			vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.6 },
		},	
--------------------------------------------------------------------
        --Item
        {
        type = "item",
        name = "n_gatling_turret",
        icon = "__NPUtils__/graphics/war/icon/n-gatling-turret-icon.png",
        flags = {"goes-to-quickbar"},
        subgroup = "n-machine",
        order = "a",
        place_result = "n_gatling_turret",
        stack_size = 50
        },
        --Recipe
        {
        type = "recipe",
        name = "n_gatling_turret",
        enabled = "true",
        ingredients = 
        {
          {"steel-plate", 40},
	      {"iron-gear-wheel", 30},
	      {"electronic-circuit", 10},
	      {"engine-unit", 3}
        },
        result = "n_gatling_turret"
        },
        --Technology

        --Entity	
		{
			type = "ammo-turret",
			name = "n_gatling_turret",
			icon = "__NPUtils__/graphics/war/icon/n-gatling-turret-icon.png",
			flags = {"placeable-player", "player-creation"},
			minable = {mining_time = 0.5, result = "n_gatling_turret"},
			max_health = 1250,
			resistances =
			{
				{ type = "fire", percent = 40, },
				{ type = "acid", percent = 40, },
			},						
			corpse = "small-remnants",
			collision_box = {{ -0.7, -0.7}, {0.7, 0.7}},
			selection_box = {{ -1.0, -1.0}, {1.0, 1.0}},
			rotation_speed = 0.015,
			preparing_speed = 0.075,
			dying_explosion = "medium-explosion",
			folding_speed = 0.075,
			inventory_size = 3,
			automated_ammo_count = 20,			
			circuit_wire_max_distance = 7.5,			
			folded_animation = (function()
			local res = util.table.deepcopy(n_gatling_turret)
			res.frame_count = 1
			res.line_length = 1
			return res
			end)(),
			preparing_animation = n_gatling_turret,			
			prepared_animation =
			{
				filename = "__NPUtils__/graphics/war/n-gatling-turret.png",
				priority = "medium",width = 256,height = 256,shift = { 0, -1.25},
				direction_count = 64,
				frame_count = 1,
				line_length = 8,
				axially_symmetrical = false,
                scale = 0.75		
			},			
			folding_animation = (function()
			local res = util.table.deepcopy(n_gatling_turret)
			res.run_mode = "backward"
			return res
			end)(),			
			attack_parameters =
			{
				type="projectile",
				ammo_category = "bullet",
				cooldown = 4,
				projectile_center = {0, 0},
				projectile_creation_distance = 1.4,
				damage_modifier = 1.75,
				range = 25,
				shell_particle = 
				{
					name = "shell-particle",
					direction_deviation = 0.1,
					speed = 0.1,
					speed_deviation = 0.03,
					center = {0, 0.6},
					creation_distance = -1.925,
					starting_frame_speed = 0.2,
					starting_frame_speed_deviation = 0.1
				},
				sound =
				{
					{
						filename = "__base__/sound/fight/light-gunshot-1.ogg",
						volume = 0.6
					}
				}
			},
			call_for_help_radius = 30,
			vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.6 },
		},
-------------------------------------------------------------------------------------------------------------------
    --Item
        {
        type = "item",
        name = "n_rocket_turret",
        icon = "__NPUtils__/graphics/war/icon/n-rocket-turret-icon.png",
        flags = {"goes-to-quickbar"},
        subgroup = "n-machine",
        order = "a",
        place_result = "n_rocket_turret",
        stack_size = 50
        },
        --Recipe
        {
        type = "recipe",
        name = "n_rocket_turret",
        enabled = "true",
        ingredients = 
        {
          {"steel-plate", 50},
	      {"iron-gear-wheel", 25},
	      {"electronic-circuit", 30},
	      {"electric-engine-unit", 2}
        },
        result = "n_rocket_turret"
        },
        --Technology

        --Entity	
		{
			type = "ammo-turret",
			name = "n_rocket_turret",
			icon = "__NPUtils__/graphics/war/icon/n-rocket-turret-icon.png",
			flags = {"placeable-player", "player-creation"},
			minable = {mining_time = 0.5, result = "n_rocket_turret"},
			max_health = 1250,
			resistances =
			{
				{ type = "fire", percent = 50, },
				{ type = "acid", percent = 50, },
			},						
			corpse = "small-remnants",
			collision_box = {{ -0.7, -0.7}, {0.7, 0.7}},
			selection_box = {{ -1.0, -1.0}, {1.0, 1.0}},
			rotation_speed = 0.015,
			preparing_speed = 0.075,
			dying_explosion = "medium-explosion",
			folding_speed = 0.075,
			inventory_size = 3,
			automated_ammo_count = 20,			
			circuit_wire_max_distance = 7.5,			
			folded_animation = (function()
			local res = util.table.deepcopy(n_rocket_turret)
			res.frame_count = 1
			res.line_length = 1
			return res
			end)(),
			preparing_animation = n_rocket_turret,			
			prepared_animation =
			{
				filename = "__NPUtils__/graphics/war/n-rocket-turret.png",
				priority = "medium",width = 256,height = 256,shift = { 0, -1.25},
				direction_count = 64,
				frame_count = 1,
				line_length = 8,
				axially_symmetrical = false,
                scale = 0.75		
			},			
			folding_animation = (function()
			local res = util.table.deepcopy(n_rocket_turret)
			res.run_mode = "backward"
			return res
			end)(),			
			attack_parameters =
			{
				type="projectile",
				ammo_category = "rocket",
				cooldown = 40,
				projectile_center = {0, 0},
				projectile_creation_distance = 3,
				damage_modifier = 0.5,
				range = 35,
				shell_particle = 
				{
					name = "shell-particle",
					direction_deviation = 0.1,
					speed = 0.1,
					speed_deviation = 0.03,
					center = {0, 0.6},
					creation_distance = -1.925,
					starting_frame_speed = 0.2,
					starting_frame_speed_deviation = 0.1
				},
				sound =
				{
					{
						filename = "__base__/sound/fight/rocket-launcher.ogg",
						volume = 0.6
					}
				}
			},
			call_for_help_radius = 30,
			vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.6 },
		},
-------------------------------------------------------------------------------------------------------------------------
    --Item
        {
        type = "item",
        name = "n_cannon_turret",
        icon = "__NPUtils__/graphics/war/icon/n-cannon-turret-icon.png",
        flags = {"goes-to-quickbar"},
        subgroup = "n-machine",
        order = "a",
        place_result = "n_cannon_turret",
        stack_size = 50
        },
        --Recipe
        {
        type = "recipe",
        name = "n_cannon_turret",
        enabled = "true",
        ingredients = 
        {
          {"steel-plate", 60},
	      {"iron-gear-wheel", 40},
	      {"electronic-circuit", 10},
	      {"engine-unit", 4}
        },
        result = "n_cannon_turret"
        },
        --Technology

        --Entity	
		{
			type = "ammo-turret",
			name = "n_cannon_turret",
			icon = "__NPUtils__/graphics/war/icon/n-cannon-turret-icon.png",
			flags = {"placeable-player", "player-creation"},
			minable = {mining_time = 0.5, result = "n_cannon_turret"},
			max_health = 1250,
			resistances =
			{
				{ type = "fire", percent = 40, },
				{ type = "acid", percent = 40, },
			},						
			corpse = "small-remnants",
			collision_box = {{ -0.7, -0.7}, {0.7, 0.7}},
			selection_box = {{ -1.0, -1.0}, {1.0, 1.0}},
			rotation_speed = 0.015,
			preparing_speed = 0.075,
			dying_explosion = "medium-explosion",
			folding_speed = 0.075,
			inventory_size = 3,
			automated_ammo_count = 20,			
			circuit_wire_max_distance = 7.5,			
			folded_animation = (function()
			local res = util.table.deepcopy(n_cannon_turret)
			res.frame_count = 1
			res.line_length = 1
			return res
			end)(),
			preparing_animation = n_cannon_turret,			
			prepared_animation =
			{
				filename = "__NPUtils__/graphics/war/n-cannon-turret.png",
				priority = "medium",width = 256,height = 256,shift = { 0, -1.25},
				direction_count = 64,
				frame_count = 1,
				line_length = 8,
				axially_symmetrical = false,
                scale = 0.75		
			},			
			folding_animation = (function()
			local res = util.table.deepcopy(n_cannon_turret)
			res.run_mode = "backward"
			return res
			end)(),			
			attack_parameters =
			{
				type="projectile",
				ammo_category = "cannon-shell",
				cooldown = 40,
				projectile_center = {0, 0},
				projectile_creation_distance = 2,
				damage_modifier = 2,
				range = 35,
				shell_particle = 
				{
					name = "shell-particle",
					direction_deviation = 0.1,
					speed = 0.1,
					speed_deviation = 0.03,
					center = {0, 0.6},
					creation_distance = -1.925,
					starting_frame_speed = 0.2,
					starting_frame_speed_deviation = 0.1
				},
				sound =
				{
					{
						filename = "__base__/sound/fight/tank-cannon.ogg",
						volume = 0.6
					}
				}
			},
			call_for_help_radius = 30,
			vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.6 },
		},

		
		


		
	})
