

data:extend(
{
  --Item
  {
    type = "item",
    name = "n-ammunition-fabricator",
    icon = "__NPUtils__/graphics/war/icon/n-ammunition-fabricator-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "n-machine-2",
    order = "a",
    place_result = "n-ammunition-fabricator",
    stack_size = 50
  },
  --Recipe
    {
    type = "recipe",
    name = "n-ammunition-fabricator",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 18},
	  {"iron-gear-wheel", 15},
	  {"copper-plate", 60},
	  {"electronic-circuit", 6}
    },
    result = "n-ammunition-fabricator"
  },
  --Technology

  --Entity
    {
    type = "assembling-machine",
		name = "n-ammunition-fabricator",
		icon = "__NPUtils__/graphics/war/icon/n-ammunition-fabricator-icon.png",
		flags = {"placeable-neutral","placeable-player", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "n-ammunition-fabricator"},
		max_health = 300,
		corpse = "big-remnants",
		collision_box = {{-1.3, -1.3}, {1.3, 1.3}},
		selection_box = {{-1.5, -1.5}, {1.5, 1.5}},	
		crafting_categories = {"n-ammo-maker"},
		energy_usage = "260kW",
        ingredient_count = 6,
        crafting_speed = 1,
		open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
        close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
        energy_source = {type = "electric", input_priority = "secondary", usage_priority = "secondary-input", emissions = 0.0045, },
		module_specification =
		{
			module_slots = 2
		},
		allowed_effects = {"consumption", "speed", "productivity", "pollution"},
		working_sound =
        {
        sound = {
        {
        filename = "__base__/sound/assembling-machine-t1-1.ogg",
        volume = 0.8
        },       
        },
        idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
        apparent_volume = 1.5,
        },
		animation =
		{
            filename = "__NPUtils__/graphics/war/n-ammunition-fabricator.png",priority = "medium", width = 128, height = 128, frame_count = 32, line_length = 16, shift = {0.34375, -0.25}, animation_speed=0.5,  		
		},

	},
        
 }
)


