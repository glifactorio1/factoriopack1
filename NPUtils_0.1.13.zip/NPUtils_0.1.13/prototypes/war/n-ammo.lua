
data:extend(
{
   {
        type = "item",
        name = "n-ammo-caps",
        icon = "__NPUtils__/graphics/war/icon/n-ammo-caps-icon.png",
        flags = {"goes-to-main-inventory"},
        subgroup = "n-ammunition",
        order = "a",
        stack_size = 100,
    },
    {
		type = "recipe",
		name = "n-ammo-caps-m",				
		energy_required = 4.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="steel-plate", amount=2},			
        },		
		result = "n-ammo-caps",
		result_count = 1,
	},
	---------
	{
        type = "item",
        name = "n-cannon-caps",
        icon = "__NPUtils__/graphics/war/icon/n-cannon-caps-icon.png",
        flags = {"goes-to-main-inventory"},
        subgroup = "n-ammunition",
        order = "a",
        stack_size = 100,
    },
    {
		type = "recipe",
		name = "n-cannon-caps-m",				
		energy_required = 6.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="steel-plate", amount=4},			
        },		
		result = "n-cannon-caps",
		result_count = 1,
	},
	----------
	{
        type = "item",
        name = "n-rocket-caps",
        icon = "__NPUtils__/graphics/war/icon/n-rocket-caps-icon.png",
        flags = {"goes-to-main-inventory"},
        subgroup = "n-ammunition",
        order = "a",
        stack_size = 100,
    },
    {
		type = "recipe",
		name = "n-rocket-caps-m",				
		energy_required = 6.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="steel-plate", amount=4},			
        },		
		result = "n-rocket-caps",
		result_count = 1,
	},

-----------------------------------------------------------------------------------------
    --Recipe
	{
		type = "recipe",
		name = "n-hard-magazine-recipe",
		enabled = "true",
		energy_required = 2,
		ingredients = {{"n-ammo-caps", 4},{"clean-carbon", 4},{"iron-plate", 2}},
		result = "n-hard-magazine",
		subgroup = "n-ammunition",
		category = "n-ammo-maker",
        order = "b",
	},
	--Entity
	{
		type = "ammo",
		name = "n-hard-magazine",
		icon = "__NPUtils__/graphics/war/icon/n-hard-magazine-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
			category = "bullet",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "instant",
					source_effects =
					{
						type = "create-explosion",
						entity_name = "explosion-gunshot"
					},
					target_effects =
					{
						{
							type = "create-entity",
							entity_name = "explosion-hit"
						},
						{ type = "damage", damage = { amount = 8 , type = "impact"}, },
						{ type = "damage", damage = { amount = 8 , type = "physical"}, }																
					}
				}
			}
		},
		magazine_size = 35,
		subgroup = "n-ammunition",
        order = "b",
		stack_size = 80, default_request_amount = 30, 
	},
-------------------------------------------------------------------------------------------------
    --Recipe
	{
		type = "recipe",
		name = "n-obsidian-magazine-recipe",
		enabled = "true",
		energy_required = 2,
		ingredients = {{"n-ammo-caps", 4},{"n-alisidian", 2},{"iron-plate", 2}},
		result = "n-obsidian-magazine",
		subgroup = "n-ammunition",
		category = "n-ammo-maker",
        order = "b",
	},
	--Entity
	{
		type = "ammo",
		name = "n-obsidian-magazine",
		icon = "__NPUtils__/graphics/war/icon/n-obsidian-magazine-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
			category = "bullet",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "instant",
					source_effects =
					{
						type = "create-explosion",
						entity_name = "explosion-gunshot"
					},
					target_effects =
					{
						{
							type = "create-entity",
							entity_name = "explosion-hit"
						},
						{ type = "damage", damage = { amount = 6 , type = "impact"}, },
						{ type = "damage", damage = { amount = 12 , type = "physical"}, }																
					}
				}
			}
		},
		magazine_size = 35,
		subgroup = "n-ammunition",
        order = "b",
		stack_size = 80, default_request_amount = 30, 
	},
----------------------------------------------------------------------------------
    --Recipe
	{
		type = "recipe",
		name = "n-copper-magazine-recipe",
		enabled = "true",
		energy_required = 2,
		ingredients = {{"n-ammo-caps", 4},{"pure-copper", 6},{"iron-plate", 2}},
		result = "n-copper-magazine",
		subgroup = "n-ammunition",
		category = "n-ammo-maker",
        order = "b",
	},
	--Entity
	{
		type = "ammo",
		name = "n-copper-magazine",
		icon = "__NPUtils__/graphics/war/icon/n-copper-magazine-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
			category = "bullet",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "instant",
					source_effects =
					{
						type = "create-explosion",
						entity_name = "explosion-gunshot"
					},
					target_effects =
					{
						{
							type = "create-entity",
							entity_name = "explosion-hit"
						},
						{ type = "damage", damage = { amount = 5 , type = "physical"}, }																
					}
				}
			}
		},
		magazine_size = 35,
		subgroup = "n-ammunition",
        order = "b",
		stack_size = 80, default_request_amount = 30, 
	},
-------------------------------------------------------------------------------------------------
    --Recipe
	{
		type = "recipe",
		name = "n-iron-magazine-recipe",
		enabled = "true",
		energy_required = 2,
		ingredients = {{"n-ammo-caps", 4},{"pure-iron", 4},{"iron-plate", 2}},
		result = "n-iron-magazine",
		subgroup = "n-ammunition",
		category = "n-ammo-maker",
        order = "b",
	},
	--Entity
	{
		type = "ammo",
		name = "n-iron-magazine",
		icon = "__NPUtils__/graphics/war/icon/n-iron-magazine-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
			category = "bullet",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "instant",
					source_effects =
					{
						type = "create-explosion",
						entity_name = "explosion-gunshot"
					},
					target_effects =
					{
						{
							type = "create-entity",
							entity_name = "explosion-hit"
						},
						{ type = "damage", damage = { amount = 7 , type = "physical"}, }																
					}
				}
			}
		},
		magazine_size = 35,
		subgroup = "n-ammunition",
        order = "b",
		stack_size = 80, default_request_amount = 30, 
	},
----------------------------------------------------------------------------
    --Recipe
	{
		type = "recipe",
		name = "n-sulfur-magazine-recipe",
		enabled = "true",
		energy_required = 2,
		ingredients = {{"n-ammo-caps", 4},{"sulfur", 4},{"iron-plate", 2}},
		result = "n-sulfur-magazine",
		subgroup = "n-ammunition",
		category = "n-ammo-maker",
        order = "b",
	},
	--Entity
	{
		type = "ammo",
		name = "n-sulfur-magazine",
		icon = "__NPUtils__/graphics/war/icon/n-sulfur-magazine-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
			category = "bullet",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "instant",
					source_effects =
					{
						type = "create-explosion",
						entity_name = "explosion-gunshot"
					},
					target_effects =
					{
						{
							type = "create-entity",
							entity_name = "explosion-hit"
						},
						{ type = "damage", damage = { amount = 8 , type = "poison"}, },
						{ type = "damage", damage = { amount = 10 , type = "physical"}, }																
					}
				}
			}
		},
		magazine_size = 35,
		subgroup = "n-ammunition",
        order = "b",
		stack_size = 80, default_request_amount = 30, 
	},
-----------------------------------------------------------------------------------------
    --Recipe
	{
		type = "recipe",
		name = "n-flame-magazine-recipe",
		enabled = "true",
		energy_required = 2,
		ingredients = {{"n-ammo-caps", 4},{"sulfur", 2},{"clean-carbon", 2},{"iron-plate", 2}},
		result = "n-flame-magazine",
		subgroup = "n-ammunition",
		category = "n-ammo-maker",
        order = "b",
	},
	--Entity
	{
		type = "ammo",
		name = "n-flame-magazine",
		icon = "__NPUtils__/graphics/war/icon/n-flame-magazine-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
			category = "bullet",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "instant",
					source_effects =
					{
						type = "create-explosion",
						entity_name = "explosion-gunshot"
					},
					target_effects =
					{
						{
							type = "create-entity",
							entity_name = "explosion-hit"
						},
						{ type = "damage", damage = { amount = 8 , type = "fire"}, },
						{ type = "damage", damage = { amount = 8 , type = "physical"}, }																
					}
				}
			}
		},
		magazine_size = 35,
		subgroup = "n-ammunition",
        order = "b",
		stack_size = 80, default_request_amount = 30, 
	},
-----------------------------------------------------------------------------------------------
    --Recipe
	{
		type = "recipe",
		name = "n-diamond-magazine-recipe",
		enabled = "true",
		energy_required = 2,
		ingredients = {{"n-ammo-caps", 4},{"cryamond", 2},{"iron-plate", 2}},
		result = "n-diamond-magazine",
		subgroup = "n-ammunition",

        order = "b",
	},
	--Entity
	{
		type = "ammo",
		name = "n-diamond-magazine",
		icon = "__NPUtils__/graphics/war/icon/n-diamond-magazine-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
			category = "bullet",
			action =
			{
				type = "direct",
				action_delivery =
				{
					type = "instant",
					source_effects =
					{
						type = "create-explosion",
						entity_name = "explosion-gunshot"
					},
					target_effects =
					{
						{
							type = "create-entity",
							entity_name = "explosion-hit"
						},
						{ type = "damage", damage = { amount = 25 , type = "physical"}, }																
					}
				}
			}
		},
		magazine_size = 35,
		subgroup = "n-ammunition",
        order = "b",
		stack_size = 80, default_request_amount = 30, 
	},
--------------------------------------------------------------------------------------------------------
    --Recipe
	{
		type = "recipe",
		name = "n-flame-rocket-recipe",
		enabled = "true",
		energy_required = 6,
		ingredients = {{"n-rocket-caps", 2},{"sulfur", 6},{"clean-carbon", 6},{"iron-plate", 2}},
		result = "n-flame-rocket",
		subgroup = "n-ammunition",
		category = "n-ammo-maker",
        order = "c",
	},
	--Entity
	{
		type = "ammo",
		name = "n-flame-rocket",
		icon = "__NPUtils__/graphics/war/icon/n-flame-rocket-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
			category = "rocket",
			action =
			{
				type = "direct",
				action_delivery =
				{
                type = "projectile",
                projectile = "n-flame-rocket",
                starting_speed = 0.1,
                source_effects =
                    {
                    type = "create-entity",
                    entity_name = "explosion-hit"
                    }
                }
			}
		},
		magazine_size = 12,
		subgroup = "n-ammunition",
        order = "c",
		stack_size = 80, default_request_amount = 30, 
	},
-------------------------------------------------------------------------------------
    --Recipe
	{
		type = "recipe",
		name = "n-sulfur-rocket-recipe",
		enabled = "true",
		energy_required = 6,
		ingredients = {{"n-rocket-caps", 2},{"sulfur", 12},{"iron-plate", 2}},
		result = "n-sulfur-rocket",
		subgroup = "n-ammunition",
		category = "n-ammo-maker",
        order = "c",
	},
	--Entity
	{
		type = "ammo",
		name = "n-sulfur-rocket",
		icon = "__NPUtils__/graphics/war/icon/n-sulfur-rocket-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
			category = "rocket",
			action =
			{
				type = "direct",
				action_delivery =
				{
                type = "projectile",
                projectile = "n-sulfur-rocket",
                starting_speed = 0.1,
                source_effects =
                    {
                    type = "create-entity",
                    entity_name = "explosion-hit"
                    }
                }
			}
		},
		magazine_size = 12,
		subgroup = "n-ammunition",
        order = "c",
		stack_size = 80, default_request_amount = 30, 
	},
-------------------------------------------------------------------------------------------------------------
    --Recipe
	{
		type = "recipe",
		name = "n-sulfur-cannon-recipe",
		enabled = "true",
		energy_required = 6,
		ingredients = {{"n-cannon-caps", 2},{"sulfur", 16},{"iron-plate", 2}},
		result = "n-sulfur-cannon",
		subgroup = "n-ammunition",
		category = "n-ammo-maker",
        order = "d",
	},
	--Entity
	{
		type = "ammo",
		name = "n-sulfur-cannon",
		icon = "__NPUtils__/graphics/war/icon/n-sulfur-cannon-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
        category = "cannon-shell",
        target_type = "direction",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "n-sulfur-cannon-shell",
            starting_speed = 1,
            direction_deviation = 0.1,
            range_deviation = 0.1,
            max_range = 30,
            source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            },
          }
        },
      },
		magazine_size = 12,
		subgroup = "n-ammunition",
        order = "d",
		stack_size = 80, default_request_amount = 30, 
	},
----------------------------------------------------------------------------------------
--Recipe
	{
		type = "recipe",
		name = "n-flame-cannon-recipe",
		enabled = "true",
		energy_required = 6,
		ingredients = {{"n-cannon-caps", 2},{"sulfur", 8},{"clean-carbon", 8},{"iron-plate", 2}},
		result = "n-flame-cannon",
		subgroup = "n-ammunition",
		category = "n-ammo-maker",
        order = "d",
	},
	--Entity
	{
		type = "ammo",
		name = "n-flame-cannon",
		icon = "__NPUtils__/graphics/war/icon/n-flame-cannon-icon.png",
		flags = {"goes-to-main-inventory"},
		ammo_type =
		{
        category = "cannon-shell",
        target_type = "direction",
        action =
        {
          type = "direct",
          action_delivery =
          {
            type = "projectile",
            projectile = "n-flame-cannon-shell",
            starting_speed = 1,
            direction_deviation = 0.1,
            range_deviation = 0.1,
            max_range = 30,
            source_effects =
            {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
            },
          }
        },
      },
		magazine_size = 12,
		subgroup = "n-ammunition",
        order = "d",
		stack_size = 80, default_request_amount = 30, 
	},
  

  
  
  
})
