  
data:extend(
{
-----------------------------------Raw-------------------------------
   --Item
    {
    type = "item",
    name = "n-survivalist-car",
    icon = "__NPUtils__/graphics/war/icon/n-sur-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "n-car",
    order = "a",
    place_result = "n-survivalist-car",
    stack_size = 50
    },
    --Recipe
    {
    type = "recipe",
    name = "n-survivalist-car",
    enabled = "true",
    ingredients = 
    {
      {"steel-plate", 60},
	  {"iron-gear-wheel", 50},
	  {"engine-unit", 4},
	  {"electronic-circuit", 25}

    },
    result = "n-survivalist-car"
    },
    --Technology

    --Entity
   {
    type = "car",
    name = "n-survivalist-car",
    icon = "__NPUtils__/graphics/war/icon/n-sur-icon.png",
    flags = {"pushable", "placeable-neutral", "player-creation", "placeable-off-grid"},
    minable = {mining_time = 1, result = "n-survivalist-car"},
    max_health = 500,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    energy_per_hit_point = 1,
    crash_trigger = crash_trigger(),
	collision_box = {{-1.0, -1.4}, {1.0, 1.4}},
    selection_box = {{-1.0, -1.4}, {1.0, 1.4}},
	open_sound = { filename = "__base__/sound/car-door-open.ogg", volume=0.7 },
    close_sound = { filename = "__base__/sound/car-door-close.ogg", volume = 0.7 },
    resistances =
    {
      {
        type = "impact",
        percent = 30,
        decrease = 30
      }
    },
    effectivity = 0.5,
    braking_power = "200kW",
    burner =
    {
      effectivity = 0.6,
      fuel_inventory_size = 1,
      smoke =
      {
        {
          name = "car-smoke",
          deviation = {0.25, 0.25},
          frequency = 200,
          position = {0, 1.5},
          starting_frame = 0,
          starting_frame_deviation = 60
        }
      }
    },
    consumption = "450kW",
    friction = 0.004,
    light =
    {
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {-0.6, -14},
        size = 2,
        intensity = 0.6
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {0.6, -14},
        size = 2,
        intensity = 0.6
      }
    },
    animation =
    {
      layers =
      {
        {
          width = 256,
          height = 256,
          frame_count = 1,
          direction_count = 64,
          shift = {-0.375, -0.4375},
          animation_speed = 8,
          max_advance = 0.2,
          stripes =
          {
            {
             filename = "__NPUtils__/graphics/war/n-survivalist-car.png",
             width_in_frames = 8,
             height_in_frames = 8,
            },
          }
        },
		
      }
    },
    --[[turret_animation =
    {
      layers =
      {
        {
          filename = "__NPUtils__/graphics/war/s-gatling.png",
          line_length = 8,
          width = 256,
          height = 256,
          frame_count = 1,
          direction_count = 64,
          shift = {-0.375, -0.4375},
          animation_speed = 8,
        },
      }
    },
    turret_rotation_speed = 0.35 / 60,]]
    sound_no_fuel =
    {
      {
        filename = "__base__/sound/fight/car-no-fuel-1.ogg",
        volume = 0.6
      },
    },
    stop_trigger_speed = 0.2,
    stop_trigger =
    {
      {
        type = "play-sound",
        sound =
        {
          {
            filename = "__base__/sound/car-breaks.ogg",
            volume = 0.6
          },
        }
      },
    },
    sound_minimum_speed = 0.2;
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/car-engine.ogg",
        volume = 0.6
      },
      activate_sound =
      {
        filename = "__base__/sound/car-engine-start.ogg",
        volume = 0.6
      },
      deactivate_sound =
      {
        filename = "__base__/sound/car-engine-stop.ogg",
        volume = 0.6
      },
      match_speed_to_activity = true,
    },
    rotation_speed = 0.02,
    weight = 700,
   --[[ guns = { "vehicle-machine-gun" },]]
    inventory_size = 70
  },
 ----------------------------------------------Gatling-------------------------
 --Item
    {
    type = "item",
    name = "n-survivalist-g-car",
    icon = "__NPUtils__/graphics/war/icon/n-sur-gat-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "n-car",
    order = "b",
    place_result = "n-survivalist-g-car",
    stack_size = 50
    },
    --Recipe
    {
    type = "recipe",
    name = "n-survivalist-g-car",
    enabled = "true",
    ingredients = 
    {
        {"n-survivalist-car", 1},
		{"n_gatling_turret", 1},
		{"iron-gear-wheel", 20}

    },
    result = "n-survivalist-g-car"
    },
    --Technology

    --Entity
   {
    type = "car",
    name = "n-survivalist-g-car",
    icon = "__NPUtils__/graphics/war/icon/n-sur-gat-icon.png",
    flags = {"pushable", "placeable-neutral", "player-creation", "placeable-off-grid"},
    minable = {mining_time = 1, result = "n-survivalist-g-car"},
    max_health = 500,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    energy_per_hit_point = 1,
    crash_trigger = crash_trigger(),
	collision_box = {{-1.0, -1.4}, {1.0, 1.4}},
    selection_box = {{-1.0, -1.4}, {1.0, 1.4}},
	open_sound = { filename = "__base__/sound/car-door-open.ogg", volume=0.7 },
    close_sound = { filename = "__base__/sound/car-door-close.ogg", volume = 0.7 },
    resistances =
    {
      {
        type = "impact",
        percent = 30,
        decrease = 30
      }
    },
    effectivity = 0.5,
    braking_power = "200kW",
    burner =
    {
      effectivity = 0.6,
      fuel_inventory_size = 1,
      smoke =
      {
        {
          name = "car-smoke",
          deviation = {0.25, 0.25},
          frequency = 200,
          position = {0, 1.5},
          starting_frame = 0,
          starting_frame_deviation = 60
        }
      }
    },
    consumption = "450kW",
    friction = 0.004,
    light =
    {
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {-0.6, -14},
        size = 2,
        intensity = 0.6
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {0.6, -14},
        size = 2,
        intensity = 0.6
      }
    },
    animation =
    {
      layers =
      {
        {
          width = 256,
          height = 256,
          frame_count = 1,
          direction_count = 64,
          shift = {-0.375, -0.4375},
          animation_speed = 8,
          max_advance = 0.2,
          stripes =
          {
            {
             filename = "__NPUtils__/graphics/war/n-survivalist-car.png",
             width_in_frames = 8,
             height_in_frames = 8,
            },
          }
        },
		
      }
    },
    turret_animation =
    {
      layers =
      {
        {
          filename = "__NPUtils__/graphics/war/s-gatling.png",
          line_length = 8,
          width = 192,
          height = 192,
          frame_count = 1,
          direction_count = 64,
          shift = {-0.375, -0.4375},
          animation_speed = 8,
		  scale = 1.5,
        },
      }
    },
    turret_rotation_speed = 0.55 / 60,
    sound_no_fuel =
    {
      {
        filename = "__base__/sound/fight/car-no-fuel-1.ogg",
        volume = 0.6
      },
    },
    stop_trigger_speed = 0.2,
    stop_trigger =
    {
      {
        type = "play-sound",
        sound =
        {
          {
            filename = "__base__/sound/car-breaks.ogg",
            volume = 0.6
          },
        }
      },
    },
    sound_minimum_speed = 0.2;
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/car-engine.ogg",
        volume = 0.6
      },
      activate_sound =
      {
        filename = "__base__/sound/car-engine-start.ogg",
        volume = 0.6
      },
      deactivate_sound =
      {
        filename = "__base__/sound/car-engine-stop.ogg",
        volume = 0.6
      },
      match_speed_to_activity = true,
    },
    rotation_speed = 0.02,
    weight = 700,
    guns = { "vehicle-machine-gun" },
    inventory_size = 70
  },
-----------------------------------Cannon----------------------------------------------
--Item
    {
    type = "item",
    name = "n-survivalist-c-car",
    icon = "__NPUtils__/graphics/war/icon/n-sur-can-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "n-car",
    order = "b",
    place_result = "n-survivalist-c-car",
    stack_size = 50
    },
    --Recipe
    {
    type = "recipe",
    name = "n-survivalist-c-car",
    enabled = "true",
    ingredients = 
    {
        {"n-survivalist-car", 1},
		{"n_cannon_turret", 1},
		{"iron-gear-wheel", 20}

    },
    result = "n-survivalist-c-car"
    },
    --Technology

    --Entity
   {
    type = "car",
    name = "n-survivalist-c-car",
    icon = "__NPUtils__/graphics/war/icon/n-sur-can-icon.png",
    flags = {"pushable", "placeable-neutral", "player-creation", "placeable-off-grid"},
    minable = {mining_time = 1, result = "n-survivalist-c-car"},
    max_health = 500,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    energy_per_hit_point = 1,
    crash_trigger = crash_trigger(),
	collision_box = {{-1.0, -1.4}, {1.0, 1.4}},
    selection_box = {{-1.0, -1.4}, {1.0, 1.4}},
	open_sound = { filename = "__base__/sound/car-door-open.ogg", volume=0.7 },
    close_sound = { filename = "__base__/sound/car-door-close.ogg", volume = 0.7 },
    resistances =
    {
      {
        type = "impact",
        percent = 30,
        decrease = 30
      }
    },
    effectivity = 0.5,
    braking_power = "200kW",
    burner =
    {
      effectivity = 0.6,
      fuel_inventory_size = 1,
      smoke =
      {
        {
          name = "car-smoke",
          deviation = {0.25, 0.25},
          frequency = 200,
          position = {0, 1.5},
          starting_frame = 0,
          starting_frame_deviation = 60
        }
      }
    },
    consumption = "450kW",
    friction = 0.004,
    light =
    {
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {-0.6, -14},
        size = 2,
        intensity = 0.6
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {0.6, -14},
        size = 2,
        intensity = 0.6
      }
    },
    animation =
    {
      layers =
      {
        {
          width = 256,
          height = 256,
          frame_count = 1,
          direction_count = 64,
          shift = {-0.375, -0.4375},
          animation_speed = 8,
          max_advance = 0.2,
          stripes =
          {
            {
             filename = "__NPUtils__/graphics/war/n-survivalist-car.png",
             width_in_frames = 8,
             height_in_frames = 8,
            },
          }
        },
		
      }
    },
    turret_animation =
    {
      layers =
      {
        {
          filename = "__NPUtils__/graphics/war/s-cannon.png",
          line_length = 8,
          width = 192,
          height = 192,
          frame_count = 1,
          direction_count = 64,
          shift = {-0.375, -0.4375},
          animation_speed = 8,
		  scale = 1.5,
        },
      }
    },
    turret_rotation_speed = 0.55 / 60,
    sound_no_fuel =
    {
      {
        filename = "__base__/sound/fight/car-no-fuel-1.ogg",
        volume = 0.6
      },
    },
    stop_trigger_speed = 0.2,
    stop_trigger =
    {
      {
        type = "play-sound",
        sound =
        {
          {
            filename = "__base__/sound/car-breaks.ogg",
            volume = 0.6
          },
        }
      },
    },
    sound_minimum_speed = 0.2;
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/car-engine.ogg",
        volume = 0.6
      },
      activate_sound =
      {
        filename = "__base__/sound/car-engine-start.ogg",
        volume = 0.6
      },
      deactivate_sound =
      {
        filename = "__base__/sound/car-engine-stop.ogg",
        volume = 0.6
      },
      match_speed_to_activity = true,
    },
    rotation_speed = 0.02,
    weight = 700,
    guns = { "tank-cannon" },
    inventory_size = 70
  },
-------------------------------------Rocket----------------------------------------
--Item
    {
    type = "item",
    name = "n-survivalist-r-car",
    icon = "__NPUtils__/graphics/war/icon/n-sur-roc-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "n-car",
    order = "b",
    place_result = "n-survivalist-r-car",
    stack_size = 50
    },
    --Recipe
    {
    type = "recipe",
    name = "n-survivalist-r-car",
    enabled = "true",
    ingredients = 
    {
        {"n-survivalist-car", 1},
		{"n_rocket_turret", 1},
		{"iron-gear-wheel", 20}

    },
    result = "n-survivalist-r-car"
    },
    --Technology

    --Entity
   {
    type = "car",
    name = "n-survivalist-r-car",
    icon = "__NPUtils__/graphics/war/icon/n-sur-roc-icon.png",
    flags = {"pushable", "placeable-neutral", "player-creation", "placeable-off-grid"},
    minable = {mining_time = 1, result = "n-survivalist-r-car"},
    max_health = 500,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    energy_per_hit_point = 1,
    crash_trigger = crash_trigger(),
	collision_box = {{-1.0, -1.4}, {1.0, 1.4}},
    selection_box = {{-1.0, -1.4}, {1.0, 1.4}},
	open_sound = { filename = "__base__/sound/car-door-open.ogg", volume=0.7 },
    close_sound = { filename = "__base__/sound/car-door-close.ogg", volume = 0.7 },
    resistances =
    {
      {
        type = "impact",
        percent = 30,
        decrease = 30
      }
    },
    effectivity = 0.5,
    braking_power = "200kW",
    burner =
    {
      effectivity = 0.6,
      fuel_inventory_size = 1,
      smoke =
      {
        {
          name = "car-smoke",
          deviation = {0.25, 0.25},
          frequency = 200,
          position = {0, 1.5},
          starting_frame = 0,
          starting_frame_deviation = 60
        }
      }
    },
    consumption = "450kW",
    friction = 0.004,
    light =
    {
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {-0.6, -14},
        size = 2,
        intensity = 0.6
      },
      {
        type = "oriented",
        minimum_darkness = 0.3,
        picture =
        {
          filename = "__core__/graphics/light-cone.png",
          priority = "medium",
          scale = 2,
          width = 200,
          height = 200
        },
        shift = {0.6, -14},
        size = 2,
        intensity = 0.6
      }
    },
    animation =
    {
      layers =
      {
        {
          width = 256,
          height = 256,
          frame_count = 1,
          direction_count = 64,
          shift = {-0.375, -0.4375},
          animation_speed = 8,
          max_advance = 0.2,
          stripes =
          {
            {
             filename = "__NPUtils__/graphics/war/n-survivalist-car.png",
             width_in_frames = 8,
             height_in_frames = 8,
            },
          }
        },
		
      }
    },
    turret_animation =
    {
      layers =
      {
        {
          filename = "__NPUtils__/graphics/war/s-rocket.png",
          line_length = 8,
          width = 192,
          height = 192,
          frame_count = 1,
          direction_count = 64,
          shift = {-0.375, -0.4375},
          animation_speed = 8,
		  scale = 1.5,
        },
      }
    },
    turret_rotation_speed = 0.55 / 60,
    sound_no_fuel =
    {
      {
        filename = "__base__/sound/fight/car-no-fuel-1.ogg",
        volume = 0.6
      },
    },
    stop_trigger_speed = 0.2,
    stop_trigger =
    {
      {
        type = "play-sound",
        sound =
        {
          {
            filename = "__base__/sound/car-breaks.ogg",
            volume = 0.6
          },
        }
      },
    },
    sound_minimum_speed = 0.2;
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/car-engine.ogg",
        volume = 0.6
      },
      activate_sound =
      {
        filename = "__base__/sound/car-engine-start.ogg",
        volume = 0.6
      },
      deactivate_sound =
      {
        filename = "__base__/sound/car-engine-stop.ogg",
        volume = 0.6
      },
      match_speed_to_activity = true,
    },
    rotation_speed = 0.02,
    weight = 700,
    guns = { "rocket-launcher" },
    inventory_size = 70
  },
  
 })