
data:extend({
    --Item
    {
        type = "item",
        name = "np-wall",
        icon = "__NPUtils__/graphics/np-wall/np-wall-icon.png",
        flags = {"goes-to-main-inventory"},
	    place_result = "np-wall",
        subgroup = "n-machine-2",
        order = "b",
        stack_size = 100,
    },
    --Recipe
    {
		type = "recipe",
		name = "np-wall",
		energy_required = 3.0,
		enabled = "true",
		ingredients = 
        {
		    {type="item", name="n-alisidian-brick", amount=4},
		},
		result = "np-wall",
		result_count = 1,
		icon = "__NPUtils__/graphics/np-wall/np-wall-icon.png",
		order = "b", group = "NPUtils-War", subgroup = "n-machine-2",
	
	},
    --Entity	
	{
		type = "wall",
		name = "np-wall",
		icon = "__NPUtils__/graphics/np-wall/np-wall-icon.png",		
		flags = {"placeable-neutral", "player-creation"},
		collision_box = {{-0.29, -0.29}, {0.29, 0.29}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		minable = {mining_time = 1, result = "np-wall"},
		max_health = 1200,		
		corpse = "wall-remnants",
		repair_sound = { filename = "__base__/sound/manual-repair-simple.ogg" },
		mined_sound = { filename = "__base__/sound/deconstruct-bricks.ogg" },		
		repair_speed_modifier = 2,
		fast_replaceable_group = "wall",
		vehicle_impact_sound =  { filename = "__base__/sound/car-stone-impact.ogg", volume = 1.0 },
		connected_gate_visualization = { filename = "__core__/graphics/arrows/underground-lines.png",priority = "high",width = 64,height = 64,scale = 0.5 },
		resistances =
		{
			{ type = "physical", decrease = 7, percent = 60 },
			{ type = "explosion", decrease = 6, percent = 60 },
			{ type = "fire", percent = 100 },			
			{ type = "acid", percent = 50 },
		},
		wall_diode_green =
		{
			filename = "__base__/graphics/entity/gate/wall-diode-green.png",
			width = 21,
			height = 22,
			shift = {0, -0.78125}
		},
		wall_diode_green_light =
		{
			minimum_darkness = 0.3,
			color = {g=1},
			shift = {0, -0.78125},
			size = 1,
			intensity = 0.3
		},
		wall_diode_red =
		{
			filename = "__base__/graphics/entity/gate/wall-diode-red.png",
			width = 21,
			height = 22,
			shift = {0, -0.78125}
		},
		wall_diode_red_light =
		{
			minimum_darkness = 0.3,
			color = {r=1},
			shift = {0, -0.78125},
			size = 1,
			intensity = 0.3
		},
		circuit_wire_connection_point =
		{
			shadow =
			{
				red = {0.890625, 0.828125},
				green = {0.890625, 0.703125}
			},
			wire =
			{
				red = {-0.28125, -0.71875},
				green = {-0.28125, -0.84375}
			}
		},
		circuit_wire_max_distance = 7.5,
		circuit_connector_sprites = get_circuit_connector_sprites({0, -0.59375}, nil, 6),
		default_output_signal = "signal-G",
		pictures =
		{
			single =
			{
				{
					filename = "__NPUtils__/graphics/np-wall/np-wall-single.png",priority = "extra-high",width = 48,height = 48,shift = {0.2, -0.2}
				}
			},
			straight_vertical =
			{
				{
					filename = "__NPUtils__/graphics/np-wall/np-wall-sv.png",priority = "extra-high",width = 48,height = 48,shift = {0.2, -0.2}
				},
				
			},
			straight_horizontal =
			{
				{
					filename = "__NPUtils__/graphics/np-wall/np-wall-sh.png",priority = "extra-high",width = 48,height = 48,shift = {0.2, -0.2}
				},
			},
			corner_right_down =
			{
				{
					filename = "__NPUtils__/graphics/np-wall/np-wall-rd.png",priority = "extra-high",width = 48,height = 48,shift = {0.2, -0.2}
				}
			},
			corner_left_down =
			{
				{
					filename = "__NPUtils__/graphics/np-wall/np-wall-ld.png",priority = "extra-high",width = 48,height = 48,shift = {0.2, -0.2}
				}
			},
			t_up =
			{
				{
					filename = "__NPUtils__/graphics/np-wall/np-wall-tu.png",priority = "extra-high",width = 48,height = 48,shift = {0.2, -0.2}
				}
			},
			ending_right =
			{
				{
					filename = "__NPUtils__/graphics/np-wall/np-wall-er.png",priority = "extra-high",width = 48,height = 48,shift = {0.2, -0.2}
				}
			},
			ending_left =
			{
				{
					filename = "__NPUtils__/graphics/np-wall/np-wall-el.png",priority = "extra-high",width = 48,height = 48,shift = {0.2, -0.2}
				}
			}
		}
	},
		

})