
data.raw["item"]["rail-signal"].icon = "__rail-icons__/rail-signal.png"
data.raw["item"]["rail-chain-signal"].icon = "__rail-icons__/rail-chain-signal.png"
data.raw["rail-signal"]["rail-signal"].icon = "__rail-icons__/rail-signal.png"
data.raw["rail-chain-signal"]["rail-chain-signal"].icon = "__rail-icons__/rail-chain-signal.png"
