data:extend ({
{
type = "item-group",
name = "compression",
icon = "__compressor__/graphics/icons/compressor2.jpg",
inventory_order = "f",
order = "e"
},
{
type = "item-subgroup",
name = "compression",
group = "compression",
order = "a"
},


{
type = "item-group",
name = "uncompression",
icon = "__compressor__/graphics/icons/uncompressor2.png",
inventory_order = "f",
order = "e"
},
{
type = "item-subgroup",
name = "uncompression",
group = "uncompression",
order = "b"
},

})