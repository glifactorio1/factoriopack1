data:extend({
{
type = "recipe-category",
name = "compression"
},
{
type = "recipe-category",
name = "decompression"
},

})