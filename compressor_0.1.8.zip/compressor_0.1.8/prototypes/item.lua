data:extend({
{ type = "item", name = "compressed-iron", icon = "__compressor__/graphics/icons/filler.png", flags = {"goes-to-main-inventory"}, subgroup = "compression", order = "z[compressed-iron]", stack_size =100 },
{ type = "item", name = "compressed-copper", icon = "__compressor__/graphics/icons/filler2.png", flags = {"goes-to-main-inventory"}, subgroup = "compression", order = "z[compressed-copper]", stack_size = 100 },
{ type = "item", name = "compressed-stone", icon = "__compressor__/graphics/icons/stone2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-stone]", stack_size = 100 },
{ type = "item", name = "compressed-coal", icon = "__compressor__/graphics/icons/coal2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-coal]", stack_size = 100 },
{ type = "item", name = "compressed-logs", icon = "__compressor__/graphics/icons/raw-wood2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-logs]", stack_size = 100 },

{ type = "item",
 name = "compressor", 
 icon = "__compressor__/graphics/icons/compressor2.jpg", 
 flags = ("goes-to-quickbar"), 
 subgroup = "compression", 
 order = "a[compressor]", 
 place_result = "compressor",
 stack_size = 100 },
{ type = "item", name = "uncompressor", 
icon = "__compressor__/graphics/icons/uncompressor2.png", 
flags = ("goes-to-quickbar"), 
subgroup = "uncompression", 
order = "a[uncompressor]", 
place_result = "uncompressor",
stack_size = 100 },

{ type = "item", name = "compressed-steel", icon = "__compressor__/graphics/icons/steel-plate2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-steel]", stack_size = 100 },
{ type = "item", name = "compressed-circuit1", icon = "__compressor__/graphics/icons/electronic-circuit2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-circuit1]", stack_size = 100 },
{ type = "item", name = "compressed-processing-unit", icon = "__compressor__/graphics/icons/processing-unit2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-processing-unit]", stack_size = 100 },
{ type = "item", name = "compressed-belt1", icon = "__compressor__/graphics/icons/basic-transport-belt2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-belt1]", stack_size = 100 },
{ type = "item", name = "compressed-circuit2", icon = "__compressor__/graphics/icons/advanced-circuit2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-circuit2]", stack_size = 100 },
{ type = "item", name = "compressed-bullet1", icon = "__compressor__/graphics/icons/basic-bullet-magazine2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-bullet1]", stack_size = 100 },
{ type = "item", name = "compressed-grenade", icon = "__compressor__/graphics/icons/basic-grenade2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-grenade]", stack_size = 100 },
{ type = "item", name = "compressed-inserter", icon = "__compressor__/graphics/icons/basic-inserter2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-inserter]", stack_size = 100 },
{ type = "item", name = "compressed-splitter", icon = "__compressor__/graphics/icons/basic-splitter2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-splitter]", stack_size = 100 },
{ type = "item", name = "compressed-underground", icon = "__compressor__/graphics/icons/basic-transport-belt-to-ground2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-underground]", stack_size = 100 },
{ type = "item", name = "compressed-battery", icon = "__compressor__/graphics/icons/battery2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-battery]", stack_size = 100 },
{ type = "item", name = "compressed-cannon-shell", icon = "__compressor__/graphics/icons/cannon-shell2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-cannon-shell]", stack_size = 100 },
{ type = "item", name = "compressed-concrete", icon = "__compressor__/graphics/icons/concrete2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-concrete]", stack_size = 100 },
{ type = "item", name = "compressed-copper-ore", icon = "__compressor__/graphics/icons/copper-ore2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-copper-ore]", stack_size = 100 },
{ type = "item", name = "compressed-iron-ore", icon = "__compressor__/graphics/icons/iron-ore2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-iron-ore]", stack_size = 100 },
{ type = "item", name = "compressed-rail2", icon = "__compressor__/graphics/icons/curved-rail2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-rail2]", stack_size = 100 },
{ type = "item", name = "compressed-rail", icon = "__compressor__/graphics/icons/straight-rail2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-rail]", stack_size = 100 },


{ type = "item", name = "compressed-solid-fuel", icon = "__compressor__/graphics/icons/solid-fuel2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-solid-fuel]", stack_size = 100 },
{ type = "item", name = "compressed-fast-transport-belt", icon = "__compressor__/graphics/icons/fast-transport-belt2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order ="z[compressed-fast-transport-belt", stack_size = 100 },
{ type = "item", name = "compressed-piercing-bullet-magazine", icon = "__compressor__/graphics/icons/piercing-bullet-magazine2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-piercing-bullet-magazine]", stack_size = 100 },
{ type = "item", name = "compressed-piercing-shotgun-shell", icon = "__compressor__/graphics/icons/piercing-shotgun-shell2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-piercing-shotgun-shell]", stack_size = 100 },
{ type = "item", name = "compressed-fast-splitter", icon = "__compressor__/graphics/icons/fast-splitter2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-fast-splitter]", stack_size = 100 },
{ type = "item", name = "compressed-fast-transport-belt-to-ground", icon = "__compressor__/graphics/icons/fast-transport-belt-to-ground2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-fast-transport-belt-to-ground]", stack_size = 100 },
{ type = "item", name = "compressed-express-transport-belt", icon = "__compressor__/graphics/icons/express-transport-belt2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-express-transport-belt]", stack_size = 100 },
{ type = "item", name = "compressed-express-transport-belt-to-ground", icon = "__compressor__/graphics/icons/express-transport-belt-to-ground2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-express-transport-belt-to-ground]", stack_size = 100 },
{ type = "item", name = "compressed-express-splitter", icon = "__compressor__/graphics/icons/express-splitter2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-express-splitter]", stack_size = 100 },
{ type = "item", name = "compressed-roboport", icon = "__compressor__/graphics/icons/roboport2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-roboport]", stack_size = 100 },
{ type = "item", name = "compressed-stone-brick", icon = "__compressor__/graphics/icons/stone-brick2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-stone-brick]", stack_size = 100 },
{ type = "item", name = "compressed-tank", icon = "__compressor__/graphics/icons/tank2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-tank]", stack_size = 100 },
{ type = "item", name = "compressed-long-handed-inserter", icon = "__compressor__/graphics/icons/long-handed-inserter2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-long-handed-inserter]", stack_size = 100 },
{ type = "item", name = "compressed-pipe", icon = "__compressor__/graphics/icons/pipe2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-pipe]", stack_size = 100 },
{ type = "item", name = "compressed-pipe-to-ground", icon = "__compressor__/graphics/icons/pipe-to-ground2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-pipe-to-ground]", stack_size = 100 },
{ type = "item", name = "compressed-smart-inserter", icon = "__compressor__/graphics/icons/smart-inserter2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-smart-inserter]", stack_size = 100 },
{ type = "item", name = "compressed-logistic-robot", icon = "__compressor__/graphics/icons/logistic-robot2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-logistic-robot]", stack_size = 100 },
{ type = "item", name = "compressed-construction-robot", icon = "__compressor__/graphics/icons/construction-robot2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-construction-robot]", stack_size = 100 },
{ type = "item", name = "compressed-flying-robot-frame", icon = "__compressor__/graphics/icons/flying-robot-frame2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-flying-robot-frame]", stack_size = 100 },
{ type = "item", name = "compressed-rail-chain-signal", icon = "__compressor__/graphics/icons/rail-chain-signal2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-rail-chain-signal]", stack_size = 100 },
{ type = "item", name = "compressed-rail-signal", icon = "__compressor__/graphics/icons/rail-signal2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-rail-signal]", stack_size = 100 },
{ type = "item", name = "compressed-small-electric-pole", icon = "__compressor__/graphics/icons/small-electric-pole2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-small-electric-pole]", stack_size = 100 },
{ type = "item", name = "compressed-medium-electric-pole", icon = "__compressor__/graphics/icons/medium-electric-pole2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-medium-electric-pole]", stack_size = 100 },
{ type = "item", name = "compressed-substation", icon = "__compressor__/graphics/icons/substation2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-substation]", stack_size = 100 },
{ type = "item", name = "compressed-explosive-cannon-shell", icon = "__compressor__/graphics/icons/explosive-cannon-shell2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-explosive-cannon-shell]", stack_size = 100 },
{ type = "item", name = "compressed-rocket", icon = "__compressor__/graphics/icons/rocket2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-rocket]", stack_size = 100 },
{ type = "item", name = "compressed-explosive-rocket", icon = "__compressor__/graphics/icons/explosive-rocket2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-explosive-rocket]", stack_size = 100 },
{ type = "item", name = "compressed-engine-unit", icon = "__compressor__/graphics/icons/engine-unit2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-engine-unit]", stack_size = 100 },
{ type = "item", name = "compressed-electric-engine-unit", icon = "__compressor__/graphics/icons/electric-engine-unit2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-electric-engine-unit]", stack_size = 100 },
{ type = "item", name = "compressed-steel-axe", icon = "__compressor__/graphics/icons/steel-axe2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-steel-axe]", stack_size = 100 },
{ type = "item", name = "compressed-solar-panel", icon = "__compressor__/graphics/icons/solar-panel2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-solar-panel]", stack_size = 100 },
{ type = "item", name = "compressed-basic-accumulator", icon = "__compressor__/graphics/icons/basic-accumulator2.png", flags = ("goes-to-main-inventory"), subgroup = "compression", order = "z[compressed-basic-accumulator]", stack_size = 100 },

{
type = "item",
name = "compressed-fast-inserter",
icon = "__compressor__/graphics/icons/fast-inserter2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[compressed-fast-inserter]",
stack_size = 100
},

{
type = "item",
name = "compressed-plastic-bar",
icon = "__compressor__/graphics/icons/plastic-bar2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[compressed-plastic-bar]",
stack_size = 100
},
{
type = "item",
name = "compressed-copper-cable",
icon = "__compressor__/graphics/icons/copper-cable2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[copper-cable]",
stack_size = 100
},
{
type = "item",
name = "compressed-explosives",
icon = "__compressor__/graphics/icons/explosives2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[explosives]",
stack_size = 100
},
{
type = "item",
name = "compressed-sulfur",
icon = "__compressor__/graphics/icons/sulfur2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[sulfur]",
stack_size = 100
},
{
type = "item",
name = "compressed-flame-thrower-ammo",
icon = "__compressor__/graphics/icons/flame-thrower-ammo2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[flame-thrower-ammo]",
stack_size = 100
},
{
type = "item",
name = "compressed-basic-mining-drill",
icon = "__compressor__/graphics/icons/basic-mining-drill2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[basic-mining-drill]",
stack_size = 100
},
{
type = "item",
name = "compressed-train-stop",
icon = "__compressor__/graphics/icons/train-stop2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[train-stop]",
stack_size = 100
},
{
type = "item",
name = "compressed-big-electric-pole",
icon = "__compressor__/graphics/icons/big-electric-pole2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[big-electric-pole]",
stack_size = 100
},
{
type = "item",
name = "compressed-laser-turret",
icon = "__compressor__/graphics/icons/laser-turret2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[laser-turret]",
stack_size = 100
},
{
type = "item",
name = "compressed-storage-tank",
icon = "__compressor__/graphics/icons/storage-tank2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[storage-tank]",
stack_size = 100
},
{
type = "item",
name = "compressed-steam-engine",
icon = "__compressor__/graphics/icons/steam-engine2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[steam-engine]",
stack_size = 100
},
{
type = "item",
name = "compressed-shotgun-shell",
icon = "__compressor__/graphics/icons/shotgun-shell2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[shotgun-shell]",
stack_size = 100
},
{
type = "item",
name = "compressed-steel-furnace",
icon = "__compressor__/graphics/icons/steel-furnace2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[steel-furnace]",
stack_size = 100
},
{
type = "item",
name = "compressed-stone-furnace",
icon = "__compressor__/graphics/icons/stone-furnace2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[stone-furnace]",
stack_size = 100
},
{
type = "item",
name = "compressed-chemical-plant",
icon = "__compressor__/graphics/icons/chemical-plant2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[chemical-plant]",
stack_size = 100
},
{
type = "item",
name = "compressed-repair-pack",
icon = "__compressor__/graphics/icons/repair-pack2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[repair-pack]",
stack_size = 100
},
{
type = "item",
name = "compressed-electric-furnace",
icon = "__compressor__/graphics/icons/electric-furnace2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[electric-furnace]",
stack_size = 100
},
{
type = "item",
name = "compressed-land-mine",
icon = "__compressor__/graphics/icons/land-mine2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[land-mine]",
stack_size = 100
},
{
type = "item",
name = "compressed-speed-module",
icon = "__compressor__/graphics/icons/speed-module2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[speed-module]",
stack_size = 100
},
{
type = "item",
name = "compressed-speed-module-2",
icon = "__compressor__/graphics/icons/speed-module-22.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[speed-module-2]",
stack_size = 100
},
{
type = "item",
name = "compressed-speed-module-3",
icon = "__compressor__/graphics/icons/speed-module-32.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[speed-module-3]",
stack_size = 100
},
{
type = "item",
name = "compressed-logistic-chest-active-provider",
icon = "__compressor__/graphics/icons/logistic-chest-active-provider2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[logistic-chest-active-provider]",
stack_size = 100
},
{
type = "item",
name = "compressed-logistic-chest-passive-provider",
icon = "__compressor__/graphics/icons/logistic-chest-passive-provider2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[logistic-chest-passive-provider]",
stack_size = 100
},
{
type = "item",
name = "compressed-logistic-chest-requester",
icon = "__compressor__/graphics/icons/logistic-chest-requester2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[logistic-chest-requester]",
stack_size = 100
},
{
type = "item",
name = "compressed-logistic-chest-storage",
icon = "__compressor__/graphics/icons/logistic-chest-storage2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[logistic-chest-storage]",
stack_size = 100
},
{
type = "item",
name = "compressed-defender-capsule",
icon = "__compressor__/graphics/icons/defender-capsule2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[defender-capsule]",
stack_size = 100
},
{
type = "item",
name = "compressed-destroyer-capsule",
icon = "__compressor__/graphics/icons/destroyer-capsule2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[destroyer-capsule]",
stack_size = 100
},
{
type = "item",
name = "compressed-distractor-capsule",
icon = "__compressor__/graphics/icons/distractor-capsule2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[distractor-capsule]",
stack_size = 100
},
{
type = "item",
name = "compressed-poison-capsule",
icon = "__compressor__/graphics/icons/poison-capsule2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[poison-capsule]",
stack_size = 100
},
{
type = "item",
name = "compressed-slowdown-capsule",
icon = "__compressor__/graphics/icons/slowdown-capsule2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[slowdown-capsule]",
stack_size = 100
},
{
type = "item",
name = "compressed-pumpjack",
icon = "__compressor__/graphics/icons/pumpjack2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[pumpjack]",
stack_size = 100
},
{
type = "item",
name = "compressed-science-pack-1",
icon = "__compressor__/graphics/icons/science-pack-12.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[science-pack-1]",
stack_size = 100
},
{
type = "item",
name = "compressed-science-pack-2",
icon = "__compressor__/graphics/icons/science-pack-22.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[science-pack-2]",
stack_size = 100
},
{
type = "item",
name = "compressed-science-pack-3",
icon = "__compressor__/graphics/icons/science-pack-32.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[science-pack-3]",
stack_size = 100
},
{
type = "item",
name = "compressed-effectivity-module",
icon = "__compressor__/graphics/icons/effectivity-module2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[effectivity-module]",
stack_size = 100
},
{
type = "item",
name = "compressed-effectivity-module-2",
icon = "__compressor__/graphics/icons/effectivity-module-22.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[effectivity-module-2]",
stack_size = 100
},
{
type = "item",
name = "compressed-effectivity-module-3",
icon = "__compressor__/graphics/icons/effectivity-module-32.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[effectivity-module-3]",
stack_size = 100
},
{
type = "item",
name = "compressed-productivity-module",
icon = "__compressor__/graphics/icons/productivity-module2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[productivity-module]",
stack_size = 100
},
{
type = "item",
name = "compressed-productivity-module-2",
icon = "__compressor__/graphics/icons/productivity-module-22.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[productivity-module-2]",
stack_size = 100
},
{
type = "item",
name = "compressed-productivity-module-3",
icon = "__compressor__/graphics/icons/productivity-module-32.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[productivity-module-3]",
stack_size = 100
},
{
type = "item",
name = "compressed-satellite",
icon = "__compressor__/graphics/icons/satellite2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[satellite]",
stack_size = 100
},
{
type = "item",
name = "compressed-rocket-fuel",
icon = "__compressor__/graphics/icons/rocket-fuel2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[rocket-fuel]",
stack_size = 100
},
{
type = "item",
name = "compressed-rocket-control-unit",
icon = "__compressor__/graphics/icons/rocket-control-unit2.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[rocket-control-unit]",
stack_size = 100
},
--[[
{
type = "item",
name = "compressed-",
icon = "__compressor__/graphics/icons/.png",
flags = ("goes-to-main-inventory"),
subgroup = "compression",
order = "z[]",
stack_size = 100
},
--]]

})