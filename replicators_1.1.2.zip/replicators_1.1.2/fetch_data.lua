require "util"
require("config")
-- to print in factorio log: error("Hi player") error(serpent.block(table_name))
-- Initialise
local recipes = table.deepcopy(data.raw.recipe)
local recipes_copy = table.deepcopy(data.raw.recipe)
--known_recipes = {}
item = {}
fluid = {}

--item["copper-ore"] = {time = 0.9*2, comp = 0} -- basis for time ist hardness*mining_time/count
-- time: time needed to produce, comp: Complexity of an item = Sum of ingredients complexity+1
--item["iron-ore"] = {time = 0.9*2, comp = 0}
--item["coal"] = {time = 0.9*2, comp = 0}
item["raw-wood"] = {time = 0.5*2/4, comp = 0}
--item["stone"] = {time = 0.4*2, comp = 0}
item["alien-artifact"] = {time = 2000, comp = 100}

-- Bobs ores
-- item["tin-ore"] = {time = 0.8*2, comp = 0}
-- item["lead-ore"] = {time = 0.7*1.5, comp = 0}
-- item["quartz"] = {time = 0.5*2, comp = 0}
-- item["silver-ore"] = {time = 0.6*1.5, comp = 0}
-- item["zinc-ore"] = {time = 1.4*2, comp = 0}
-- item["gold-ore"] = {time = 0.6*2 * 2, comp = 0}
-- item["bauxite-ore"] = {time = 1.4*2, comp = 0}
-- item["rutile-ore"] = {time = 2.6*2, comp = 0}
-- item["tungsten-ore"] = {time = 2.6*2, comp = 0}
-- item["nickel-ore"] = {time = 1.4*2, comp = 0}
-- item["cobalt-ore"] = {time = 1.4*2.5, comp = 0}
-- item["gem-ore"] = {time = 2.4*2 * 0.75, comp = 0}
-- item["ruby-ore"] = {time = (2.4*2+1)/1, comp = 1}
-- item["sapphire-ore"] = {time = (2.4*2+1)/0.8, comp = 1}
-- item["emerald-ore"] = {time = (2.4*2+1)/0.6, comp = 1}
-- item["amethyst-ore"] = {time = (2.4*2+1)/0.5, comp = 1}
-- item["topaz-ore"] = {time = (2.4*2+1)/0.4, comp = 1}
-- item["diamond-ore"] = {time = (2.4*2+1)/0.2, comp = 1}
item["alien-artifact-red"] = {time = 2000, comp = 100}
item["alien-artifact-orange"] = {time = 2000, comp = 100}
item["alien-artifact-yellow"] = {time = 2000, comp = 100}
item["alien-artifact-green"] = {time = 2000, comp = 100}
item["alien-artifact-blue"] = {time = 2000, comp = 100}
item["alien-artifact-purple"] = {time = 2000, comp = 100}
-- item["y-res1"] = {time = 2500, comp = 0}
-- item["y-res2"] = {time = 2500, comp = 0}
-- item["uraninite"] = {time = 2500, comp = 0}
-- item["fluorite"] = {time = 2500, comp = 0}


-- fluids
fluid["water"] = {time = 0.01, comp = 0}
--fluid["crude-oil"] = {time = 1, comp = 0}
fluid["liquid-air"] = {time = 0.1, comp = 5}
fluid["gas-compressed-air"] = {time = 0.1, comp = 5}


local function table_length(table)
	local count = 0
	for _, __ in pairs(table) do
		count = count +1
	end
	return count
end

local function get_time(name, rtype)
	if rtype == "item" then
		return item[name].time
	else
		return fluid[name].time
	end
end

local function get_comp(name, rtype)
	if rtype == "item" then
		return item[name].comp
	else
		return fluid[name].comp
	end
end

local function add_known_recipe(name, rtable, rtype) -- input: string, table: {time = 1, comp = 1}, string
	if rtype == "item" then
		if item[name]==nil then 
			item[name] = rtable
		-- if it is already in the table then choose the one with smaller complexity, if complexity ist equal then choose the one with smaller time
		elseif item[name].comp > rtable.comp then item[name] = rtable
		elseif item[name].comp == rtable.comp and item[name].time > rtable.time then item[name] = rtable
		end
	elseif rtype == "fluid" then
		if fluid[name]==nil then
			fluid[name] = rtable
		elseif fluid[name].comp > rtable.comp then fluid[name] = rtable
		elseif fluid[name].comp == rtable.comp and fluid[name].time > rtable.time then fluid[name] = rtable
		end
	end
end


local function delete_recipe(name)
	recipes[name] = nil
end

-- function for formation of any ingredients syntax to {{name,amount,type},...}
local function ingred_structure(ing)
	local returnval = {}
	for i, ingredient in pairs(ing) do
		if ingredient[1] and ingredient[2] then -- structure is {"steel-plate", 10}
			returnval[i] = {}
			returnval[i]["name"]= ingredient[1]
			returnval[i]["amount"]= ingredient[2]
			returnval[i]["type"]= "item"
		elseif ingredient.name and ingredient.amount and ingredient.type then --structure is {name = "steel-plate", amount = 10, type = "item"}
			returnval[i] = {}
			returnval[i]["name"]= ingredient.name
			returnval[i]["amount"]= ingredient.amount
			returnval[i]["type"]= ingredient.type
		else
			error("Repl: Error in ingred_structure, unkown ingredients structure")
		end
	end
	return returnval
end

-- function for formation of any results syntax to {{name,amount,type},...}
local function result_structure(result)
	local returnval = {}
	for i, results in pairs(result) do
		if results[1] and results[2] then -- structure is {"steel-plate", 10}
			returnval[i] = {}
			returnval[i]["name"]= results[1]
			returnval[i]["amount"]= results[2]
			returnval[i]["type"]= "item"
		elseif results.name and results.amount and results.type and results.probability then --structure is {name = "steel-plate", amount = 10, type = "item"}
			returnval[i] = {}
			returnval[i]["name"]= results.name
			returnval[i]["amount"]= results.amount * results.probability
			returnval[i]["type"]= results.type
		elseif results.name and results.amount and results.type then
			returnval[i] = {}
			returnval[i]["name"]= results.name
			returnval[i]["amount"]= results.amount
			returnval[i]["type"]= results.type
		elseif results.name and results.amount_min and results.amount_max and results.type  and results.probability == nil then
			returnval[i] = {}
			returnval[i]["name"]= results.name
			returnval[i]["amount"]= (results.amount_min + results.amount_max) / 2
			returnval[i]["type"]= results.type
		elseif results.name and results.amount_min and results.amount_max and results.type and results.probability then
			returnval[i] = {}
			returnval[i]["name"]= results.name
			returnval[i]["amount"]= (results.amount_min + results.amount_max) / 2 * results.probability
			returnval[i]["type"]= results.type
		else
			log("Repl: Error in result_structure, unkown results structure")
		end
	end
	return returnval
end

local function make_known_recipe(recipe_table) -- input: {type="recipe", name, ingredients, required_energy, ...}
	if table_length(recipe_table.ingredients) ~= 0 then
		-- initialize variables
		local new_krecipe = {}
		local rtime = recipe_table.energy_required or 0.5
		local comp = 0
		local result = {{}}
		--check if recipe uses result ore results
		if recipe_table.results then
			result=result_structure(recipe_table.results) -- returns structure {{name, amount, type}}
		else
			result[1].name = recipe_table.result
			result[1].amount = recipe_table.result_count or 1
			result[1].type = "item"
			
		end

		recipe_table.ingredients = ingred_structure(recipe_table.ingredients)
		for i , material in pairs(recipe_table.ingredients) do

			rtime = rtime + get_time(material.name, material.type) * material.amount
			comp = i + comp + get_comp(material.name, material.type)

		end
		new_krecipe.time = rtime / result[1].amount -- there should only be one single result item. because the they get splited later
		new_krecipe.comp = comp
		add_known_recipe(result[1].name, new_krecipe,  result[1].type)
	end
end

local function contains_known_recipe(recipe_table) -- input: {type="recipe", name, ingredients, required_energy, ...}, output: true/false
	recipe_table.ingredients = ingred_structure(recipe_table.ingredients)
	for i, ingredient_table in pairs(recipe_table.ingredients) do -- example ingredient_table={name="steel", amount=10, type="item"}
		if ingredient_table.type == "item" then 
			if item[ingredient_table.name] == nil then 
				return false
			end
		end
		if ingredient_table.type == "fluid" then 
			if fluid[ingredient_table.name] == nil then 
				return false
			end
		end
	end
	return true
end


-- extract resources
local resources = {}
for name, res in pairs(data.raw.resource) do
	-- print(name .. "--" .. serpent.block(res))
	if res.autoplace and name ~= "rare-earth" then
		local new_hardness = res.minable.hardness
		local new_mining_time = res.minable.mining_time
		local new_infinite = res.infinite or false
		local new_maximum = res.maximum
		local new_normal = res.normal
		local new_minimum = res.minimum
		
		local new_a_coverage = res.autoplace.coverage or 0.02
		local new_a_random_probability_penalty = res.autoplace.random_probability_penalty or 0
		local new_a_richness_multiplier 
		
		if res.autoplace.richness_multiplier == 0 and (res.category == "basic-fluid" or res.category == "water") then new_a_richness_multiplier = 30000 * 100 --factor 100 because fludis seem to have too long replication times
		elseif res.autoplace.richness_multiplier == 0 then new_a_richness_multiplier = 1500
		else new_a_richness_multiplier = res.autoplace.richness_multiplier end
		
		local new_a_richness_base
		--print(name .. "-.-.-" .. res.autoplace.richness_base)
		if res.autoplace.richness_base == 0 and (res.category == "basic-fluid" or res.category == "water") then new_a_richness_base = 6000 * 100
		elseif res.autoplace.richness_base == 0 then new_a_richness_base = 500 
		else new_a_richness_base = res.autoplace.richness_base end
		--print(name .. "-" .. new_a_richness_base)
		local new_a_max_probability = res.autoplace.max_probability or 1
		
		local result = {{}}
		if res.minable.results then
			result=result_structure(res.minable.results) -- returns structure {{name, amount, type},...}
			for _, resource in pairs(result) do
				if not resources[resource.name] then
					resources[resource.name] = 
						{
						amount = resource.amount * #result ,
						hardness = new_hardness,
						mining_time = new_mining_time,
						infinite = new_infinite,
						maximum = new_maximum,
						normal = new_normal,
						minimum = new_minimum,
						a_coverage = new_a_coverage,
						a_random_probability_penalty = new_a_random_probability_penalty,
						a_richness_multiplier = new_a_richness_multiplier,
						a_richness_base = new_a_richness_base,
						a_max_probability = new_a_max_probability,
						type = resource.type
						}
				else
					resources[resource.name] = 
						{
						amount = (resource.amount + resources.amount) / 2,
						hardness = (new_hardness + resources[resource.name]) / 2,
						mining_time = (new_mining_time + resources[resource.name]) / 2,
						infinite = new_infinite,
						maximum = (new_maximum + resources[resource.name]) / 2,
						normal = (new_normal + resources[resource.name]) / 2,
						minimum = (new_minimum + resources[resource.name]) / 2,
						a_coverage = (new_a_coverage + resources[resource.name]) / 2,
						a_random_probability_penalty = (new_a_random_probability_penalty + resources[resource.name]) / 2,
						a_richness_multiplier = (new_a_richness_multiplier + resources[resource.name]) / 2,
						a_richness_base = (new_a_richness_base + resources[resource.name]) / 2,
						a_max_probability = (new_a_max_probability + resources[resource.name]) / 2,
						}
				end
			end
		else
			result[1].name = res.minable.result
			result[1].amount = res.minable.result_count or 1
			result[1].type = "item"
			if not resources[result[1].name] then
				resources[result[1].name] = 
					{
					amount = result[1].amount,
					hardness = new_hardness,
					mining_time = new_mining_time,
					infinite = new_infinite,
					maximum = new_maximum,
					normal = new_normal,
					minimum = new_minimum,
					a_coverage = new_a_coverage,
					a_random_probability_penalty = new_a_random_probability_penalty,
					a_richness_multiplier = new_a_richness_multiplier,
					a_richness_base = new_a_richness_base,
					a_max_probability = new_a_max_probability,
					type = result[1].type
					}
			else
				resources[result[1].name] = 
					{
					amount = (result[1].amount + resources.amount) / 2,
					hardness = (new_hardness + resources[resource.name]) / 2,
					mining_time = (new_mining_time + resources[resource.name]) / 2,
					infinite = new_infinite,
					maximum = (new_maximum + resources[resource.name]) / 2,
					normal = (new_normal + resources[resource.name]) / 2,
					minimum = (new_minimum + resources[resource.name]) / 2,
					a_coverage = (new_a_coverage + resources[resource.name]) / 2,
					a_random_probability_penalty = (new_a_random_probability_penalty + resources[resource.name]) / 2,
					a_richness_multiplier = (new_a_richness_multiplier + resources[resource.name]) / 2,
					a_richness_base = (new_a_richness_base + resources[resource.name]) / 2,
					a_max_probability = (new_a_max_probability + resources[resource.name]) / 2,
					}
			end
		end
	end
end

for name, res in pairs(resources) do
	--print(serpent.block(res))
	if not res.a_random_probability_penalty then prob_factor = res.a_max_probability
	elseif res.a_max_probability > res.a_random_probability_penalty then prob_factor = res.a_max_probability - 0.5 * res.a_random_probability_penalty
	else prob_factor = 0.5 * res.a_max_probability^2 / res.a_random_probability_penalty end
	local inf_factor
	if res.infinite and res.normal then inf_factor = math.log(res.normal + 10) / math.log(10) else inf_factor = 1 end
	local time = res.hardness * res.mining_time / res.a_coverage / (res.a_richness_multiplier + res.a_richness_base)^(1/2) / prob_factor / res.amount / inf_factor
	resources[name].time = time
end
--print(serpent.block(resources))

for name, tab in pairs(resources) do
	if tab.type == "item" and (not item[name]) then
		item[name] = {time = tab.time, comp = 0}
	elseif tab.type == "fluid" and (not fluid[name]) then
		fluid[name] = {time = tab.time, comp = 0}
	end
end

--it[i] = 0

-- split recipes with multiple outputs into seperate recipes
for name, recipe  in pairs(recipes) do
	if recipe.results and #recipe.results > 1 then -- checked for multiple results
		local recipe_name = recipe.name --name from recpet with multiple results
		local results = result_structure(recipe.results) --the multiple results with uniform data structure: no probabilitys, only {name, amount, type}
		local ingred = ingred_structure(recipe.ingredients) --ingredients which produce multiple results
		local full_result_amount = 0
		local new_amount = {}
		for i, rtable in pairs(results) do -- example: rtable = {name=, type=, amount=}
			full_result_amount = full_result_amount + rtable.amount
		end
		for i, rtable in pairs(results) do -- example results has 3 entries: heavy oil, light oil, petrol-> i = 1,2,3
			recipes[recipe_name .. "--" .. i] = table.deepcopy(recipe) -- copy for each result of recipe_name and write it in initial recipes table
			recipes[recipe_name .. "--" .. i].name = recipe_name .. "--" .. i
			recipes[recipe_name .. "--" .. i].results = {rtable}
			recipes[recipe_name .. "--" .. i].ingredients = table.deepcopy(ingred) -- use uniform data structure
			for k, ingredi in pairs(ingred) do -- example ingred { {name="water"....}, {name="oil"....}}-> ingredi = {name="water"....}

				new_amount[k] = ingredi.amount * rtable.amount / full_result_amount -- example: basic oil processing: 3 heavy oil, 3 light oil, 4 petrol: rtable for heavy oil--> rtable.amount=4 , full_result_amount=3+3+4=10, ingredi.amount=10 oil-->new_amount=3
				recipes[recipe_name .. "--" .. i].ingredients[k].amount = new_amount[k]
			end
		end
		delete_recipe(name) --after adding recipes for alle the diffrent results of recipe, the original can be deleted
	end
end



delete_recipe("wooden-box")
delete_recipe("steel-box")
delete_recipe("tungsten-box")
delete_recipe("empty-barrel")
delete_recipe("gas-canister")
delete_recipe("empty-canister")

local j = table_length(recipes)
local l = j + 1
while j < l do -- l will stop loop if j stops decreasing
	for name, recipe_table in pairs(recipes) do
		if contains_known_recipe(recipe_table) then 
			make_known_recipe(recipe_table)
			delete_recipe(name)
		end
	end
	j = table_length(recipes)
	if j == 0 then break end
	l=l-1
end
--print("Not recognized recipes: " .. j)
--print(serpent.block(recipes))


-- deletes black listed items
for i, name in pairs(black_list_item) do
	item[name] = nil
end
-- deletes black listed fluids
for i, name in pairs(black_list_fluid) do
	fluid[name] = nil
end


-- restrutucture result node in recipes table; delete multiple results
for name, recipe  in pairs(recipes_copy) do
	if recipe.results and #recipe.results > 1 then -- checked for multiple results
		recipes_copy[name] = nil
	elseif recipe.result then 
		recipe.results = {{name = recipe.result, type="item"}} 
		recipe.result = nil -- restructure result node in recipes table
	end
end

local function technology_unlock_recipe(technology, recipe_name) -- returns true if technology unlocks recipe
	if not technology.effects then return false end
	local n = #technology.effects
	for i=1,n do
		--print(serpent.block(technology.effects[i]))
		if technology.effects[i] and technology.effects[i].type == "unlock-recipe" and technology.effects[i].recipe == recipe_name then
			return true
		end
	end
	return false
end

-- find preq for the entries in item: Search for recipes with single result->search for technologie which enables this recipe -> add this tech to preq
for name, rtable in pairs(item) do
	local recipe_name
		for name2, rtable2 in pairs(recipes_copy) do 
			if name == rtable2.results[1].name then 
				recipe_name = name2
				for tech_name, tech in pairs(data.raw.technology) do
					if not tech_name:match("repltech") and technology_unlock_recipe(tech, recipe_name) then
						item[name].preq = tech_name
						--print(serpent.block(item[name]))
					end
				end
			end
		end
end
--[[
for name, rtable in pairs(fluid) do
	local recipe_name
		for name2, rtable2 in pairs(recipes_copy) do 
			if name == rtable2.results[1].name then 
				recipe_name = name2 -- Recept_name for an fluid is know known
				for tech_name, tech in pairs(data.raw.technology) do
					if not tech_name:match("repltech") and technology_unlock_recipe(tech, recipe_name) then
						fluid[name].preq = tech_name
						print(name .. "-----" .. serpent.block(fluid[name]))
					end
				end
			end
		end
end

local debug1 = 0
local debug2 = 0
for _, tab in pairs(item) do
	if tab.preq then debug1=debug1+1 else debug2=debug2+1 end
end
print("debug1: " .. debug1)
print("debug2: " .. debug2)
]]

--print(serpent.block(recipes,{comment=false}))
--print(serpent.block(item,{comment=false}))
--print(serpent.block(fluid,{comment=false}))
--print(table_length(recipes))



item_numbervec = {}

for name, rtable in pairs(item) do
	if rtable.comp ~= 0 then
		item_numbervec[#item_numbervec+1] = rtable.comp
	end
end

table.sort(item_numbervec)


local n = table_length(item_numbervec)
local function sum(t)
    local sum = 0
    for k,v in pairs(t) do
        sum = sum + v
    end
    return sum
end
function round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

local function quantil(t, p)
	table.sort(t)
	local n = table_length(t)
	if (n * p) % 1 == 0 then
		return (t[n*p]+t[n*p+1])/2
	else
		return t[round(n*p)]
	end
end

--[[print(item_numbervec[1])
print(quantil(item_numbervec, 1/5))
print(quantil(item_numbervec, 2/5))
print(quantil(item_numbervec, 3/5))
print(quantil(item_numbervec, 4/5))
print(item_numbervec[table_length(item_numbervec)])]]

quantiles = {}
quantiles[1] = 0
quantiles[2] = quantil(item_numbervec, 1/5)
quantiles[3] = quantil(item_numbervec, 2/5)
quantiles[4] = quantil(item_numbervec, 3/5)
quantiles[5] = quantil(item_numbervec, 4/5)
quantiles[6] = item_numbervec[table_length(item_numbervec)]+1


entity_set = {}
equipment_set ={}
for category, rtable in pairs(data.raw) do
	for name, rtable2 in pairs(rtable) do 
		if rtable2.selection_box then entity_set[name] = true end
	end
end
for category, rtable in pairs(data.raw) do
	for name, rtable2 in pairs(rtable) do 
		if rtable2.placed_as_equipment_result then equipment_set[name] = true end
	end
end

pen_factor = quantil(item_numbervec, 0.5)
--print(pen_factor)
function repl_penalty(arg)
  local time
  local tier
  if (type(arg) == "table") then
    time = arg["time"]
    tier = arg["tier"] or 0
  else
    time=arg
    tier=0
  end
  -- ceil to the third leading number
  return time * (1 + math.sqrt(tier) / pen_factor) * replcation_time_factor
end

--it[t]=1
