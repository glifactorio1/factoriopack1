function research(count, one, two, three, four, time)
  local ing = {}
  if one > 0 then ing[#ing + 1] = {"science-pack-1", one} end
  if two > 0 then ing[#ing + 1] = {"science-pack-2", two} end
  if three > 0 then ing[#ing + 1] = {"science-pack-3", three} end
  if four > 0 then ing[#ing + 1] = {"alien-science-pack", four} end
  local unit = {
    count = count or 10,
    ingredients = ing,
    time = time * (one + two + three + four)
  }
  return unit
end

function repl_research(count, one, two, three, four, time)
  local ing = {}
  if one > 0 then ing[#ing + 1] = {"rare-earth", one} end
  if two > 0 then ing[#ing + 1] = {"rare-earth-magnet", two} end
  if three > 0 then ing[#ing + 1] = {"superconductor", three} end
  if four > 0 then ing[#ing + 1] = {"ion-conduit", four} end
  local unit = {
    count = count or 10,
    ingredients = ing,
    time = time * (one + two + three + four)
  }
  return unit
end
require("prototypes.pipe-position")
require("prototypes.rare-earth")
require("prototypes.item-groups")
require("prototypes.rare-earth-processing-items")
require("prototypes.replication-lab")
require("prototypes.replicators")
require("prototypes.replication")