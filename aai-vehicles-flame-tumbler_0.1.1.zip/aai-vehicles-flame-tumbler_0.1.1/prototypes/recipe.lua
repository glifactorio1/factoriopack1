data:extend({{
	type = "recipe",
	name = "vehicle-flame-tumbler",
	ingredients =
	{
		{"car", 1},
		{"steel-plate", 25},
		{"engine-unit", 25},
		{"advanced-circuit", 25}
	},
	enabled = false,
	energy_required = 5,
	results=
	{
	  {type="item", name="vehicle-flame-tumbler", amount=1},
	}
}})
