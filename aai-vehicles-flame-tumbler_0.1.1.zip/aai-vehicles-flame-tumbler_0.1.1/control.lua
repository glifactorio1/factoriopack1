script.on_configuration_changed(function()
	for _, force in pairs(game.forces) do
		force.reset_recipes()
		force.reset_technologies()
		for tech_name, tech in pairs(force.technologies) do
			if tech.researched then
				tech.researched = false
				tech.researched = true
			end
		end
	end
end)