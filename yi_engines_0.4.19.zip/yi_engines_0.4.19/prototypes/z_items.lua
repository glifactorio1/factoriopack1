
--automatically generated file | fMT-Export (c)YT v0.04-216Mrz03
--export-date: 2016-Jul-11

data:extend({

{
   type="item", name="ye_plant_carni", icon="__yi_engines__/graphics/icons/carni.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="d9",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_package_carni", icon="__yi_engines__/graphics/icons/package_carni.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_agro_package", order="d9",  
   stack_size = 50, default_request_amount = 5,
},
{
   type="item", name="ye_can_water", icon="__yi_engines__/graphics/can_water_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="w2",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_can_cw", icon="__yi_engines__/graphics/can_cw_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="w1",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_icemaker", icon="__yi_engines__/graphics/entity/icemaker_icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie_machinery2", order="f1",  
   stack_size = 25, default_request_amount = 5,
   place_result="ye_icemaker", 
},
{
   type="item", name="ye_package_spliced_cells", icon="__yi_engines__/graphics/icons/package_cells.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_agro_package", order="d8",  
   stack_size = 50, default_request_amount = 5,
},
{
   type="item", name="ye_package_verotin", icon="__yi_engines__/graphics/icons/package_verotin.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_agro_package", order="d6",  
   stack_size = 50, default_request_amount = 5,
},
{
   type="item", name="ye_package_omtrinit", icon="__yi_engines__/graphics/icons/package-omtrinit.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_agro_package", order="d5",  
   stack_size = 50, default_request_amount = 5,
},
{
   type="item", name="ye_package_organic", icon="__yi_engines__/graphics/icons/package_om.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_agro_package", order="d7",  
   stack_size = 50, default_request_amount = 5,
},
{
   type="item", name="ye_package_substratin", icon="__yi_engines__/graphics/icons/package_substrat.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_agro_package", order="d4",  
   stack_size = 50, default_request_amount = 5,
},
{
   type="item", name="ye_package_c_meat", icon="__yi_engines__/graphics/icons/package_cooked_meat.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_agro_package", order="d2",  
   stack_size = 50, default_request_amount = 5,
},
{
   type="item", name="ye_package_r_meat", icon="__yi_engines__/graphics/icons/package_raw_meat.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_agro_package", order="d1",  
   stack_size = 50, default_request_amount = 5,
},
{
   type="item", name="ye_package_empty", icon="__yi_engines__/graphics/icons/package_empty.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie-parts", order="a",  
   stack_size = 600, default_request_amount = 50,
},
{
   type="item", name="ye_ice_container_empty", icon="__yi_engines__/graphics/icons/ice_container_empty.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie-parts", order="a",  
   stack_size = 400, default_request_amount = 20,
},
{
   type="item", name="ye_ice_container_filled", icon="__yi_engines__/graphics/icons/ice_container_filled.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie-parts", order="a",  
   stack_size = 200, default_request_amount = 10,
},
{
   type="item", name="ye_dnasplicer", icon="__yi_engines__/graphics/entity/dna_splicer_icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie_agromachinery", order="a",  
   stack_size = 20, default_request_amount = 5,
   place_result="ye_dnasplicer", 
},
{
   type="item", name="ye_fassembly1", icon="__yi_engines__/graphics/entity/factory_var_1_icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie_machinery2", order="a1",  
   stack_size = 20, default_request_amount = 5,
   place_result="ye_fassembly1", 
},
{
   type="item", name="ye_fassembly_sp", icon="__yi_engines__/graphics/entity/factory_var_3_icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie_machinery2", order="a3",  
   stack_size = 20, default_request_amount = 5,
   place_result="ye_fassembly_sp", 
},
{
   type="item", name="ye_fassembly2", icon="__yi_engines__/graphics/entity/factory_var_2_icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie_machinery2", order="a2",  
   stack_size = 20, default_request_amount = 5,
   place_result="ye_fassembly2", 
},
{
   type="item", name="ye_can_unicomp", icon="__yi_engines__/graphics/can_uc_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie-engines", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="yie_science_blue_gen", icon="__yi_engines__/graphics/entity/science_gen_icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie_machinery", order="a",  
   stack_size = 25, default_request_amount = 5,
   place_result="yie_science_blue_gen", 
},
{
   type="item", name="yie_hard_metals", icon="__yi_engines__/graphics/icons/blechrolle_32.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie-parts", order="a",  
   stack_size = 400, default_request_amount = 25,
},
{
   type="item", name="yie_crystal_grey", icon="__yi_engines__/graphics/icons/quarz_a32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_crystalite", icon="__yi_engines__/graphics/icons/rohkris_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_krakon5", icon="__yi_engines__/graphics/icons/krak_8_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_krakon4", icon="__yi_engines__/graphics/icons/krak_5_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_krakon3", icon="__yi_engines__/graphics/icons/krak_3_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_krakon2", icon="__yi_engines__/graphics/icons/krak_2_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_krakon1", icon="__yi_engines__/graphics/icons/krak_1_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_center", icon="__yi_engines__/graphics/icons/uni-k_zer_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_dnaline", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_yellow_split", icon="__yi_engines__/graphics/icons/gelb_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_dnaline", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_yellow_core", icon="__yi_engines__/graphics/icons/gelb2_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_dnaline", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_base_brown", icon="__yi_engines__/graphics/icons/kautschuk2_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_base_green", icon="__yi_engines__/graphics/icons/biomasse_a.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_zells", icon="__yi_engines__/graphics/icons/zellen_a.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_substrat", icon="__yi_engines__/graphics/icons/substrat_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_verotin", icon="__yi_engines__/graphics/icons/veroi_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_ferrotin", icon="__yi_engines__/graphics/icons/ferotin_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_chitrotin", icon="__yi_engines__/graphics/icons/chitrotin_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_c60crystal", icon="__yi_engines__/graphics/icons/ematrix_rot_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_magnalit", icon="__yi_engines__/graphics/icons/ematrix_lila_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_omtrinit", icon="__yi_engines__/graphics/icons/prisma_krist_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_organic_metall", icon="__yi_engines__/graphics/icons/lebmetal_32.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_can_petrol", icon="__yi_engines__/graphics/can_petrol_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_can_ho", icon="__yi_engines__/graphics/can_ho_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_can_sa", icon="__yi_engines__/graphics/can_sa_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_can_co", icon="__yi_engines__/graphics/can_co_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_meatcooked", icon="__yi_engines__/graphics/cooked_meat.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 700, default_request_amount = 50,
},
{
   type="item", name="ye_dna", icon="__yi_engines__/graphics/dna.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_farming", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_rawmeat", icon="__yi_engines__/graphics/raw_meat.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 900, default_request_amount = 100,
},
{
   type="item", name="ye_meatfarm", icon="__yi_engines__/graphics/entity/cage_empty_icon.png", flags={"goes-to-quickbar"}, 
   group="yie_harvest", subgroup="yie_agromachinery", order="a",  
   stack_size = 100, default_request_amount = 5,
   place_result="ye_meatfarm", 
},
{
   type="item", name="ye_can_slurry", icon="__yi_engines__/graphics/can_dg_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_can_blood", icon="__yi_engines__/graphics/can_red_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 100, default_request_amount = 5,
},
--can-machinery
{
   type="item", name="ye_canmachine", icon="__yi_engines__/graphics/canning-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie_machinery", order="a",  
   stack_size = 20, default_request_amount = 5,
   place_result="ye_canmachine", 
},
{
   type="item", name="ye_can_eth", icon="__yi_engines__/graphics/can_eth_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_can_veg", icon="__yi_engines__/graphics/can_veg_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_can_lub", icon="__yi_engines__/graphics/can_lub_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_can_mf", icon="__yi_engines__/graphics/can_mf_f.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 100, default_request_amount = 5,
},
{
   type="item", name="ye_sealing", icon="__yi_engines__/graphics/sealing.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 125, default_request_amount = 25,
},
{
   type="item", name="ye_canister", icon="__yi_engines__/graphics/canister.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie_fluid_handle", order="a",  
   stack_size = 325, default_request_amount = 25,
},
--TMFW-Gen 1.1/8.913 - S
{
   type="item", name="ye_tfmw_generator-s", icon="__yi_engines__/graphics/entity/energy2/hngen-o-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-exp", order="a",  
   stack_size = 10, default_request_amount = 5,
   place_result="ye_tfmw_generator-s", 
},
--sugar
{
   type="item", name="ye_sugar", icon="__yi_engines__/graphics/sugar.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie-processed", order="a",  
   stack_size = 500, default_request_amount = 25,
},
--ausgangsstoff f�r biofuel
{
   type="item", name="ye_biomixed", icon="__yi_engines__/graphics/biomixed.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 150, default_request_amount = 25,
   fuel_value="80MJ", 
},
--cellulose
{
   type="item", name="ye_celluose", icon="__yi_engines__/graphics/cellulose.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 150, default_request_amount = 25,
},
--sugar
{
   type="item", name="ye_corn_b", icon="__yi_engines__/graphics/sugarcane.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 800, default_request_amount = 100,
   fuel_value="2MJ", 
},
--sugar
{
   type="item", name="ye_seed_b", icon="__yi_engines__/graphics/sugar-seed.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 25, default_request_amount = 5,
},
--AKW Rheinsberg
{
   type="item", name="ye_rheinsberg", icon="__yi_engines__/graphics/entity/rheinsberg-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-exp", order="a",  
   stack_size = 25, default_request_amount = 5,
   place_result="ye_rheinsberg", 
},
--Steam-Turbine
{
   type="item", name="ye_sturbine", icon="__yi_engines__/graphics/entity/energy2/turbine_icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-engines", order="a",  
   stack_size = 25, default_request_amount = 5,
   place_result="ye_sturbine", 
},
--Steamer
{
   type="item", name="ye_overheater", icon="__yi_engines__/graphics/entity/heater55_icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-exp", order="a",  
   stack_size = 25, default_request_amount = 5,
   place_result="ye_overheater", 
},
--Small E-Motor
{
   type="item", name="y-emotor-s", icon="__yi_engines__/graphics/entity/e-motor-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-engines", order="a",  
   stack_size = 20, default_request_amount = 5,
   place_result="y-emotor-s", 
},
--Little Stirling Engine
{
   type="item", name="y-1stirling-engine", icon="__yi_engines__/graphics/icons/fce-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-engines", order="a",  
   stack_size = 100, default_request_amount = 5,
   place_result="y-1stirling-engine", 
},
--Electric Air-Heater
{
   type="item", name="y-electric-air-heater", icon="__yi_engines__/graphics/entity/energy2/air-heater-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-engines", order="a",  
   stack_size = 20, default_request_amount = 5,
   place_result="y-electric-air-heater", 
},
--Underground-Shaft
{
   type="item", name="y-mftrans-shaft-ground", icon="__yi_engines__/graphics/entity/shaft-pipe/shaft-ground-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-parts", order="a",  
   stack_size = 100, default_request_amount = 10,
   place_result="y-mftrans-shaft-ground", 
},
--Underground-Shaft-Red
{
   type="item", name="y-mftrans-shaft-ground-red", icon="__yi_engines__/graphics/entity/shaft-pipe/shaft-ground-r-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-parts", order="a",  
   stack_size = 100, default_request_amount = 10,
   place_result="y-mftrans-shaft-ground-red", 
},
--blue transmission shaft
{
   type="item", name="y-mftrans-shaft", icon="__yi_engines__/graphics/entity/shaft-pipe/shaft-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-parts", order="a",  
   stack_size = 100, default_request_amount = 20,
   place_result="y-mftrans-shaft", 
},
--blue transmission shaft
{
   type="item", name="y-mftrans-shaft-red", icon="__yi_engines__/graphics/entity/shaft-pipe/shaft-r-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-parts", order="a",  
   stack_size = 100, default_request_amount = 20,
   place_result="y-mftrans-shaft-red", 
},
--gearbox
{
   type="item", name="y-gearbox-power", icon="__yi_engines__/graphics/entity/gearbox-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-engines", order="a",  
   stack_size = 20, default_request_amount = 5,
   place_result="y-gearbox-power", 
},
{
   type="item", name="y-iron-case", icon="__yi_engines__/graphics/caseing-icon.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie-engines", order="a",  
   stack_size = 100, default_request_amount = 10,
},
--quantrium-reactor
{
   type="item", name="y-quantrinum-reactor", icon="__yi_engines__/graphics/entity/energy2/qr-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-engines", order="a",  
   stack_size = 20, default_request_amount = 5,
   place_result="y-quantrinum-reactor", 
},
--solid-fuel-engine
{
   type="item", name="y-sfe", icon="__yi_engines__/graphics/entity/energy2/sfe-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-engines", order="a",  
   stack_size = 20, default_request_amount = 5,
   place_result="y-sfe", 
},
--liquid-fuel-engine
{
   type="item", name="y-ffe", icon="__yi_engines__/graphics/entity/energy2/ffe-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-parts", order="a",  
   stack_size = 20, default_request_amount = 5,
   place_result="y-ffe", 
},
--Motor Wicklung
{
   type="item", name="y-winding", icon="__yi_engines__/graphics/winding-icon.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie-parts", order="i1",  
   stack_size = 30, default_request_amount = 5,
},
--water-pump
{
   type="item", name="y-mwater-pump", icon="__yi_engines__/graphics/entity/pump-icon.png", flags={"goes-to-quickbar"}, 
   group="yi_engines", subgroup="yie-engines", order="a",  
   stack_size = 10, default_request_amount = 5,
   place_result="y-mwater-pump", 
},
{
   type="item", name="ye_farm", icon="__yi_engines__/graphics/entity/farm-icon.png", flags={"goes-to-quickbar"}, 
   group="yie_harvest", subgroup="yie_agromachinery", order="a",  
   stack_size = 20, default_request_amount = 5,
   place_result="ye_farm", 
},
{
   type="item", name="ye_seed_a", icon="__yi_engines__/graphics/seed-icon.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 25, default_request_amount = 5,
},
{
   type="item", name="ye_corn_a", icon="__yi_engines__/graphics/corn-icon.png", flags={"goes-to-main-inventory"}, 
   group="yie_harvest", subgroup="yie_agroproducts", order="a",  
   stack_size = 800, default_request_amount = 5,
},
--quantrinum
{
   type="item", name="y-quantrinum-charge", icon="__yi_engines__/graphics/quantrinum-32.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie-processed", order="1",  
   stack_size = 25, default_request_amount = 5,
},
--waste
{
   type="item", name="y-pol-waste", icon="__yi_engines__/graphics/icons/kalkstein_32.png", flags={"goes-to-main-inventory"}, 
   group="yi_engines", subgroup="yie-processed", order="1",  
   stack_size = 300, default_request_amount = 100,
},

})