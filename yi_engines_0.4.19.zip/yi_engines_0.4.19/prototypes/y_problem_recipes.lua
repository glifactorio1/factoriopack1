
data:extend({


	{
	  type = "recipe",
	  name = "ye_dna_plant4_recipe",
	  category = "yrcat_dna", -- DNA-Line
	  enabled = "true",
	  energy_required = 10.00,
	  ingredients = {
		{ type = "fluid", name = "y-mechanical-force" , amount = 8.0, },
		{ type = "item", name = "ye_zells" , amount = 4.0, },
	  },
	  results = {
		{ type = "item", name = "ye_plant_carni", amount = 1.0, },
		{ type = "item", name = "y_greensign", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/carni_splice.png",
	  order = "p3", group = "yie_harvest", subgroup = "yie_dnaline",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_grow_plant2_recipe",
	  category = "yrcat-farm", -- farm itself
	  enabled = "true",
	  energy_required = 450.00,
	  ingredients = {
		{ type = "item", name = "ye_plant_carni" , amount = 1.0, },
		{ type = "fluid", name = "water" , amount = 300.0, },
		{ type = "item", name = "ye_rawmeat" , amount = 30.0, },
	  },
	  results = {
		{ type = "item", name = "ye_chitrotin", amount = 10.0, },
		{ type = "item", name = "ye_zells", amount = 8.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/carni.png",
	  order = "a15", group = "yie_harvest", subgroup = "yie_farming",
	},
	
	-- 
	{
	  type = "recipe",
	  name = "ye_package_carni_recipe",
	  category = "crafting", -- 
	  enabled = "true",
	  energy_required = 4.00,
	  ingredients = {
		{ type = "item", name = "ye_package_empty" , amount = 1.0, },
		{ type = "item", name = "ye_chitrotin" , amount = 10.0, },
	  },
	  results = {
		{ type = "item", name = "ye_package_carni", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_carni.png",
	  order = "d9", group = "yi_engines", subgroup = "yie_agro_package",
	},
	
	-- 
	{
	  type = "recipe",
	  name = "ye_export06_recipe",
	  category = "yuoki-stargate-recipe", -- stargate-trades
	  enabled = "true",
	  energy_required = 3.00,
	  ingredients = {
		{ type = "item", name = "ye_package_carni" , amount = 5.0, },
	  },
	  results = {
		{ type = "item", name = "ypfw_trader_sign", amount = 15.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_carni_retrade.png",
	  order = "exp07", group = "yie_harvest", subgroup = "yie_trades",
	},
	-- 
	{
	  type = "recipe",
	  name = "ye_neutralisatzion_recipe",
	  category = "yuoki-archaeology-wash", -- 
	  enabled = "true",
	  energy_required = 2.00,
	  ingredients = {
		{ type = "fluid", name = "sulfuric-acid" , amount = 9.0, },
		{ type = "item", name = "ye_substrat" , amount = 40.0, },
		{ type = "fluid", name = "water" , amount = 100.0, },
	  },
	  results = {
		{ type = "fluid", name = "y-con_water", amount = 20.0, },
		{ type = "fluid", name = "y-mechanical-force", amount = 9.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/wh_plateq32.png",
	  order = "v4", group = "yi_engines", subgroup = "yie-fluids",
	},

	{
	  type = "recipe",
	  name = "ye_export05_recipe",
	  category = "yuoki-stargate-recipe", -- stargate-trades
	  enabled = "true",
	  energy_required = 3.00,
	  ingredients = {
		{ type = "item", name = "ye_package_spliced_cells" , amount = 10.0, },
	  },
	  results = {
		--{ type = "item", name = "ypfw_trader_sign", amount = 5.0, },
		--{ type = "item", name = "ye_science_blue", amount = 5.0, },
		{ type = "item", name = "ye_krakon2", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_cells_trade.png",
	  order = "exp07", group = "yie_harvest", subgroup = "yie_trades",
	},
	-- 
	{
	  type = "recipe",
	  name = "ye_export04_recipe",
	  category = "yuoki-stargate-recipe", -- stargate-trades
	  enabled = "true",
	  energy_required = 3.00,
	  ingredients = {
		{ type = "item", name = "ye_package_organic" , amount = 10.0, },
	  },
	  results = {
		{ type = "item", name = "ypfw_trader_sign", amount = 100.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_om_trade.png",
	  order = "exp06", group = "yie_harvest", subgroup = "yie_trades",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_export03_recipe",
	  category = "yuoki-stargate-recipe", -- stargate-trades
	  enabled = "true",
	  energy_required = 3.00,
	  ingredients = {
		{ type = "item", name = "ye_package_verotin" , amount = 10.0, },
		{ type = "item", name = "y-fame" , amount = 2.0, },
	  },
	  results = {
		{ type = "item", name = "ypfw_trader_sign", amount = 20.0, },
		{ type = "item", name = "y-infused-uca2", amount = 20.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_verotin_trade.png",
	  order = "exp05", group = "yie_harvest", subgroup = "yie_trades",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_export02_recipe",
	  category = "yuoki-stargate-recipe", -- stargate-trades
	  enabled = "true",
	  energy_required = 3.00,
	  ingredients = {
		{ type = "item", name = "ye_package_omtrinit" , amount = 10.0, },
	  },
	  results = {
		{ type = "item", name = "ypfw_trader_sign", amount = 50.0, },
		{ type = "item", name = "y-fame", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package-omtrinit-trade.png",
	  order = "exp04", group = "yie_harvest", subgroup = "yie_trades",
	},
	
	-- 
	{
	  type = "recipe",
	  name = "ye_export01_recipe",
	  category = "yuoki-stargate-recipe", -- stargate-trades
	  enabled = "true",
	  energy_required = 3.00,
	  ingredients = {
		{ type = "item", name = "ye_package_substratin" , amount = 10.0, },
	  },
	  results = {
		{ type = "item", name = "ypfw_trader_sign", amount = 10.0, },
		{ type = "item", name = "y_greensign", amount = 3.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_substrat_trade.png",
	  order = "exp03", group = "yie_harvest", subgroup = "yie_trades",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_package_verotin_recipe",
	  category = "crafting", -- 
	  enabled = "true",
	  energy_required = 4.00,
	  ingredients = {
		{ type = "item", name = "ye_package_empty" , amount = 1.0, },
		{ type = "item", name = "ye_verotin" , amount = 10.0, },
	  },
	  results = {
		{ type = "item", name = "ye_package_verotin", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_verotin.png",
	  order = "d6", group = "yi_engines", subgroup = "yie_agro_package",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_package_omtrinit_recipe",
	  category = "crafting", -- 
	  enabled = "true",
	  energy_required = 4.00,
	  ingredients = {
		{ type = "item", name = "ye_package_empty" , amount = 1.0, },
		{ type = "item", name = "ye_omtrinit" , amount = 12.0, },
	  },
	  results = {
		{ type = "item", name = "ye_package_omtrinit", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package-omtrinit.png",
	  order = "d5", group = "yi_engines", subgroup = "yie_agro_package",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_package_organic_recipe",
	  category = "crafting", -- 
	  enabled = "true",
	  energy_required = 6.00,
	  ingredients = {
		{ type = "item", name = "ye_ice_container_filled" , amount = 1.0, },
		{ type = "item", name = "ye_organic_metall" , amount = 10.0, },
		{ type = "item", name = "ye_package_empty" , amount = 1.0, },
	  },
	  results = {
		{ type = "item", name = "ye_package_organic", amount = 1.0, },
		{ type = "item", name = "ye_ice_container_empty", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_om.png",
	  order = "d7", group = "yi_engines", subgroup = "yie_agro_package",
	},
	{
	  type = "recipe",
	  name = "ye_package_substratin_recipe",
	  category = "crafting", -- 
	  enabled = "true",
	  energy_required = 6.00,
	  ingredients = {
		{ type = "item", name = "ye_ice_container_filled" , amount = 1.0, },
		{ type = "item", name = "ye_substrat" , amount = 40.0, },
		{ type = "item", name = "ye_package_empty" , amount = 2.0, },
	  },
	  results = {
		{ type = "item", name = "ye_package_substratin", amount = 2.0, },
		{ type = "item", name = "ye_ice_container_empty", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_substrat.png",
	  order = "d4", group = "yi_engines", subgroup = "yie_agro_package",
	},
	{
	  type = "recipe",
	  name = "ye_package_c_meat_recipe",
	  category = "crafting", -- 
	  enabled = "true",
	  energy_required = 6.00,
	  ingredients = {
		{ type = "item", name = "ye_ice_container_filled" , amount = 1.0, },
		{ type = "item", name = "ye_meatcooked" , amount = 7.0, },
		{ type = "item", name = "ye_package_empty" , amount = 1.0, },
	  },
	  results = {
		{ type = "item", name = "ye_package_c_meat", amount = 1.0, },
		{ type = "item", name = "ye_ice_container_empty", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_cooked_meat.png",
	  order = "d2", group = "yi_engines", subgroup = "yie_agro_package",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_package_r_meat_recipe",
	  category = "crafting", -- 
	  enabled = "true",
	  energy_required = 6.00,
	  ingredients = {
		{ type = "item", name = "ye_ice_container_filled" , amount = 2.0, },
		{ type = "item", name = "ye_package_empty" , amount = 4.0, },
		{ type = "item", name = "ye_rawmeat" , amount = 120.0, },
	  },
	  results = {
		{ type = "item", name = "ye_package_r_meat", amount = 4.0, },
		{ type = "item", name = "ye_ice_container_empty", amount = 2.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_raw_meat.png",
	  order = "d1", group = "yi_engines", subgroup = "yie_agro_package",
	},	
	
	-- 
	{
	  type = "recipe",
	  name = "ye_package_empty_recipe",
	  category = "crafting", -- 
	  enabled = "true",
	  energy_required = 4.00,
	  ingredients = {
		{ type = "item", name = "y-iron-case" , amount = 1.0, },
		{ type = "item", name = "y_organic_dust" , amount = 6.0, },
	  },
	  results = {
		{ type = "item", name = "ye_package_empty", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/package_empty.png",
	  order = "a", group = "yi_engines", subgroup = "yie-parts",
	},
	
	-- 
	{
	  type = "recipe",
	  name = "ye_ice_container_filled_recipe",
	  category = "yrcat_icemaker", -- Ice-Maker
	  enabled = "true",
	  energy_required = 60.00,
	  ingredients = {
		{ type = "item", name = "ye_ice_container_empty" , amount = 20.0, },
		{ type = "fluid", name = "y-mechanical-force" , amount = 8.0, },
		{ type = "fluid", name = "water" , amount = 400.0, },
	  },
	  results = {
		{ type = "item", name = "ye_ice_container_filled", amount = 20.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/ice_container_filled.png",
	  order = "a", group = "yi_engines", subgroup = "yie-fluids",
	},
	
	-- 
	{
	  type = "recipe",
	  name = "ye_grow_animal4_recipe",
	  category = "yrcat_meat", -- meat-category
	  enabled = "true",
	  energy_required = 600.00,
	  ingredients = {
		{ type = "item", name = "ye_krakon3" , amount = 1.0, },
		{ type = "item", name = "yie_hard_metals" , amount = 32.0, },
		{ type = "fluid", name = "lubricant" , amount = 22.0, },
		{ type = "item", name = "y-slag" , amount = 62.0, },
	  },
	  results = {
		{ type = "item", name = "ye_organic_metall", amount = 40.0, },
		{ type = "fluid", name = "ye_slurry", amount = 36.0, },
		{ type = "item", name = "ye_science_blue", amount = 3.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/animal_4.png",
	  order = "fa4", group = "yie_harvest", subgroup = "yie_animals",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_dna_animal4_recipe",
	  category = "yrcat_dna", -- DNA-Line
	  enabled = "true",
	  energy_required = 20.00,
	  ingredients = {
		{ type = "item", name = "ye_verotin" , amount = 3.0, },
		{ type = "item", name = "ye_dna" , amount = 1.0, },
		{ type = "item", name = "ye_substrat" , amount = 5.0, },
		{ type = "item", name = "ye_science_blue" , amount = 2.0, },
		{ type = "fluid", name = "y-mechanical-force" , amount = 100.0, },
	  },
	  results = {
		{ type = "item", name = "ye_krakon3", amount = 1.0, },
		{ type = "item", name = "y_greensign", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/animal_4_splice.png",
	  order = "g3", group = "yie_harvest", subgroup = "yie_dnaline",
	},
	
	-- 
	{
	  type = "recipe",
	  name = "ye_grow_animal3_recipe",
	  category = "yrcat_meat", -- meat-category
	  enabled = "true",
	  energy_required = 1200.00,
	  ingredients = {
		{ type = "item", name = "ye_krakon2" , amount = 1.0, },
		{ type = "item", name = "ye_substrat" , amount = 30.0, },
		{ type = "fluid", name = "crude-oil" , amount = 10.0, },
	  },
	  results = {
		{ type = "item", name = "ye_verotin", amount = 30.0, },
		{ type = "item", name = "ye_rawmeat", amount = 8.0, },
		{ type = "fluid", name = "ye_blood", amount = 2.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/animal_3.png",
	  order = "fa3", group = "yie_harvest", subgroup = "yie_animals",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_grow_animal2_recipe",
	  category = "yrcat_meat", -- meat-category
	  enabled = "true",
	  energy_required = 900.00,
	  ingredients = {
		{ type = "item", name = "ye_krakon1" , amount = 1.0, },
		{ type = "item", name = "y-pol-waste" , amount = 70.0, },
		{ type = "item", name = "ye_seed_b" , amount = 40.0, },
		{ type = "fluid", name = "ye_cornoil" , amount = 30.0, },
	  },
	  results = {
		{ type = "item", name = "ye_rawmeat", amount = 20.0, },
		{ type = "fluid", name = "ye_blood", amount = 3.0, },
		{ type = "item", name = "ye_omtrinit", amount = 24.0, },
		{ type = "fluid", name = "ye_slurry", amount = 42.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/animal_2.png",
	  order = "fa2", group = "yie_harvest", subgroup = "yie_animals",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_dna_animal3_recipe",
	  category = "yrcat_dna", -- DNA-Line
	  enabled = "true",
	  energy_required = 20.00,
	  ingredients = {
		{ type = "item", name = "ye_science_blue" , amount = 1.0, },
		{ type = "item", name = "ye_dna" , amount = 1.0, },
	  },
	  results = {
		{ type = "item", name = "ye_krakon2", amount = 1.0, },
		{ type = "item", name = "y_greensign", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/animal_3_splice.png",
	  order = "g2", group = "yie_harvest", subgroup = "yie_dnaline",
	},

	-- 
	{
	  type = "recipe",
	  name = "ye_dna_animal2_recipe",
	  category = "yrcat_dna", -- DNA-Line
	  enabled = "true",
	  energy_required = 20.00,
	  ingredients = {
		{ type = "item", name = "ye_dna" , amount = 1.0, },
		{ type = "item", name = "y_rwtechsign" , amount = 6.0, },
	  },
	  results = {
		{ type = "item", name = "ye_krakon1", amount = 1.0, },
		{ type = "item", name = "y_greensign", amount = 1.0, },
	  },
	  icon = "__yi_engines__/graphics/icons/animal_2_splice.png",
	  order = "g1", group = "yie_harvest", subgroup = "yie_dnaline",
	},
	
})