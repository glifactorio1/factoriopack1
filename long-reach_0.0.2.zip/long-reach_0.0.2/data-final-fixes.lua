data.raw.player.player.build_distance = 10000
data.raw.player.player.reach_distance = 10000
