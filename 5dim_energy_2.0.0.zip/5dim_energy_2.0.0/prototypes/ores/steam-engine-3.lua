data:extend({
-- Item
  {
    type = "item",
    name = "5d-steam-engine-3",
    icon = "__5dim_energy__/graphics/icon/icon_5d_steam-engine_3_.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy-engine-1",
    order = "b[steam-power]-b[steam-engine]",
    place_result = "5d-steam-engine-3",
    stack_size = 50
  },

--Recipe
  {
    type = "recipe",
    name = "5d-steam-engine-3",
    enabled = "false",
    ingredients =
    {
      {"5d-gold-wire", 5},
      {"5d-aluminium-gear-wheel", 12},
      {"5d-pipe-mk2", 12},
      {"zinc-plate", 12},
      {"5d-steam-engine-2", 1},
    },
    result = "5d-steam-engine-3"
  },

--Entity
  {
    type = "generator",
    name = "5d-steam-engine-3",
    icon = "__5dim_energy__/graphics/icon/icon_5d_steam-engine_3_.png",
    flags = {"placeable-neutral","player-creation"},
    minable = {mining_time = 1, result = "5d-steam-engine-3"},
    max_health = 300,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    effectivity = 3,
    fluid_usage_per_tick = 0.1,
    resistances =
    {
      {
        type = "fire",
        percent = 70
      }
    },
    collision_box = {{-1.35, -2.35}, {1.35, 2.35}},
    selection_box = {{-1.5, -2.5}, {1.5, 2.5}},
	fast_replaceable_group = "steam-engine",
    fluid_box =
    {
      base_area = 5,
      pipe_covers = pipecoverspictures(),
      pipe_connections =
      {
        { position = {0, 3} },
        { position = {0, -3} },
      },
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-output"
    },
    horizontal_animation =
    {
      filename = "__5dim_energy__/graphics/icon/icon_5d_steam-engine-horizontal_3.png",
      width = 246,
      height = 137,
      frame_count = 32,
      line_length = 8,
      shift = {1.34, -0.06}
    },
    vertical_animation =
    {
      filename = "__5dim_energy__/graphics/icon/icon_5d_steam-engine-vertical_3.png",
      width = 155,
      height = 186,
      frame_count = 32,
      line_length = 8,
      shift = {0.812, 0.031}
    },
    smoke =
    {
      {
        name = "smoke",
        north_position = {0, -2.2},
        east_position = {-1.9, -1.6},
        deviation = {0.2, 0.2},
        frequency = 2 / 31,
        starting_vertical_speed = 0.05
      }
    },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/steam-engine-90bpm.ogg",
        volume = 0.6
      },
      match_speed_to_activity = true,
    },
    min_perceived_performance = 0.25,
    performance_to_sound_speedup = 0.5
  },
})