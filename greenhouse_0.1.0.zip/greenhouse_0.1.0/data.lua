require("prototypes.entities")
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.technology")