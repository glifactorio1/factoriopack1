
game.reload_script()

for index, force in pairs(game.forces) do
  force.reset_recipes()
  force.reset_technologies()

  if force.technologies["natural-gas-processing"].researched then
    if force.recipes["ethane-to-ethylene"] then
      force.recipes["natural-gas-processing"].enabled = true
      force.recipes["hydrogen-to-solid-fuel"].enabled = true
      force.recipes["ethane-to-ethylene"].enabled = true
	end
  end
  
  if force.technologies["plastics"].researched then
    if force.recipes["ethylene-to-plastic"] then
      force.recipes["ethylene-to-plastic"].enabled = true
	end
  end
  
  if force.technologies["steam-power"].researched then
    if force.recipes["methane-power"] then
      force.recipes["methane-power"].enabled = true
	end
  end
end
