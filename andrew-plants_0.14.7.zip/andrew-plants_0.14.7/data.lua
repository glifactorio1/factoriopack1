
-- entity --
require("prototypes.entity.chemical-plants")
require("prototypes.entity.electric-furnace")
require("prototypes.entity.assembling-machine")
require("prototypes.entity.electronics-machine")
require("prototypes.entity.advanced-oil-refinery")

-- item --
require("prototypes.item.chemical-plants")
require("prototypes.item.electric-furnace")
require("prototypes.item.assembling-machine")
require("prototypes.item.electronics-machine")
require("prototypes.item.advanced-oil-refinery")

-- recipe --
require("prototypes.recipe.chemical-plants")
require("prototypes.recipe.electric-furnace")
require("prototypes.recipe.assembling-machine")
require("prototypes.recipe.electronics-machine")
require("prototypes.recipe.advanced-oil-refinery")
require("prototypes.recipe.crude-oil-to-heavy-oil")
require("prototypes.recipe.crude-oil-to-light-oil")
require("prototypes.recipe.crude-oil-to-petroleum-gas")
require("prototypes.recipe.heavy-oil-to-petroleum-gas")

-- technology --
require("prototypes.technology.advanced-material-processing")
require("prototypes.technology.chemical-processing")
require("prototypes.technology.automations")
require("prototypes.technology.electronics-machine")
require("prototypes.technology.advanced-oil-refinery")
require("prototypes.technology.oil-processing-to-heavy-oil")
require("prototypes.technology.oil-processing-to-light-oil")
require("prototypes.technology.oil-processing-to-petroleum-gas")


if data.raw.resource["natural-gas"] then
-- item --
require("prototypes.item.ethane")
require("prototypes.item.butane")
require("prototypes.item.hydrogen")
require("prototypes.item.ethylene")
require("prototypes.item.methane")

-- recipe --
require("prototypes.recipe.methane-power")
require("prototypes.recipe.hydrogen-to-solid-fuel")
require("prototypes.recipe.natural-gas-processing")
require("prototypes.recipe.ethane-to-ethylene")
require("prototypes.recipe.ethylene-to-plastic")

-- technology --
require("prototypes.technology.natural-gas-processing")
require("prototypes.technology.plastics")
require("prototypes.technology.steam-power")
end
