
-- crude-oil-to-heavy-oil --
data:extend(
{
  {
    type = "recipe",
    name = "crude-oil-to-heavy-oil",
    category = "advanced-oil-processing",
    icon = "__andrew-plants__/graphics/icons/fluid/crude-oil-to-heavy-oil.png",
    subgroup = "liquid-processing",
    order = "e",
    enabled = false,
    energy_required = 15,
    ingredients =
    {
      {type="fluid", name="water", amount=5},
      {type="fluid", name="crude-oil", amount=10}
    },
    results=
    {
      {type="fluid", name="heavy-oil", amount=10},
    },
  }
}
)
