data:extend(
{
  {
    type = "recipe",
    name = "electronics-machine-1",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "electronics-machine-1",
	result_count = 1,
    ingredients =
    {
      {"electronic-circuit", 5},
      {"iron-plate", 5},
      {"iron-gear-wheel", 5},
    },
  },
}
)


data:extend(
{
  {
    type = "recipe",
    name = "electronics-machine-2",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "electronics-machine-2",
	result_count = 1,
    ingredients =
    {
      {"electronics-machine-1", 1},
      {"advanced-circuit", 5},
      {"steel-plate", 5},
      {"iron-gear-wheel", 5},
    },
  },
}
)


data:extend(
{
  {
    type = "recipe",
    name = "electronics-machine-3",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "electronics-machine-3",
	result_count = 1,
    ingredients =
    {
      {"electronics-machine-2", 1},
      {"processing-unit", 5},
      {"steel-plate", 5},
      {"iron-gear-wheel", 5},
    },
  },
}
)



