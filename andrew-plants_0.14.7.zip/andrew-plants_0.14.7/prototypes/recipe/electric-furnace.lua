-- electric-furnace-2 --
data:extend(
{
  {
    type = "recipe",
    name = "electric-furnace-2",
    category = "crafting",
    enabled = false,
    energy_required = 5,
    result = "electric-furnace-2",
	result_count = 1,
    ingredients = {
      {"effectivity-module", 4},
	  {"concrete", 4},
      {"electric-furnace", 1},
    },
  },
}
)

-- electric-furnace-3 --
data:extend(
{
  {
    type = "recipe",
    name = "electric-furnace-3",
    category = "crafting",
    enabled = false,
    energy_required = 5,
    result = "electric-furnace-3",
	result_count = 1,
    ingredients = {
      {"speed-module-2", 4},
      {"electric-furnace-2", 1},
    },
  },
}
)

-- electric-furnace-4 --
data:extend(
{
  {
    type = "recipe",
    name = "electric-furnace-4",
    category = "crafting",
    enabled = false,
    energy_required = 5,
    result = "electric-furnace-4",
	result_count = 1,
    ingredients = {
      {"speed-module-3", 4},
      {"effectivity-module-2", 2},
      {"electric-furnace-3", 1},
    },
  },
}
)

-- electric-furnace-5 --
data:extend(
{
  {
    type = "recipe",
    name = "electric-furnace-5",
    category = "crafting",
    enabled = false,
    energy_required = 5,
    result = "electric-furnace-5",
	result_count = 1,
    ingredients = {
      {"speed-module-3", 5},
      {"effectivity-module-3", 3},
      {"electric-furnace-4", 1},
    },
  },
}
)
