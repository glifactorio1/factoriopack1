
-- methane-power --
data:extend(
{
  {
	type = "recipe",
	name = "methane-power",
	icon = "__andrew-plants__/graphics/icons/steam.png",
	category = "steam-boiler",
	subgroup = "liquid-recipe",
	order = "v",
	energy_required = 1,
	enabled = false,
	ingredients =
	{
	  {type="fluid", name="water", amount=60},
      {type="fluid", name="methane", amount=10},
	},
	results=
	{
	  {type="fluid", name="steam", amount=60, temperature = 250},
	}
  },
}
)
