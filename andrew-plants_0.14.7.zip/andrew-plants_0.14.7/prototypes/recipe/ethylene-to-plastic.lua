
-- ethylene-to-plastic --
data:extend(
{
  {
	type = "recipe",
	name = "ethylene-to-plastic",
	icon = "__andrew-plants__/graphics/icons/plastic-bar.png",
	category = "chemistry",
	enabled = false,
	energy_required = 5,
	ingredients =
	{
	  {type="fluid", name="ethylene", amount=6},
	  {type="fluid", name="butane", amount=6},
	},
	results=
	{
	  {"plastic-bar",4},
	}
  },
}
)
