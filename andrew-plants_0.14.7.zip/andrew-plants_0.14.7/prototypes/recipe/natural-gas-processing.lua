
-- natural-gas-processing --
data:extend(
{
  {
    type = "recipe",
    name = "natural-gas-processing",
    icon = "__andrew-plants__/graphics/icons/natural-gas.png",
    category = "oil-processing",
    subgroup = "liquid-processing",
    order = "c-a",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {type = "fluid", name = "natural-gas", amount = 10},
    },
    results=
    {
      {type = "fluid", name = "ethane", amount = 3},
	  {type = "fluid", name = "butane", amount = 3},
	  {type = "fluid", name = "methane", amount = 4},
    },
  },
}
)
