
-- crude-oil-to-petroleum-gas --
data:extend(
{
  {
    type = "recipe",
    name = "crude-oil-to-petroleum-gas",
    icon = "__andrew-plants__/graphics/icons/fluid/crude-oil-to-petroleum-gas.png",
    category = "advanced-oil-processing",
    subgroup = "liquid-processing",
    order = "c-b",
    enabled = false,
    energy_required = 15,
    ingredients =
    {
      {type="fluid", name="water", amount=5},
      {type="fluid", name="crude-oil", amount=10}
    },
    results=
    {
      {type="fluid", name="petroleum-gas", amount=10}
    },
  },
}
)
