
-- assembling-machine-4 --
data:extend(
{
  {
    type = "recipe",
    name = "assembling-machine-4",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "assembling-machine-4",
	result_count = 1,
    ingredients =
    {
      {"assembling-machine-3", 1},
      {"advanced-circuit", 3},
      {"steel-plate", 9},
      {"steel-bearing", 5},
      {"steel-gear-wheel", 5},
    },
  },
}
)

-- assembling-machine-5 --
data:extend(
{

  {
    type = "recipe",
    name = "assembling-machine-5",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "assembling-machine-5",
	result_count = 1,
    ingredients =
    {
      {"assembling-machine-4", 1},
      {"advanced-processing-unit", 4},
      {"steel-plate", 9},
      {"steel-bearing", 7},
      {"steel-gear-wheel", 7},
    },
  },
}
)

-- assembling-machine-6 --
data:extend(
{
  {
    type = "recipe",
    name = "assembling-machine-6",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "assembling-machine-6",
	result_count = 1,
    ingredients =
    {
      {"assembling-machine-5", 1},
      {"computer-chip", 5},
      {"steel-plate", 5},
      {"steel-bearing", 10},
      {"steel-gear-wheel", 10},
    },
  },
}
)