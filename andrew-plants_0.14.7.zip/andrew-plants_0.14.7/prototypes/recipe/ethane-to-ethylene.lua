
-- ethane-to-ethylene --
data:extend(
{
  {
	type = "recipe",
	name = "ethane-to-ethylene",
	icon = "__andrew-plants__/graphics/icons/ethylene.png",
	category = "chemistry",
	subgroup = "liquid-recipe",
	order = "v",
	enabled = false,
	energy_required = 1,
	ingredients =
	{
	  {type="fluid", name="ethane", amount=6},
	},
	results=
	{
	  {type="fluid", name="ethylene", amount=6},
	  {type="fluid", name="hydrogen", amount=2},
	}
  },
}
)
