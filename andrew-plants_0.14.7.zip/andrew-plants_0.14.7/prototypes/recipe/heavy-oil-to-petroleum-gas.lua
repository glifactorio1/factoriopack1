
-- heavy-oil-to-petroleum-gas --
data:extend(
{
  {
    type = "recipe",
    name = "heavy-oil-to-petroleum-gas",
    category = "advanced-oil-processing",
    icon = "__andrew-plants__/graphics/icons/fluid/heavy-oil-to-petroleum-gas.png",
    subgroup = "liquid-processing",
    order = "c-b",
    enabled = false,
    energy_required = 15,
    ingredients =
    {
      {type="fluid", name="water", amount=5},
      {type="fluid", name="heavy-oil", amount=10}
    },
    results=
    {
      {type="fluid", name="petroleum-gas", amount=10}
    },
  },
}
)
