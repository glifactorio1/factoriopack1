
-- advanced-oil-refinery --
data:extend(
{
  {
    type = "recipe",
    name = "advanced-oil-refinery",
    energy_required = 20,
    result = "advanced-oil-refinery",
    enabled = false,
    ingredients =
    {
      {"steel-plate", 15},
      {"iron-plate", 35},
      {"oil-refinery", 1},
      {"iron-gear-wheel", 20},
      {"stone-brick", 5},
      {"electronic-circuit", 20},
      {"pipe", 15}
    },
  },
}
)