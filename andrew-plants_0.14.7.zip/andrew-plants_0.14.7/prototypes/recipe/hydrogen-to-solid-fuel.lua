
-- hydrogen-to-solid-fuel --
data:extend(
{
  {
	type = "recipe",
	name = "hydrogen-to-solid-fuel",
	icon = "__andrew-plants__/graphics/icons/hydrogen-to-solid-fuel.png",
	category = "chemistry",
	subgroup = "liquid-recipe",
	order = "v",
	enabled = false,
	energy_required = 10,
	ingredients =
	{
	  {type="fluid", name="hydrogen", amount=20},
	},
	results=
	{
	  {"solid-fuel",1},
	}
  },
}
)