
-- crude-oil-to-light-oil --
  data:extend(
{
  {
    type = "recipe",
    name = "crude-oil-to-light-oil",
    category = "advanced-oil-processing",
    icon = "__andrew-plants__/graphics/icons/fluid/crude-oil-to-light-oil.png",
    subgroup = "liquid-processing",
    order = "d",
    enabled = false,
    energy_required = 15,
    ingredients =
    {
      {type="fluid", name="water", amount=5},
      {type="fluid", name="crude-oil", amount=10}
    },
    results=
    {
      {type="fluid", name="light-oil", amount=10},
    },
  },
}
)
