
-- chemical-plant-2 --
data:extend(
{
  {
    type = "recipe",
    name = "chemical-plant-2",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "chemical-plant-2",
    result_count = 1,
    ingredients =
    {
      {"chemical-plant", 1},
      {"steel-bearing", 5},
      {"steel-gear-wheel", 5},
      {"advanced-circuit", 5},
      {"pipe", 5},
    },
  },

}
)

-- chemical-plant-3 --
data:extend(
{
  {
    type = "recipe",
    name = "chemical-plant-3",
    category = "crafting",
    enabled = false,
    energy_required = 10,	
    result = "chemical-plant-3",	
    result_count = 1,	
    ingredients =
    {
      {"chemical-plant-2", 1},
      {"steel-bearing", 5},
      {"steel-gear-wheel", 5},
	  {"processing-unit", 5},
      {"pipe", 5},
    },
  },
}
)

-- chemical-plant-4 --
data:extend(
{
  {
    type = "recipe",
    name = "chemical-plant-4",
    category = "crafting",
    enabled = false,	
    energy_required = 10,
    result = "chemical-plant-4",
    result_count = 1,	
    ingredients =
    {
      {"chemical-plant-3", 1},
      {"steel-bearing", 5},
      {"steel-gear-wheel", 5},
	  {"advanced-processing-unit", 5},
      {"pipe", 5},
    },
  },
}
)