
-- butane --
data:extend(
{
  {
    type = "fluid",
    name = "butane",
    icon = "__andrew-plants__/graphics/icons/butane.png",
    subgroup = "liquid-recipe",
    order = "i",
    default_temperature = 25,
    max_temperature = 25,
    heat_capacity = "1KJ",
    base_color = {r=0.7, g=0.7, b=0.7},
    flow_color = {r=0.9, g=0.9, b=0.9},
    pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
  },
}
)
