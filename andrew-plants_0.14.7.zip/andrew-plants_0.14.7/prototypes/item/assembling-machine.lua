
-- assembling-machine-4 --
data:extend(
{
  {
    type = "item",
    name = "assembling-machine-4",
    icon = "__andrew-plants__/graphics/icons/assembling-machine-4.png",
    flags = {"goes-to-quickbar"},
    subgroup = "assembling-machine",
    order = "c[assembling-machine-4]",
    place_result = "assembling-machine-4",
    stack_size = 50
  },
}
)

-- assembling-machine-5 --
data:extend(
{
  {
    type = "item",
    name = "assembling-machine-5",
    icon = "__andrew-plants__/graphics/icons/assembling-machine-5.png",
    flags = {"goes-to-quickbar"},
    subgroup = "assembling-machine",
    order = "c[assembling-machine-5]",
    place_result = "assembling-machine-5",
    stack_size = 50
  },
}
)

-- assembling-machine-6 --
data:extend(
{
  {
    type = "item",
    name = "assembling-machine-6",
    icon = "__andrew-plants__/graphics/icons/assembling-machine-6.png",
    flags = {"goes-to-quickbar"},
    subgroup = "assembling-machine",
    order = "c[assembling-machine-6]",
    place_result = "assembling-machine-6",
    stack_size = 50
  },
}
)