-- electric-furnace-2 --
data:extend(
{
  {
    type = "item",
    name = "electric-furnace-2",
    icon = "__andrew-plants__/graphics/icons/electric-furnace-2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "furnace-electric",
    order = "b[electric-furnace]b",
    place_result = "electric-furnace-2",
    stack_size = 50
  },
}
)

-- electric-furnace-3 --
data:extend(
{
  {
    type = "item",
    name = "electric-furnace-3",
    icon = "__andrew-plants__/graphics/icons/electric-furnace-3.png",
    flags = {"goes-to-quickbar"},
    subgroup = "furnace-electric",
    order = "c[electric-furnace]c",
    place_result = "electric-furnace-3",
    stack_size = 50
  },
}
)

-- electric-furnace-4 --
data:extend(
{
  {
    type = "item",
    name = "electric-furnace-4",
    icon = "__andrew-plants__/graphics/icons/electric-furnace-4.png",
    flags = {"goes-to-quickbar"},
    subgroup = "furnace-electric",
    order = "d[electric-furnace]c",
    place_result = "electric-furnace-4",
    stack_size = 50
  },
}
)

-- electric-furnace-5 --
data:extend(
{
  {
    type = "item",
    name = "electric-furnace-5",
    icon = "__andrew-plants__/graphics/icons/electric-furnace-5.png",
    flags = {"goes-to-quickbar"},
    subgroup = "furnace-electric",
    order = "e[electric-furnace]c",
    place_result = "electric-furnace-5",
    stack_size = 50
  },
}
)