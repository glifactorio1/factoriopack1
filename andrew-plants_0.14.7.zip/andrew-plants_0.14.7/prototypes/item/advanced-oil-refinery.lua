
-- advanced-oil-refinery --
data:extend(
{

  {
    type = "item",
    name = "advanced-oil-refinery",
    icon = "__andrew-plants__/graphics/icons/advanced-oil-refinery.png",
    flags = {"goes-to-quickbar"},
    subgroup = "liquid-refinery",
    order = "b",
    place_result = "advanced-oil-refinery",
    stack_size = 20
  },
}
)
