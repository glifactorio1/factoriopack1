data.raw.item["chemical-plant"].stack_size = 50

-- chemical-plant-2 --
data:extend(
{ 
  {
    type = "item",
    name = "chemical-plant-2",
    icon = "__andrew-plants__/graphics/icons/chemical-plant-2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "liquid-plant",
    order = "b[chemical-plant-2]",
    place_result = "chemical-plant-2",
    stack_size = 50
  },
}
)

-- chemical-plant-3 --
data:extend(
{
  {
    type = "item",
    name = "chemical-plant-3",
    icon = "__andrew-plants__/graphics/icons/chemical-plant-3.png",
    flags = {"goes-to-quickbar"},
    subgroup = "liquid-plant",
    order = "c[chemical-plant-3]",
    place_result = "chemical-plant-3",
    stack_size = 50
  },
}
)

-- chemical-plant-4 --
data:extend(
{
  {
    type = "item",
    name = "chemical-plant-4",
    icon = "__andrew-plants__/graphics/icons/chemical-plant-4.png",
    flags = {"goes-to-quickbar"},
    subgroup = "liquid-plant",
    order = "d[chemical-plant-4]",
    place_result = "chemical-plant-4",
    stack_size = 50
  },
}
)