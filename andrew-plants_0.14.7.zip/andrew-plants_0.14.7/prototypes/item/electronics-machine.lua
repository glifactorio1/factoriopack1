
require("prototypes.category_functions")

-- electronics-machine-1 --
data:extend(
{
  {
    type = "item",
    name = "electronics-machine-1",
    icon = "__andrew-plants__/graphics/icons/electronics-machine-1.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electronics-machine",
    order = "a[electronics-machine-1]",
    place_result = "electronics-machine-1",
    stack_size = 50
  },
}
)

-- electronics-machine-2 --
data:extend(
{
  {
    type = "item",
    name = "electronics-machine-2",
    icon = "__andrew-plants__/graphics/icons/electronics-machine-2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electronics-machine",
    order = "b[electronics-machine-2]",
    place_result = "electronics-machine-2",
    stack_size = 50
  },
}
)

-- electronics-machine-3 --
data:extend(
{
  {
    type = "item",
    name = "electronics-machine-3",
    icon = "__andrew-plants__/graphics/icons/electronics-machine-3.png",
    flags = {"goes-to-quickbar"},
    subgroup = "electronics-machine",
    order = "c[electronics-machine-3]",
    place_result = "electronics-machine-3",
    stack_size = 50
  },
}
)
