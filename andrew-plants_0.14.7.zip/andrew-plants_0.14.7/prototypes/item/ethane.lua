
-- ethane --
data:extend(
{
  {
    type = "fluid",
    name = "ethane",
    icon = "__andrew-plants__/graphics/icons/ethane.png",
    subgroup = "liquid-recipe",
    order = "k",
    default_temperature = 25,
    max_temperature = 25,
    heat_capacity = "1KJ",
    base_color = {r=0.6, g=0.6, b=0.6},
    flow_color = {r=0.9, g=0.9, b=0.9},
    pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
  },
}
)
