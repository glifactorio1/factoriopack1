
if data.raw.module["speed-module-4"] then
	Change_Recipe("electric-furnace-5", "speed-module-3", "speed-module-4", 2)
end

if data.raw.module["effectivity-module-4"] then
	Change_Recipe("electric-furnace-5", "effectivity-module-3", "effectivity-module-4", 1)
end


