
--chemical-plant --
if data.raw.item["steel-pipe"] then
	Change_Recipe("chemical-plant-2", "pipe", "steel-pipe", 5)
	Change_Recipe("chemical-plant-3", "pipe", "steel-pipe", 5)
end

if data.raw.item["plastic-pipe"] then
	Change_Recipe("chemical-plant-4", "pipe", "plastic-pipe", 5)
end
