
if data.raw.item["clay-brick"] then
Change_Recipe("electric-furnace-2", "concrete", "clay-brick", 10)
end
