
-- advanced-oil-refinery --
data:extend(
{  
  {
    type = "technology",
    name = "advanced-oil-refinery",
    icon = "__andrew-plants__/graphics/icons/advanced-oil-refinery.png",
    upgrade = true,
	icon_size = 32,
    order = "g-c-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "advanced-oil-refinery"
      },
      {
        type = "unlock-recipe",
        recipe = "heavy-oil-to-petroleum-gas"
      },
    },
    prerequisites =
    {
      "advanced-oil-processing",
    },
    unit =
    {
      count = 100,
	  time = 30,
      ingredients = science4()
    },
  },
}
)
