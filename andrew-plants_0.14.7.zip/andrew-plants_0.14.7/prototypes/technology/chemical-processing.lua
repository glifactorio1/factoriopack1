-- chemical-processing-1 --
data:extend(
{
  {
    type = "technology",
    name = "chemical-processing-1",
    icon = "__andrew-plants__/graphics/technology/chemistry.png",
    upgrade = true,
    order = "d-b-b1",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "chemical-plant-2",
      },
    },	
    prerequisites =
    {
      "advanced-electronics",
	  "oil-processing",
	  "steel-processing",
    },
    unit =
    {
      count = 100,
	  time = 30,
      ingredients = science3()
    },
  },
}
)

-- chemical-processing-2 --
data:extend(
{
  {
    type = "technology",
    name = "chemical-processing-2",
    icon = "__andrew-plants__/graphics/technology/chemistry.png",
    upgrade = true,
    order = "d-b-b2",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "chemical-plant-3"
      },
    },	
    prerequisites =
    {
      "chemical-processing-1",
    },
    unit =
    {
      count = 150,
      time = 30,
      ingredients = science3()
    },
  },

}
)

-- chemical-processing-3 --
data:extend(
{
  {
    type = "technology",
    name = "chemical-processing-3",
    icon = "__andrew-plants__/graphics/technology/chemistry.png",
    upgrade = true,
    order = "d-b-b3",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "chemical-plant-4"
      },
    },
    prerequisites =
    {
      "chemical-processing-2",
	  "advanced-electronics-3",
    },
    unit =
    {
      count = 150,
      time = 30,
      ingredients = science4()
    },
  },
}
)