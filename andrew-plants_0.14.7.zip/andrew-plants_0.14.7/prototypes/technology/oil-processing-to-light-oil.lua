
-- crude-oil-to-light-oil --
data:extend(
{  
  {
    type = "technology",
    name = "oil-processing-to-light-oil",
    icon = "__andrew-plants__/graphics/icons/fluid/crude-oil-to-light-oil.png",
    upgrade = true,
	icon_size = 32,
    order = "g-c-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "crude-oil-to-light-oil"
      },
    },
    prerequisites =
    {
      "advanced-oil-refinery",
    },
    unit =
    {
      count = 110,
	  time = 30,
      ingredients = science4()
    },
  },
}
)
