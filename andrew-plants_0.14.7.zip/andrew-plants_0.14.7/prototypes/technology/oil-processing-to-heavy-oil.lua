
-- crude-oil-to-heavy-oil --
data:extend(
{  
  {
    type = "technology",
    name = "oil-processing-to-heavy-oil",
    icon = "__andrew-plants__/graphics/icons/fluid/crude-oil-to-heavy-oil.png",
    upgrade = true,
	icon_size = 32,
    order = "g-c-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "crude-oil-to-heavy-oil"
      },
    },
    prerequisites =
    {
      "advanced-oil-refinery",
    },
    unit =
    {
      count = 110,
	  time = 30,
      ingredients = science4()
    },
  },
}
)
