-- electronics-machine-1 --
data:extend(
{
  {
    type = "technology",
    name = "electronics-machine-1",
    icon = "__base__/graphics/technology/automation.png",
    upgrade = true,
    order = "a-c-a",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "electronics-machine-1"
      }
    },
    prerequisites =
    {
      "automation",
      "electronics"
    },
    unit =
    {
      count = 30,
      time = 15,
      ingredients = science1()
    },
  },
}
)

-- electronics-machine-2 --
data:extend(
{
  {
    type = "technology",
    name = "electronics-machine-2",
    icon = "__base__/graphics/technology/automation.png",
    upgrade = true,
    order = "a-c-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "electronics-machine-2"
      }
    },
    prerequisites =
    {
      "electronics-machine-1",
      "steel-processing",
      "advanced-electronics"
    },
    unit =
    {
      count = 50,
      time = 30,
      ingredients = science2()
    },
  },
}
)

-- electronics-machine-3 --
data:extend(
{
  {
    type = "technology",
    name = "electronics-machine-3",
    icon = "__base__/graphics/technology/automation.png",
    upgrade = true,
    order = "a-c-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "electronics-machine-3"
      }
    },
    prerequisites =
    {
      "electronics-machine-2",
      "advanced-electronics-2"
    },
    unit =
    {
      count = 100,
      time = 45,
      ingredients = science3()
    },
  },
}
)
