-- advanced-material-processing-3 --
data:extend(
{
  {
    type = "technology",
    name = "advanced-material-processing-3",
    icon = "__andrew-plants__/graphics/technology/advanced-material-processing.png",
    upgrade = true,
    order = "c-c-c",
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "electric-furnace-2"
      }
    },	
    prerequisites =
	{
	 "advanced-material-processing-2",
	 "effectivity-module",
	 "concrete",
	},
    unit =
    {
      count = 150,
	  time = 30,
      ingredients = science2()
    },
  },
}
)

-- advanced-material-processing-4 --
data:extend(
{
  {
    type = "technology",
    name = "advanced-material-processing-4",
    icon = "__andrew-plants__/graphics/technology/advanced-material-processing.png",
    upgrade = true,
    order = "c-c-d",
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "electric-furnace-3"
      }
    },	
    prerequisites = 
	{
	  "advanced-material-processing-3", 
	  "speed-module-2",
	},
    unit =
    {
      count = 350,
	  time = 30,
      ingredients = science3()
    },
  }
}
)

-- advanced-material-processing-5 --
data:extend(
{
  {
    type = "technology",
    name = "advanced-material-processing-5",
    icon = "__andrew-plants__/graphics/technology/advanced-material-processing.png",
    upgrade = true,
    order = "c-c-d",
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "electric-furnace-4"
      }
    },	
    prerequisites = 
	{
	  "advanced-material-processing-4", 
	  "speed-module-2",
	},
    unit =
    {
      count = 400,
	  time = 30,
      ingredients = science4()
    },
  }
}
)

-- advanced-material-processing-6 --
data:extend(
{
  {
    type = "technology",
    name = "advanced-material-processing-6",
    icon = "__andrew-plants__/graphics/technology/advanced-material-processing.png",
    upgrade = true,
    order = "c-c-d",
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "electric-furnace-5"
      }
    },	
    prerequisites = 
	{
	  "advanced-material-processing-5", 
	  "speed-module-2",
	},
    unit =
    {
      count = 680,
	  time = 30,
      ingredients = science4()
    },
  }
}
)