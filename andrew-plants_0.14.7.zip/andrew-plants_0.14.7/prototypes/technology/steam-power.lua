
Add_Recipe_To_Tech("steam-power", "methane-power")