
Add_Recipe_To_Tech("natural-gas-processing", "natural-gas-processing")
Add_Recipe_To_Tech("natural-gas-processing", "hydrogen-to-solid-fuel")
Add_Recipe_To_Tech("natural-gas-processing", "ethane-to-ethylene")

