-- automation-4 --
data:extend(
{
  {
    type = "technology",
    name = "automation-4",
    icon = "__base__/graphics/technology/automation.png",
    upgrade = true,
    order = "a-b-d",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "assembling-machine-4"
      }
    },
    prerequisites =
    {
      "automation-3"
    },
    unit =
    {
      count = 80,
      time = 45,
      ingredients = science3()
    },
  },
}
)

-- automation-5 --
data:extend(
{
   {
    type = "technology",
    name = "automation-5",
    icon = "__base__/graphics/technology/automation.png",
    upgrade = true,
    order = "a-b-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "assembling-machine-5"
      }
    },
    prerequisites =
    {
      "automation-4",
      "advanced-electronics-2",
    },
    unit =
    {
      count = 120,
      time = 60,
      ingredients = science3()
    },
  },
}
)

-- automation-6 --
data:extend(
{
  {
    type = "technology",
    name = "automation-6",
    icon = "__base__/graphics/technology/automation.png",
    upgrade = true,
    order = "a-b-f",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "assembling-machine-6"
      }
    },
    prerequisites = {"automation-5"},
    unit =
    {
      count = 150,
      time = 75,
      ingredients = science4()
    },
  },
}
)