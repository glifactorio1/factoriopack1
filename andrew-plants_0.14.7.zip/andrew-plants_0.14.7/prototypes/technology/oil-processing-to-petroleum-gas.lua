
-- crude-oil-to-petroleum-gas --
data:extend(
{  
  {
    type = "technology",
    name = "oil-processing-to-petroleum-gas",
    icon = "__andrew-plants__/graphics/icons/fluid/crude-oil-to-petroleum-gas.png",
    upgrade = true,
	icon_size = 32,
    order = "g-c-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "crude-oil-to-petroleum-gas"
      },
    },
    prerequisites =
    {
      "advanced-oil-refinery",
    },
    unit =
    {
      count = 110,
	  time = 30,
      ingredients = science4()
    },
  },
}
)
