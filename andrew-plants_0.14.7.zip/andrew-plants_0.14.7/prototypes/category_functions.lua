
-- add new electronics crafting categories

Category_Add_Category("player", "crafting", "electronics")
Category_Add_Category("assembling-machine", "crafting", "electronics")
Category_Add_Category("assembling-machine", "crafting", "electronics-machine")

data.raw.recipe["insulated-wire"].category = "electronics"
data.raw.recipe["cpu"].category = "electronics"
data.raw.recipe["copper-cable"].category = "electronics"
data.raw.recipe["green-wire"].category = "electronics"
data.raw.recipe["red-wire"].category = "electronics"
data.raw.recipe["electronic-circuit"].category = "electronics"
data.raw.recipe["advanced-circuit"].category = "electronics"
data.raw.recipe["processing-unit"].category = "electronics-machine"
data.raw.recipe["advanced-processing-unit"].category = "electronics-machine"
data.raw.recipe["computer-chip"].category = "electronics-machine"
data.raw.recipe["advanced-computer-chip"].category = "electronics-machine"
data.raw.recipe["computer-processing-chip"].category = "electronics-machine"
data.raw.recipe["advanced-computer-processing-chip"].category = "electronics-machine"
