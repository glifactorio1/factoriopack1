return {
  ["farl"] = {"fuels-high"}
}
