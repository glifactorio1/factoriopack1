--
-- Disclaimer: mp warranty void if edited.
--

return {
  ["ammo-bullets"] = {"piercing-bullet-magazine", "basic-bullet-magazine"},
  ["ammo-shells"] = {"cannon-shell"},
  ["fuels-all"] = {},
  ["fuels-high"] = {}
}
