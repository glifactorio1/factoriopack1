--Define if mining is installed
mining = true --Default: True