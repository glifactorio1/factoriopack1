table.insert(data.raw["technology"]["tanks"].effects, {type = "unlock-recipe", recipe = "vehicle-laser-tank"})
table.insert(data.raw["technology"]["tanks"].effects, {type = "unlock-recipe", recipe = "laser-cannon-battery-piercing"})
table.insert(data.raw["technology"]["tanks"].effects, {type = "unlock-recipe", recipe = "laser-cannon-battery-focussed"})

table.insert(data.raw["technology"]["laser-turret-damage-1"].effects, 
{
	type = "ammo-damage",
	ammo_category = "laser-cannon",
	modifier = "0.1"
})
table.insert(data.raw["technology"]["laser-turret-damage-2"].effects, 
{
	type = "ammo-damage",
	ammo_category = "laser-cannon",
	modifier = "0.1"
})
table.insert(data.raw["technology"]["laser-turret-damage-3"].effects, 
{
	type = "ammo-damage",
	ammo_category = "laser-cannon",
	modifier = "0.2"
})
table.insert(data.raw["technology"]["laser-turret-damage-4"].effects, 
{
	type = "ammo-damage",
	ammo_category = "laser-cannon",
	modifier = "0.2"
})
table.insert(data.raw["technology"]["laser-turret-damage-5"].effects, 
{
	type = "ammo-damage",
	ammo_category = "laser-cannon",
	modifier = "0.4"
})