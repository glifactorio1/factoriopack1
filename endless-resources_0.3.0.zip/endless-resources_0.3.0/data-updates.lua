for _, resource in pairs(data.raw.resource) do
    if not resource.infinite then
		resource.infinite = true
		resource.minimum = 200
		resource.normal = 1000
	end
end