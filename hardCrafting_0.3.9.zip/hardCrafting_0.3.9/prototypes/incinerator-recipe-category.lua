data:extend({
	{
    type = "recipe-category",
    name = "incinerator"
  }
})