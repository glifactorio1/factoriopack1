data:extend(
{
  {
    type = "item",
    name = "fuel-cell",
    icon = "__usefulbyproducts__/graphics/icons/fuel-cell.png",
    flags = {"goes-to-main-inventory"},
    fuel_value = "45MJ",
    subgroup = "raw-resource",
    order = "c[solid-fuel]",
    stack_size = 50
  },
}
)
