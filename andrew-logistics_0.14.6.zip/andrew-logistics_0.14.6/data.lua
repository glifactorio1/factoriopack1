
-- entity --
require("prototypes.entity.robots.construction-robot-2")
require("prototypes.entity.robots.construction-robot-3")
require("prototypes.entity.robots.construction-robot-4")
require("prototypes.entity.robots.construction-robot-5")
require("prototypes.entity.robots.logistic-robot-2")
require("prototypes.entity.robots.logistic-robot-3")
require("prototypes.entity.robots.logistic-robot-4")
require("prototypes.entity.robots.logistic-robot-5")

require("prototypes.entity.pipes.stone-pipe")
require("prototypes.entity.pipes.stone-pipe-to-ground")
require("prototypes.entity.pipes.steel-pipe")
require("prototypes.entity.pipes.steel-pipe-to-ground")
require("prototypes.entity.pipes.copper-pipe")
require("prototypes.entity.pipes.copper-pipe-to-ground")
require("prototypes.entity.pipes.plastic-pipe")
require("prototypes.entity.pipes.plastic-pipe-to-ground")

require("prototypes.entity.inserters.burner-long-handed-inserter")
require("prototypes.entity.inserters.fast-long-handed-inserter")
require("prototypes.entity.inserters.express-inserter")
require("prototypes.entity.inserters.filter-long-handed-inserter")
require("prototypes.entity.inserters.stack-long-handed-inserter")
require("prototypes.entity.inserters.stack-filter-long-handed-inserter")

require("prototypes.entity.transport.ultra-transport-belt-pictures")
require("prototypes.entity.transport.super-transport-belt-pictures")
require("prototypes.entity.transport.hyper-transport-belt-pictures")

require("prototypes.entity.transport.ultra-transport-belt")
require("prototypes.entity.transport.super-transport-belt")
require("prototypes.entity.transport.hyper-transport-belt")

require("prototypes.entity.transport.ultra-underground-belt")
require("prototypes.entity.transport.super-underground-belt")
require("prototypes.entity.transport.hyper-underground-belt")

require("prototypes.entity.transport.ultra-splitter")
require("prototypes.entity.transport.super-splitter")
require("prototypes.entity.transport.hyper-splitter")

require("prototypes.entity.transport.ultra-loader")
require("prototypes.entity.transport.super-loader")
require("prototypes.entity.transport.hyper-loader")

-- item --
require("prototypes.item.robots.construction-robot-2")
require("prototypes.item.robots.construction-robot-3")
require("prototypes.item.robots.construction-robot-4")
require("prototypes.item.robots.construction-robot-5")
require("prototypes.item.robots.logistic-robot-2")
require("prototypes.item.robots.logistic-robot-3")
require("prototypes.item.robots.logistic-robot-4")
require("prototypes.item.robots.logistic-robot-5")
require("prototypes.item.robots.flying-robot-frame-2")
require("prototypes.item.robots.flying-robot-frame-3")
require("prototypes.item.robots.flying-robot-frame-4")
require("prototypes.item.robots.flying-robot-frame-5")

require("prototypes.item.pipes.stone-pipe")
require("prototypes.item.pipes.stone-pipe-to-ground")
require("prototypes.item.pipes.steel-pipe")
require("prototypes.item.pipes.steel-pipe-to-ground")
require("prototypes.item.pipes.copper-pipe")
require("prototypes.item.pipes.copper-pipe-to-ground")
require("prototypes.item.pipes.plastic-pipe")
require("prototypes.item.pipes.plastic-pipe-to-ground")

require("prototypes.item.inserters.burner-long-handed-inserter")
require("prototypes.item.inserters.fast-long-handed-inserter")
require("prototypes.item.inserters.express-inserter")
require("prototypes.item.inserters.filter-long-handed-inserter")
require("prototypes.item.inserters.stack-long-handed-inserter")
require("prototypes.item.inserters.stack-filter-long-handed-inserter")

require("prototypes.item.fluid-barrels.heavy-oil-barrel")
require("prototypes.item.fluid-barrels.light-oil-barrel")
require("prototypes.item.fluid-barrels.lubricant-barrel")
require("prototypes.item.fluid-barrels.petroleum-gas-barrel")
require("prototypes.item.fluid-barrels.sulfuric-acid-barrel")
require("prototypes.item.fluid-barrels.water-barrel")
require("prototypes.item.fluid-barrels.advanced-lubricant-barrel")

require("prototypes.item.transport.ultra-transport-belt")
require("prototypes.item.transport.super-transport-belt")
require("prototypes.item.transport.hyper-transport-belt")

require("prototypes.item.transport.ultra-underground-belt")
require("prototypes.item.transport.super-underground-belt")
require("prototypes.item.transport.hyper-underground-belt")


require("prototypes.item.transport.ultra-splitter")
require("prototypes.item.transport.super-splitter")
require("prototypes.item.transport.hyper-splitter")

require("prototypes.item.transport.ultra-loader")
require("prototypes.item.transport.super-loader")
require("prototypes.item.transport.hyper-loader")

require("prototypes.item.advanced-lubricant")

-- recipe --
require("prototypes.recipe.robots.construction-robot")
require("prototypes.recipe.robots.flying-robot-frame")
require("prototypes.recipe.robots.logistic-robot")

require("prototypes.recipe.pipes.stone-pipe")
require("prototypes.recipe.pipes.stone-pipe-to-ground")
require("prototypes.recipe.pipes.steel-pipe")
require("prototypes.recipe.pipes.steel-pipe-to-ground")
require("prototypes.recipe.pipes.copper-pipe")
require("prototypes.recipe.pipes.copper-pipe-to-ground")
require("prototypes.recipe.pipes.plastic-pipe")
require("prototypes.recipe.pipes.plastic-pipe-to-ground")

require("prototypes.recipe.inserters.burner-long-handed-inserter")
require("prototypes.recipe.inserters.fast-long-handed-inserter")
require("prototypes.recipe.inserters.express-inserter")
require("prototypes.recipe.inserters.filter-long-handed-inserter")
require("prototypes.recipe.inserters.stack-long-handed-inserter")
require("prototypes.recipe.inserters.stack-filter-long-handed-inserter")

require("prototypes.recipe.fluid-barrels.fill-heavy-oil-barrel")
require("prototypes.recipe.fluid-barrels.fill-light-oil-barrel")
require("prototypes.recipe.fluid-barrels.fill-lubricant-barrel")
require("prototypes.recipe.fluid-barrels.fill-petroleum-gas-barrel")
require("prototypes.recipe.fluid-barrels.fill-sulfuric-acid-barrel")
require("prototypes.recipe.fluid-barrels.fill-water-barrel")
require("prototypes.recipe.fluid-barrels.fill-advanced-lubricant-barrel")

require("prototypes.recipe.fluid-barrels.empty-heavy-oil-barrel")
require("prototypes.recipe.fluid-barrels.empty-light-oil-barrel")
require("prototypes.recipe.fluid-barrels.empty-lubricant-barrel")
require("prototypes.recipe.fluid-barrels.empty-petroleum-gas-barrel")
require("prototypes.recipe.fluid-barrels.empty-sulfuric-acid-barrel")
require("prototypes.recipe.fluid-barrels.empty-water-barrel")
require("prototypes.recipe.fluid-barrels.empty-advanced-lubricant-barrel")

require("prototypes.recipe.transport.ultra-transport-belt")
require("prototypes.recipe.transport.super-transport-belt")
require("prototypes.recipe.transport.hyper-transport-belt")

require("prototypes.recipe.transport.ultra-underground-belt")
require("prototypes.recipe.transport.super-underground-belt")
require("prototypes.recipe.transport.hyper-underground-belt")

require("prototypes.recipe.transport.ultra-splitter")
require("prototypes.recipe.transport.super-splitter")
require("prototypes.recipe.transport.hyper-splitter")


require("prototypes.recipe.transport.ultra-loader")
require("prototypes.recipe.transport.super-loader")
require("prototypes.recipe.transport.hyper-loader")

require("prototypes.recipe.advanced-lubricant")

-- technology --
require("prototypes.technology.robotics")
require("prototypes.technology.pipes")

require("prototypes.technology.inserters.burner-long-handed-inserter")
require("prototypes.technology.inserters.fast-long-handed-inserter")
require("prototypes.technology.inserters.express-inserters")
require("prototypes.technology.inserters.filter-long-handed-inserter")
require("prototypes.technology.inserters.stack-long-handed-inserter")
require("prototypes.technology.inserters.stack-filter-long-handed-inserter")

require("prototypes.technology.barreling")

require("prototypes.technology.logistics-4")
require("prototypes.technology.logistics-5")
require("prototypes.technology.logistics-6")

require("prototypes.technology.loader-4")
require("prototypes.technology.loader-5")
require("prototypes.technology.loader-6")

if data.raw.item["clay-brick"] then
-- entity --
require("prototypes.entity.pipes.clay-pipe")
require("prototypes.entity.pipes.clay-pipe-to-ground")

-- item --
require("prototypes.item.pipes.clay-pipe")
require("prototypes.item.pipes.clay-pipe-to-ground")

-- recipe --
require("prototypes.recipe.pipes.clay-pipe")
require("prototypes.recipe.pipes.clay-pipe-to-ground")
end

