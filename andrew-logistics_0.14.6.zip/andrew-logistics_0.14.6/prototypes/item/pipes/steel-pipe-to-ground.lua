-- steel-pipe-to-ground --
data:extend(
{
  {
    type = "item",
    name = "steel-pipe-to-ground",
    icon = "__andrew-logistics__/graphics/icons/pipe/steel-pipe-to-ground.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-pipe-ground",
    order = "d",
    place_result = "steel-pipe-to-ground",
    stack_size = 50,
  },
}
)
