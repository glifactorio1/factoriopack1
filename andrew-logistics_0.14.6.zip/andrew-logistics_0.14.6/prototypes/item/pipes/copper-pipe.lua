-- copper-pipe --
data:extend(
{
  {
    type = "item",
    name = "copper-pipe",
    icon = "__andrew-logistics__/graphics/icons/pipe/copper-pipe.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-pipe",
    order = "c",
    place_result = "copper-pipe",
    stack_size = 50,
  },
}
)
