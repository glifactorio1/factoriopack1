-- plastic-pipe-to-ground --
data:extend(
{
  {
    type = "item",
    name = "plastic-pipe-to-ground",
    icon = "__andrew-logistics__/graphics/icons/pipe/plastic-pipe-to-ground.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-pipe-ground",
    order = "e",
    place_result = "plastic-pipe-to-ground",
    stack_size = 50,
  },
}
)
