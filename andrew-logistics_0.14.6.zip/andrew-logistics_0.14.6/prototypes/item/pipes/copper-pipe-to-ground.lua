-- copper-pipe-to-ground --
data:extend(
{
  {
    type = "item",
    name = "copper-pipe-to-ground",
    icon = "__andrew-logistics__/graphics/icons/pipe/copper-pipe-to-ground.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-pipe-ground",
    order = "c",
    place_result = "copper-pipe-to-ground",
    stack_size = 50,
  },
}
)
