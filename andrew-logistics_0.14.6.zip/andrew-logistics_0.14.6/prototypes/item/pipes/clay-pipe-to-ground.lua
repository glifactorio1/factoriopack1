-- clay-pipe-to-ground --
data:extend(
{
  {
    type = "item",
    name = "clay-pipe-to-ground",
    icon = "__andrew-logistics__/graphics/icons/pipe/clay-pipe-to-ground.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-pipe-ground",
    order = "b",
    place_result = "clay-pipe-to-ground",
    stack_size = 50,
  },
}
)