-- stone-pipe-to-ground --
data:extend(
{
  {
    type = "item",
    name = "stone-pipe-to-ground",
    icon = "__andrew-logistics__/graphics/icons/pipe/stone-pipe-to-ground.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-pipe-ground",
    order = "b",
    place_result = "stone-pipe-to-ground",
    stack_size = 50,
  },
}
)
