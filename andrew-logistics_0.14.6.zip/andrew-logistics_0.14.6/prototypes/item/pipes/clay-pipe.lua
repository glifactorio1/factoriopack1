-- clay-pipe --
data:extend(
{
  {
    type = "item",
    name = "clay-pipe",
    icon = "__andrew-logistics__/graphics/icons/pipe/clay-pipe.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-pipe",
    order = "b",
    place_result = "clay-pipe",
    stack_size = 50,
  },
}
)

