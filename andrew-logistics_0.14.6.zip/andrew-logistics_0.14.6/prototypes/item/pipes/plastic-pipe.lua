-- plastic-pipe --
data:extend(
{
  {
    type = "item",
    name = "plastic-pipe",
    icon = "__andrew-logistics__/graphics/icons/pipe/plastic-pipe.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-pipe",
    order = "e",
    place_result = "plastic-pipe",
    stack_size = 50,
  },
}
)
