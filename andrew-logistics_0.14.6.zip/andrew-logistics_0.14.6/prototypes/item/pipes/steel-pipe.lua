-- steel-pipe -
data:extend(
{
  {
    type = "item",
    name = "steel-pipe",
    icon = "__andrew-logistics__/graphics/icons/pipe/steel-pipe.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-pipe",
    order = "d",
    place_result = "steel-pipe",
    stack_size = 50,
  },
}
)
