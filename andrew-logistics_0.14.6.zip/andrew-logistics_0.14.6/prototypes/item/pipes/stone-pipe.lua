-- stone-pipe --
data:extend(
{
  {
    type = "item",
    name = "stone-pipe",
    icon = "__andrew-logistics__/graphics/icons/pipe/stone-pipe.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-pipe",
    order = "b",
    place_result = "stone-pipe",
    stack_size = 50,
  },
}
)