-- flying-robot-frame-4 --
data:extend(
{
  {
    type = "item",
    name = "flying-robot-frame-4",
    icon = "__andrew-logistics__/graphics/icons/flying-robot-frame-4.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "logistic-robot-f",
    order = "d",
    stack_size = 50
  },
}
)