-- construction-robot-3 --
data:extend(
{
  {
    type = "item",
    name = "construction-robot-3",
    icon = "__andrew-logistics__/graphics/icons/construction-robot-3.png",
    flags = {"goes-to-quickbar"},
    subgroup = "logistic-robot-c",
    order = "c",
    place_result = "construction-robot-3",
    stack_size = 50
  },
}
)