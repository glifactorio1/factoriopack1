-- construction-robot-5 --
data:extend(
{
  {
    type = "item",
    name = "construction-robot-5",
    icon = "__andrew-logistics__/graphics/icons/construction-robot-5.png",
    flags = {"goes-to-quickbar"},
    subgroup = "logistic-robot-c",
    order = "e",
    place_result = "construction-robot-5",
    stack_size = 50
  },
}
)