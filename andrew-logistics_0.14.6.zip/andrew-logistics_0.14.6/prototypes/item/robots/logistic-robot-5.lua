-- logistic-robot-5 --
data:extend(
{
  {
    type = "item",
    name = "logistic-robot-5",
    icon = "__andrew-logistics__/graphics/icons/logistic-robot-5.png",
    flags = {"goes-to-quickbar"},
    subgroup = "logistic-robot",
    order = "e",
    place_result = "logistic-robot-5",
    stack_size = 50
  },
}
)