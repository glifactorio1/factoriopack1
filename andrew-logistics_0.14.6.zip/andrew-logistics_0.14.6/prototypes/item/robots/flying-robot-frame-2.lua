-- flying-robot-frame-2 --
data:extend(
{
  {
    type = "item",
    name = "flying-robot-frame-2",
    icon = "__andrew-logistics__/graphics/icons/flying-robot-frame-2.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "logistic-robot-f",
    order = "b",
    stack_size = 50
  },
}
)