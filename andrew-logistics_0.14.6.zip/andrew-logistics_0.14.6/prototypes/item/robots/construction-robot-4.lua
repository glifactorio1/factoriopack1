-- construction-robot-4 --
data:extend(
{
  {
    type = "item",
    name = "construction-robot-4",
    icon = "__andrew-logistics__/graphics/icons/construction-robot-4.png",
    flags = {"goes-to-quickbar"},
    subgroup = "logistic-robot-c",
    order = "d",
    place_result = "construction-robot-4",
    stack_size = 50
  },
}
)