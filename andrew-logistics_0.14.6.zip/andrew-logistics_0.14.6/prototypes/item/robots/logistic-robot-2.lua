-- logistic-robot-2 --
data:extend(
{
  {
    type = "item",
    name = "logistic-robot-2",
    icon = "__andrew-logistics__/graphics/icons/logistic-robot-2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "logistic-robot",
    order = "b",
    place_result = "logistic-robot-2",
    stack_size = 50
  },
}
)