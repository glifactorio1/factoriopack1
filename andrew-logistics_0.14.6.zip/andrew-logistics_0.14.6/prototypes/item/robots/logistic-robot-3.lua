-- logistic-robot-3 --
data:extend(
{
  {
    type = "item",
    name = "logistic-robot-3",
    icon = "__andrew-logistics__/graphics/icons/logistic-robot-3.png",
    flags = {"goes-to-quickbar"},
    subgroup = "logistic-robot",
    order = "c",
    place_result = "logistic-robot-3",
    stack_size = 50
  },
}
)