-- logistic-robot-4 --
data:extend(
{
  {
    type = "item",
    name = "logistic-robot-4",
    icon = "__andrew-logistics__/graphics/icons/logistic-robot-4.png",
    flags = {"goes-to-quickbar"},
    subgroup = "logistic-robot",
    order = "d",
    place_result = "logistic-robot-4",
    stack_size = 50
  },
}
)
