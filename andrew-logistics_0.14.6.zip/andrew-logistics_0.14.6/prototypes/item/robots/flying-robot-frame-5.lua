-- flying-robot-frame-5 --
data:extend(
{
  {
    type = "item",
    name = "flying-robot-frame-5",
    icon = "__andrew-logistics__/graphics/icons/flying-robot-frame-5.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "logistic-robot-f",
    order = "e",
    stack_size = 50
  },
}
)