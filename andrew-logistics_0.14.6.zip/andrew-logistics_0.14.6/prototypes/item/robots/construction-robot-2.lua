-- construction-robot-2 --
data:extend(
{
  {
    type = "item",
    name = "construction-robot-2",
    icon = "__andrew-logistics__/graphics/icons/construction-robot-2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "logistic-robot-c",
    order = "b",
    place_result = "construction-robot-2",
    stack_size = 50
  },
}
)
