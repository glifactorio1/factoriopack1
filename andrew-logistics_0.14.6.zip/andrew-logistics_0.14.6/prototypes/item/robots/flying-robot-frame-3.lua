-- flying-robot-frame-3 --
data:extend(
{
  {
    type = "item",
    name = "flying-robot-frame-3",
    icon = "__andrew-logistics__/graphics/icons/flying-robot-frame-3.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "logistic-robot-f",
    order = "c",
    stack_size = 50
  },
}
)