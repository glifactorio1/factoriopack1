-- water-barrel --
data:extend(
{
  {
	type = "item",
	name = "water-barrel",
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/water-barrel.png",
	flags = {"goes-to-main-inventory"},
	subgroup = "liquid-barrels",
	order = "b",
	stack_size = 20
  },
}
)
