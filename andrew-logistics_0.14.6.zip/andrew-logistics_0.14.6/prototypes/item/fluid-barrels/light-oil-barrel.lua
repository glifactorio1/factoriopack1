-- light-oil-barrel --
data:extend(
{
  {
	type = "item",
	name = "light-oil-barrel",
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/light-oil-barrel.png",
	flags = {"goes-to-main-inventory"},
	subgroup = "liquid-barrels",
	order = "d",
	stack_size = 20
  },
}
)
