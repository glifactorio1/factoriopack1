
-- advanced-lubricant-barrel --
data:extend(
{
  {
	type = "item",
	name = "advanced-lubricant-barrel",
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/advanced-lubricant-barrel.png",
	flags = {"goes-to-main-inventory"},
	subgroup = "liquid-barrels",
	order = "e",
	stack_size = 20
  },
}
)