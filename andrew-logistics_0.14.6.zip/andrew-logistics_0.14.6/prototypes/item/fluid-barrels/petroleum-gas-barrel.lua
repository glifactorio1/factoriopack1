-- petroleum-gas-barrel --
data:extend(
{
  {
	type = "item",
	name = "petroleum-gas-barrel",
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/petroleum-gas-barrel.png",
	flags = {"goes-to-main-inventory"},
	subgroup = "liquid-barrels",
	order = "f",
	stack_size = 20
  },
}
)
