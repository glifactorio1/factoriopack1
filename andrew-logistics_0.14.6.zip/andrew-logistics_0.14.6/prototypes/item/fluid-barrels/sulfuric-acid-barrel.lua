-- sulfuric-acid-barrel --
data:extend(
{
  {
	type = "item",
	name = "sulfuric-acid-barrel",
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/sulfuric-acid-barrel.png",
	flags = {"goes-to-main-inventory"},
	subgroup = "liquid-barrels",
	order = "g",
	stack_size = 20
  },
}
)