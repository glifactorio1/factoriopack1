
-- lubricant-barrel --
data:extend(
{
  {
	type = "item",
	name = "lubricant-barrel",
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/lubricant-barrel.png",
	flags = {"goes-to-main-inventory"},
	subgroup = "liquid-barrels",
	order = "e",
	stack_size = 20
  },
}
)