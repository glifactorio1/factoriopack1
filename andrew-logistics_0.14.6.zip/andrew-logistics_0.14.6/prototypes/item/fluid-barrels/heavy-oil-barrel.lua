-- heavy-oil-barrel --
data:extend(
{
  {
	type = "item",
	name = "heavy-oil-barrel",
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/heavy-oil-barrel.png",
	flags = {"goes-to-main-inventory"},
	subgroup = "liquid-barrels",
	order = "c",
	stack_size = 20
  },
}
)
