-- stack-filter-long-handed-inserter --
data:extend(
{
  {
    type = "item",
    name = "stack-filter-long-handed-inserter",
    icon = "__andrew-logistics__/graphics/icons/inserter/stack-filter-long-handed-inserter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "stack-filter-inserters",
    order = "b",
    place_result = "stack-filter-long-handed-inserter",
    stack_size = 50
  },
}
)