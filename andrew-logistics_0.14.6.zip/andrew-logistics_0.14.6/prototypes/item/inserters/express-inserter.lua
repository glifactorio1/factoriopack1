-- express-inserter --
data:extend(
{
  {
    type = "item",
    name = "express-inserter",
    icon = "__andrew-logistics__/graphics/icons/inserter/express-inserter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "inserters-express",
    order = "b",
    place_result = "express-inserter",
    stack_size = 50,
  },
}
)