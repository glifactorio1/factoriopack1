-- filter-long-handed-inserter --
data:extend(
{
  {
    type = "item",
    name = "filter-long-handed-inserter",
    icon = "__andrew-logistics__/graphics/icons/inserter/filter-long-handed-inserter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "filter-inserters",
    order = "b",
    place_result = "filter-long-handed-inserter",
    stack_size = 50
  },
}
)