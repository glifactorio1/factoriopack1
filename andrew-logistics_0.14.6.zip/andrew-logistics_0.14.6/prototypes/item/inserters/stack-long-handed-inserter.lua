-- stack-long-handed-inserter --
data:extend(
{
  {
    type = "item",
    name = "stack-long-handed-inserter",
    icon = "__andrew-logistics__/graphics/icons/inserter/stack-long-handed-inserter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "stack-inserters",
    order = "b",
    place_result = "stack-long-handed-inserter",
    stack_size = 50
  },
}
)