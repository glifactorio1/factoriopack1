-- fast-long-handed-inserter --
data:extend(
{
  {
    type = "item",
    name = "fast-long-handed-inserter",
    icon = "__andrew-logistics__/graphics/icons/inserter/fast-long-handed-inserter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "fast-inserters",
    order = "b",
    place_result = "fast-long-handed-inserter",
    stack_size = 50
  },
}
)