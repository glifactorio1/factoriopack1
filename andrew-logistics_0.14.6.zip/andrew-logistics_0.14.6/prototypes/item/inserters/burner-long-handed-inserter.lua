-- burner-long-handed-inserter --
data:extend(
{
  {
    type = "item",
    name = "burner-long-handed-inserter",
    icon = "__andrew-logistics__/graphics/icons/inserter/burner-long-handed-inserter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "burner-inserters",
    order = "b",
    place_result = "burner-long-handed-inserter",
    stack_size = 50
  },
}
)