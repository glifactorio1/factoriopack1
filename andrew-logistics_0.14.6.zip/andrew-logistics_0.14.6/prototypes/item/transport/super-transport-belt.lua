-- super-transport-belt --
data:extend(
{
  {
    type = "item",
    name = "super-transport-belt",
    icon = "__andrew-logistics__/graphics/icons/super-transport-belt.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-belt",
    order = "e",
    place_result = "super-transport-belt",
    stack_size = 200
  },
}
)
