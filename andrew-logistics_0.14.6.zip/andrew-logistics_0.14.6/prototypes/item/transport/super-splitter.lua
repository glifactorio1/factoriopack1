-- super-splitter --
data:extend(
{
  {
    type = "item",
    name = "super-splitter",
    icon = "__andrew-logistics__/graphics/icons/super-splitter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-splitters",
    order = "e",
    place_result = "super-splitter",
    stack_size = 100
  },
}
)
