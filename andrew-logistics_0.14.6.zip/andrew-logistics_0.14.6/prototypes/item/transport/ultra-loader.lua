-- ultra-loader --
data:extend(
{
  {
    type = "item",
    name = "ultra-loader",
    icon = "__andrew-logistics__/graphics/icons/ultra-loader.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-loader",
    order = "d",
    place_result = "ultra-loader",
    stack_size = 50
  },
}
)