-- super-loader --
data:extend(
{
  {
    type = "item",
    name = "super-loader",
    icon = "__andrew-logistics__/graphics/icons/super-loader.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-loader",
    order = "e",
    place_result = "super-loader",
    stack_size = 50
  },
}
)
