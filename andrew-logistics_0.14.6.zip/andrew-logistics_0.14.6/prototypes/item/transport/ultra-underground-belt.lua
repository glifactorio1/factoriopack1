-- ultra-underground-belt --
data:extend(
{
  {
    type = "item",
    name = "ultra-underground-belt",
    icon = "__andrew-logistics__/graphics/icons/ultra-underground-belt.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-ground",
    order = "d",
    place_result = "ultra-underground-belt",
    stack_size = 100
  },
}
)
