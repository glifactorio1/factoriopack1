-- hyper-splitter --
data:extend(
{
  {
    type = "item",
    name = "hyper-splitter",
    icon = "__andrew-logistics__/graphics/icons/hyper-splitter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-splitters",
    order = "f",
    place_result = "hyper-splitter",
    stack_size = 100
  },
}
)
