-- hyper-loader --
data:extend(
{
  {
    type = "item",
    name = "hyper-loader",
    icon = "__andrew-logistics__/graphics/icons/hyper-loader.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-loader",
    order = "f",
    place_result = "hyper-loader",
    stack_size = 50
  },
}
)
