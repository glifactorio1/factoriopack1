-- hyper-underground-belt --
data:extend(
{
  {
    type = "item",
    name = "hyper-underground-belt",
    icon = "__andrew-logistics__/graphics/icons/hyper-underground-belt.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-ground",
    order = "f",
    place_result = "hyper-underground-belt",
    stack_size = 100
  },
}
)
