-- ultra-splitter --
data:extend(
{
  {
    type = "item",
    name = "ultra-splitter",
    icon = "__andrew-logistics__/graphics/icons/ultra-splitter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-splitters",
    order = "d",
    place_result = "ultra-splitter",
    stack_size = 100
  },
}
)