-- super-underground-belt --
data:extend(
{
  {
    type = "item",
    name = "super-underground-belt",
    icon = "__andrew-logistics__/graphics/icons/super-underground-belt.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-ground",
    order = "e",
    place_result = "super-underground-belt",
    stack_size = 100
  },
}
)
