-- ultra-transport-belt --
data:extend(
{
  {
    type = "item",
    name = "ultra-transport-belt",
    icon = "__andrew-logistics__/graphics/icons/ultra-transport-belt.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-belt",
    order = "d",
    place_result = "ultra-transport-belt",
    stack_size = 200
  },
}
)