-- hyper-transport-belt --
data:extend(
{
  {
    type = "item",
    name = "hyper-transport-belt",
    icon = "__andrew-logistics__/graphics/icons/hyper-transport-belt.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport-belt",
    order = "f",
    place_result = "hyper-transport-belt",
    stack_size = 200
  },
}
)
