-- advanced-lubricant --
data:extend(
{
  {
    type = "fluid",
    name = "advanced-lubricant",
    icon = "__andrew-logistics__/graphics/icons/advanced-lubricant.png",
    default_temperature = 25,
    base_color = {r=0.45, g=0.10, b=0.33},
    flow_color = {r=0.75, g=0.75, b=0.75},
    max_temperature = 100,
    pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
    subgroup = "liquid-recipe",
    order = "w[advanced-lubricant]",
  },
}
)