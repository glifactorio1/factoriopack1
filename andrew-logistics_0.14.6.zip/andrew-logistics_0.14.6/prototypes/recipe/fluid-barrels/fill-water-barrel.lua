-- fill-water-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "fill-water-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-fill",
	order = "b",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/fill-water-barrel.png",
	ingredients =
	{
	  {type="fluid", name="water", amount=30},
	  {"empty-barrel",1},
	},
	results=
	{
	  {"water-barrel",1}
	}
  },
}
)
