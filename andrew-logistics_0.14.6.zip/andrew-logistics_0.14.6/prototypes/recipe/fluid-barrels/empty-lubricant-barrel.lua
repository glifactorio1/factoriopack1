
-- empty-lubricant-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "empty-lubricant-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-empty",
	order = "e",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/empty-lubricant-barrel.png",
	ingredients =
	{
	  {"lubricant-barrel",1}
	},
	results=
	{
	  {type="fluid", name="lubricant", amount=30},
	  {"empty-barrel",1}
	}
  },
}
)