-- empty-petroleum-gas-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "empty-petroleum-gas-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-empty",
	order = "f",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/empty-petroleum-gas-barrel.png",
	ingredients =
	{
	  {"petroleum-gas-barrel",1}
	},
	results=
	{
	  {type="fluid", name="petroleum-gas", amount=30},
	  {"empty-barrel",1}
	}
  },
}
)