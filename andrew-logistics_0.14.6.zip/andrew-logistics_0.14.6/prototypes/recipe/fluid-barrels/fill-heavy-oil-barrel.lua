-- fill-heavy-oil-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "fill-heavy-oil-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-fill",
	order = "c",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/fill-heavy-oil-barrel.png",
	ingredients =
	{
	  {type="fluid", name="heavy-oil", amount=30},
	  {"empty-barrel",1},
	},
	results=
	{
	  {"heavy-oil-barrel",1}
	}
  },
}
)
