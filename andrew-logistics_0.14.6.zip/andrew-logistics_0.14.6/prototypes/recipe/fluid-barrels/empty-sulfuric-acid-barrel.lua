-- empty-sulfuric-acid-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "empty-sulfuric-acid-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-empty",
	order = "g",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/empty-sulfuric-acid-barrel.png",
	ingredients =
	{
	  {"sulfuric-acid-barrel",1}
	},
	results=
	{
	  {type="fluid", name="sulfuric-acid", amount=30},
	  {"empty-barrel",1}
	}
  },
}
)