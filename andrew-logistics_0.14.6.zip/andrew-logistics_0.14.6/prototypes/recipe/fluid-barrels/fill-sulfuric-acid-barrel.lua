-- fill-sulfuric-acid-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "fill-sulfuric-acid-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-fill",
	order = "g",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/fill-sulfuric-acid-barrel.png",
	ingredients =
	{
	  {type="fluid", name="sulfuric-acid", amount=30},
	  {"empty-barrel",1},
	},
	results=
	{
	  {"sulfuric-acid-barrel",1}
	}
  },
}
)