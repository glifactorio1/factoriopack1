-- empty-water-barrel --
data:extend(
{	
  {
	type = "recipe",
	name = "empty-water-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-empty",
	order = "b",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/empty-water-barrel.png",
	ingredients =
	{
	  {"water-barrel",1}
	},
	results=
	{
	  {type="fluid", name="water", amount=30},
	  {"empty-barrel",1}
	}
  },
}
)
