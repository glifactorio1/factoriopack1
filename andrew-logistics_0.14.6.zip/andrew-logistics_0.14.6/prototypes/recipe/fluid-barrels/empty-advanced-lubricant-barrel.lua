
-- empty-advanced-lubricant-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "empty-advanced-lubricant-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-empty",
	order = "e",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/empty-advanced-lubricant-barrel.png",
	ingredients =
	{
	  {"advanced-lubricant-barrel",1}
	},
	results=
	{
	  {type="fluid", name="advanced-lubricant", amount=30},
	  {"empty-barrel",1}
	}
  },
}
)