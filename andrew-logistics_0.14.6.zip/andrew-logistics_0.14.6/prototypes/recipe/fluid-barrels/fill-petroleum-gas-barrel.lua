-- fill-petroleum-gas-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "fill-petroleum-gas-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-fill",
	order = "f",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/fill-petroleum-gas-barrel.png",
	ingredients =
	{
	  {type="fluid", name="petroleum-gas", amount=30},
	  {"empty-barrel",1},
	},
	results=
	{
	  {"petroleum-gas-barrel",1}
	}
  },
}
)