
-- fill-advanced-lubricant-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "fill-advanced-lubricant-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-fill",
	order = "e",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/fill-advanced-lubricant-barrel.png",
	ingredients =
	{
	  {type="fluid", name="advanced-lubricant", amount=30},
	  {"empty-barrel",1},
	},
	results=
	{
	  {"advanced-lubricant-barrel",1}
	}
  },
}
)