-- fill-light-oil-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "fill-light-oil-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-fill",
	order = "d",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/fill-light-oil-barrel.png",
	ingredients =
	{
	  {type="fluid", name="light-oil", amount=30},
	  {"empty-barrel",1},
	},
	results=
	{
	  {"light-oil-barrel",1}
	}
  },
}
)
