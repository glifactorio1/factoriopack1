-- empty-light-oil-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "empty-light-oil-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-empty",
	order = "d",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/empty-light-oil-barrel.png",
	ingredients =
	{
	  {"light-oil-barrel",1}
	},
	results=
	{
	  {type="fluid", name="light-oil", amount=30},
	  {"empty-barrel",1}
	}
  },
}
)
