-- empty-heavy-oil-barrel --
data:extend(
{
  {
	type = "recipe",
	name = "empty-heavy-oil-barrel",
	category = "crafting-with-fluid",
	energy_required = 1,
	subgroup = "liquid-empty",
	order = "c",
	enabled = false,
	icon = "__andrew-logistics__/graphics/icons/fluid-barrels/empty-heavy-oil-barrel.png",
	ingredients =
	{
	  {"heavy-oil-barrel",1}
	},
	results=
	{
	  {type="fluid", name="heavy-oil", amount=30},
	  {"empty-barrel",1}
	}
  },
}
)
