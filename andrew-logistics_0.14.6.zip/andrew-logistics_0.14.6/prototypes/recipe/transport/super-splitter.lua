-- super-splitter --
data:extend(
{
  {
    type = "recipe",
    name = "super-splitter",
    category = "crafting",
    enabled = false,
    energy_required = 3,
    result = "super-splitter",
    result_count = 1,
    ingredients =
    {
      {"steel-gear-wheel", 10},
	  {"steel-bearing", 4},
      {"ultra-splitter", 1},
      {"advanced-processing-unit", 5},
    },
  },
}
)
