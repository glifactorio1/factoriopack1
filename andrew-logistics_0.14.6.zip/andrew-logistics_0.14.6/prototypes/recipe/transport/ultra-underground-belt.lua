-- ultra-underground-belt --
data:extend(
{
  {
    type = "recipe",
    name = "ultra-underground-belt",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "ultra-underground-belt",
    result_count = 2,
    ingredients =
    {
      {"steel-gear-wheel", 10},
	  {"steel-bearing", 6},
      {"express-underground-belt", 2},
    },
  },
}
)
