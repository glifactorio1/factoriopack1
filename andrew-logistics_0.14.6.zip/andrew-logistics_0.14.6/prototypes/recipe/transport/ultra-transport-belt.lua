-- ultra-transport-belt --
data:extend(
{
  {
    type = "recipe",
    name = "ultra-transport-belt",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "ultra-transport-belt",
	result_count = 1,
    requester_paste_multiplier = 4,
    ingredients =
    {
      {"steel-gear-wheel", 5},
      {"express-transport-belt", 1}
    },
  },
}
)
