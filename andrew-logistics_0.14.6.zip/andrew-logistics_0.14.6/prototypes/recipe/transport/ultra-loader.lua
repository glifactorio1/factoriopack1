-- ultra-loader --
data:extend(
{
  {
    type = "recipe",
    name = "ultra-loader",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "ultra-loader",
	result_count = 1,
    ingredients =
    {
      {"ultra-transport-belt", 5},
      {"express-loader", 1}
    },
  },
}
)