-- hyper-loader --
data:extend(
{
  {
    type = "recipe",
    name = "hyper-loader",
    category = "crafting",
    enabled = false,
    energy_required = 12,
    result = "hyper-loader",
	result_count = 1,
    ingredients =
    {
      {"hyper-transport-belt", 5},
      {"super-loader", 1}
    },
  },
}
)
