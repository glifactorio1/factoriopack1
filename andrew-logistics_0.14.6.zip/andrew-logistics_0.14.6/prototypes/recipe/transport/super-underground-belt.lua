-- super-underground-belt --
data:extend(
{
  {
    type = "recipe",
    name = "super-underground-belt",
    category = "crafting",
    energy_required = 0.5,
    enabled = false,
    result = "super-underground-belt",
    result_count = 2,
    ingredients =
    {
      {"steel-gear-wheel", 20},
	  {"steel-bearing", 6},
      {"ultra-underground-belt", 2},
    },
  },
}
)
