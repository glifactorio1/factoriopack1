-- super-transport-belt --
data:extend(
{
  {
    type = "recipe",
    name = "super-transport-belt",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "super-transport-belt",
	result_count = 1,
    requester_paste_multiplier = 4,
    ingredients =
    {
      {"steel-gear-wheel", 5},
      {"ultra-transport-belt", 1}
    },
  },
}
)