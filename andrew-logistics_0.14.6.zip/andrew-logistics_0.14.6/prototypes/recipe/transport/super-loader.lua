-- super-loader --
data:extend(
{
  {
    type = "recipe",
    name = "super-loader",
    category = "crafting",
    enabled = false,
    energy_required = 12,
    result = "super-loader",
	result_count = 1,
    ingredients =
    {
      {"super-transport-belt", 5},
      {"ultra-loader", 1}
    },
  },
}
)
