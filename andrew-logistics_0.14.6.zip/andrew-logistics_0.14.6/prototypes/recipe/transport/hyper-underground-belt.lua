-- hyper-underground-belt --
data:extend(
{
  {
    type = "recipe",
    name = "hyper-underground-belt",
    category = "crafting-with-fluid",
    energy_required = 0.5,
    enabled = false,
    result = "hyper-underground-belt",
    result_count = 2,
    ingredients =
    {
      {"steel-gear-wheel", 20},
	  {"steel-bearing", 6},
      {"super-underground-belt", 2},
      {type="fluid", name="advanced-lubricant", amount=3},
    },
  },
}
)
