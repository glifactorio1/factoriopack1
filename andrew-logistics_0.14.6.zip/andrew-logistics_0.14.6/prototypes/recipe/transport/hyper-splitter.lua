-- hyper-splitter --
data:extend(
{
  {
    type = "recipe",
    name = "hyper-splitter",
    category = "crafting-with-fluid",
    enabled = false,
    energy_required = 3,
    result = "hyper-splitter",
    result_count = 1,
    ingredients =
    {
      {"steel-gear-wheel", 5},
	  {"steel-bearing", 1},
      {"super-splitter", 1},
      {"computer-chip", 2},
      {type="fluid", name="advanced-lubricant", amount=3},
    },
  },
}
)