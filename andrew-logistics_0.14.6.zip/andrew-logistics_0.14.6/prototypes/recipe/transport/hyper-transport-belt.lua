-- hyper-transport-belt --
data:extend(
{
  {
    type = "recipe",
    name = "hyper-transport-belt",
    category = "crafting-with-fluid",
    enabled = false,
    energy_required = 0.5,
    result = "hyper-transport-belt",
	result_count = 1,
    requester_paste_multiplier = 4,
    ingredients =
    {
      {"steel-gear-wheel", 5},
      {"super-transport-belt", 1},
      {type="fluid", name="advanced-lubricant", amount=3},
    },
  },
}
)