-- ultra-splitter --
data:extend(
{
  {
    type = "recipe",
    name = "ultra-splitter",
    category = "crafting",
    enabled = false,
    energy_required = 3,
    result = "ultra-splitter",
    result_count = 1,
    ingredients =
    {
      {"steel-gear-wheel", 10},
	  {"steel-bearing", 4},
      {"express-splitter", 1},
      {"processing-unit", 5},
    },
  },
}
)
