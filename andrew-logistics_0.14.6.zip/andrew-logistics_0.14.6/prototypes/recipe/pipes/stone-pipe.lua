-- stone-pipe --
data:extend(
{
  {
    type = "recipe",
    name = "stone-pipe",
    category = "crafting",
    enabled = true,
    energy_required = 0.5,
    result = "stone-pipe",
	result_count = 1,
    ingredients =
    {
      {"stone-brick", 1},
    },
  },
}
)