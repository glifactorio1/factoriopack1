-- plastic-pipe --
data:extend(
{
  {
    type = "recipe",
    name = "plastic-pipe",
    category = "crafting",
    enabled = false,
	energy_required = 0.5,
	result = "plastic-pipe",
	result_count = 1,
    ingredients =
    {
      {"plastic-bar", 1},
    },
  },
}
)
