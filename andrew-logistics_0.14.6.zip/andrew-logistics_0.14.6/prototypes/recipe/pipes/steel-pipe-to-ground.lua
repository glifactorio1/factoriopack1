-- steel-pipe-to-ground --
data:extend(
{
  {
    type = "recipe",
    name = "steel-pipe-to-ground",
    category = "crafting",
    enabled = false,
	energy_required = 0.5,
	result = "steel-pipe-to-ground",
	result_count = 2,
    ingredients =
    {
      {"steel-pipe", 10},
      {"steel-plate", 5},
    },
  },
}
)
