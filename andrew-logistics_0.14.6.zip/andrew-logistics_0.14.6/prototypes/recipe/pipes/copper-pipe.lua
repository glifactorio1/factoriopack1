-- copper-pipe --
data:extend(
{
  {
    type = "recipe",
    name = "copper-pipe",
    category = "crafting",
    enabled = true,
	energy_required = 0.5,
	result = "copper-pipe",
	result_count = 1,
    ingredients =
    {
      {"copper-plate", 1},
    },
  },
}
)
