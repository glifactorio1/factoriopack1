-- clay-pipe --
data:extend(
{
  {
    type = "recipe",
    name = "clay-pipe",
    category = "crafting",
    enabled = true,
    energy_required = 0.5,
    result = "clay-pipe",
	result_count = 1,
    ingredients =
    {
      {"clay-brick", 1},
    },
  },
}
)

