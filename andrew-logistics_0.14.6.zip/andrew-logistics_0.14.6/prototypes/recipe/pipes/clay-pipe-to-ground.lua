-- clay-pipe-to-ground --
data:extend(
{
  {
    type = "recipe",
    name = "clay-pipe-to-ground",
    category = "crafting",
    enabled = true,
	energy_required = 0.5,
    result = "clay-pipe-to-ground",
	result_count = 2,	
    ingredients =
    {
      {"clay-pipe", 10},
      {"clay-brick", 5},
    },
  },
}
)