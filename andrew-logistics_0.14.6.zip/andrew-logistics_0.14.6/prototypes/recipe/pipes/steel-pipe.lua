-- steel-pipe --
data:extend(
{
  {
    type = "recipe",
    name = "steel-pipe",
    category = "crafting",
    enabled = false,
	energy_required = 0.5,
    result = "steel-pipe",
	result_count = 1,
    ingredients =
    {
      {"steel-plate", 1},
    },
  },
}
)
