-- copper-pipe-to-ground --
data:extend(
{
  {
    type = "recipe",
    name = "copper-pipe-to-ground",
    category = "crafting",
	enabled = true,
	energy_required = 0.5,
    result = "copper-pipe-to-ground",
	result_count = 2,
    ingredients =
    {
      {"copper-pipe", 10},
      {"copper-plate", 5},
    },
  },
}
)
