-- plastic-pipe-to-ground --
data:extend(
{
  {
    type = "recipe",
    name = "plastic-pipe-to-ground",
    category = "crafting",
    enabled = false,
	energy_required = 0.5,
	result = "plastic-pipe-to-ground",
    result_count = 2,
    ingredients =
    {
      {"plastic-pipe", 10},
      {"plastic-bar", 5},
    },
  },
}
)
