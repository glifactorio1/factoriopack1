-- stone-pipe-to-ground --
data:extend(
{
  {
    type = "recipe",
    name = "stone-pipe-to-ground",
    category = "crafting",
    enabled = true,
	energy_required = 0.5,
    result = "stone-pipe-to-ground",
	result_count = 2,	
    ingredients =
    {
      {"stone-pipe", 10},
      {"stone-brick", 5},
    },
  },
}
)