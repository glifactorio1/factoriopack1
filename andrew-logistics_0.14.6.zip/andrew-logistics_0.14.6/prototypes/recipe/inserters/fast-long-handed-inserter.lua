-- fast-long-handed-inserter --
data:extend(
{
  {
    type = "recipe",
    name = "fast-long-handed-inserter",
    enabled = false,
    energy_required = 0.5,
    result = "fast-long-handed-inserter",
	result_count = 1,
    requester_paste_multiplier = 4,
    ingredients =
    {
      {"iron-gear-wheel", 1},
      {"iron-plate", 1},
      {"fast-inserter", 1}
    },
  },
}
)