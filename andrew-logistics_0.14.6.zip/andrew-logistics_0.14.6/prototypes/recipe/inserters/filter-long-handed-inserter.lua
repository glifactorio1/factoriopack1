-- filter-long-handed-inserter --
data:extend(
{
   {
    type = "recipe",
    name = "filter-long-handed-inserter",
    enabled = false,
    energy_required = 0.5,
    result = "filter-long-handed-inserter",
	result_count = 1,
    requester_paste_multiplier = 4,
    ingredients =
    {
      {"iron-plate", 1},
      {"iron-gear-wheel", 1},
      {"filter-inserter", 1},
    },
  },
}
)