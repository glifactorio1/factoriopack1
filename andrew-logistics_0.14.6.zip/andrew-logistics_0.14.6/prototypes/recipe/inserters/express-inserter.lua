-- express-inserter --
data:extend(
{
  {
    type = "recipe",
    name = "express-inserter",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "express-inserter",
	result_count = 1,
    ingredients =
    {
      {"steel-gear-wheel", 5},
      {"advanced-circuit", 2},
      {"fast-inserter", 1}
    },
  },
}
)