data:extend(
{
  {
    type = "recipe",
    name = "logistic-robot-2",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "logistic-robot-2",
	result_count = 1,
    ingredients =
    {
      {"logistic-robot", 1},
      {"flying-robot-frame-2", 1},
    },
  },

  {
    type = "recipe",
    name = "logistic-robot-3",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "logistic-robot-3",
	result_count = 1,
    ingredients =
    {
      {"logistic-robot-2", 1},
      {"flying-robot-frame-3", 1},
    },
  },

  {
    type = "recipe",
    name = "logistic-robot-4",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "logistic-robot-4",
	result_count = 1,
    ingredients =
    {
      {"logistic-robot-3", 1},
      {"flying-robot-frame-4", 1},
    },
  },
  
  {
    type = "recipe",
    name = "logistic-robot-5",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "logistic-robot-5",
	result_count = 1,
    ingredients =
    {
      {"logistic-robot-4", 1},
      {"flying-robot-frame-5", 1},
    },
  },
}
)
