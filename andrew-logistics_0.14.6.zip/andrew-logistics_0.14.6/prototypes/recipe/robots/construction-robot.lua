-- construction-robot-2 --
data:extend(
{
  {
    type = "recipe",
    name = "construction-robot-2",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "construction-robot-2",
	result_count = 1,
    ingredients =
    {
      {"construction-robot", 1},
      {"flying-robot-frame-2", 1},
    },
  },
}
)

-- construction-robot-3 --
data:extend(
{
  {
    type = "recipe",
    name = "construction-robot-3",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "construction-robot-3",
	result_count = 1,
    ingredients =
    {
      {"construction-robot-2", 1},
      {"flying-robot-frame-3", 1},
    },
  },
}
)

-- construction-robot-4 --
data:extend(
{
  {
    type = "recipe",
    name = "construction-robot-4",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "construction-robot-4",
	result_count = 1,
    ingredients =
    {
      {"construction-robot-3", 1},
      {"flying-robot-frame-4", 1},
    },
  },
}
)

-- construction-robot-5 --
data:extend(
{
  {
    type = "recipe",
    name = "construction-robot-5",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
	result = "construction-robot-5",
	result_count = 1,
    ingredients =
    {
      {"construction-robot-4", 1},
      {"flying-robot-frame-5", 1},
    },
  },
}
)