-- flying-robot-frame-2 --
data:extend(
{
  {
    type = "recipe",
    name = "flying-robot-frame-2",
	category = "crafting",
    enabled = false,
    energy_required = 20,
    result = "flying-robot-frame-2",
	result_count = 1,
    ingredients =
    {
      {"electric-engine-unit", 1},
      {"battery", 2},
      {"steel-plate", 1},
      {"advanced-circuit", 3}
    },
  },
}
)

-- flying-robot-frame-3 --
data:extend(
{
  {
    type = "recipe",
    name = "flying-robot-frame-3",
    category = "crafting",
    enabled = false,
    energy_required = 20,
    result = "flying-robot-frame-3",
	result_count = 1,
    ingredients =
    {
      {"electric-engine-unit", 1},
      {"battery", 2},
      {"steel-plate", 1},
      {"processing-unit", 3}
    },
  },
}
)

-- flying-robot-frame-4 --
data:extend(
{
  {
    type = "recipe",
    name = "flying-robot-frame-4",
    category = "crafting",
    enabled = false,
    energy_required = 20,
    result = "flying-robot-frame-4",
	result_count = 1,
    ingredients =
    {
      {"electric-engine-unit", 1},
      {"battery", 2},
      {"steel-plate", 1},
      {"advanced-processing-unit", 3}
    },
  },
}
)

-- flying-robot-frame-5 --
data:extend(
{
  {
    type = "recipe",
    name = "flying-robot-frame-5",
    category = "crafting",
    enabled = false,
    energy_required = 20,
    result = "flying-robot-frame-5",
	result_count = 1,
    ingredients =
    {
      {"electric-engine-unit", 1},
      {"battery", 2},
      {"steel-plate", 1},
      {"computer-chip", 3}
    },
  },
}
)