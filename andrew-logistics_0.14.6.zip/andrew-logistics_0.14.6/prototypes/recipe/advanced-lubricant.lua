-- advanced-lubricant --
data:extend(
{
  {
    type = "recipe",
    name = "advanced-lubricant",
    category = "chemistry",
    enabled = false,
    energy_required = 3,
    ingredients =
    {
      {type="fluid", name="light-oil", amount=10}
    },
    results=
    {
      {type="fluid", name="advanced-lubricant", amount=15}
    },
  },
}
)