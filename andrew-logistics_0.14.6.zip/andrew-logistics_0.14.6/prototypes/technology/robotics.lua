-- robotics-1 --
data:extend(
{
  {
    type = "technology",
    name = "robotics-1",
    icon = "__andrew-logistics__/graphics/technology/robotics.png",
    upgrade = true,
    order = "c-k-a-a",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "flying-robot-frame-2"
      },
      {
        type = "unlock-recipe",
        recipe = "logistic-robot-2"
      },
      {
        type = "unlock-recipe",
        recipe = "construction-robot-2"
      },
    },
    prerequisites =
    {
      "construction-robotics",
      "logistic-robotics",
    },
    unit =
    {
      count = 75,
      time = 30,
      ingredients = science2()
    },
  },
}
)

-- robotics-2 --
data:extend(
{
  {
    type = "technology",
    name = "robotics-2",
    icon = "__andrew-logistics__/graphics/technology/robotics.png",
    upgrade = true,
    order = "c-k-a-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "flying-robot-frame-3"
      },
      {
        type = "unlock-recipe",
        recipe = "logistic-robot-3"
      },
      {
        type = "unlock-recipe",
        recipe = "construction-robot-3"
      },
    },
    prerequisites =
    {
      "robotics-1",
    },
    unit =
    {
      count = 75,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- robotics-3 --
data:extend(
{
  {
    type = "technology",
    name = "robotics-3",
    icon = "__andrew-logistics__/graphics/technology/robotics.png",
    upgrade = true,
    order = "c-k-a-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "flying-robot-frame-4"
      },
      {
        type = "unlock-recipe",
        recipe = "logistic-robot-4"
      },
      {
        type = "unlock-recipe",
        recipe = "construction-robot-4"
      },
    },
    prerequisites =
    {
      "robotics-2",
    },
    unit =
    {
      count = 100,
      time = 30,
      ingredients = science4()
    },
  },
}
)

-- robotics-4 --
data:extend(
{
  {
    type = "technology",
    name = "robotics-4",
    icon = "__andrew-logistics__/graphics/technology/robotics.png",
    upgrade = true,
    order = "c-k-a-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "flying-robot-frame-5"
      },
      {
        type = "unlock-recipe",
        recipe = "logistic-robot-5"
      },
      {
        type = "unlock-recipe",
        recipe = "construction-robot-5"
      },
    },
    prerequisites =
    {
      "robotics-3",
    },
    unit =
    {
      count = 125,
      time = 30,
      ingredients = science4()
    },
  },
}
)