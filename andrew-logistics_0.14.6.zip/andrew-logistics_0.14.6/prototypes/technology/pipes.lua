
Add_Recipe_To_Tech("steel-processing", "steel-pipe")
Add_Recipe_To_Tech("steel-processing", "steel-pipe-to-ground")

Add_Recipe_To_Tech("plastics", "plastic-pipe")
Add_Recipe_To_Tech("plastics", "plastic-pipe-to-ground")