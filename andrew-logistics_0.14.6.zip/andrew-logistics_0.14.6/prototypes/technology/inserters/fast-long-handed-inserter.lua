
Add_Recipe_To_Tech("logistics", "fast-long-handed-inserter")
