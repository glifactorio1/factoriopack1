
Add_Recipe_To_Tech("automation","burner-long-handed-inserter")
