-- express-inserters --
data:extend(
{
  {
    type = "technology",
    name = "express-inserter",
    icon = "__andrew-logistics__/graphics/icons/inserter/express-inserter.png",
    upgrade = true,
    order = "a-f",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "express-inserter"
      },
    },
    prerequisites =
    {
      "advanced-electronics",
      "logistics",
    },
    unit =
    {
      count = 50,
      time = 30,
      ingredients = science3()
    },
  },
}
)