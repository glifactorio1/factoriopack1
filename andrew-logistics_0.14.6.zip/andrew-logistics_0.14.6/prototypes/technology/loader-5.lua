-- loader-5 --
data:extend(
{
 {
    type = "technology",
    name = "loader-5",
    icon = "__base__/graphics/technology/logistics.png",
    upgrade = true,
    order = "c-k-f-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "super-loader"
      },
    },
    prerequisites = 
	{
	  "loader-4",
	  "logistics-5",
	},
    unit =
    {
      count = 410,
      time = 30,
      ingredients = science4()
    },
  },
}
)