-- logistics-5 --
data:extend(
{
{
    type = "technology",
    name = "logistics-5",
    icon = "__base__/graphics/technology/logistics.png",
    upgrade = true,
    order = "a-f-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "super-transport-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "super-underground-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "super-splitter"
      }
    },
    prerequisites = 
	{
	  "logistics-4",
	},
    unit =
    {
      count = 400,
      time = 30,
      ingredients = science4()
    },
  },
}
)
