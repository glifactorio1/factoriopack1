-- logistics-6 --
data:extend(
{
{
    type = "technology",
    name = "logistics-6",
    icon = "__base__/graphics/technology/logistics.png",
    upgrade = true,
    order = "a-f-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "hyper-transport-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "hyper-underground-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "hyper-splitter"
      },
	  {
        type = "unlock-recipe",
        recipe = "advanced-lubricant"
      },
	  {
        type = "unlock-recipe",
        recipe = "fill-advanced-lubricant-barrel"
      },
	  {
        type = "unlock-recipe",
        recipe = "empty-advanced-lubricant-barrel"
      },
    },
    prerequisites = 
	{
	  "logistics-5",
	},
    unit =
    {
      count = 510,
      time = 30,
      ingredients = science4()
    },
  },
}
)
