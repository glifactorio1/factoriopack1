-- logistics-4 --
data:extend(
{
{
    type = "technology",
    name = "logistics-4",
    icon = "__base__/graphics/technology/logistics.png",
    upgrade = true,
    order = "a-f-d",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "ultra-transport-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "ultra-underground-belt"
      },
      {
        type = "unlock-recipe",
        recipe = "ultra-splitter"
      }
    },
    prerequisites = 
	{
	  "logistics-3",
	},
    unit =
    {
      count = 300,
      time = 30,
      ingredients = science4()
    },
  },
}
)
