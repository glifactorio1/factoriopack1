-- loader-6 --
data:extend(
{
 {
    type = "technology",
    name = "loader-6",
    icon = "__base__/graphics/technology/logistics.png",
    upgrade = true,
    order = "c-k-f-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "hyper-loader"
      },
    },
    prerequisites = 
	{
	  "loader-5",
	  "logistics-6",
	},
    unit =
    {
      count = 485,
      time = 30,
      ingredients = science4()
    },
  },
}
)