-- loader-4 --
data:extend(
{
 {
    type = "technology",
    name = "loader-4",
    icon = "__base__/graphics/technology/logistics.png",
    upgrade = true,
    order = "c-k-f-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "ultra-loader"
      },
    },
    prerequisites = 
	{
	  "loader-3",
	  "logistics-4",
	},
    unit =
    {
      count = 300,
      time = 30,
      ingredients = science4()
    },
  },
}
)