if data.raw.item["aluminium-plate"] then
Change_Recipe("flying-robot-frame-2", "steel-plate", "aluminium-plate", 1)
Change_Recipe("flying-robot-frame-3", "steel-plate", "aluminium-plate", 1)
Change_Recipe("flying-robot-frame-4", "steel-plate", "aluminium-plate", 1)
Change_Recipe("flying-robot-frame-5", "steel-plate", "aluminium-plate", 1)
end





