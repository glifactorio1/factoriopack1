-- logistic-robot-3 --
data:extend(
{
  {
    type = "logistic-robot",
    name = "logistic-robot-3",
    icon = "__andrew-logistics__/graphics/icons/logistic-robot-3.png",
    flags = {"placeable-player", "player-creation", "placeable-off-grid", "not-on-map"},
    minable = {hardness = 0.1, mining_time = 0.1, result = "logistic-robot-3"},
    max_health = 200,
    collision_box = {{0, 0}, {0, 0}},
    selection_box = {{-0.5, -1.5}, {0.5, -0.5}},
    max_payload_size = 4,
    speed = 0.15,
    transfer_distance = 0.5,
    max_energy = "900kJ",
    energy_per_tick = "6J",
    speed_multiplier_when_out_of_energy = 0.2,
    energy_per_move = "600J",
    min_to_charge = 0.2,
    max_to_charge = 0.95,
    working_sound = flying_robot_sounds(),
    cargo_centered = {0.0, 0.2},
    picture =
    {
      filename = "__andrew-logistics__/graphics/entity/robots/logistic-robot-3.png",
      priority = "high",
      width = 32,
      height = 32,
    },
    idle =
    {
      filename = "__andrew-logistics__/graphics/entity/robots/logistic-robot-3.png",
      priority = "high",
      width = 32,
      height = 32,
      frame_count = 1,
      direction_count = 1,
    },
    idle_with_cargo =
    {
      filename = "__andrew-logistics__/graphics/entity/robots/logistic-robot-3.png",
      priority = "high",
      width = 32,
      height = 32,
      frame_count = 1,
      direction_count = 1,
    },
    in_motion =
    {
      filename = "__andrew-logistics__/graphics/entity/robots/logistic-robot-3.png",
      priority = "high",
      width = 32,
      height = 32,
      frame_count = 1,
      direction_count = 1,
    },
    in_motion_with_cargo =
    {
      filename = "__andrew-logistics__/graphics/entity/robots/logistic-robot-3.png",
      priority = "high",
      width = 32,
      height = 32,
      frame_count = 1,
      direction_count = 1,
    },
    shadow =
    {
      filename = "__andrew-logistics__/graphics/entity/robots/robot-shadow.png",
      priority = "high",
      width = 52,
      height = 37,
    },
    shadow_idle =
    {
      filename = "__andrew-logistics__/graphics/entity/robots/robot-shadow.png",
      priority = "high",
      width = 52,
      height = 37,
      frame_count = 1,
      direction_count = 1,
    },
    shadow_idle_with_cargo =
    {
      filename = "__andrew-logistics__/graphics/entity/robots/robot-shadow.png",
      priority = "high",
      width = 52,
      height = 37,
      frame_count = 1,
      direction_count = 1,
    },
    shadow_in_motion =
    {
      filename = "__andrew-logistics__/graphics/entity/robots/robot-shadow.png",
      priority = "high",
      width = 52,
      height = 37,
      frame_count = 1,
      direction_count = 1,
    },
    shadow_in_motion_with_cargo =
    {
      filename = "__andrew-logistics__/graphics/entity/robots/robot-shadow.png",
      priority = "high",
      width = 52,
      height = 37,
      frame_count = 1,
      direction_count = 1,
    },
  },
}
)
