-- super-splitter --
data:extend(
{
  {
    type = "splitter",
    name = "super-splitter",
    icon = "__andrew-logistics__/graphics/icons/super-splitter.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "super-splitter"},
    max_health = 80,
    corpse = "medium-remnants",
    fast_replaceable_group = "splitter",
    speed = 0.15625,
    resistances =
    {
      {
        type = "fire",
        percent = 60
      }
    },
    collision_box = {{-0.9, -0.4}, {0.9, 0.4}},
    selection_box = {{-0.9, -0.5}, {0.9, 0.5}},
    animation_speed_coefficient = 32,
	structure = splitter("super"),
    structure_animation_speed_coefficient = 1.2,
    structure_animation_movement_cooldown = 10,
    belt_horizontal = super_belt_horizontal, -- specified in transport-belt-pictures.lua
    belt_vertical = super_belt_vertical,
    ending_top = super_belt_ending_top,
    ending_bottom = super_belt_ending_bottom,
    ending_side = super_belt_ending_side,
    starting_top = super_belt_starting_top,
    starting_bottom = super_belt_starting_bottom,
    starting_side = super_belt_starting_side,
    ending_patch = ending_patch_prototype,
  },
}
)
