-- hyper-transport-belt --
data:extend(
{
  {
    type = "transport-belt",
    name = "hyper-transport-belt",
    icon = "__andrew-logistics__/graphics/icons/hyper-transport-belt.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.3, result = "hyper-transport-belt"},
    max_health = 50,
    corpse = "small-remnants",
    fast_replaceable_group = "transport-belt",
    speed = 0.1875,
    resistances =
    {
      {
        type = "fire",
        percent = 50
      }
    },
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/fast-transport-belt.ogg",
        volume = 0.4
      },
      max_sounds_per_type = 3
    },
    animation_speed_coefficient = 32,
    animations =
    {
      filename = "__andrew-logistics__/graphics/entity/transport-belt/hyper-transport-belt/hyper-transport-belt.png",
      priority = "extra-high",
      width = 40,
      height = 40,
      frame_count = 32,
      direction_count = 12,
    },
    belt_horizontal = hyper_belt_horizontal, -- specified in transport-belt-pictures.lua
    belt_vertical = hyper_belt_vertical,
    ending_top = hyper_belt_ending_top,
    ending_bottom = hyper_belt_ending_bottom,
    ending_side = hyper_belt_ending_side,
    starting_top = hyper_belt_starting_top,
    starting_bottom = hyper_belt_starting_bottom,
    starting_side = hyper_belt_starting_side,
    ending_patch = ending_patch_prototype,
    connector_frame_sprites = transport_belt_connector_frame_sprites,
    circuit_connector_sprites = transport_belt_circuit_connector_sprites,
    circuit_wire_connection_point = transport_belt_circuit_wire_connection_point,
    circuit_wire_max_distance = transport_belt_circuit_wire_max_distance
  },
}
)