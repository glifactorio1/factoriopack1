-- super-loader --
data:extend(
{
  {
    type = "loader",
    name = "super-loader",
    icon = "__andrew-logistics__/graphics/icons/super-loader.png",
    flags = {"placeable-neutral", "player-creation", "fast-replaceable-no-build-while-moving"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "super-loader"},
    max_health = 70,
    filter_count = 5,
    corpse = "small-remnants",
    fast_replaceable_group = "loader",
    speed = 0.16,
    resistances =
    {
      {
        type = "fire",
        percent = 60
      }
    },
    collision_box = {{-0.4, -0.9}, {0.4, 0.9}},
    selection_box = {{-0.5, -1}, {0.5, 1}},
    animation_speed_coefficient = 32,
    structure =loader("super"),
    belt_horizontal = super_belt_horizontal,
    belt_vertical = super_belt_vertical,
    ending_top = super_belt_ending_top,
    ending_bottom = super_belt_ending_bottom,
    ending_side = super_belt_ending_side,
    starting_top = super_belt_starting_top,
    starting_bottom = super_belt_starting_bottom,
    starting_side = super_belt_starting_side,
    ending_patch = ending_patch_prototype
  },
}
)
