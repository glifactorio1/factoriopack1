ultra_belt_horizontal =
  {
    filename = "__andrew-logistics__/graphics/entity/transport-belt/ultra-transport-belt/ultra-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 32
  }
ultra_belt_vertical =
  {
    filename = "__andrew-logistics__/graphics/entity/transport-belt/ultra-transport-belt/ultra-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 32,
    y = 40
  }
ultra_belt_ending_top =
  {
    filename = "__andrew-logistics__/graphics/entity/transport-belt/ultra-transport-belt/ultra-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 32,
    y = 80
  }
ultra_belt_ending_bottom =
  {
    filename = "__andrew-logistics__/graphics/entity/transport-belt/ultra-transport-belt/ultra-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 32,
    y = 120
  }
ultra_belt_ending_side =
  {
    filename = "__andrew-logistics__/graphics/entity/transport-belt/ultra-transport-belt/ultra-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 32,
    y = 160
  }
ultra_belt_starting_top =
  {
    filename = "__andrew-logistics__/graphics/entity/transport-belt/ultra-transport-belt/ultra-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 32,
    y = 200
  }
ultra_belt_starting_bottom =
  {
    filename = "__andrew-logistics__/graphics/entity/transport-belt/ultra-transport-belt/ultra-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 32,
    y = 240
  }
ultra_belt_starting_side =
  {
    filename = "__andrew-logistics__/graphics/entity/transport-belt/ultra-transport-belt/ultra-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 32,
    y = 280
  }
