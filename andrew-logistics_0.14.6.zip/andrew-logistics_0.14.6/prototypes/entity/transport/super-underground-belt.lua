-- super-underground-belt --
data:extend(
{
  {
    type = "underground-belt",
    name = "super-underground-belt",
    icon = "__andrew-logistics__/graphics/icons/super-underground-belt.png",
    flags = {"placeable-neutral", "player-creation", "fast-replaceable-no-build-while-moving"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "super-underground-belt"},
    max_health = 60,
    corpse = "small-remnants",
    fast_replaceable_group = "underground-belt",
    speed = 0.15625,
    resistances =
    {
      {
        type = "fire",
        percent = 60
      }
    },
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    animation_speed_coefficient = 32,
    underground_sprite =
    {
      filename = "__core__/graphics/arrows/underground-lines.png",
      priority = "high",
      width = 64,
      height = 64,
      x = 64,
      scale = 0.5
    },
    structure =Underground_Belt("super"),
    belt_horizontal = super_belt_horizontal, -- specified in transport-belt-pictures.lua
    belt_vertical = super_belt_vertical,
    ending_top = super_belt_ending_top,
    ending_bottom = super_belt_ending_bottom,
    ending_side = super_belt_ending_side,
    starting_top = super_belt_starting_top,
    starting_bottom = super_belt_starting_bottom,
    starting_side = super_belt_starting_side,
    ending_patch = ending_patch_prototype
  },
}
)
