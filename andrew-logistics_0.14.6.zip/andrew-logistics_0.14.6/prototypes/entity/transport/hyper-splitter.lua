-- hyper-splitter --
data:extend(
{
  {
    type = "splitter",
    name = "hyper-splitter",
    icon = "__andrew-logistics__/graphics/icons/hyper-splitter.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "hyper-splitter"},
    max_health = 80,
    corpse = "medium-remnants",
    fast_replaceable_group = "splitter",
    speed = 0.1875,
    resistances =
    {
      {
        type = "fire",
        percent = 60
      }
    },
    collision_box = {{-0.9, -0.4}, {0.9, 0.4}},
    selection_box = {{-0.9, -0.5}, {0.9, 0.5}},
    animation_speed_coefficient = 32,
	structure = splitter("hyper"),
    structure_animation_speed_coefficient = 1.2,
    structure_animation_movement_cooldown = 10,
    belt_horizontal = hyper_belt_horizontal, -- specified in transport-belt-pictures.lua
    belt_vertical = hyper_belt_vertical,
    ending_top = hyper_belt_ending_top,
    ending_bottom = hyper_belt_ending_bottom,
    ending_side = hyper_belt_ending_side,
    starting_top = hyper_belt_starting_top,
    starting_bottom = hyper_belt_starting_bottom,
    starting_side = hyper_belt_starting_side,
    ending_patch = ending_patch_prototype,
  },
}
)
