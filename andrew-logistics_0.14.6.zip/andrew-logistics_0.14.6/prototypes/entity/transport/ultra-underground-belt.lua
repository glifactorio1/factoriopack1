-- ultra-underground-belt --
data:extend(
{
  {
    type = "underground-belt",
    name = "ultra-underground-belt",
    icon = "__andrew-logistics__/graphics/icons/ultra-underground-belt.png",
    flags = {"placeable-neutral", "player-creation", "fast-replaceable-no-build-while-moving"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "ultra-underground-belt"},
    max_health = 60,
    corpse = "small-remnants",
    fast_replaceable_group = "underground-belt",
    speed = 0.125,
    resistances =
    {
      {
        type = "fire",
        percent = 60
      }
    },
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    animation_speed_coefficient = 32,
    underground_sprite =
    {
      filename = "__core__/graphics/arrows/underground-lines.png",
      priority = "high",
      width = 64,
      height = 64,
      x = 64,
      scale = 0.5
    },
    structure = Underground_Belt("ultra"),
    belt_horizontal = ultra_belt_horizontal, -- specified in transport-belt-pictures.lua
    belt_vertical = ultra_belt_vertical,
    ending_top = ultra_belt_ending_top,
    ending_bottom = ultra_belt_ending_bottom,
    ending_side = ultra_belt_ending_side,
    starting_top = ultra_belt_starting_top,
    starting_bottom = ultra_belt_starting_bottom,
    starting_side = ultra_belt_starting_side,
    ending_patch = ending_patch_prototype
  },
}
)
