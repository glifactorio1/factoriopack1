game.reload_script()

for index, force in pairs(game.forces) do
  force.reset_recipes()
  force.reset_technologies()
  
  if force.technologies["steel-processing"].researched then
    force.recipes["steel-pipe"].enabled = true
  end
  if force.technologies["steel-processing"].researched then
    force.recipes["steel-pipe-to-ground"].enabled = true
  end
  if force.technologies["plastics"].researched then
    force.recipes["plastic-pipe"].enabled = true
  end
  if force.technologies["loader-4"].researched then
    force.recipes["ultra-loader"].enabled = true
  end
  if force.technologies["loader-5"].researched then
    force.recipes["super-loader"].enabled = true
  end
  if force.technologies["logistics-4"].researched then
    force.recipes["ultra-transport-belt"].enabled = true
    force.recipes["ultra-underground-belt"].enabled = true
    force.recipes["ultra-splitter"].enabled = true
  end
  if force.technologies["logistics-5"].researched then
    force.recipes["super-transport-belt"].enabled = true
    force.recipes["super-underground-belt"].enabled = true
    force.recipes["super-splitter"].enabled = true
  end
  if force.technologies["logistics-6"].researched then
    force.recipes["advanced-lubricant"].enabled = true
	force.recipes["advanced-lubricant-barrel"].enabled = true
	force.recipes["fill-advanced-lubricant-barrel"].enabled = true
	force.recipes["empty-advanced-lubricant-barrel"].enabled = true
  end
  if force.technologies["fluid-handling"].researched then
    force.recipes["empty-heavy-oil-barrel"].enabled = true
	force.recipes["empty-light-oil-barrel"].enabled = true
	force.recipes["empty-lubricant-barrel"].enabled = true
	force.recipes["empty-petroleum-gas-barrel"].enabled = true
	force.recipes["empty-sulfuric-acid-barrel"].enabled = true
	force.recipes["empty-water-barrel"].enabled = true
    force.recipes["fill-heavy-oil-barrel"].enabled = true
	force.recipes["fill-light-oil-barrel"].enabled = true
	force.recipes["fill-lubricant-barrel"].enabled = true
	force.recipes["fill-petroleum-gas-barrel"].enabled = true
	force.recipes["fill-sulfuric-acid-barrel"].enabled = true
	force.recipes["fill-water-barrel"].enabled = true
  end
end
