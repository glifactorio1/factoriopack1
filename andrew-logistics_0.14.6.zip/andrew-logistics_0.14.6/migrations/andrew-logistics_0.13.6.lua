game.reload_script()

for index, force in pairs(game.forces) do
  force.reset_recipes()
  force.reset_technologies()
  
  if force.technologies["steel-processing"].researched then
    force.recipes["steel-pipe"].enabled = true
  end
  if force.technologies["steel-processing"].researched then
    force.recipes["steel-pipe-to-ground"].enabled = true
  end
  if force.technologies["plastics"].researched then
    force.recipes["plastic-pipe"].enabled = true
  end
  if force.technologies["plastics"].researched then
    force.recipes["plastic-pipe-to-ground"].enabled = true
  end
end
