local recipe_cat = {
    type = "recipe-category",
    name = "compression"
}
data:extend({recipe_cat})
