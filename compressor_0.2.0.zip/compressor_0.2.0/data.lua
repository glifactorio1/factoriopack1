require("prototypes/item-groups")
require("prototypes/recipe-categories")
require("prototypes/technologies")
require("prototypes/auto-compressor")
