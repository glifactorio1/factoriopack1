data:extend(
{
  {
    type = "damage-type",
    name = "plasma"
  },
  {
    type = "damage-type",
    name = "radiation"
  },
  {
    type = "damage-type",
    name = "lightning"
  },
  {
    type = "damage-type",
    name = "lava"
  },
}
)
