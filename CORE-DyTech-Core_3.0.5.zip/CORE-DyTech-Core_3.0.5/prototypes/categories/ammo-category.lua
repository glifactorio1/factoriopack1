data:extend(
{
  {
    type = "ammo-category",
    name = "sniper-ammo"
  },
  {
    type = "ammo-category",
    name = "gem-ammo"
  },
  {
    type = "ammo-category",
    name = "battery"
  },
  {
    type = "ammo-category",
    name = "battery-shotgun"
  },
  {
    type = "ammo-category",
    name = "battery-tank"
  },
}
)