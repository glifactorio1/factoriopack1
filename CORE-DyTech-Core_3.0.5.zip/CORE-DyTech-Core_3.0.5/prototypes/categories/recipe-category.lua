data:extend(
{
  {
    type = "recipe-category",
    name = "polishing"
  },
  {
    type = "recipe-category",
    name = "converter"
  },
  {
    type = "recipe-category",
    name = "recycling"
  },
  {
    type = "recipe-category",
    name = "metallurgy-mold"
  },
  {
    type = "recipe-category",
    name = "metallurgy-wire"
  },
  {
    type = "recipe-category",
    name = "metallurgy-circuit"
  },
  {
    type = "recipe-category",
    name = "metallurgy-ammo-basic"
  },
  {
    type = "recipe-category",
    name = "metallurgy-ammo-advanced"
  },
  {
    type = "recipe-category",
    name = "metallurgy-tool"
  },
  {
    type = "recipe-category",
    name = "lava"
  },
  {
    type = "recipe-category",
    name = "air-collection"
  },
  {
    type = "recipe-category",
    name = "centrifuge"
  },
  {
    type = "recipe-category",
    name = "forge"
  },
  {
    type = "recipe-category",
    name = "blast-furnace"
  },
  {
    type = "recipe-category",
    name = "liquid-handler"
  },
  {
    type = "recipe-category",
    name = "lava-heater"
  },
  {
    type = "recipe-category",
    name = "lava-cooler"
  },
  {
	type = "recipe-category",
	name = "nuclear-recipe"
  },
  {
	type = "recipe-category",
	name = "sawmill"
  },
  {
    type = "recipe-category",
    name = "lava-handler"
  },
  {
    type = "recipe-category",
    name = "greenhouse"
  },
}
)
