data:extend(
{
  {
    type = "noise-layer",
    name = "sand"
  },
  {
    type = "noise-layer",
    name = "random"
  },
  {
    type = "noise-layer",
    name = "gems"
  },
}
)