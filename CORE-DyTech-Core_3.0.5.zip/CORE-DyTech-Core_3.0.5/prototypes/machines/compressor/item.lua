data:extend(
{
  {
	type = "item",
	name = "compressor",
    icon = "__CORE-DyTech-Core__/graphics/machines/dytech-compressor-icon.png",
	flags = {"goes-to-quickbar"},
	subgroup = "dytech-machines-cleaning",
	order = "compressor",
	place_result = "compressor",
	stack_size = 50,
  },
}
)