data:extend
({
	{
		type = "item",
		name = "DT-germling",
		icon = "__CORE-DyTech-Core__/graphics/regular-tree/germling.png",
		flags = {"goes-to-main-inventory"},
		subgroup = "dytech-intermediates-raw",
		order = "7",
		fuel_value = "1MJ",
		stack_size = 200
	  },
  })