data:extend(
{
  {
    type = "autoplace-control",
    name = "gemstones",
    richness = true,
    order = "g-s"
  },
}
)
