data:extend(
{ 
  {
    type = "recipe",
    name = "rubber-seed",
	icon = "__CORE-DyTech-Core__/graphics/rubber-tree/stage-1.png",
    energy_required = 1,
    ingredients = 
	{
	  {"resin", 1}
	},
    result = "rubber-seed"
  },
}
)