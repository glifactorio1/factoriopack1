data:extend(
{
  {
    type = "item",
    name = "rubber-seed",
	icon = "__CORE-DyTech-Core__/graphics/rubber-tree/stage-1.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "dytech-intermediates-raw",
    order = "seed-rubber",
    place_result = "rubber-seed",
    fuel_value = "1MJ",
    stack_size = 50
  },
}
)