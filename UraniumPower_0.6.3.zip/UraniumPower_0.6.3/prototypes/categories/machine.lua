data:extend(
{
	{
		type = "item-subgroup",
		name = "uranium-production-machine", --reactors
		group = "uranium",
		order = "d",
	}
})