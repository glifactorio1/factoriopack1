data:extend(
{
	{
		type = "recipe-category",
		name = "heat-exchanger-01",
		group = "uranium",
		order = "z-a"
	},
	{
		type = "recipe-category",
		name = "heat-exchanger-02",
		group = "uranium",
		order = "z-b"
	},	
	{
		type = "recipe-category",
		name = "pressure-pump",
		group = "uranium",
		order = "z-c"
	}
})
