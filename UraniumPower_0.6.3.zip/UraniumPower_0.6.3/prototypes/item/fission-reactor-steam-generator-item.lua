data:extend(
{
	{
		type = "item",
		name = "reactor-steam-generator-01",
		icon = "__UraniumPower__/graphics/entity/steam-generator/steamgenprotoicon.png",
		flags = {"goes-to-quickbar"},
		subgroup = "uranium-energy-conversion",
		order = "c-1a",
		stack_size = 5,
		place_result = "reactor-steam-generator-01",
	}
})