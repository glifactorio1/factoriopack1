require("prototypes.equipment-grid")

data.raw["locomotive"]["diesel-locomotive"].equipment_grid = "large-equipment-grid"
data.raw["car"]["car"].equipment_grid = "medium-equipment-grid"
data.raw["car"]["tank"].equipment_grid = "tank-equipment-grid"
data.raw["cargo-wagon"]["cargo-wagon"].equipment_grid = "large-equipment-grid"
