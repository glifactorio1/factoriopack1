require("prototypes.technology")
require("prototypes.style")
require("prototypes.item")
require("prototypes.recipe")