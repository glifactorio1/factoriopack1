data:extend(
{
  {
    type = "recipe",
    name = "elite-solar",
    energy_required = 10,
    enabled = false,
    ingredients =
    {
      {"steel-plate", 25},
      {"advanced-circuit", 15},
      {"advanced-solar", 10}
    },
    result = "elite-solar"
  }
}
)
