data:extend(
{
  {
    type = "recipe",
    name = "advanced-solar",
    energy_required = 10,
    enabled = false,
    ingredients =
    {
      {"steel-plate", 25},
      {"electronic-circuit", 15},
      {"solar-panel", 10}
    },
    result = "advanced-solar"
  }
}
)
