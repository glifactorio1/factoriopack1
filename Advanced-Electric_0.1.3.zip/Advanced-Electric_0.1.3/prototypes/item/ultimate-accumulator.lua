data:extend(
{
  {
    type = "item",
    name = "ultimate-accumulator",
    icon = "__Advanced-Electric__/graphics/ultimate-accumulator/ultimate-accumulator-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy",
    order = "e-b",
    place_result = "ultimate-accumulator",
    stack_size = 50
  }
}
)
