data:extend(
{
  {
    type = "item",
    name = "advanced-solar",
    icon = "__Advanced-Electric__/graphics/advanced-solar/advanced-solar-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy",
    order = "d[solar-panel]-a[solar-panel]",
    place_result = "advanced-solar",
    stack_size = 50
  }
}
)
