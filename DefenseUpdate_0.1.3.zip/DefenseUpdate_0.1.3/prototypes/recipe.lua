data:extend({
  {
    type = "recipe",
    name = "concrete-wall",
	energy_required = 1;
    enabled = false,
    ingredients =
    {
      {"concrete", 10},
	  {"steel-plate", 1},
    },
    result = "concrete-wall",
    requester_paste_multiplier = 10
  }
})
