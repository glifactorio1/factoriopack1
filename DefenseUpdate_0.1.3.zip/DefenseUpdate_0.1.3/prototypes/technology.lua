data:extend(
{
  {
    type = "technology",
    name = "concrete-walls",
    icon = "__DefenseUpdate__/graphics/technology/concrete-walls.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "concrete-wall"
      }
    },
	prerequisites = {"concrete", "gates"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 2},
        {"science-pack-3", 1}
      },
      time = 30
    },
    order = "a-k-a"
  },
  {
    type = "technology",
    name = "laser-turret-damage-7",
    icon = "__base__/graphics/technology/laser-turret-damage.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "laser-turret",
        modifier = "0.5"
      }
    },
    prerequisites = {"laser-turret-damage-6"},
    unit =
    {
      count = 350,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "e-n-f"
  },
  {
    type = "technology",
    name = "laser-turret-damage-8",
    icon = "__base__/graphics/technology/laser-turret-damage.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "laser-turret",
        modifier = "0.6"
      }
    },
    prerequisites = {"laser-turret-damage-7"},
    unit =
    {
      count = 400,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "e-n-f"
  },
  {
    type = "technology",
    name = "gun-turret-damage-7",
    icon = "__base__/graphics/technology/gun-turret-damage.png",
    effects =
    {
      {
        type = "turret-attack",
        turret_id = "gun-turret",
        modifier = "0.5"
      }
    },
    prerequisites = {"gun-turret-damage-6"},
    unit =
    {
      count = 350,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "e-o-f"
  },
  {
    type = "technology",
    name = "gun-turret-damage-8",
    icon = "__base__/graphics/technology/gun-turret-damage.png",
    effects =
    {
      {
        type = "turret-attack",
        turret_id = "gun-turret",
        modifier = "0.6"
      }
    },
    prerequisites = {"gun-turret-damage-7"},
    unit =
    {
      count = 400,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    upgrade = true,
    order = "e-o-f"
  },
  {
    type = "technology",
    name = "flamethrower-damage-7",
    icon = "__base__/graphics/technology/flamethrower-turret-damage.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "flame-thrower",
        modifier = "0.2"
      },
      {
        type = "turret-attack",
        turret_id = "flamethrower-turret",
        modifier = "0.2"
      }
    },
    prerequisites = {"flamethrower-damage-6"},
    unit =
    {
      count = 550,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 80
    },
    upgrade = true,
    order = "e-o-p-f"
  },
  {
    type = "technology",
    name = "flamethrower-damage-8",
    icon = "__base__/graphics/technology/flamethrower-turret-damage.png",
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "flame-thrower",
        modifier = "0.2"
      },
      {
        type = "turret-attack",
        turret_id = "flamethrower-turret",
        modifier = "0.2"
      }
    },
    prerequisites = {"flamethrower-damage-7"},
    unit =
    {
      count = 600,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 80
    },
    upgrade = true,
    order = "e-o-p-f"
  }
})
