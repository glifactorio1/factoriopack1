data:extend({
  {
    type = "item",
    name = "concrete-wall",
    icon = "__DefenseUpdate__/graphics/icons/concrete-wall.png",
    flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
    order = "f",
    place_result = "concrete-wall",
    stack_size = 50
  }
})
