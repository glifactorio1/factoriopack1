data:extend(
{
  {
    type = "recipe",
    name = "tank-wagon",
    enabled = false,
    ingredients =
    {
      {"iron-gear-wheel", 10},
      {"iron-plate", 20},
      {"steel-plate", 10}
    },
    result = "tank-wagon"
  }
})