tank_car = util.table.deepcopy(data.raw["cargo-wagon"]["cargo-wagon"])
tank_car.name = "tank-wagon"
tank_car.icon = "__Tank Wagon__/graphics/icons/tank-wagon.png"
tank_car.inventory_size = 0
tank_car.minable = {mining_time = 1, result = "tank-wagon"}
tank_car.color = {r = 0.5, g = 0.5, b = 0.5, a = 0.75}
tank_car.pictures =
{
  layers =
  {
    {
      priority = "very-low",
      width = 222,
      height = 205,
      back_equals_front = true,
      direction_count = 128,
      filenames =
      {
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-1.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-2.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-3.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-4.png"
      },
      line_length = 4,
      lines_per_file = 8,
      shift = {0, -0.796875}
    },
    {
      flags = { "mask" },
      width = 222,
      height = 205,
      back_equals_front = true,
      apply_runtime_tint = true,
      direction_count = 128,
      filenames =
      {
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-1.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-2.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-3.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-4.png"
      },
      line_length = 4,
      lines_per_file = 8,
      shift = {0, -0.796875}
    },
    {
      flags = { "mask" },
      width = 196,
      height = 174,
      direction_count = 128,
      back_equals_front = true,
      apply_runtime_tint = false,
      shift = {0, -1.125},
      filenames =
      {
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-mask-1.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-mask-2.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-mask-3.png"
      },
      line_length = 4,
      lines_per_file = 11,
    },
    {
      flags = { "compressed" },
      width = 246,
      height = 201,
      back_equals_front = true,
      draw_as_shadow = true,
      direction_count = 128,
      filenames =
      {
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-shadow-1.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-shadow-2.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-shadow-3.png",
        "__base__/graphics/entity/cargo-wagon/cargo-wagon-shadow-4.png"
      },
      line_length = 4,
      lines_per_file = 8,
      shift = {0.8, -0.078125}
    }
  }
}
tank_car.horizontal_doors = nil
tank_car.vertical_doors = nil

dummy_tank = util.table.deepcopy(data.raw["storage-tank"]["storage-tank"])
dummy_tank.name = "tank-wagon-dummy"
dummy_tank.icon = "__core__/graphics/questionmark.png"
dummy_tank.flags = {"placeable-player", "player-creation", "placeable-off-grid"}
dummy_tank.minable = nil
dummy_tank.collision_mask = {"ghost-layer"}
dummy_tank.collision_box = {{-0.55, -0.55}, {0.55, 0.55}}
dummy_tank.selection_box = {{-2.0, -2.0}, {2.0, 2.0}}
dummy_tank.drawing_box = {{0, 0}, {0, 0}}
dummy_tank.fluid_box.base_area = 250
dummy_tank.fluid_box.pipe_covers = nil
dummy_tank.fluid_box.pipe_connections = 
{
  { position = {-0.5, -1.5} },
  { position = {-0.5, 1.5} },
  { position = {0.5, -1.5} },
  { position = {0.5, 1.5} }
}
dummy_tank.pictures =
{
  picture =
  {
    sheet =
    {
      filename = "__core__/graphics/empty.png",
      priority = "extra-high",
      frames = 1,
      width = 1,
      height = 1
    }
  },
}
dummy_tank.pictures.fluid_background = dummy_tank.pictures.picture.sheet
dummy_tank.pictures.window_background = dummy_tank.pictures.picture.sheet
dummy_tank.pictures.flow_sprite = dummy_tank.pictures.picture.sheet
dummy_tank.circuit_wire_max_distance = 0
dummy_tank.order="z"

data:extend(
{
  tank_car,
  dummy_tank
})