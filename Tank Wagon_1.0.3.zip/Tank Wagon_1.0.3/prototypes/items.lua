data:extend(
{
  {
    type = "item",
    name = "tank-wagon",
    icon = "__Tank Wagon__/graphics/icons/tank-wagon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-h[tank-wagon]",
    place_result = "tank-wagon",
    stack_size = 5
  }
})