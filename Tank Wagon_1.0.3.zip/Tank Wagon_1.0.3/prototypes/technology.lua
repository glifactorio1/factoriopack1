data:extend(
{
  {
    type = "technology",
    name = "tank-wagon",
    icon = "__Tank Wagon__/graphics/technology/tank-wagon.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "tank-wagon"
      }
    },
    prerequisites = {"railway", "fluid-handling"},
    unit =
    {
      count = 20,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 1},
      },
      time = 10
    },
    order = "c-g-a",
  }
})