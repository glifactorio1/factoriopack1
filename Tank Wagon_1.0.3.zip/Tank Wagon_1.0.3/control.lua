DEFAULT_COLOUR = {r = 0.5, g = 0.5, b = 0.5}

local function init_global()
  global = global or {}
  global.tankwagons = global.tankwagons or {}
end

script.on_configuration_changed(init_global)
script.on_init(init_global)

function placedTankWagon(entity, player)
  global.tankwagons[entity.unit_number] = {}
  global.tankwagons[entity.unit_number].wagon = entity
  if isGridAligned(entity) then
    placeDummyTank(entity)
  end
  entity.color = DEFAULT_COLOUR
end

function removedTankWagon(entity)
  if global.tankwagons[entity.unit_number].tank then
    removeDummyTank(entity)
  end
  global.tankwagons[entity.unit_number] = nil
end

function isGridAligned(entity)
  return entity.orientation * 4 % 1 == 0
end

function findPumps(entity)
  local x = 2 - (entity.direction / 2 % 2)
  local y = 1 + (entity.direction / 2 % 2)
  local ex, ey = entity.position.x, entity.position.y
  return 0 < entity.surface.count_entities_filtered
  {
    area = {{ex - x, ey - y}, {ex + x, ey + y}},
    type = "pump",
    limit = 1
  }
end

function positionsMatch(p1, p2)
  return p1.x == p2.x and p1.y == p2.y
end

function placeDummyTank(entity)
  global.tankwagons[entity.unit_number].wagon = entity
  global.tankwagons[entity.unit_number].tank
    = global.tankwagons[entity.unit_number].tank or {}
  if global.tankwagons[entity.unit_number].tank.valid
    and not positionsMatch(global.tankwagons[entity.unit_number].tank.position, entity.position) then
    removeDummyTank(entity)
  end
  if not global.tankwagons[entity.unit_number].tank.valid then
    global.tankwagons[entity.unit_number].tank = entity.surface.create_entity
    {
      name = "tank-wagon-dummy",
      position = entity.position,
      force = entity.force,
      direction = entity.orientation * 8 % 8
    }
    global.tankwagons[entity.unit_number].tank.operable = false
    global.tankwagons[entity.unit_number].tank.fluidbox[1]
      = global.tankwagons[entity.unit_number].fluid
    if findPumps(global.tankwagons[entity.unit_number].tank) then
      global.tankwagons[entity.unit_number].tank.direction
        = (global.tankwagons[entity.unit_number].tank.direction + 2) % 8
    end
  else
  end
end

function removeDummyTank(entity)
  if global.tankwagons[entity.unit_number].tank
    and global.tankwagons[entity.unit_number].tank.valid then
    global.tankwagons[entity.unit_number].fluid
      = global.tankwagons[entity.unit_number].tank.fluidbox[1]
    global.tankwagons[entity.unit_number].tank.destroy()
  end
end

function placeDummiesFromTrain(train)
  for i,entity in pairs(train.cargo_wagons) do
    if entity.name == "tank-wagon" then
      placeDummyTank(entity)
    end
  end
end

function removeDummiesFromTrain(train)
  for i,entity in pairs(train.cargo_wagons) do
    if entity.name == "tank-wagon" then
      removeDummyTank(entity)
      updateColor(entity)
    end
  end
end

function updateColor(wagon)
  if global.tankwagons[wagon.unit_number].fluid and
      global.tankwagons[wagon.unit_number].fluid.amount > 0 then
    wagon.color =
        game.fluid_prototypes[global.tankwagons[wagon.unit_number].fluid.type].base_color
  else
    wagon.color = DEFAULT_COLOUR
  end
end

script.on_event(defines.events.on_train_changed_state, function(event)
  if event.train.state == defines.train_state.manual_control then
    if event.train.speed == 0 then
      placeDummiesFromTrain(event.train)
    else
      removeDummiesFromTrain(event.train)
    end
  elseif event.train.state == defines.train_state.wait_station
    or event.train.state == defines.train_state.wait_signal
    or event.train.state == defines.train_state.no_path then
    placeDummiesFromTrain(event.train)
  elseif event.train.state == defines.train_state.on_the_path then
    removeDummiesFromTrain(event.train)
  end
end)

script.on_event(defines.events.on_built_entity, function(event)
  if event.created_entity.name == "tank-wagon" then
    placedTankWagon(event.created_entity, game.players[event.player_index])
  end
end)

script.on_event(defines.events.on_robot_built_entity, function(event)
  if event.created_entity.name == "tank-wagon" then
    placedTankWagon(event.created_entity, event.robot.built_by)
  end
end)

script.on_event(defines.events.on_preplayer_mined_item, function(event)
  if event.entity.name == "tank-wagon" then
    removedTankWagon(event.entity)
  end
end)

script.on_event(defines.events.on_robot_pre_mined, function(event)
  if event.entity.name == "tank-wagon" then
    removedTankWagon(event.entity)
  end
end)

script.on_event(defines.events.on_entity_died, function(event)
  if event.entity.name == "tank-wagon" then
    removedTankWagon(event.entity)
  end
end)

script.on_event(defines.events.on_tick, function(event)
  if event.tick % 60 == 36 then
    for i,t in pairs(global.tankwagons) do
      if t.wagon and t.wagon.valid and t.tank and t.tank.valid then
        if t.tank.fluidbox[1] and t.tank.fluidbox[1].amount > 0 then
          t.wagon.color = game.fluid_prototypes[t.tank.fluidbox[1].type].base_color
        else
          t.wagon.color = DEFAULT_COLOUR
        end
      end
    end
  end
end)