
-- variable of out loop
local techLevel = 99
local techModifier = 0.9
local techModifierDelta = 0.09
local researchCount = 99

-- gun turret damage
techLevel = 6
techModifier = 0.4
techModifierDelta = 0.1
researchCount = 250

for i = 7 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "gun-turret-damage-"..techLevel,
	    icon = "__base__/graphics/technology/gun-turret-damage.png",
	    effects =
	    {
	     {
	        type = "turret-attack",
	        turret_id = "gun-turret",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"gun-turret-damage-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 60
	    },
	    upgrade = true,
	    order = "e-o-f"
	  },
	})
end

-- burret damage
techLevel = 6
techModifier = 0.4
techModifierDelta = 0.1
researchCount = 250

for i = 7 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "bullet-damage-"..techLevel,
	    icon = "__base__/graphics/technology/bullet-damage.png",
	    effects =
	    {
	      {
	        type = "ammo-damage",
	        ammo_category = "bullet",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"bullet-damage-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 60
	    },
	    upgrade = true,
	    order = "e-l-f"
	  },
	})
end



-- burret speed
techLevel = 6
techModifier = 0.4
techModifierDelta = 0.0
researchCount = 250

for i = 7 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "bullet-speed-"..techLevel,
	    icon = "__base__/graphics/technology/bullet-speed.png",
	    effects =
	    {
	      {
	        type = "gun-speed",
	        ammo_category = "bullet",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"bullet-speed-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 60
	    },
	    upgrade = true,
	    order = "e-l-l"
	  },
	})
end

-- laser turret damage
techLevel = 6
techModifier = 0.4
techModifierDelta = 0.1
researchCount = 250

for i = 7 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "laser-turret-damage-"..techLevel,
	    icon = "__base__/graphics/technology/laser-turret-damage.png",
	    effects =
	    {
	      {
	        type = "ammo-damage",
	        ammo_category = "laser-turret",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"laser-turret-damage-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 60
	    },
	    upgrade = true,
	    order = "e-n-f"
	  },
	})
end

-- laser turret speed
techLevel = 6
techModifier = 0.4
techModifierDelta = 0.0
researchCount = 250

for i = 7 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "laser-turret-speed-"..techLevel,
	    icon = "__base__/graphics/technology/laser-turret-speed.png",
	    effects =
	    {
	      {
	        type = "gun-speed",
	        ammo_category = "laser-turret",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"laser-turret-speed-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 60
	    },
	    upgrade = true,
	    order = "e-n-l"
	  },
	})
end


-- combat robot damage
techLevel = 5
techModifier = 0.3
techModifierDelta = 0.05
researchCount = 250

for i = 6 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "combat-robot-damage-"..techLevel,
	    icon = "__base__/graphics/technology/combat-robot-damage.png",
	    effects =
	    {
	      {
	        type = "ammo-damage",
	        ammo_category = "combat-robot-laser",
	        modifier = techModifier
	      },
	      {
	        type = "ammo-damage",
	        ammo_category = "combat-robot-beam",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"combat-robot-damage-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"science-pack-1", 2},
	        {"science-pack-2", 2},
	        {"science-pack-3", 1},
	        {"alien-science-pack", 1},
	      },
	      time = 30
	    },
	    upgrade = true,
	    order = "e-p-g"
	  },
	})
end


-- robots speed
techLevel = 5
techModifier = 0.65
techModifierDelta = 0.1
researchCount = 500

for i = 6 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "worker-robots-speed-"..techLevel,
	    icon = "__base__/graphics/technology/worker-robots-speed.png",
	    effects =
	    {
	      {
	        type = "worker-robot-speed",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"worker-robots-speed-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 60
	    },
	    upgrade = true,
	    order = "c-k-f-e"
		  },
	})
end


-- shotgun damage
techLevel = 6
techModifier = 0.4
techModifierDelta = 0.1
researchCount = 250

for i = 7 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "shotgun-shell-damage-"..techLevel,
	    icon = "__base__/graphics/technology/shotgun-shell-damage.png",
	    effects =
	    {
	      {
	        type = "ammo-damage",
	        ammo_category = "shotgun-shell",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"shotgun-shell-damage-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 60
	    },
	    upgrade = true,
	    order = "e-n-f"
	  },
	})
end


-- shotgun speed
techLevel = 6
techModifier = 0.4
techModifierDelta = 0.0
researchCount = 250

for i = 7 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "shotgun-shell-speed-"..techLevel,
	    icon = "__base__/graphics/technology/shotgun-shell-speed.png",
	    effects =
	    {
	      {
	        type = "gun-speed",
	        ammo_category = "shotgun-shell",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"shotgun-shell-speed-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 60
	    },
	    upgrade = true,
	    order = "e-n-l"
	  },
	})
end


-- flamethrower damage
techLevel = 6
techModifier = 0.2
techModifierDelta = 0.0
researchCount = 500

for i = 7 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "flamethrower-damage-"..techLevel,
	    icon = "__base__/graphics/technology/flamethrower-turret-damage.png",
	    effects =
	    {
	      {
	        type = "ammo-damage",
	        ammo_category = "flame-thrower",
	        modifier = techModifier
	      },
	      {
	        type = "turret-attack",
	        turret_id = "flamethrower-turret",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"flamethrower-damage-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 80
	    },
	    upgrade = true,
	    order = "e-o-p-f"
	  },
	})
end


-- grenade damage
techLevel = 6
techModifier = 0.2
techModifierDelta = 0.0
researchCount = 1000

for i = 7 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "grenade-damage-"..techLevel,
	    icon = "__base__/graphics/technology/grenade-damage.png",
	    effects =
	    {
	      {
	        type = "ammo-damage",
	        ammo_category = "grenade",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"grenade-damage-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1},
	        {"alien-science-pack", 1}
	      },
	      time = 45
	    },
	    upgrade = true,
	    order = "e-n-a"
	  },
	})
end


-- rocket power
techLevel = 5
techModifier = 0.2
techModifierDelta = 0.0
researchCount = 250

for i = 6 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "rocket-damage-"..techLevel,
	    icon = "__base__/graphics/technology/rocket-damage.png",
	    effects =
	    {
	      {
	        type = "ammo-damage",
	        ammo_category = "rocket",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"rocket-damage-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 60
	    },
	    upgrade = true,
	    order = "e-j-e"
	  },
	})
end


-- rocket speed
techLevel = 5
techModifier = 0.4
techModifierDelta = 0.0
researchCount = 250

for i = 6 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "rocket-speed-"..techLevel,
	    icon = "__base__/graphics/technology/rocket-speed.png",
	    effects =
	    {
	      {
	        type = "gun-speed",
	        ammo_category = "rocket",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"rocket-speed-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"alien-science-pack", 1},
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 60
	    },
	    upgrade = true,
	    order = "e-j-j"
	  },
	})
end


-- research speed
techLevel = 4
techModifier = 0.5
techModifierDelta = 0.1
researchCount = 500

for i = 5 , 20 do
	techLevel = techLevel + 1;
	techModifier = techModifier + techModifierDelta
	researchCount = researchCount + researchCount
	
	data:extend({
	  {
	    type = "technology",
	    name = "research-speed-"..techLevel,
	    icon = "__base__/graphics/technology/research-speed.png",
	    effects =
	    {
	      {
	        type = "laboratory-speed",
	        modifier = techModifier
	      }
	    },
	    prerequisites = {"research-speed-"..(techLevel - 1)},
	    unit =
	    {
	      count = researchCount,
	      ingredients =
	      {
	        {"science-pack-1", 1},
	        {"science-pack-2", 1},
	        {"science-pack-3", 1}
	      },
	      time = 30
	    },
	    upgrade = true,
	    order = "c-m-d"
	  },
	})
end



