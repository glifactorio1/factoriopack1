table.insert(
    data.raw["technology"]["railway"]["effects"],
    { type = "unlock-recipe", recipe = "curved-rail" }
)