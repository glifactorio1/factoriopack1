data:extend({
  {
    type = "recipe",
    name = "curved-rail",
    enabled = false,
    ingredients = {{"rail", 4}},
    result = "curved-rail",
  }
})