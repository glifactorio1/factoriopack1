data:extend({
  {
    type = "item",
    name = "curved-rail",
    icon = "__base__/graphics/icons/curved-rail.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-b[curved-rail]",
    place_result = "curved-rail2",
    stack_size = 50,
  }
})