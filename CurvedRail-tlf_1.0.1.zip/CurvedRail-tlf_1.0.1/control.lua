function replace_rail(rail)
	local surface = rail.surface;
	local position = rail.position;
	local direction = rail.direction;
	local force = rail.force;
	local playerbuilt = rail.last_user;
	rail.destroy();
	local newrail = surface.create_entity{name="curved-rail", position=position, direction=direction, force=force};
	if newrail ~= nil then
		newrail.last_user = playerbuilt;
	end
end

function on_script_event(event)
	if event.created_entity.name == "curved-rail2" then
		replace_rail(event.created_entity)
	end
end

script.on_event(defines.events.on_built_entity, on_script_event)
script.on_event(defines.events.on_robot_built_entity, on_script_event)
