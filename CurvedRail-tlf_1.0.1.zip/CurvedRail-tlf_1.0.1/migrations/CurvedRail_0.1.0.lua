for _, force in pairs(game.forces) do
	if force.technologies["railway"].researched then
		force.recipes["curved-rail"].enabled = true
	end
end