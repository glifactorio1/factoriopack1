data:extend(
{
  { 
    type = "autoplace-control",
    name = "uranium-ore",
    richness = true,
    order = "b-e"
  }
})