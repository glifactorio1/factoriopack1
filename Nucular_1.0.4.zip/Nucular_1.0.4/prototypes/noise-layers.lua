data:extend(
{
  {
    type = "noise-layer",
    name = "uranium-ore"
  }
})