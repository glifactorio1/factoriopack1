--
-- Disclaimer: mp warranty void if edited.
--

--y_ammo_plasma=Plasma Capsule
--y_ammo_flame=Blaze-Mixture Canister

return {
  ["ammo-yi-plasma"] = {"y_ammo_plasma"},
  ["ammo-yi-chem"] = {"y_ammo_flame"}
}