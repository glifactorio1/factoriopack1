data.raw["gui-style"].default["no-padding"] =
{
    type = "button_style",
    parent = "button_style",
    top_padding = 0,
    bottom_padding = 0,
    left_padding = 0,
    right_padding = 0,
}
