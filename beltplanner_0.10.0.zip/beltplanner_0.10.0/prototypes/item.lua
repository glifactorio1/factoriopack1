data:extend({
    {
        type = "item",
        name = "beltplanner",
        subgroup = "tool",
        order = "c[automated-construction]-c[beltplanner]",
        icon = "__beltplanner__/graphics/item/beltplanner.png",
        flags = {"goes-to-quickbar"},
        place_result = "beltplanner",
        stack_size = 1,
    },
})
