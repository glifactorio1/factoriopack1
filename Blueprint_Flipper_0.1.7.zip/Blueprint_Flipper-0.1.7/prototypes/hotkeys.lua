data:extend({
  {
    type = "custom-input",
    name = "blueprint_hotkey_flip_horizontal",
    key_sequence = "SHIFT + z",
  },
  {
    type = "custom-input",
    name = "blueprint_hotkey_flip_vertical",
    key_sequence = "SHIFT + x",
  }
})