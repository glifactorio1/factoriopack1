data:extend(
{
-- Burner filter Inserter
  {
    type = "item",
    name = "burner-filter-inserter",
    icon = "__Burner-Filter-Inserter__/graphics/icons/burner-filter-inserter.png",
    flags = {"goes-to-quickbar"},
    subgroup = "inserter",
    order = "c[burner-filter-inserter]",
    place_result = "burner-filter-inserter",
    stack_size = 50
  }
}
)