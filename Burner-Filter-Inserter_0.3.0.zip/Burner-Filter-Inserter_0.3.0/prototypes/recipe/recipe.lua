data:extend(
{
-- ****************************
--  Burner filter Inserter
-- ****************************
  {
    type = "recipe",
    name = "burner-filter-inserter",
    enabled = "true",
    ingredients =
    {
      {"burner-inserter", 1},
      {"electronic-circuit", 1}
    },
    result = "burner-filter-inserter"
  }
}
)