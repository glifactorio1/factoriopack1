require("prototypes.entities.entities")
require("prototypes.items.items")
require("prototypes.recipe.recipe")