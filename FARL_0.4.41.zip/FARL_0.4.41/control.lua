require "defines"
require "Settings"
require "FARL"
require "GUI"

MOD_NAME = "FARL"
debugButton = false
godmode = false
removeStone = true

function resetMetatable(o, mt)
  setmetatable(o,{__index=mt})
  return o
end

function setMetatables()
  for i,farl in pairs(global.farl) do
    farl = resetMetatable(farl, FARL)
  end
  for name, s in pairs(global.players) do
    s = resetMetatable(s,Settings)
  end
end

local function on_tick(event)
  local status, err = pcall(function()
    if global.destroyNextTick[event.tick] then
      local pis = global.destroyNextTick[event.tick]
      for _, pi in pairs(pis) do
        GUI.destroyGui(game.players[pi])
        debugDump("Gui destroyed (on tick)")
      end
      global.destroyNextTick[event.tick] = nil
    end
    for i, farl in pairs(global.farl) do
      if not farl.destroy then
        local status, err = pcall(function()
          farl:update(event)
          if farl.driver and farl.driver.name ~= "farl_player" then
            GUI.updateGui(farl)
          end
        end)
        if not status then
          if farl and farl.active then
            farl:deactivate("Unexpected error: "..err)
          end
          debugDump("Unexpected error: "..err,true)
        end
      else
        if farl.destroy == event.tick then
          farl.destroy = false
          farl.settings = false
        end
      end
    end
  end)
  if not status then
    debugDump("Unexpected error:",true)
    debugDump(err,true)
  end
end

local function init_global()
  global.players =  global.players or {}
  global.savedBlueprints = global.savedBlueprints or {}
  global.farl = global.farl or {}
  global.railInfoLast = global.railInfoLast or {}
  global.electricInstalled = remote.interfaces.dim_trains and remote.interfaces.dim_trains.railCreated
  global.godmode = false
  godmode = global.godmode
  global.destroyNextTick = global.destroyNextTick or {}
  global.version = global.version or "0.4.41"
  setMetatables()
end

local function init_player(player)
  Settings.loadByPlayer(player)
end

local function init_players()
  for i,player in pairs(game.players) do
    init_player(player)
  end
end

local function on_init()
  init_global()
end

local function on_load()
  setMetatables()
  godmode = global.godmode
end

local function on_configuration_changed(data)
  if not data or not data.mod_changes then
    return
  end
  if data.mod_changes[MOD_NAME] then
    local newVersion = data.mod_changes[MOD_NAME].new_version
    local oldVersion = data.mod_changes[MOD_NAME].old_version
    -- mod was added to existing save
    init_global()
    init_players()
    global.electricInstalled = remote.interfaces.dim_trains and remote.interfaces.dim_trains.railCreated
    global.version = "0.4.41"
  end
  if data.mod_changes["5dim_trains"] then
    --5dims_trains was added/updated
    if data.mod_changes["5dim_trains"].new_version then
      global.electricInstalled = remote.interfaces.dim_trains and remote.interfaces.dim_trains.railCreated
    else
      --5dims_trains was removed
      global.electricInstalled = false
    end
  end
  setMetatables()
  for name,s in pairs(global.players) do
    s:checkMods()
  end
end

local function on_player_created(event)
  init_player(game.players[event.player_index])
end

local function on_gui_click(event)
  local status, err = pcall(function()
    local index = event.player_index
    local player = game.players[index]
    if player.gui.left.farl ~= nil then --and player.gui.left.farlAI == nil then
      local farl = FARL.findByPlayer(player)
      if farl then
        GUI.onGuiClick(event, farl, player)
      else
        player.print("Gui without train, wrooong!")
        GUI.destroyGui(player)
      end
    end
  end)
  if not status then
    debugDump("Unexpected error:",true)
    debugDump(err,true)
  end
end

function on_preplayer_mined_item(event)
  local ent = event.entity
  local cname = ent.name
  if ent.type == "locomotive" and cname == "farl" then
    for i=1,#global.farl do
      if global.farl[i].name == ent.backer_name then
        global.farl[i].delete = true
      end
    end
  end
end

function on_player_mined_item(event)
  if event.item_stack.name == "farl" then
    for i=#global.farl,1,-1 do
      if global.farl[i].delete then
        table.remove(global.farl, i)
      end
    end
  end
end

function on_entity_died(event)
  local ent = event.entity
  if ent.type == "locomotive" and ent.name == "farl" then
    local i = FARL.findByLocomotive(event.entity)
    if i then
      table.remove(global.farl, i)
    end
  end
end

function on_player_driving_changed_state(event)
  local player = game.players[event.player_index]
  if (player.vehicle ~= nil and player.vehicle.name == "farl") then
    if player.gui.left.farl == nil then
      FARL.onPlayerEnter(player)
      GUI.createGui(player)
    end
  end
  if player.vehicle == nil and player.gui.left.farl ~= nil then
    FARL.onPlayerLeave(player, event.tick + 5)
    debugDump("onPlayerLeave (driving state changed)")
    local tick = event.tick + 5
    if not global.destroyNextTick[tick] then
      global.destroyNextTick[tick] = {}
    end
    table.insert(global.destroyNextTick[tick], event.player_index)
  end
end

function debugDump(var, force)
  if false or force then
    for i,player in ipairs(game.players) do
      local msg
      if type(var) == "string" then
        msg = var
      else
        msg = serpent.dump(var, {name="var", comment=false, sparse=false, sortkeys=true})
      end
      player.print(msg)
    end
  end
end

function saveVar(var, name)
  local var = var or global
  local n = name or ""
  game.write_file("farl/farl"..n..".lua", serpent.block(var, {name="glob"}))
end

script.on_init(on_init)
script.on_load(on_load)
script.on_configuration_changed(on_configuration_changed)
script.on_event(defines.events.on_player_created, on_player_created)

script.on_event(defines.events.on_tick, on_tick)
script.on_event(defines.events.on_gui_click, on_gui_click)
--script.on_event(defines.events.on_train_changed_state, ontrainchangedstate)
script.on_event(defines.events.on_player_mined_item, on_player_mined_item)
script.on_event(defines.events.on_preplayer_mined_item, on_preplayer_mined_item)
--script.on_event(defines.events.on_built_entity, onbuiltentity)
script.on_event(defines.events.on_entity_died, on_entity_died)
script.on_event(defines.events.on_player_driving_changed_state, on_player_driving_changed_state)

--  driverNextDir = 1
--
--  function setGhostDriver(locomotive)
--    local ghost = newGhostDriverEntity(game.player.position)
--    locomotive.passenger = ghost
--    return ghost
--  end
--
--  function newGhostDriverEntity(position)
--    game.createentity({name="farl_player", position=position, force=game.forces.player})
--    local entities = game.findentitiesfiltered({area={{position.x, position.y},{position.x, position.y}}, name="farl_player"})
--    if entities[1] ~= nil then
--      return entities[1]
--    end
--  end

remote.add_interface("farl",
  {
    railInfo = function(rail)
      debugDump(rail.name.."@"..pos2Str(rail.position).." dir:"..rail.direction,true)
      if type(global.railInfoLast) == "table" and global.railInfoLast.valid then
        local pos = global.railInfoLast.position
        local diff={x=rail.position.x-pos.x, y=rail.position.y-pos.y}
        debugDump("Offset from last: x="..diff.x..",y="..diff.y,true)
        debugDump("Distance (util): "..util.distance(pos, rail.position),true)
        if AStar then
          local max = AStar.heuristic(global.railInfoLast, rail)
          debugDump("Distance (heuristic): "..max, true)
        end
        global.railInfoLast = false
      else
        global.railInfoLast = rail
      end
    end,
    --/c remote.call("farl", "debugInfo")
    debugInfo = function()
      saveVar(global, "console")
      --saveVar(global.debug, "RailDebug")
    end,
    reset = function()
      global.farl = {}
      if game.forces.player.technologies["rail-signals"].researched then
        game.forces.player.recipes["farl"].enabled = true
      end
      for i,p in ipairs(game.players) do
        if p.gui.left.farl then p.gui.left.farl.destroy() end
        if p.gui.top.farl then p.gui.top.farl.destroy() end
      end
      init_global()
    end,

    setCurvedWeight = function(weight, player)
      local w = tonumber(weight) or 4
      local s = Settings.loadByPlayer(player)
      s.curvedWeight = weight
    end,

    godmode = function(bool)
      global.godmode = bool
      godmode = bool
    end,

    setSpeed = function(speed)
      for name, s in pairs(global.players) do
        s.cruiseSpeed = speed
      end
    end,

    tileAt = function(x,y)
      debugDump(game.get_tile(x, y).name,true)
    end,

    quickstart = function()
      local items = {"farl", "curved-rail", "straight-rail", "medium-electric-pole", "big-electric-pole",
        "small-lamp", "solid-fuel", "rail-signal", "blueprint", "cargo-wagon"}
      local count = {5,50,50,50,50,50,50,50,10,5}
      for i=1,#items do
        game.player.insert{name=items[i], count=count[i]}
      end
    end,
    quickstart2 = function()
      local items = {"power-armor-mk2", "personal-roboport-equipment", "fusion-reactor-equipment",
        "blueprint", "deconstruction-planner", "construction-robot", "basic-exoskeleton-equipment"}
      local count = {1,5,3,1,1,50,2}
      for i=1,#items do
        game.player.insert{name=items[i], count=count[i]}
      end
    end,

    quickstartElectric = function()
      local items = {"farl", "curved-power-rail", "straight-power-rail", "medium-electric-pole", "big-electric-pole",
        "small-lamp", "solid-fuel", "rail-signal", "blueprint", "electric-locomotive", "solar-panel", "basic-accumulator"}
      local count = {5,50,50,50,50,50,50,50,10,2,50,50}
      for i=1,#items do
        game.player.insert{name=items[i], count=count[i]}
      end
    end,

    wagons = function()
      for i,w in ipairs(game.player.selected.train.carriages) do
        debugDump({i=i,type=w.type},true)
      end
    end,

    setBoundingBox = function(type, corner, x,y, player)
      local player = player
      if not player then player = game.players[1] end
      local psettings = Settings.loadByPlayer(player)
      if psettings then
        local bb = psettings.boundingBoxOffsets[type][corner]
        local x = x and x or bb.x
        local y = y and y or bb.y
        psettings.boundingBoxOffsets[type][corner] = {x=x,y=y}
      end
    end,
  })
