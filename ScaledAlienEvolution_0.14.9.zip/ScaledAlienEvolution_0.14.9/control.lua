require "config"

script.on_event(defines.events.on_tick, function(event)

	if global.maxlevel then
		return
	end
	
	if event.tick % 60 == 0 then

		-- limitation has never been calculated
		if not global.evolution_limit then
			calculateEvolutionLimit()
		end
		
		-- apply the limitation
		if game.evolution_factor > global.evolution_limit then
			game.evolution_factor = global.evolution_limit
		end
		
	end
	
end)

script.on_event(defines.events.on_player_joined_game, function(event)
	
	calculateEvolutionLimit()
	
end)

script.on_event(defines.events.on_player_left_game, function(event)

	calculateEvolutionLimit()
	
end)

script.on_event(defines.events.on_research_finished, function(event)

	calculateEvolutionLimit()
	
end)

function calculateEvolutionLimit()

	local limit
	local limitMin
	local nbTechsReached = 0

	calculateSciencePacklevel()
	calculateMaxLevel()
	
	oldEvolution_limit = global.evolution_limit
	
	if not global.maxlevel then
	
		global.researchedTechPoints = 0.0
		global.totalTechPoints = 0.0
		global.evolution_limit = 0.0
		
		for playerName, player in pairs(game.players) do
			for techName, tech in pairs(player.force.technologies) do
				local techPoints = 1.0
				techPoints = getTechPoints(tech)
				if techPoints == nil then 
					techPoints = 1.0
				end
				global.totalTechPoints = global.totalTechPoints + techPoints
				if tech.researched then
					nbTechsReached = nbTechsReached + 1
					global.researchedTechPoints = global.researchedTechPoints + techPoints
				end
			end
		end
		
		limitMin = nbTechsReached * (minlimitationincreaseperresearchmade/100)
		limit = global.researchedTechPoints / global.totalTechPoints
		if limit < limitMin then
			limit = limitMin
		end
		if limit < global.sciencepacklevel then
			limit = global.sciencepacklevel
		end 
		if limit > 1 then
			limit = 1
		end
		
		global.evolution_limit = limit
		
	else
	
		global.evolution_limit = 1
	
	end
	
	if displaylimit==true and (oldEvolution_limit ~= global.evolution_limit) then
		for name, player in pairs(game.players) do
			player.print("Scaled alien evolution : game evolution factor is now currently limited to " .. round(global.evolution_limit*100, 1) .. "%" )
		end
	end
	
end

function calculateSciencePacklevel()

	local nbSciencePackRecipes = 0
	local nbEnabledSciencePackRecipes = 0
	local stepValue
	
	global.sciencepacklevel = 0
	for playerName, player in pairs(game.players) do
		for recipeName, recipe in pairs(player.force.recipes) do
			if string.match(recipeName, "science%-pack") then
				nbSciencePackRecipes = nbSciencePackRecipes + 1
				if (recipe.enabled) then
					nbEnabledSciencePackRecipes = nbEnabledSciencePackRecipes + 1
				end
			end
		end
	end
	if nbSciencePackRecipes == 0 then
		global.sciencepacklevel = 0 -- can't do much if all science packs are removed from the game
	else
		stepValue = 1 / (nbSciencePackRecipes+1)
		global.sciencepacklevel = nbEnabledSciencePackRecipes * stepValue
		-- but first two steps can't be > 10% and > 20 %
		if (nbEnabledSciencePackRecipes == 1) and (global.sciencepacklevel > 0.1) then
			global.sciencepacklevel = 0.1
		elseif (nbEnabledSciencePackRecipes == 2) and (global.sciencepacklevel > 0.2) then
			global.sciencepacklevel = 0.2
		end
	end
	
end

function getTechPoints(tech)

	local techPoints = 1.0
	
	if tech.name then
		if string.match(tech.name, "armor") or string.match(tech.name, "wall") or string.match(tech.name, "turret") or string.match(tech.name, "radar") or string.match(tech.name, "mine") or string.match(tech.name, "gate") or string.match(tech.name, "flame") or string.match(tech.name, "grenade") or string.match(tech.name, "laser") or string.match(tech.name, "tank") or string.match(tech.name, "combat") or string.match(tech.name, "shotgun") or string.match(tech.name, "equipment") or string.match(tech.name, "personal") or string.match(tech.name, "portable") or string.match(tech.name, "follower") or string.match(tech.name, "rocket") or string.match(tech.name, "defense") or string.match(tech.name, "bomb") or string.match(tech.name, "bullet") or string.match(tech.name, "destroyer") or string.match(tech.name, "defender") or string.match(tech.name, "distractor") or string.match(tech.name, "magazine") or isDerivedFromMilitary(tech) then
			techPoints = techPoints * militaryweight
		end
	end
	
	return techPoints
	
end

function isDerivedFromMilitary(tech)
	local derivedFromMilitary = false
	for name, subTech in pairs(tech.prerequisites) do
		derivedFromMilitary = derivedFromMilitary  or isDerivedFromMilitary(subTech)
		if derivedFromMilitary then
			break
		end
	end
	return derivedFromMilitary or string.match(tech.name, "military") 
end

script.on_configuration_changed(function(data)

	-- displaylimit
	-- nothing to do

	-- stopanylimitationwhenrocketsilo
	-- militaryweight
	-- minlimitationincreaseperresearchmade
	-- re-calculation
	
	calculateEvolutionLimit()
	
 end)

function calculateMaxLevel()
	global.maxlevel = (hasResearchedMissileSilo() and stopanylimitationwhenrocketsilo)
end
 
function hasResearchedMissileSilo()
  for playerName, player in pairs(game.players) do
		for techName, tech in pairs(player.force.technologies) do
			if techName == "rocket-silo" then
				if tech.researched then
					return true
				end
			end
		end
	end
	return false
end

function round(num, idp)
  return tonumber(string.format("%." .. (idp or 0) .. "f", num))
end
	
