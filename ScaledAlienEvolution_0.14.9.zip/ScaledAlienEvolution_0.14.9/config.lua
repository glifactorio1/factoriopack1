--[[ welcome to the configuration file for Scaled Alien Evolution
accepted values are both decimal or integers (examples 55, 10.5) 
or for booleans they must be true or false
thanks for reporting any bug or strange or undesired behavior at
https://forums.factorio.com/viewtopic.php?f=94&t=34318&p=215716#p215716
]]

--[[ displaylimit
If set to true, will shout at the players the limit for the biter evolution when the limitation value has changed.
false is default
]]
displaylimit=true

--[[ militaryweight 
The weight of military researchs in the calculated progression.
Must be > 0
e.g. 1 is normal, 0.5 will divide the weight by 2, 20 will make their weight twenty times greater
20 is default
]]
militaryweight=20

--[[ minlimitationincreaseperresearchmade
Minimum increase of the limitation for each tehnology researched.
Set to 0 to ignore this.
(value is in %, must be >= 0 and <= 100). 
Default is 0.1
]]
minlimitationincreaseperresearchmade=0.1

--[[ stopanylimitationwhenrocketsilo
The mod will stop to apply any limitation if you have researched the rocket silo
true is default
]]
stopanylimitationwhenrocketsilo=true


