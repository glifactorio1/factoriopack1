
-- Item
data:extend({
	{
		type = "item",
		name = "belt-sorter-everythingelse",
		order = "z[belt-sprter-everythingelse]",
		icon = "__beltSorter__/graphics/icons/belt-sorter-everythingelse.png",
		stack_size = 1,
		flags = {"goes-to-main-inventory", "hidden"}
	}
})