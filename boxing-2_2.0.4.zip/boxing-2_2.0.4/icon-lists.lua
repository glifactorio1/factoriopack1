boxing["icon-lists"] = {
	"icon-lists/Bio_Industries.lua",
	"icon-lists/CharcoalBurner.lua",
	"icon-lists/Natural_Evolution_Buildings.lua",
	"icon-lists/StickyNotes.lua",
	"icon-lists/base.lua",
	"icon-lists/bobelectronics.lua",
	"icon-lists/bobenemies.lua",
	"icon-lists/bobgreenhouse.lua",
	"icon-lists/boblogistics.lua",
	"icon-lists/bobores.lua",
	"icon-lists/bobplates.lua",
	"icon-lists/bobwarfare.lua",
};
