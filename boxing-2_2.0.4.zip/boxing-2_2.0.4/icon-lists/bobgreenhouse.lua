boxing.icons["bobgreenhouse"] = {
	["graphics/icons/fertiliser.png"] = true,
	["graphics/icons/seedling.png"] = true,
};
