boxing.icons["Natural_Evolution_Buildings"] = {
	["graphics/icons/Building_Materials.png"] = true,
};
