boxing.icons["Bio_Industries"] = {
	["graphics/icons/Clean_Air2.png"] = true,
	["graphics/icons/Seedling.png"] = true,
	["graphics/icons/Woodpulp_32.png"] = true,
	["graphics/icons/advanced_fertiliser_32.png"] = true,
	["graphics/icons/ash.png"] = true,
	["graphics/icons/charcoal.png"] = true,
	["graphics/icons/coke-coal.png"] = true,
	["graphics/icons/crushed-stone.png"] = true,
	["graphics/icons/fertiliser_32.png"] = true,
};
