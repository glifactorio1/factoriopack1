boxing.icons["StickyNotes"] = {
	["graphics/sign-icon.png"] = true,
	["graphics/sticky-note.png"] = true,
};
