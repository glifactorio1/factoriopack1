boxing.icons["bobwarfare"] = {
	["graphics/icons/gun-cotton.png"] = true,
	["graphics/icons/petroleum-jelly.png"] = true,
	["graphics/icons/robot-brain-combat-2.png"] = true,
	["graphics/icons/robot-brain-combat-3.png"] = true,
	["graphics/icons/robot-brain-combat-4.png"] = true,
	["graphics/icons/robot-brain-combat.png"] = true,
	["graphics/icons/robot-tool-combat.png"] = true,
	["graphics/icons/rocket-engine.png"] = true,
};
