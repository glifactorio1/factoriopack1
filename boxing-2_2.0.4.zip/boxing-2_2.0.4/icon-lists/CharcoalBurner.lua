boxing.icons["CharcoalBurner"] = {
	["graphics/icons/charcoal-preparate.png"] = true,
};
