local NE = NEConfig
--[[---------------------------------------------------------------------------
------------------------------------- Credits ---------------------------------
-------------------------------------------------------------------------------

L0771 - For his help given to me to start this MOD.
AlyxDeLunar - For his MOD Dynamic Expansion that I�ve used in my MOD.
Albatrosv13 - For his MOD Alien Temple that I�ve used in my MOD.
FreeER - For his MOD Mind Control that I�ve used in my MOD.
Darkshadow1809  - For his Evolution MOD .
Rsending91, DOSorDIE and SpeedyBrain - Item/Corpse Collector Mod.
ThaPear, Semvoz,  Billw, Adil, Rseding91, Orzelek & Chlue - Coding help!
DySoch - DyTech and Bobingabout - Bob's Mods - Learned a lot from looking at your amazing work. 
YuokiTani - Art!!  


---------------------------------------------------------------------------
---------------------------------------------------------------------------
------------------------ On / Off Toggles ---------------------------------
---------------------------------------------------------------------------
--- true = On / Yes
--- false = Off / No
---------------------------------------------------------------------------]]

NE.ExtraLoot = true --Extra Loot from Aliens (small-alien-artifact)


NE.Set_Difficulty = 2
-- Affects difficulty factor
-- Options: 
--			1 = Normal
--			2 = Hard
-- Hard is about a 2x factor on everything


NE.Spawners = true 
-- Changes to the games Spawners and Units
-- Do you want tweaks made to the spawners - Mainly more units around the spawners 
-- More units around the spawners 
-- Vanilla Spawners will be higher than currently.
-- Bob's be higher and will be be adjusted to match DyTech's it you're playing with DyTech
-- Currently not adjusting DyTech, until tested a little more 
-- Do you want tweaks made to the games biter & spitters
-- Lower Pollution levels before attacking.
-- New Enemy Units
-- Adjusted Resistances of units


----------------------------- END -------------------------------------------

NE.QCCode = false
-- Used for QC
-- Displays messages used for checking my code



