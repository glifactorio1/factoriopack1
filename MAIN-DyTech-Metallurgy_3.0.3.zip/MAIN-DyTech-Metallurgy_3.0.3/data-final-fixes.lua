require "config"

-- Base edit --
require("prototypes.base-edit.base-edit")

-- Adding gears to teach --
AddRecipeToTech("steel-processing", "bronze-gear-wheel2")
AddRecipeToTech("steel-processing", "brass-gear-wheel2")