data:extend(
{
  {
    type = "noise-layer",
    name = "bauxite-ore"
  },
  {
    type = "noise-layer",
    name = "tin-ore"
  },
  {
    type = "noise-layer",
    name = "zinc-ore"
  },
  {
    type = "noise-layer",
    name = "lead-ore"
  },
  {
    type = "noise-layer",
    name = "silver-ore"
  },
  {
    type = "noise-layer",
    name = "gold-ore"
  },
  {
    type = "noise-layer",
    name = "tungsten-ore"
  },
  {
    type = "noise-layer",
    name = "rutile-ore"
  },
  {
    type = "noise-layer",
    name = "cobalt-ore"
  },
  {
    type = "noise-layer",
    name = "chromite-ore"
  },
  {
    type = "noise-layer",
    name = "lava"
  },
  {
    type = "noise-layer",
    name = "metallurgy-ores"
  },
}
)