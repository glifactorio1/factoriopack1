data:extend(
{
  {
    type = "autoplace-control",
    name = "magma",
    richness = true,
    order = "m"
  },
  {
    type = "autoplace-control",
    name = "tin-ore",
    richness = true,
    order = "m-o"
  },
  {
    type = "autoplace-control",
    name = "silver-ore",
    richness = true,
    order = "m-o"
  },
  {
    type = "autoplace-control",
    name = "lead-ore",
    richness = true,
    order = "m-o"
  },
  {
    type = "autoplace-control",
    name = "bauxite-ore",
    richness = true,
    order = "m-o"
  },
  {
    type = "autoplace-control",
    name = "gold-ore",
    richness = true,
    order = "m-o"
  },
  {
    type = "autoplace-control",
    name = "tungsten-ore",
    richness = true,
    order = "m-o"
  },
  {
    type = "autoplace-control",
    name = "zinc-ore",
    richness = true,
    order = "m-o"
  },
  {
    type = "autoplace-control",
    name = "cobalt-ore",
    richness = true,
    order = "m-o"
  },
  {
    type = "autoplace-control",
    name = "rutile-ore",
    richness = true,
    order = "m-o"
  },
  {
    type = "autoplace-control",
    name = "chromite-ore",
    richness = true,
    order = "m-o"
  },
  
}
)
