data:extend(
{
  {
    type = "recipe",
    name = "metallurgy-mold-machine",
    enabled = false,
    ingredients =
    {
      {"forge", 1},
      {"assembling-machine-3", 1}
    },
    result = "metallurgy-mold-machine"
  },
}
)