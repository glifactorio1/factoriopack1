data:extend(
{
  {
    type = "item",
    name = "metallurgy-mold-machine",
    icon = "__MAIN-DyTech-Metallurgy__/graphics/icons/molds/mold-gear-machine.png",
    flags = {"goes-to-quickbar"},
    subgroup = "metallurgy-machines",
    order = "metallurgy-mold-machine",
    place_result = "metallurgy-mold-machine",
    stack_size = 20
  },
}
)