require("scripts/tools-database")
ToolsDatabase.CreateModularTools()
