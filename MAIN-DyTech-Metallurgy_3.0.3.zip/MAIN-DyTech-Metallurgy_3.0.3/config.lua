Config = {} -- DONT TOCUH THIS!

--[[ Do you want to have a tier of blister steel? ]]--
Config.BlisterSteel = false

--[[ Chance that a mold is returned (1 is guaranteed, 0 is lost on use, 0.5 is 50% chance) ]]--
Config.MoldBreakChance = 0.99

