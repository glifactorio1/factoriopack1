--Define if module is installed
modules = true --Default: True