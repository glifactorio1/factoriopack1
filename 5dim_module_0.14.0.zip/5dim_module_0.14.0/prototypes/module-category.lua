data:extend(
{
  {
    type = "module-category",
    name = "pollution"
  }
}
)
