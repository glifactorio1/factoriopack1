--gui main call
script.on_event(defines.events.on_player_created, function(event)
	gui_main_create(event.player_index)
end)
script.on_event(defines.events.on_player_joined_game, function(event)
	gui_main_create(event.player_index)
end)
script.on_init(function()
	for a,b in pairs(game.players) do
		gui_main_create(a)
	end
end)
--gui main create
function gui_main_create(a)
	local g=game.players[a].gui.left
	if global.list==nil then global.list={} end
	if g.main==nil then
		global.list[a]=0
		g.add{type="frame",name="main",style="outer_frame_style",direction="vertical"}
		g.main.add{type="button",name="button",style="ac_button",tooltip={"ac.button"}}
		g.main.add{type="frame",name="list",direction="horizontal"}
		g.main.list.style.visible=false
		g.main.list.add{type="table",name="table",colspan=12}
		gui_element_create(a)
	end
end
--gui element create
function gui_element_create(a)
	local g=game.players[a].gui.left.main.list.table
	global.list[a]=global.list[a]+1
	g.add{type="sprite-button",name="item-"..global.list[a],style="side_menu_button_style",tooltip="click with the item what you want to craft"}
	g.add{type="textfield",name="amount-"..global.list[a],text=0,tooltip="type only number"}
	g["amount-"..global.list[a]].style.minimal_width=50
	g["amount-"..global.list[a]].style.maximal_width=50
	g.add{type="button",name="ok-"..global.list[a],caption="ok",tooltip="apply"}
	g["ok-"..global.list[a]].style.maximal_height=24
	g["ok-"..global.list[a]].style.font="default-small"
	g["ok-"..global.list[a]].style.top_padding=0
	g.add{type="checkbox",name="remove-"..global.list[a],state=false,tooltip="check to remove"}
end
--gui click
script.on_event(defines.events.on_gui_click, function(event)
	local e=event.element
	local a=event.player_index
	local b=game.players[a]
	local g=b.gui.left.main
	if e==g.button then
		if g.list.style.visible then g.list.style.visible=false
		else g.list.style.visible=true
		end
	elseif e.parent==g.list.table then
		local name=string.sub(e.name,1,2)
		local num=tonumber(string.sub(e.name,string.find(e.name,"-")+1,string.len(e.name)))
		if name=="it" and b.cursor_stack.valid_for_read then
			e.sprite="item/"..b.cursor_stack.name
			e.tooltip=game.item_prototypes[b.cursor_stack.name].localised_name
			if global.list[a]==num then
				gui_element_create(a)
			end
		elseif name=="ok" then
			if tonumber(g.list.table["amount-"..num].text) then
				g.list.table["amount-"..num].text=tonumber(g.list.table["amount-"..num].text)
			else g.list.table["amount-"..num].text=0
			end
			g.list.table["amount-"..num].style.minimal_width=50
			g.list.table["amount-"..num].style.maximal_width=50
		end
	end
end)
script.on_event(defines.events.on_gui_text_changed, function(event)
	local e=event.element
	local a=event.player_index
	local b=game.players[a]
	local g=b.gui.left.main.list.table
	if e.parent==g and string.sub(e.name,1,2)=="am" then
		if tonumber(e.text)==nil then e.text=string.gsub(e.text,"%D","") end
		if tonumber(e.text)==nil then e.text=0 end
	end
end)
--gui remove
script.on_event(defines.events.on_gui_checked_state_changed, function(event)
	local e=event.element
	local a=event.player_index
	local b=game.players[a]
	local g=b.gui.left.main
	if e.parent==g.list.table and string.sub(e.name,1,2)=="re" then
		local num=tonumber(string.sub(e.name,string.find(e.name,"-")+1,string.len(e.name)))
		if #g.list.table["item-"..num].sprite>0 then
			g.list.table["item-"..num].destroy()
			g.list.table["amount-"..num].destroy()
			g.list.table["ok-"..num].destroy()
			g.list.table["remove-"..num].destroy()
			if #g.list.table.children_names==0 then gui_element_create(a) end	
		else e.state=false
		end
	end
end)
--craft call
script.on_event(defines.events.on_player_quickbar_inventory_changed, function(event)
	craft_start(event.player_index)
end)
script.on_event(defines.events.on_player_main_inventory_changed, function(event)
	craft_start(event.player_index)
end)
--craft start
function craft_start(a)
	local b=game.players[a]
	local g=b.gui.left.main.list.table
	if b.character and b.crafting_queue_size==0 and #g.children_names>4 then
		local done=0
		for c,d in pairs(g.children_names) do
			local name=string.sub(d,1,2)
			if name=="it" then
				local num=tonumber(string.sub(d,string.find(d,"-")+1,string.len(d)))
				name="item-"..num
				if #g[name].sprite>0 then
					item=string.sub(g[name].sprite,string.find(g[name].sprite,"/")+1,string.len(g[name].sprite))
					if b.character.get_item_count(item)<tonumber(g["amount-"..num].text) then
						if b.force.recipes[item] then
							done=b.begin_crafting{count=1,recipe=item,silent=true}
						end
						if done==0 then 
							g[name].style="red_circuit_network_content_slot_style"
						elseif done>0 then 
							g[name].style="slot_button_style"
							break
						end
					elseif b.character.get_item_count(item)>=tonumber(g["amount-"..num].text) then
						g[name].style="green_circuit_network_content_slot_style"
					end
				end
			end
		end
	end
end
--on tick
script.on_event(defines.events.on_tick, function(event)
	if event.tick%60==29 then
		for a,b in pairs(game.players) do
			craft_start(a)
		end
	end
end)