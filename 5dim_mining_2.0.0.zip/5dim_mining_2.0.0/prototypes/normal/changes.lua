data.raw.item["basic-mining-drill"].subgroup = "mining-speed"
data.raw.item["basic-mining-drill"].order = "b"
data.raw.item["basic-mining-drill"].fast_replaceable_group = "mining-drill";
data.raw.item["pumpjack"].subgroup = "mining-liquid"
data.raw.item["pumpjack"].order = "a"
data.raw.item["burner-mining-drill"].subgroup = "mining-speed"
data.raw.item["burner-mining-drill"].order = "a"