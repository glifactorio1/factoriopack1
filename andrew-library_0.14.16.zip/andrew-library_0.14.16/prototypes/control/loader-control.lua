
function Clean_Loaders()
  for Z,F in pairs(global.loaders) do
	if F[1].valid==false or F[2].valid==false or 
	(F[2].train.state~=7 and F[2].train.state~=9) or F[2].train.speed~=0 then
	  table.remove(global.loaders,Z)			
	  Clean_Loaders()
	  break
	end
  end
end

function Find_Loader(P,E_C_E)
  local P_S_F = P.surface.find_entities_filtered
  local P_P_X = P.position.x
  local P_P_Y = P.position.y
  if (P.train.state==7 or P.train.state==9) and P.train.speed==0 then
	if P.orientation==0 or P.orientation==0.5 then	
	  for j,loader in pairs(P_S_F{type="loader",area={
	  {P_P_X-1.5,P_P_Y-2.2},{P_P_X-0.5,P_P_Y+2.2}}}) do
		if E_C_E and loader==E_C_E then
		  table.insert(global.loaders,{loader,P,6})
		elseif E_C_E==nil then
		  table.insert(global.loaders,{loader,P,6})
		end
      end
	  for j,loader in pairs(P_S_F{type="loader",area={
	  {P_P_X+0.5,P_P_Y-2.2},{P_P_X+1.5,P_P_Y+2.2}}}) do
		if E_C_E and loader==E_C_E then
		  table.insert(global.loaders,{loader,P,2})
		elseif E_C_E==nil then
		  table.insert(global.loaders,{loader,P,2})
		end
   	  end					
	elseif P.orientation==0.25 or P.orientation==0.75 then
	  for j,loader in pairs(P_S_F{type="loader",area={
	  {P_P_X-2.2,P_P_Y-1.5},{P_P_X+2.2,P_P_Y-0.5}}}) do
		if E_C_E and loader==E_C_E then
		  table.insert(global.loaders,{loader,P,0})
		elseif E_C_E==nil then
		  table.insert(global.loaders,{loader,P,0})
		end
  	  end
	  for j,loader in pairs(P_S_F{type="loader",area={
	  {P_P_X-2.2,P_P_Y+0.5},{P_P_X+2.2,P_P_Y+1.5}}}) do
		if E_C_E and loader==E_C_E then
		  table.insert(global.loaders,{loader,P,4})
		elseif E_C_E==nil then
		  table.insert(global.loaders,{loader,P,4})
		end
  	  end					
	end		
  end
end

script.on_event(defines.events.on_train_changed_state, function(event)
	for Z,P in pairs(event.train.cargo_wagons) do
		Find_Loader(P)
	end		
end)

script.on_event(defines.events.on_built_entity, function(event)
  local E_C_E=event.created_entity
  local E_S_F = E_C_E.surface.find_entities_filtered
  local E_P_X = E_C_E.position.x
  local E_P_Y = E_C_E.position.y
  if E_C_E.type=="loader" then
	local P=E_S_F{type="cargo-wagon",area={{E_P_X-2,E_P_Y-2},{E_P_X+2,E_P_Y+2}}}
	for a,Q in pairs(P) do
	  Find_Loader(Q,E_C_E)
	end
  elseif E_C_E.type=="cargo-wagon" then
	Find_Loader(E_C_E)
  end
end)

script.on_event(defines.events.on_tick, function(event)
  if global.loaders==nil then
	global.loaders={}
	for a,Q in pairs(game.surfaces) do
	  local wagon=Q.find_entities_filtered{type="cargo-wagon"}
	  if #wagon>0 then
		for Z,P in pairs(wagon) do
		  Find_Loader(P)
		end
	  end
	end			
  elseif #global.loaders>0 then
	Clean_Loaders()
	for Z,F in pairs(global.loaders) do
	  loader_work(F[1],F[2].get_inventory(defines.inventory.cargo_wagon),F[3])
	end
  end
end)

function Active_Loader(E_C_E,direction)
  local E_L_T = E_C_E.loader_type
  local E_D = E_C_E.direction
  if E_L_T =="output" and E_D==direction then
	return true
  elseif E_L_T =="input" and E_D==(direction+4)%8 then
	return true
  else return false
  end
end

function loader_work(E_C_E,P,direction)
  local E_G_T = E_C_E.get_transport_line
  if E_C_E.loader_type=="output" and Active_Loader(E_C_E,direction) then
	if P.is_empty()==false and E_G_T(1).can_insert_at_back() then
	  if Filter_Loader(E_C_E) then
		local done=false
		for name,count in pairs(P.get_contents()) do	
		  if done then break end
		  for Y,F in pairs(Filter_Loader(E_C_E)) do
			if name==F then
			  P.remove({name=name,count=1})
			  E_G_T(1).insert_at_back({name=name,count=1})
			  done=true break
			end
		  end
		end
  	  else
		for name,count in pairs(P.get_contents()) do
		  P.remove({name=name,count=1})
		  E_G_T(1).insert_at_back({name=name,count=1})
		  break
		end
	  end
	end
	if P.is_empty()==false and E_G_T(2).can_insert_at_back() then
	  if Filter_Loader(E_C_E) then
		local done=false
		for name,count in pairs(P.get_contents()) do	
  		  if done then break end
			for Y,F in pairs(Filter_Loader(E_C_E)) do
			  if name==F then
				P.remove({name=name,count=1})
				E_G_T(2).insert_at_back({name=name,count=1})
				done=true break
			  end
			end
		  end
		else
		  for name,count in pairs(P.get_contents()) do
			P.remove({name=name,count=1})
			E_G_T(2).insert_at_back({name=name,count=1})
			break
		  end
		end
	end
  elseif E_C_E.loader_type=="input" and Active_Loader(E_C_E,direction) then
	if E_G_T(1).get_item_count()>0 then
	  for name,count in pairs(E_G_T(1).get_contents()) do
		if P.can_insert({name=name,count=1}) then
		  E_G_T(1).remove_item({name=name,count=1})
		  P.insert({name=name,count=1})
		  break
		end
	  end
	end
	if E_G_T(2).get_item_count()>0 then
	  for name,count in pairs(E_G_T(2).get_contents()) do
		if P.can_insert({name=name,count=1}) then
	  	  E_G_T(2).remove_item({name=name,count=1})
		  P.insert({name=name,count=1})
		  break
		end
	  end
	end
  end
end
