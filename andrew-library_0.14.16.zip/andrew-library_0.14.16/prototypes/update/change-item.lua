
local D_R_I = data.raw.item
local D_R = data.raw
local Mod_Name_G = "__andrew-library__/graphics"

D_R["item-group"]["signals"].icon = Mod_Name_G.."/item-group/signals.png" 

D_R_I["crude-oil-barrel"].icon = Mod_Name_G.."/icons/fluid-barrels/crude-oil-barrel.png"

D_R_I["loader"].icon =  Mod_Name_G.."/icons/loader.png"
D_R_I["fast-loader"].icon =  Mod_Name_G.."/icons/fast-loader.png"
D_R_I["express-loader"].icon =  Mod_Name_G.."/icons/express-loader.png"

D_R_I["loader"].flags = {"goes-to-quickbar"}
D_R_I["fast-loader"].flags = {"goes-to-quickbar"}
D_R_I["express-loader"].flags = {"goes-to-quickbar"}

D_R["loader"]["loader"]["structure"] = Loader_Base("loader")
D_R["loader"]["fast-loader"]["structure"] = Loader_Base("fast-loader")
D_R["loader"]["express-loader"]["structure"] = Loader_Base("express-loader")

D_R_I["stone"].icon = Mod_Name_G.."/icons/ore/stone.png"
D_R_I["coal"].icon = Mod_Name_G.."/icons/ore/coal.png"
D_R_I["iron-ore"].icon = Mod_Name_G.."/icons/ore/iron-ore.png"
D_R_I["copper-ore"].icon = Mod_Name_G.."/icons/ore/copper-ore.png"
