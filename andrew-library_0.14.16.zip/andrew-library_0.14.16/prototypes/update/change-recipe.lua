
Change_Recipe("rocket-silo", "processing-unit", "advanced-computer-processing-chip", 100)
Change_Recipe("stack-inserter", "iron-gear-wheel", "steel-gear-wheel", 10)
Change_Recipe("assembling-machine-3", "speed-module", "speed-module", 2)
Change_Recipe("assembling-machine-3", "assembling-machine-2", "assembling-machine-2", 1)

Add_Item_To_Recipe("assembling-machine-3", "steel-gear-wheel", 2)
Add_Item_To_Recipe("assembling-machine-3", "steel-bearing", 2)

-- fill-crude-oil-barrel --
data:extend(
{
  {
    type = "recipe",
    name = "fill-crude-oil-barrel",
    category = "crafting-with-fluid",
    energy_required = 1,
    subgroup = "barrel",
    order = "a",
    enabled = false,
    icon = "__base__/graphics/icons/fluid/fill-crude-oil-barrel.png",
    ingredients =
    {
      {type="fluid", name="crude-oil", amount=30},
      {"empty-barrel",1},
    },
    results=
    {
      {"crude-oil-barrel",1}
    }
  },
}
)

-- empty-crude-oil-barrel --
data:extend(
{
  {
    type = "recipe",
    name = "empty-crude-oil-barrel",
    category = "crafting-with-fluid",
    energy_required = 1,
    subgroup = "barrel",
    order = "a",
    enabled = false,
    icon = "__base__/graphics/icons/fluid/empty-crude-oil-barrel.png",
    ingredients =
    {
      {"crude-oil-barrel",1}
    },
    results=
    {
      {type="fluid", name="crude-oil", amount=30},
      {"empty-barrel",1}
    }
  },
}
)
