-- loader-2 --
data:extend(
{
 {
    type = "technology",
    name = "loader-2",
    icon = "__base__/graphics/technology/logistics.png",
    upgrade = true,
    order = "c-k-f-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "fast-loader"
      },
    },
    prerequisites = 
	{
	  "loader",
	  "logistics-2",
	},
    unit =
    {
      count = 150,
      time = 30,
      ingredients = science2()
    },
  },
}
)