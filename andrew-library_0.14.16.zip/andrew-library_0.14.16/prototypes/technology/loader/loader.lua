-- loader --
data:extend(
{
 {
    type = "technology",
    name = "loader",
    icon = "__base__/graphics/technology/logistics.png",
    upgrade = true,
    order = "c-k-f-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "loader"
      },
    },
    prerequisites = 
	{
	  "logistics",
	},
    unit =
    {
      count = 10,
      time = 15,
      ingredients = science2()
    },
  },
}
)