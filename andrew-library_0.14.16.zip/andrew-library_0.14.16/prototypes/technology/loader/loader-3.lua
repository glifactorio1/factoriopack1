-- loader-3 --
data:extend({
{
    type = "technology",
    name = "loader-3",
    icon = "__base__/graphics/technology/logistics.png",
    upgrade = true,
    order = "c-k-f-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "express-loader"
      },
    },
    prerequisites = 
	{
	  "loader-2",
	  "logistics-3",
	},
    unit =
    {
      count = 220,
      time = 30,
      ingredients = science3()
    },
  },
}
)