-- toolbelt-2 --
data:extend(
{ 
   {
    type = "technology",
    name = "toolbelt-2",
    icon = "__base__/graphics/technology/toolbelt.png",
	upgrade = true,
    order = "c-k-m-a",
    effects =
    {
      {
        type = "num-quick-bars",
        modifier = 1
      },
    },
    prerequisites = 
	{
	  "toolbelt",
	},
    unit =
    {
      count = 100,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- toolbelt-3 --
data:extend(
{
  {
    type = "technology",
    name = "toolbelt-3",
    icon = "__base__/graphics/technology/toolbelt.png",
    upgrade = true,
    order = "c-k-m-b",
    effects =
    {
      {
        type = "num-quick-bars",
        modifier = 1
      },
    },
    prerequisites = 
	{
	  "toolbelt-2",
	},
    unit =
    {
      count = 150,
      time = 30,
      ingredients = science4()
    },
  },
}
)