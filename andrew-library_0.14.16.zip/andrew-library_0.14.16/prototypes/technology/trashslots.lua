-- character-logistic-trash-slots-3 --
data:extend({
{
    type = "technology",
    name = "character-logistic-trash-slots-3",
    icon = "__base__/graphics/technology/character-logistic-trash-slots.png",
    upgrade = true,
    order = "c-k-f-b",
    effects =
    {
      {
        type = "character-logistic-trash-slots",
        modifier = 5
      },
    },
    prerequisites = 
	{
	  "character-logistic-trash-slots-2",
	},
    unit =
    {
      count = 200,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- character-logistic-trash-slots-4 --
data:extend(
{
  {
    type = "technology",
    name = "character-logistic-trash-slots-4",
    icon = "__base__/graphics/technology/character-logistic-trash-slots.png",
    upgrade = true,
    order = "c-k-f-b",
    effects =
    {
      {
        type = "character-logistic-trash-slots",
        modifier = 5
      },
    },
    prerequisites = 
	{
	  "character-logistic-trash-slots-3",
	},
    unit =
    {
      count = 300,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- character-logistic-trash-slots-5 --
data:extend(
{
  {
    type = "technology",
    name = "character-logistic-trash-slots-5",
    icon = "__base__/graphics/technology/character-logistic-trash-slots.png",
    upgrade = true,
    order = "c-k-f-b",
    effects =
    {
      {
        type = "character-logistic-trash-slots",
        modifier = 5
      },
    },
    prerequisites = 
	{
	  "character-logistic-trash-slots-4",
	},
    unit =
    {
      count = 400,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- character-logistic-trash-slots-6 --
data:extend(
{
  {
    type = "technology",
    name = "character-logistic-trash-slots-6",
    icon = "__base__/graphics/technology/character-logistic-trash-slots.png",
    upgrade = true,
    order = "c-k-f-b",
    effects =
    {
      {
        type = "character-logistic-trash-slots",
        modifier = 5
      },
    },
    prerequisites = 
	{
	  "character-logistic-trash-slots-4",
	},
    unit =
    {
      count = 500,
      time = 30,
      ingredients = science3()
    },
  },
}
)