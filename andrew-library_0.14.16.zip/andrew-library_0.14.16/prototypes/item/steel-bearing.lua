
-- steel-bearing --
data:extend(
{
  {
    type = "item",
    name = "steel-bearing",
    icon = "__andrew-library__/graphics/icons/steel-bearing.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-gear",
    order = "d[bearing-steel]",
    stack_size = 100
  },
}
)