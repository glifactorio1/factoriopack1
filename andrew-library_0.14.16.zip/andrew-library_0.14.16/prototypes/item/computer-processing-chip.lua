
-- computer-processing-chip --
data:extend(
{
  {
    type = "item",
    name = "computer-processing-chip",
    icon = "__andrew-library__/graphics/icons/computer-processing-chip.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-chip",
    order = "g[computer-processing-chip]",
    stack_size = 200
  },
}
)
