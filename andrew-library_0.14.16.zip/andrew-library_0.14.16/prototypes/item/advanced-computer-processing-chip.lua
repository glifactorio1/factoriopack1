
-- advanced-computer-processing-chip --
data:extend(
{
  {
    type = "item",
    name = "advanced-computer-processing-chip",
    icon = "__andrew-library__/graphics/icons/advanced-computer-processing-chip.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-chip",
    order = "h[advanced-computer-processing-chip]",
    stack_size = 200
  },
}
)