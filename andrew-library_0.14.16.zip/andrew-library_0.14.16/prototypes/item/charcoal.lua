
-- charcoal --
data:extend(
{
  {
    type = "item",
    name = "charcoal",
    icon = "__andrew-library__/graphics/icons/charcoal.png",
    flags = {"goes-to-main-inventory"},
    fuel_value = "6MJ",
    subgroup = "intermediate-misc",
    order = "g",
    stack_size = 100
  },
}
)