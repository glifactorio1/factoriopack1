
-- cpu --
data:extend(
{
  {
    type = "item",
    name = "cpu",
    icon = "__andrew-library__/graphics/icons/cpu.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-wire",
    order = "f[cpu]",
    stack_size = 200
  },
}
)