
-- advanced-computer-chip --
data:extend(
{
  {
    type = "item",
    name = "advanced-computer-chip",
    icon = "__andrew-library__/graphics/icons/advanced-computer-chip.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-chip",
    order = "f[advanced-computer-chip]",
    stack_size = 200
  },
}
)