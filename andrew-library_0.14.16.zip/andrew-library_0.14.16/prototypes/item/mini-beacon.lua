
-- mini-beacon --
data:extend(
{
  {
    type = "item",
    name = "mini-beacon",
    icon = "__base__/graphics/icons/beacon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "module-case",
    order = "d",
    place_result = "mini-beacon",
    stack_size = 10
  },
}
)