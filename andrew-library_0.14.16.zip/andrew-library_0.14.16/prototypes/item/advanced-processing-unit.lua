
-- advanced-processing-unit --
data:extend(
{
  {
    type = "item",
    name = "advanced-processing-unit",
    icon = "__andrew-library__/graphics/icons/advanced-processing-unit.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-chip",
    order = "d[advanced-processing-unit]",
    stack_size = 200
  },
}
)