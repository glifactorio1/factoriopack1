
-- steel-bearing-ball --
data:extend(
{
  {
    type = "item",
    name = "steel-bearing-ball",
    icon = "__andrew-library__/graphics/icons/steel-bearing-ball.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-gear",
    order = "c[ball-bearing-steel]",
    stack_size = 500
  },
}
)