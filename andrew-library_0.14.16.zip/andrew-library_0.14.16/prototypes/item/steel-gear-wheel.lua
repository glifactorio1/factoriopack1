
-- steel-gear-wheel --
data:extend(
{
  {
    type = "item",
    name = "steel-gear-wheel",
    icon = "__andrew-library__/graphics/icons/steel-gear-wheel.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-gear",
    order = "b[steel-gear-wheel]",
    stack_size = 100
  },
}
)
