
if Mining_Item_Group == true then
data:extend(
{
  {
    type = "item-group",
    name = "mining",
    order = "cc",
    inventory_order = "ga",
    icon = "__andrew-library__/graphics/item-group/mining.png",
  },
  {
    type = "item-subgroup",
    name = "axe",
    group = "mining",
    order = "a"
  },
  {
    type = "item-subgroup",
    name = "repair",
    group = "mining",
    order = "b"
  },
  {
    type = "item-subgroup",
    name = "store-solid",
    group = "mining",
    order = "c"
  },
  {
    type = "item-subgroup",
    name = "mining-speed",
    group = "mining",
    order = "d"
  },
  {
    type = "item-subgroup",
    name = "mining-range",
    group = "mining",
    order = "e"
  },
  {
    type = "item-subgroup",
    name = "masher",
    group = "mining",
    order = "f"
  },
  {
    type = "item-subgroup",
    name = "furnace-coal",
    group = "mining",
    order = "g"
  },
  {
    type = "item-subgroup",
    name = "crusher",
    group = "mining",
    order = "h-a"
  },
  {
    type = "item-subgroup",
    name = "furnace-electric",
    group = "mining",
    order = "h-b"
  },
  {
    type = "item-subgroup",
    name = "assembling-machine",
    group = "mining",
    order = "i"
  },
  {
    type = "item-subgroup",
    name = "electronics-machine",
    group = "mining",
    order = "j"
  },
  {
    type = "item-subgroup",
    name = "lab",
    group = "mining",
    order = "k"
  },
}
)

data.raw.item["stone-furnace"].subgroup = "furnace-coal"
data.raw.item["stone-furnace"].order = "a"

data.raw.item["steel-furnace"].subgroup = "furnace-coal"
data.raw.item["steel-furnace"].order = "b"

data.raw.item["electric-furnace"].subgroup = "furnace-electric"
data.raw.item["electric-furnace"].order = "a"

data.raw.item["burner-mining-drill"].subgroup = "mining-speed"
data.raw.item["burner-mining-drill"].order = "a"

data.raw.item["electric-mining-drill"].subgroup = "mining-speed"
data.raw.item["electric-mining-drill"].order = "b"

data.raw["mining-tool"]["iron-axe"].subgroup = "axe"
data.raw["mining-tool"]["steel-axe"].subgroup = "axe"

data.raw["repair-tool"]["repair-pack"].subgroup = "repair"
data.raw["repair-tool"]["repair-pack"].order = "a"

data.raw.item["lab"].subgroup = "lab"
data.raw.item["lab"].order = "a"

data.raw.item["assembling-machine-1"].subgroup = "assembling-machine"
data.raw.item["assembling-machine-1"].order = "a"

data.raw.item["assembling-machine-2"].subgroup = "assembling-machine"
data.raw.item["assembling-machine-2"].order = "b"

data.raw.item["assembling-machine-3"].subgroup = "assembling-machine"
data.raw.item["assembling-machine-3"].order = "c"


data.raw.item["wooden-chest"].subgroup = "store-solid"
data.raw.item["wooden-chest"].order = "a"

data.raw.item["iron-chest"].subgroup = "store-solid"
data.raw.item["iron-chest"].order = "b"

data.raw.item["steel-chest"].subgroup = "store-solid"
data.raw.item["steel-chest"].order = "c"

end
