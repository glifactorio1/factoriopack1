
if Trains_Item_Group == true then
data:extend(
{
  {
    type = "item-group",
    name = "trains",
    order = "gg",
    inventory_order = "gg",
    icon = "__andrew-library__/graphics/item-group/trains.png",
  },
  {
    type = "item-subgroup",
    name = "trains-misc",
    group = "trains",
    order = "1"
  },
  {
    type = "item-subgroup",
    name = "trains-cargo",
    group = "trains",
    order = "2"
  },
  {
    type = "item-subgroup",
    name = "trains-locomotive",
    group = "trains",
    order = "3"
  },
}
)

-- Trains --

data.raw.item["train-stop"].subgroup = "trains-misc"
data.raw.item["train-stop"].order = "a"

data.raw.item["rail-signal"].subgroup = "trains-misc"
data.raw.item["rail-signal"].order = "b"

data.raw.item["rail-chain-signal"].subgroup = "trains-misc"
data.raw.item["rail-chain-signal"].order = "c"

data.raw["rail-planner"]["rail"].subgroup = "trains-misc"
data.raw["rail-planner"]["rail"].order = "a"

data.raw["item-with-entity-data"]["cargo-wagon"].subgroup = "trains-cargo"
data.raw["item-with-entity-data"]["cargo-wagon"].order = "a"

data.raw["item-with-entity-data"]["diesel-locomotive"].subgroup = "trains-locomotive"
data.raw["item-with-entity-data"]["diesel-locomotive"].order = "a"

end
