
if Transport_Item_Group == true then
data:extend(
{
  {
    type = "item-group",
    name = "transport",
    order = "aa",
    inventory_order = "gd",
    icon = "__andrew-library__/graphics/item-group/transport.png",
  },
  {
    type = "item-subgroup",
    name = "transport-belt",
    group = "transport",
    order = "1"
  },
  {
    type = "item-subgroup",
    name = "transport-ground",
    group = "transport",
    order = "2"
  },
  {
    type = "item-subgroup",
    name = "transport-splitters",
    group = "transport",
    order = "3"
  },
  {
    type = "item-subgroup",
    name = "transport-loader",
    group = "transport",
    order = "4"
  },
  {
    type = "item-subgroup",
    name = "transport-tank",
    group = "transport",
    order = "5"
  },
  {
    type = "item-subgroup",
    name = "transport-pipe",
    group = "transport",
    order = "6"
  },
  {
    type = "item-subgroup",
    name = "transport-pipe-ground",
    group = "transport",
    order = "7"
  },
}
)

-- Transport --

data.raw.item["splitter"].subgroup = "transport-splitters"
data.raw.item["splitter"].order = "a"

data.raw.item["fast-splitter"].subgroup = "transport-splitters"
data.raw.item["fast-splitter"].order = "b"

data.raw.item["express-splitter"].subgroup = "transport-splitters"
data.raw.item["express-splitter"].order = "c"

data.raw.item["transport-belt"].subgroup = "transport-belt"
data.raw.item["transport-belt"].order = "a"

data.raw.item["fast-transport-belt"].subgroup = "transport-belt"
data.raw.item["fast-transport-belt"].order = "b"

data.raw.item["express-transport-belt"].subgroup = "transport-belt"
data.raw.item["express-transport-belt"].order = "c"

data.raw.item["underground-belt"].subgroup = "transport-ground"
data.raw.item["underground-belt"].order = "a"

data.raw.item["fast-underground-belt"].subgroup = "transport-ground"
data.raw.item["fast-underground-belt"].order = "b"

data.raw.item["express-underground-belt"].subgroup = "transport-ground"
data.raw.item["express-underground-belt"].order = "c"

data.raw.item["pipe"].subgroup = "transport-pipe"
data.raw.item["pipe"].order = "a"

data.raw.item["pipe-to-ground"].subgroup = "transport-pipe-ground"
data.raw.item["pipe-to-ground"].order = "a"

data.raw.item["loader"].subgroup = "transport-loader"
data.raw.item["loader"].order = "a"

data.raw.item["fast-loader"].subgroup = "transport-loader"
data.raw.item["fast-loader"].order = "b"

data.raw.item["express-loader"].subgroup = "transport-loader"
data.raw.item["express-loader"].order = "c"

end

