
if Plates_Item_Group == true then
data:extend(
{
  {
    type = "item-group",
    name = "plates",
    order = "gaa",
    inventory_order = "gaa",
    icon = "__andrew-library__/graphics/item-group/plates.png",
  },
  {
    type = "item-subgroup",
    name = "plates-ore",
    group = "plates",
    order = "1"
  },
  {
    type = "item-subgroup",
    name = "plates-plates",
    group = "plates",
    order = "2"
  },
  {
    type = "item-subgroup",
    name = "plates-misc",
    group = "plates",
    order = "3"
  },
}
)

-- Plates --

data.raw.item["iron-ore"].subgroup = "plates-ore"
data.raw.item["iron-ore"].order = "aa"

data.raw.item["copper-ore"].subgroup = "plates-ore"
data.raw.item["copper-ore"].order = "aa"

data.raw.item["coal"].subgroup = "plates-ore"
data.raw.item["coal"].order = "aa"

data.raw.item["stone"].subgroup = "plates-ore"
data.raw.item["stone"].order = "aa"

data.raw.item["iron-plate"].subgroup = "plates-plates"
data.raw.item["iron-plate"].order = "aa"

data.raw.item["copper-plate"].subgroup = "plates-plates"
data.raw.item["copper-plate"].order = "ab"

data.raw.item["steel-plate"].subgroup = "plates-plates"
data.raw.item["steel-plate"].order = "ac"

data.raw.item["sulfur"].subgroup = "plates-misc"
data.raw.item["sulfur"].order = "a"

data.raw.item["plastic-bar"].subgroup = "plates-misc"
data.raw.item["plastic-bar"].order = "b"

data.raw.item["wood"].subgroup = "plates-misc"
data.raw.item["wood"].order = "c"

data.raw.item["raw-wood"].subgroup = "plates-misc"
data.raw.item["raw-wood"].order = "d"

data.raw.item["empty-barrel"].subgroup = "plates-misc"
data.raw.item["empty-barrel"].order = "e"

data.raw.recipe["empty-barrel"].subgroup = "plates-misc"
data.raw.recipe["empty-barrel"].order = "e"


end