
if Module_Item_Group == true then
data:extend(
{
  {
    type = "item-group",
    name = "module",
    order = "ff",
    inventory_order = "gf",
    icon = "__andrew-library__/graphics/item-group/module.png",
  },
  {
    type = "item-subgroup",
    name = "module-case",
    group = "module",
    order = "1"
  },
  {
    type = "item-subgroup",
    name = "speed-module",
    group = "module",
    order = "2"
  },
  {
    type = "item-subgroup",
    name = "effectivity-module",
    group = "module",
    order = "3"
  },
  {
    type = "item-subgroup",
    name = "productivity-module",
    group = "module",
    order = "4"
  },
  {
    type = "item-subgroup",
    name = "pollution-clean-module",
    group = "module",
    order = "5"
  },
  {
    type = "item-subgroup",
    name = "god-module",
    group = "module",
    order = "6"
  },
}
)

-- Module --

data.raw.item["beacon"].subgroup = "module-case"
data.raw.item["beacon"].order = "c"

data.raw.module["speed-module"].subgroup = "speed-module"
data.raw.module["speed-module"].order = "a"

data.raw.module["speed-module-2"].subgroup = "speed-module"
data.raw.module["speed-module-2"].order = "b"

data.raw.module["speed-module-3"].subgroup = "speed-module"
data.raw.module["speed-module-3"].order = "c"

data.raw.module["productivity-module"].subgroup = "productivity-module"
data.raw.module["productivity-module"].order = "a"

data.raw.module["productivity-module-2"].subgroup = "productivity-module"
data.raw.module["productivity-module-2"].order = "b"

data.raw.module["productivity-module-3"].subgroup = "productivity-module"
data.raw.module["productivity-module-3"].order = "c"

data.raw.module["effectivity-module"].subgroup = "effectivity-module"
data.raw.module["effectivity-module"].order = "a"

data.raw.module["effectivity-module-2"].subgroup = "effectivity-module"
data.raw.module["effectivity-module-2"].order = "b"

data.raw.module["effectivity-module-3"].subgroup = "effectivity-module"
data.raw.module["effectivity-module-3"].order = "c"

end