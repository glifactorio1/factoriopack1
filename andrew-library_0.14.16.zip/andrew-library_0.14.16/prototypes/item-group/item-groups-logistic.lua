
if Logistic_Item_Group == true then
data:extend(
{
  {
    type = "item-group",
    name = "logistic",
    order = "ee",
    inventory_order = "ge",
    icon = "__andrew-library__/graphics/item-group/logistic.png",
  },
  {
    type = "item-subgroup",
    name = "logistic-plan",
    group = "logistic",
    order = "a"
  },
  {
    type = "item-subgroup",
    name = "logistic-robot",
    group = "logistic",
    order = "b-a"
  },
  {
    type = "item-subgroup",
    name = "logistic-robot-c",
    group = "logistic",
    order = "b-b"
  },
  {
    type = "item-subgroup",
    name = "logistic-robot-f",
    group = "logistic",
    order = "b-c"
  },
  {
    type = "item-subgroup",
    name = "logistic-roboport",
    group = "logistic",
    order = "c"
  },
  {
    type = "item-subgroup",
    name = "logistic-pasive",
    group = "logistic",
    order = "d"
  },
  {
    type = "item-subgroup",
    name = "logistic-requester",
    group = "logistic",
    order = "e"
  },
  {
    type = "item-subgroup",
    name = "logistic-storage",
    group = "logistic",
    order = "f"
  },
  {
    type = "item-subgroup",
    name = "logistic-active",
    group = "logistic",
    order = "g"
  },
  {
    type = "item-subgroup",
    name = "logistic-wire",
    group = "logistic",
    order = "h-a"
  },
  {
    type = "item-subgroup",
    name = "logistic-comb",
    group = "logistic",
    order = "h-b"
  },
}
)

-- Logistic --

data.raw.item["logistic-robot"].subgroup = "logistic-robot"
data.raw.item["logistic-robot"].order = "a"

data.raw.item["construction-robot"].subgroup = "logistic-robot-c"
data.raw.item["construction-robot"].order = "a"

data.raw.item["flying-robot-frame"].subgroup = "logistic-robot-f"
data.raw.item["flying-robot-frame"].order = "a"

data.raw.item["roboport"].subgroup = "logistic-roboport"
data.raw.item["roboport"].order = "a"

data.raw.item["logistic-chest-passive-provider"].subgroup = "logistic-pasive"
data.raw.item["logistic-chest-passive-provider"].order = "a"

data.raw.item["logistic-chest-active-provider"].subgroup = "logistic-active"
data.raw.item["logistic-chest-active-provider"].order = "a"

data.raw.item["logistic-chest-storage"].subgroup = "logistic-storage"
data.raw.item["logistic-chest-storage"].order = "a"

data.raw.item["logistic-chest-requester"].subgroup = "logistic-requester"
data.raw.item["logistic-chest-requester"].order = "a"

data.raw.item["red-wire"].subgroup = "logistic-wire"
data.raw.item["red-wire"].order = "a"

data.raw.item["green-wire"].subgroup = "logistic-wire"
data.raw.item["green-wire"].order = "b"

data.raw.item["arithmetic-combinator"].subgroup = "logistic-comb"
data.raw.item["arithmetic-combinator"].order = "a"

data.raw.item["decider-combinator"].subgroup = "logistic-comb"
data.raw.item["decider-combinator"].order = "b"

data.raw.item["constant-combinator"].subgroup = "logistic-comb"
data.raw.item["constant-combinator"].order = "c"

data.raw.item["power-switch"].subgroup = "logistic-comb"
data.raw.item["power-switch"].order = "d"

data.raw["deconstruction-item"]["deconstruction-planner"].subgroup = "logistic-plan"

data.raw["blueprint"]["blueprint"].subgroup = "logistic-plan"

data.raw["blueprint-book"]["blueprint-book"].subgroup = "logistic-plan"

end