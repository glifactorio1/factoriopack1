
if Vehicles_Item_Group == true then
data:extend(
{
  {
    type = "item-group",
    name = "vehicles",
    order = "gx",
    inventory_order = "gx",
    icon = "__andrew-library__/graphics/item-group/vehicles.png",
  },
  {
    type = "item-subgroup",
    name = "vehicles-car",
    group = "vehicles",
    order = "1"
  },
  {
    type = "item-subgroup",
    name = "vehicles-tank",
    group = "vehicles",
    order = "2"
  },
  {
    type = "item-subgroup",
    name = "tank-ammo",
    group = "vehicles",
    order = "3"
  },
}
)

-- Vehicles --

data.raw["item-with-entity-data"]["tank"].subgroup = "vehicles-tank"
data.raw["item-with-entity-data"]["tank"].order = "a"

data.raw["item-with-entity-data"]["car"].subgroup = "vehicles-car"
data.raw["item-with-entity-data"]["car"].order = "a"

data.raw.ammo["cannon-shell"].subgroup = "tank-ammo"
data.raw.ammo["cannon-shell"].order = "a"

data.raw.ammo["explosive-cannon-shell"].subgroup = "tank-ammo"
data.raw.ammo["explosive-cannon-shell"].order = "b"

end
