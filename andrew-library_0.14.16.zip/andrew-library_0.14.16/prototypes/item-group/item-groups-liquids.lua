
if Liquids_Item_Group == true then
data:extend(
{
  {
    type = "item-group",
    name = "liquid",
    order = "gac",
    inventory_order = "gaa",
    icon = "__andrew-library__/graphics/item-group/liquids.png",
  },
  {
    type = "item-subgroup",
    name = "liquid-recipe",
    group = "liquid",
    order = "aa"
  },
  {
    type = "item-subgroup",
    name = "liquid-processing",
    group = "liquid",
    order = "ab"
  },
  {
    type = "item-subgroup",
    name = "liquid-fill",
    group = "liquid",
    order = "ba"
  },
  {
    type = "item-subgroup",
    name = "liquid-empty",
    group = "liquid",
    order = "bb"
  },
  {
    type = "item-subgroup",
    name = "liquid-barrels",
    group = "liquid",
    order = "bc"
  },
  {
    type = "item-subgroup",
    name = "liquid-store",
    group = "liquid",
    order = "c"
  },
  {
    type = "item-subgroup",
    name = "liquid-pumpjack",
    group = "liquid",
    order = "d-a"
  },
  {
    type = "item-subgroup",
    name = "liquid-n-pumpjack",
    group = "liquid",
    order = "d-b"
  },
  {
    type = "item-subgroup",
    name = "liquid-refinery",
    group = "liquid",
    order = "e"
  },
  {
    type = "item-subgroup",
    name = "liquid-plant",
    group = "liquid",
    order = "f"
  },
}
)

-- liquid --

data.raw.item["chemical-plant"].subgroup = "liquid-plant"
data.raw.item["chemical-plant"].order = "a"

data.raw.item["oil-refinery"].subgroup = "liquid-refinery"
data.raw.item["oil-refinery"].order = "a"

data.raw.item["pumpjack"].subgroup = "liquid-pumpjack"
data.raw.item["pumpjack"].order = "a"

data.raw.item["storage-tank"].subgroup = "liquid-store"
data.raw.item["storage-tank"].order = "a"

data.raw.recipe["sulfuric-acid"].subgroup = "liquid-recipe"

data.raw.recipe["basic-oil-processing"].subgroup = "liquid-processing"

data.raw.recipe["advanced-oil-processing"].subgroup = "liquid-processing"

data.raw.recipe["heavy-oil-cracking"].subgroup = "liquid-recipe"

data.raw.recipe["light-oil-cracking"].subgroup = "liquid-recipe"

data.raw.recipe["sulfuric-acid"].subgroup = "liquid-recipe"

data.raw.recipe["solid-fuel-from-light-oil"].subgroup = "liquid-recipe"

data.raw.recipe["solid-fuel-from-petroleum-gas"].subgroup = "liquid-recipe"

data.raw.recipe["solid-fuel-from-heavy-oil"].subgroup = "liquid-recipe"

data.raw.recipe["lubricant"].subgroup = "liquid-recipe"

data.raw.recipe["fill-crude-oil-barrel"].subgroup = "liquid-fill"
data.raw.recipe["fill-crude-oil-barrel"].order = "a"

data.raw.recipe["empty-crude-oil-barrel"].subgroup = "liquid-empty"
data.raw.recipe["empty-crude-oil-barrel"].order = "a"

data.raw.item["crude-oil-barrel"].subgroup = "liquid-barrels"
data.raw.item["crude-oil-barrel"].order = "a"

end
