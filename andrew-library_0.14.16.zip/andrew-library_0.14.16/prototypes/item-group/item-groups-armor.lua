
if Armor_Item_Group == true then
data:extend(
{
  {
    type = "item-group",
    name = "armor",
    order = "gw",
    inventory_order = "gw",
    icon = "__andrew-library__/graphics/item-group/armor.png",
  },
  {
    type = "item-subgroup",
    name = "armor-bullet",
    group = "armor",
    order = "a"
  },
  {
    type = "item-subgroup",
    name = "armor-shotgun",
    group = "armor",
    order = "b"
  },
  {
    type = "item-subgroup",
    name = "armor-rocket",
    group = "armor",
    order = "c"
  },
  {
    type = "item-subgroup",
    name = "armor-sniper",
    group = "armor",
    order = "d"
  },
  {
    type = "item-subgroup",
    name = "armor-flame",
    group = "armor",
    order = "e"
  },
  {
    type = "item-subgroup",
    name = "armor-capsule",
    group = "armor",
    order = "f"
  },
  {
    type = "item-subgroup",
    name = "armor-armor",
    group = "armor",
    order = "g"
  },
  {
    type = "item-subgroup",
    name = "armor-dmg",
    group = "armor",
    order = "h"
  },
  {
    type = "item-subgroup",
    name = "armor-util",
    group = "armor",
    order = "i"
  },
  {
    type = "item-subgroup",
    name = "armor-power",
    group = "armor",
    order = "j"
  },
}
)

-- Armor --

data.raw.gun["flame-thrower"].subgroup = "armor-flame"
data.raw.gun["flame-thrower"].order = "a"

data.raw.item["land-mine"].subgroup = "armor-capsule"
data.raw.item["land-mine"].order = "a"

data.raw.gun["rocket-launcher"].subgroup = "armor-rocket"
data.raw.gun["rocket-launcher"].order = "a"

data.raw.gun["shotgun"].subgroup = "armor-shotgun"
data.raw.gun["shotgun"].order = "a"

data.raw.gun["combat-shotgun"].subgroup = "armor-shotgun"
data.raw.gun["combat-shotgun"].order = "b"

data.raw.gun["submachine-gun"].subgroup = "armor-bullet"
data.raw.gun["submachine-gun"].order = "b"

data.raw.gun["pistol"].subgroup = "armor-bullet"
data.raw.gun["pistol"].order = "a"

data.raw.ammo["piercing-rounds-magazine"].subgroup = "armor-bullet"
data.raw.ammo["piercing-rounds-magazine"].order = "d"

data.raw.ammo["firearm-magazine"].subgroup = "armor-bullet"
data.raw.ammo["firearm-magazine"].order = "c"

data.raw.ammo["flame-thrower-ammo"].subgroup = "armor-flame"
data.raw.ammo["flame-thrower-ammo"].order = "b"

data.raw.ammo["explosive-rocket"].subgroup = "armor-rocket"
data.raw.ammo["explosive-rocket"].order = "c"

data.raw.ammo["rocket"].subgroup = "armor-rocket"
data.raw.ammo["rocket"].order = "b"

data.raw.ammo["piercing-shotgun-shell"].subgroup = "armor-shotgun"
data.raw.ammo["piercing-shotgun-shell"].order = "d"

data.raw.ammo["shotgun-shell"].subgroup = "armor-shotgun"
data.raw.ammo["shotgun-shell"].order = "c"

data.raw.capsule["grenade"].subgroup = "armor-capsule"
data.raw.capsule["grenade"].order = "a"

data.raw.capsule["cluster-grenade"].subgroup = "armor-capsule"
data.raw.capsule["cluster-grenade"].order = "a"

data.raw.capsule["poison-capsule"].subgroup = "armor-capsule"
data.raw.capsule["poison-capsule"].order = "b"

data.raw.capsule["slowdown-capsule"].subgroup = "armor-capsule"
data.raw.capsule["slowdown-capsule"].order = "c"

data.raw.capsule["defender-capsule"].subgroup = "armor-capsule"
data.raw.capsule["defender-capsule"].order = "d"

data.raw.capsule["distractor-capsule"].subgroup = "armor-capsule"
data.raw.capsule["distractor-capsule"].order = "e"

data.raw.capsule["destroyer-capsule"].subgroup = "armor-capsule"
data.raw.capsule["destroyer-capsule"].order = "f"

data.raw.capsule["discharge-defense-remote"].subgroup = "armor-capsule"
data.raw.capsule["discharge-defense-remote"].order = "g"

data.raw.armor["light-armor"].subgroup = "armor-armor"
data.raw.armor["light-armor"].order = "a"

data.raw.armor["heavy-armor"].subgroup = "armor-armor"
data.raw.armor["heavy-armor"].order = "b"

data.raw.armor["modular-armor"].subgroup = "armor-armor"
data.raw.armor["modular-armor"].order = "c"

data.raw.armor["power-armor"].subgroup = "armor-armor"
data.raw.armor["power-armor"].order = "d"

data.raw.armor["power-armor-mk2"].subgroup = "armor-armor"
data.raw.armor["power-armor-mk2"].order = "e"

data.raw.item["solar-panel-equipment"].subgroup = "armor-power"
data.raw.item["solar-panel-equipment"].order = "a-a"

data.raw.item["fusion-reactor-equipment"].subgroup = "armor-power"
data.raw.item["fusion-reactor-equipment"].order = "c-a"

data.raw.item["battery-equipment"].subgroup = "armor-power"
data.raw.item["battery-equipment"].order = "b-a"

data.raw.item["battery-mk2-equipment"].subgroup = "armor-power"
data.raw.item["battery-mk2-equipment"].order = "b-b"

data.raw.item["exoskeleton-equipment"].subgroup = "armor-util"
data.raw.item["exoskeleton-equipment"].order = "a-a"

data.raw.item["personal-roboport-equipment"].subgroup = "armor-util"
data.raw.item["personal-roboport-equipment"].order = "b-a"

data.raw.item["night-vision-equipment"].subgroup = "armor-util"
data.raw.item["night-vision-equipment"].order = "c-a"

data.raw.item["energy-shield-equipment"].subgroup = "armor-dmg"
data.raw.item["energy-shield-equipment"].order = "a-a"

data.raw.item["energy-shield-mk2-equipment"].subgroup = "armor-dmg"
data.raw.item["energy-shield-mk2-equipment"].order = "a-b"

data.raw.item["personal-laser-defense-equipment"].subgroup = "armor-dmg"
data.raw.item["personal-laser-defense-equipment"].order = "b-a"

data.raw.item["discharge-defense-equipment"].subgroup = "armor-dmg"
data.raw.item["discharge-defense-equipment"].order = "c"

end





