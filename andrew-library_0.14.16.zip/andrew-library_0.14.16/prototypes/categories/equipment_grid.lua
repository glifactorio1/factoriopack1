data:extend(
{
  {
    type = "equipment-grid",
    name = "car",
    width = 8,
    height = 8,
    equipment_categories = {"armor"}
  },
  {
    type = "equipment-grid",
    name = "tank",
    width = 10,
    height = 10,
    equipment_categories = {"armor"}
  },
  {
    type = "equipment-grid",
    name = "locomotive",
    width = 12,
    height = 12,
    equipment_categories = {"armor"}
  },
}
)

data.raw["car"]["car"].equipment_grid = "car"
data.raw["car"]["tank"].equipment_grid = "tank"
data.raw["locomotive"]["diesel-locomotive"].equipment_grid = "locomotive"
data.raw["cargo-wagon"]["cargo-wagon"].equipment_grid = "locomotive"
