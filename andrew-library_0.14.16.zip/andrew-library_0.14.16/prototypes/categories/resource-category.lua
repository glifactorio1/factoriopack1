data:extend(
{
  {
    type = "resource-category",
    name = "natural-gas"
  },
  {
    type = "resource-category",
    name = "a-basic-solid"
  },
}
)
