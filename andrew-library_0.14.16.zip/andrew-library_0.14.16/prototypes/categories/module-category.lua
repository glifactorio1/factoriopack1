data:extend(
{
  {
    type = "module-category",
    name = "pollution-clean"
  },
  {
    type = "module-category",
    name = "god"
  },
}
)


function productivitymodulelimitation()
return {"sulfuric-acid",
        "basic-oil-processing",
        "advanced-oil-processing",
        "heavy-oil-cracking",
        "light-oil-cracking",
        "solid-fuel-from-light-oil",
        "solid-fuel-from-heavy-oil",
        "solid-fuel-from-petroleum-gas",
        "lubricant",
        "iron-plate",
        "copper-plate",
        "steel-plate",
        "stone-brick",
        "sulfur",
        "plastic-bar",
        "empty-barrel",
        "iron-stick",
        "iron-gear-wheel",
        "copper-cable",
        "electronic-circuit",
        "advanced-circuit",
        "engine-unit",
        "electric-engine-unit",
        "processing-unit",
        "explosives",
        "battery",
        "flying-robot-frame",
        "science-pack-1",
        "science-pack-2",
        "science-pack-3",
        "alien-science-pack",
        "low-density-structure",
        "rocket-fuel",
        "rocket-control-unit",
        "rocket-part",
       }
end

