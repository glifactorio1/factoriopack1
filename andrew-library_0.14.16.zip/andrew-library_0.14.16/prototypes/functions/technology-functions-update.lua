
function Remove_Recipe_From_Tech(technology_Name, Recipe_Name)
  for I, effect in pairs(data.raw.technology[technology_Name].effects) do
    if effect.type == "unlock-recipe" and effect.recipe == Recipe_Name then
      table.remove(data.raw.technology[technology_Name].effects,I)
    end
  end
end