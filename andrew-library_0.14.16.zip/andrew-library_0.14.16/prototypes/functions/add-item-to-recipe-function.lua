
function Add_Item_To_Recipe(Recipe_Name, Recipe_Item, Amount)
	table.insert(data.raw.recipe[Recipe_Name].ingredients,
	{Recipe_Item, Amount})
end
