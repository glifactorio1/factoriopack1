
function Add_Productivity_Limitation(Recipe)
  if data.raw.recipe[Recipe] then
    for i, module in pairs(data.raw.module) do
      if module.limitation and module.effect.productivity then
        table.insert(module.limitation, Recipe)
      end
    end
  end
end
