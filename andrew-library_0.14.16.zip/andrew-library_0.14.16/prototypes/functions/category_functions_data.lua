
function Machine_Has_Category(machine, category_in)
  local hasit = false
  for Z, category in pairs(machine.crafting_categories) do
    if category == category_in then
      hasit = true
    end
  end
  return hasit
end

function Machine_Add_Category(machine, category)
  if not Machine_Has_Category(machine, category) then
    table.insert(machine.crafting_categories, category)
  end
end

function Category_Add_Category(machine_type, category, category_to_add)
  for i, machine in pairs(data.raw[machine_type]) do
    if Machine_Has_Category(machine, category) then
      Machine_Add_Category(machine, category_to_add)
    end
  end
end
