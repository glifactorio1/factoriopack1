
function Deposit_1(Tint)
return
  {
    filename = "__andrew-library__/graphics/entity/deposit/deposit-1.png",
    priority = "extra-high",
    width = 38,
    height = 38,
    frame_count = 4,
    variation_count = 8,
    tint = Tint,
  }
end

function Deposit_2(Tint)
return
  {
    filename = "__andrew-library__/graphics/entity/deposit/deposit-2.png",
    priority = "extra-high",
    width = 38,
    height = 38,
    frame_count = 4,
    variation_count = 8,
    tint = Tint,
  }
end

function Deposit_3(Tint)
return
  {
    filename = "__andrew-library__/graphics/entity/deposit/deposit-3.png",
    priority = "extra-high",
    width = 38,
    height = 38,
    frame_count = 4,
    variation_count = 8,
    tint = Tint,
  }
end

function Deposit_4(Tint)
return
  {
    filename = "__andrew-library__/graphics/entity/deposit/deposit-4.png",
    priority = "extra-high",
    width = 38,
    height = 38,
    frame_count = 4,
    variation_count = 8,
    tint = Tint,
  }
end

function Deposit_5(Tint)
return
  {
    filename = "__andrew-library__/graphics/entity/deposit/gas-deposit.png",
    priority = "extra-high",
    width = 75,
    height = 61,
    frame_count = 4,
    variation_count = 1,
    tint = Tint,
  }
end