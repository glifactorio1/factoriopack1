
function Add_Items_To_Resource(Item_Name, Amount_Min, Amount_Max, Probability)
return
  {
	type = "item",
	name = Item_Name,
	amount_min = Amount_Min,
	amount_max = Amount_Max,
	probability = Probability
  }
end
