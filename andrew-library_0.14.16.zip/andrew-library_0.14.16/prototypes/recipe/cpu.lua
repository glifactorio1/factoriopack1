-- cpu --
data:extend(
{
  {
    type = "recipe",
    name = "cpu",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "cpu",
    result_count = 1,	
    ingredients =
    {
      {"iron-plate", 1},
	  {"copper-plate", 1},
	  {"insulated-wire", 3},
    },
  },
}
)