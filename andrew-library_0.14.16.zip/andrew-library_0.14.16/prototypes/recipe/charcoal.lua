-- charcoal --
data:extend(
{
  {
    type = "recipe",
    name = "charcoal",
	category = "smelting",
    enabled = true,
    energy_required = 10,
    result = "charcoal",
    result_count = 9,	
    ingredients =
    {
      {"raw-wood", 10},
    },
  },
}
)