
data:extend(
{
  {
    type = "recipe",
    name = "mini-beacon",
    enabled = false,
    energy_required = 15,
    ingredients =
    {
      {"electronic-circuit", 20},
      {"advanced-circuit", 20},
      {"steel-plate", 10},
      {"copper-cable", 10}
    },
    result = "mini-beacon"
  },
}
)