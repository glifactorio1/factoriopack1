-- advanced-processing-unit --
data:extend(
{
  {
    type = "recipe",
    name = "advanced-processing-unit",
    category = "crafting-with-fluid",
    enabled = false,
    energy_required = 30,
    result = "advanced-processing-unit",
	result_count = 1,
    ingredients =
    {
      {"advanced-circuit", 20},
      {"processing-unit", 2},
      {type="fluid", name = "sulfuric-acid", amount = 2},
    },
  },
}
)
