-- steel-gear-wheel --
data:extend(
{
  {
    type = "recipe",
    name = "steel-gear-wheel",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "steel-gear-wheel",
    result_count = 1,	
    ingredients =
    {
      {"steel-plate", 1},
    },
  },
}
)
