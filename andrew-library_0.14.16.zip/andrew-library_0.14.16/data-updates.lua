
function Change_Recipe(Recipe_Name, Old_Ingredient, New_Ingredient, Amount)
  for k, v in pairs(data.raw["recipe"][Recipe_Name].ingredients) do
	if v[1] == Old_Ingredient then table.remove(data.raw["recipe"][Recipe_Name].ingredients, k) end
  end
 table.insert(data.raw["recipe"][Recipe_Name].ingredients,{New_Ingredient, Amount})
end
-- functions --
require("prototypes.functions.technology-functions-update")
require("prototypes.functions.add-productivity-limitation-function-updata")
require("prototypes.functions.add-item-to-recipe-function")

-- update --
require("prototypes.update.change-item")
require("prototypes.update.change-recipe")
require("prototypes.update.productivity-limitations")
require("prototypes.update.update-subgroup")
require("prototypes.update.larger-stack-size")

-- item-group --
require("prototypes.item-group.item-groups-armor")
require("prototypes.item-group.item-groups-decorative")
require("prototypes.item-group.item-groups-defense")
require("prototypes.item-group.item-groups-inserters")
require("prototypes.item-group.item-groups-intermediate")
require("prototypes.item-group.item-groups-liquids")
require("prototypes.item-group.item-groups-logistic")
require("prototypes.item-group.item-groups-mining")
require("prototypes.item-group.item-groups-module")
require("prototypes.item-group.item-groups-nuclear")
require("prototypes.item-group.item-groups-plates")
require("prototypes.item-group.item-groups-power")
require("prototypes.item-group.item-groups-trains")
require("prototypes.item-group.item-groups-transport")
require("prototypes.item-group.item-groups-vehicles")

data.raw["resource"]["coal"]["stages"]["sheet"] = Deposit_1({r=0.2, g=0.2, b=0.2})
data.raw["resource"]["copper-ore"]["stages"]["sheet"] = Deposit_2({r=0.803, g=0.388, b=0.215})
data.raw["resource"]["iron-ore"]["stages"]["sheet"] = Deposit_2({r=0.337, g=0.419, b=0.427})
data.raw["resource"]["stone"]["stages"]["sheet"] = Deposit_1({r=0.478, g=0.450, b=0.317})



