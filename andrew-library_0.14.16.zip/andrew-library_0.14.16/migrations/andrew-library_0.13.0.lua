game.reload_script()

for index, force in pairs(game.forces) do
  force.reset_recipes()
  force.reset_technologies()

  if force.technologies["steel-processing"].researched then
    force.recipes["steel-gear-wheel"].enabled = true
  end
  if force.technologies["steel-processing"].researched then
    force.recipes["steel-bearing-ball"].enabled = true
  end
  if force.technologies["steel-processing"].researched then
    force.recipes["steel-bearing"].enabled = true
  end
end
