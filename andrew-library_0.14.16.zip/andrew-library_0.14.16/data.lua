
data.raw.player.player.build_distance = 10000
data.raw.player.player.reach_distance = 10000
data.raw.player.player.inventory_size = 100

-- item groups starts here --
-- !!!If you want to disable my item groups download Andrew zero item groups!!! --
Armor_Item_Group = true -- default is true
Decorative_Item_Group = true -- default is true
Defense_Item_Group = true -- default is true
Inserters_Item_Group = true -- default is true 
Intermediate_Item_Group = true -- default is true 
Liquids_Item_Group = true -- default is true
Logistic_Item_Group = true -- default is true
Mining_Item_Group = true -- default is true
Module_Item_Group = true -- default is true
Nuclear_Item_Group = true -- default is true 
Plates_Item_Group = true -- default is true
Power_Item_Group = true -- default is true
Trains_Item_Group = true -- default is true
Transport_Item_Group = true -- default is true
Vehicles_Item_Group = true -- default is true
-- item groups stop here --

-- categories --
require("prototypes.categories.module-category")
require("prototypes.categories.recipe-category")
require("prototypes.categories.ammo-category")
require("prototypes.categories.equipment_grid")
require("prototypes.categories.resource-category")

-- custom-input --
require("prototypes.custom-input.custom-loader-input")

-- functions --
require("prototypes.functions.technology-functions")
require("prototypes.functions.pipe-to-ground-function")
require("prototypes.functions.pipe-function")
require("prototypes.functions.splitter-function")
require("prototypes.functions.Underground-Belt-function")
require("prototypes.functions.loader-function")
require("prototypes.functions.deposit-function")
require("prototypes.functions.category_functions_data")
require("prototypes.functions.add-items-to-resource-function")

-- entity --
require("prototypes.entity.mini-beacon")

-- item --
require("prototypes.item.advanced-processing-unit")
require("prototypes.item.computer-chip")
require("prototypes.item.advanced-computer-chip")
require("prototypes.item.computer-processing-chip")
require("prototypes.item.advanced-computer-processing-chip")
require("prototypes.item.charcoal")
require("prototypes.item.insulated-wire")
require("prototypes.item.cpu")
require("prototypes.item.steel-bearing")
require("prototypes.item.steel-bearing-ball")
require("prototypes.item.steel-gear-wheel")
require("prototypes.item.mini-beacon")

-- recipe --
require("prototypes.recipe.advanced-processing-unit")
require("prototypes.recipe.computer-chip")
require("prototypes.recipe.advanced-computer-chip")
require("prototypes.recipe.computer-processing-chip")
require("prototypes.recipe.advanced-computer-processing-chip")
require("prototypes.recipe.charcoal")
require("prototypes.recipe.insulated-wire")
require("prototypes.recipe.cpu")
require("prototypes.recipe.steel-bearing")
require("prototypes.recipe.steel-bearing-ball")
require("prototypes.recipe.steel-gear-wheel")
require("prototypes.recipe.mini-beacon")

-- technology --
require("prototypes.technology.advanced-electronics-3")
require("prototypes.technology.advanced-electronics-4")
require("prototypes.technology.steel-processing")
require("prototypes.technology.toolbelt")
require("prototypes.technology.trashslots")
require("prototypes.technology.effect-transmission")

require("prototypes.technology.loader.loader")
require("prototypes.technology.loader.loader-2")
require("prototypes.technology.loader.loader-3")
