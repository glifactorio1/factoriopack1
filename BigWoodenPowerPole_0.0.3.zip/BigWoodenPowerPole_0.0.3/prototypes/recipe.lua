data:extend(
{
  {
    type = "recipe",
    name = "big-wooden-pole",
    ingredients = 
	{
      {"wood", 10},
      {"copper-cable", 8}
    },
    result = "big-wooden-pole",
    enabled = "true"
  },
}
)