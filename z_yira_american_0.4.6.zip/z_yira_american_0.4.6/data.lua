
require "util"

require ("prototypes.subgroup")
require ("prototypes.locomotive")
require ("prototypes._wagon_cargo2a")
require ("prototypes._wagon_cargo4a")



