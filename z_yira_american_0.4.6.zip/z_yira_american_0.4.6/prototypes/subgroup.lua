
data:extend({
	{ type="item-subgroup", group="yuoki_railway", order="x", name="yir_americans", }, -- mod themed line
})