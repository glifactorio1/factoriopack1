mini = {}
require('config')

if mini.furnace then
  require('prototypes.mini-furnace')
end
if mini.assembler1 then
  require('prototypes.mini-assembler-1')
  if mini.assemblerplus then
    require('prototypes.mini-assembler-2')
	require('prototypes.mini-assembler-3')
  end
end
if mini.refinery then
  require('prototypes.mini-refinery')
end
if mini.newicons then
  require('prototypes.mini-icons')
end