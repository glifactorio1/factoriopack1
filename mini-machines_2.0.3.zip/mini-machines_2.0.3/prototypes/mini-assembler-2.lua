--Technology
table.insert(data.raw.technology["automation-2"].effects,{type = "unlock-recipe", recipe = "mini-assembler-2"})

data:extend({
--Item
  {
    type = "item",
    name = "mini-assembler-2",
    icon = "__mini-machines__/graphics/assembler/mini-assembler-2-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "production-machine",
    order = "a[assembling-machine]-b",
    place_result = "mini-assembler-2",
    stack_size = 50
  },
--Recipe
  {
    type = "recipe",
    name = "mini-assembler-2",
    ingredients = {{"iron-plate", 3}, {"iron-gear-wheel", 3}, {"electronic-circuit", 3}, {"mini-assembler-1", 1}},
    result = "mini-assembler-2",
    energy_required = 5,
    enabled = "false"
  },
--Entity
  {
    type = "assembling-machine",
    name = "mini-assembler-2",
    icon = "__base__/graphics/icons/assembling-machine-2.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "mini-assembler-2"},
    max_health = 200,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    resistances =
    {
      {
        type = "fire",
        percent = 70
      }
    },
	fluid_boxes =
    {
      {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {0.5, -1.5} }}
      },
      {
        production_type = "output",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = 1,
        pipe_connections = {{ type="output", position = {0.5, 1.5} }}
      },
      off_when_no_fluid_recipe = true
    },
    collision_box = {{-0.75, -0.75}, {0.75, 0.75}},
    selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
    fast_replaceable_group = "assembling-machine",
    animation =
    {
      filename = "__base__/graphics/entity/assembling-machine-2/assembling-machine-2.png",
      priority="high",
      width = 113,
      height = 99,
      frame_count = 32,
      line_length = 8,
	  --shift = {0.4, -0.06}
      shift = {0.4*0.66, -0.06*0.66},
	  scale = 0.66
    },
    crafting_categories = {"crafting", "advanced-crafting", "crafting-with-fluid"},
    crafting_speed = 0.75,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.04 / 2.5
    },
    energy_usage = "150kW",
    ingredient_count = 2,
	module_specification =
    {
      module_slots = 2
    },
	allowed_effects = {"consumption", "speed", "productivity", "pollution"},
    open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = {
        {
          filename = "__base__/sound/assembling-machine-t2-1.ogg",
          volume = 0.8
        },
        {
          filename = "__base__/sound/assembling-machine-t2-2.ogg",
          volume = 0.8
        },
      },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 1.5,
    }
  },
})