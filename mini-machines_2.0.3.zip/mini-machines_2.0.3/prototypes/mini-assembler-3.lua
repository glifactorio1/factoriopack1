--Technology
table.insert(data.raw.technology["automation-3"].effects,{type = "unlock-recipe", recipe = "mini-assembler-3"})

data:extend({
--Item
  {
    type = "item",
    name = "mini-assembler-3",
    icon = "__mini-machines__/graphics/assembler/mini-assembler-3-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "production-machine",
    order = "a[assembling-machine]-c",
    place_result = "mini-assembler-3",
    stack_size = 50
  },
--Recipe
  {
    type = "recipe",
    name = "mini-assembler-3",
    ingredients = {{"speed-module", 4}, {"mini-assembler-2", 2}},
    result = "mini-assembler-3",
    energy_required = 5,
    enabled = "false"
  },
--Entity
  {
    type = "assembling-machine",
    name = "mini-assembler-3",
    icon = "__base__/graphics/icons/assembling-machine-3.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "mini-assembler-3"},
    max_health = 250,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    resistances =
    {
      {
        type = "fire",
        percent = 70
      }
    },
	fluid_boxes =
    {
      {
        production_type = "input",
        pipe_picture = assembler3pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {0.5, -1.5} }}
      },
      {
        production_type = "output",
        pipe_picture = assembler3pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = 1,
        pipe_connections = {{ type="output", position = {0.5, 1.5} }}
      },
      off_when_no_fluid_recipe = true
    },
    collision_box = {{-0.75, -0.75}, {0.75, 0.75}},
    selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
    fast_replaceable_group = "assembling-machine",
    animation =
    {
      filename = "__base__/graphics/entity/assembling-machine-3/assembling-machine-3.png",
      priority="high",
      width = 142,
      height = 113,
      frame_count = 32,
      line_length = 8,
	  --shift = {0.84, -0.09}
      shift = {0.84*0.66, -0.09*0.66},
	  scale = 0.66
    },
    crafting_categories = {"crafting", "advanced-crafting", "crafting-with-fluid"},
    crafting_speed = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.03 / 3.5
    },
    energy_usage = "210kW",
    ingredient_count = 4,
	module_specification =
    {
      module_slots = 2
    },
	allowed_effects = {"consumption", "speed", "productivity", "pollution"},
    open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = {
        {
          filename = "__base__/sound/assembling-machine-t3-1.ogg",
          volume = 0.8
        },
        {
          filename = "__base__/sound/assembling-machine-t3-2.ogg",
          volume = 0.8
        },
      },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 1.5,
    }
  },
})