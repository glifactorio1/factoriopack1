--Technology
table.insert(data.raw.technology["advanced-material-processing"].effects,{type = "unlock-recipe", recipe = "mini-furnace"})

data:extend({
--Item
  {
    type = "item",
    name = "mini-furnace",
    icon = "__mini-machines__/graphics/furnace/mini-furnace-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "smelting-machine",
    order = "c[electric-furnace]-a",
    place_result = "mini-furnace",
    stack_size = 50
  },
--Recipe
  {
    type = "recipe",
    name = "mini-furnace",
    ingredients = {{"steel-plate", 10}, {"stone-brick", 10}, {"electronic-circuit", 5}},
    result = "mini-furnace",
    energy_required = 5,
    enabled = "false"
  },
--Entity
  {
    type = "furnace",
    name = "mini-furnace",
    icon = "__mini-machines__/graphics/furnace/mini-furnace-icon.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "mini-furnace"},
    max_health = 150,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    light = {intensity = 1, size = 10},
    resistances =
    {
      {
        type = "fire",
        percent = 80
      }
    },
    collision_box = {{-0.75, -0.75}, {0.75, 0.75}},
    selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
    crafting_categories = {"smelting"},
    result_inventory_size = 1,
    crafting_speed = 1,
    energy_usage = "180kW",
    source_inventory_size = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.005
    },
	module_specification =
    {
      module_slots = 0,
      module_info_icon_shift = {0, 0.8}
    },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/electric-furnace.ogg",
        volume = 0.7
      },
      apparent_volume = 1.5
    },
    animation =
    {
      filename = "__mini-machines__/graphics/furnace/mini-furnace-base.png",
      priority = "high",
      width = 129,
      height = 100,
      frame_count = 1,
	  --shift = {0.421875, 0},
      shift = {0.421875*0.6, 0},
      scale = 0.6
    },
    working_visualisations =
    {
      {
        animation =
        {
          filename = "__base__/graphics/entity/electric-furnace/electric-furnace-heater.png",
          priority = "high",
          width = 25,
          height = 15,
          frame_count = 12,
          animation_speed = 0.5,
          --shift = {0.015625, 0.890625},
          shift = {0.015625*0.6, 0.890625*0.6},
          scale = 0.6
        },
        light = {intensity = 0.4, size = 6, shift = {0.0, 1.0}}
      },
      {
        animation =
        {
          filename = "__base__/graphics/entity/electric-furnace/electric-furnace-propeller-1.png",
          priority = "high",
          width = 19,
          height = 13,
          frame_count = 4,
          animation_speed = 0.5,
          --shift = {-0.671875, -0.640625},
          shift = {-0.671875 * 0.6, -0.640625 * 0.6},
          scale = 0.6
        }
      },
      {
        animation =
        {
          filename = "__base__/graphics/entity/electric-furnace/electric-furnace-propeller-2.png",
          priority = "high",
          width = 12,
          height = 9,
          frame_count = 4,
          animation_speed = 0.5,
          --shift = {0.0625, -1.234375},
          shift = {0.0625 * 0.6, -1.234375 * 0.6},
          scale = 0.6
        }
      }
    },
    fast_replaceable_group = "furnace"
  },
})
--Order Fix
data.raw.item["electric-furnace"].order = "c[electric-furnace]-z"