--Technology
table.insert(data.raw.technology["oil-processing"].effects,{type = "unlock-recipe", recipe = "mini-refinery"})

data:extend({
--Item
  {
    type = "item",
    name = "mini-refinery",
    icon = "__mini-machines__/graphics/refinery/mini-refinery-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "production-machine",
    order = "d[refinery]-a",
    place_result = "mini-refinery",
    stack_size = 10
  },
--Recipe
  {
    type = "recipe",
    name = "mini-refinery",
    ingredients =
	{
	  {"steel-plate", 10},
      {"iron-gear-wheel", 10},
      {"stone-brick", 10},
      {"electronic-circuit", 10},
      {"pipe", 10}
	},
    result = "mini-refinery",
    energy_required = 20,
    enabled = "false"
  },
--Entity
  {
    type = "assembling-machine",
    name = "mini-refinery",
    icon = "__mini-machines__/graphics/refinery/mini-refinery-icon.png",
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "mini-refinery"},
    max_health = 250,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-1.3, -1.3}, {1.3, 1.3}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    crafting_categories = {"oil-processing"},
    crafting_speed = 0.75,
	ingredient_count = 4,
    energy_usage = "420kW",
    source_inventory_size = 1,
	has_backer_name = true,
	module_specification =
    {
      module_slots = 0,
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.03 / 3.5
    },
    animation =
    {
      north =
      {
        filename = "__base__/graphics/entity/oil-refinery/oil-refinery.png",
        width = 337,
        height = 255,
        frame_count = 1,
        shift = {2.515625*0.6, 0.484375*0.6},
		scale = 0.6
      },
      east =
      {
        filename = "__base__/graphics/entity/oil-refinery/oil-refinery.png",
        x = 337,
        width = 337,
        height = 255,
        frame_count = 1,
        shift = {2.515625*0.6, 0.484375*0.6},
		scale = 0.6
      },
      south =
      {
        filename = "__base__/graphics/entity/oil-refinery/oil-refinery.png",
        x = 674,
        width = 337,
        height = 255,
        frame_count = 1,
        shift = {2.515625*0.6, 0.484375*0.6},
		scale = 0.6
      },
      west =
      {
        filename = "__base__/graphics/entity/oil-refinery/oil-refinery.png",
        x = 1011,
        width = 337,
        height = 255,
        frame_count = 1,
        shift = {2.515625*0.6, 0.484375*0.6},
		scale = 0.6
      }
    },
    working_visualisations =
    {
      {
        north_position = {1.03125*0.6, -1.55*0.6},
        east_position = {-1.65625*0.6, -1.3*0.6},
        south_position = {-1.875*0.6, -2.0*0.6},
        west_position = {1.8437*0.6, -1.2*0.6},
        animation =
        {
          filename = "__base__/graphics/entity/oil-refinery/oil-refinery-fire.png",
          frame_count = 29,
          width = 16,
          height = 35,
          scale = 1.5*0.6,
          shift = {0, -0.5625*0.6},
          run_mode="backward"
        },
        light = {intensity = 0.4, size = 6}
      }
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = { filename = "__base__/sound/oil-refinery.ogg" },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 2.5,
    },
    fluid_boxes =
    {
      {
        production_type = "input",
		pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {-1, 2} }}
      },
      {
        production_type = "input",
		pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {1, 2} }}
      },
      {
        production_type = "output",
		pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_level = 1,
        pipe_connections = {{ position = {-1, -2} }}
      },
      {
        production_type = "output",
		pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_level = 1,
        pipe_connections = {{ position = {0, -2} }}
      },
      {
        production_type = "output",
		pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_level = 1,
        pipe_connections = {{ position = {1, -2} }}
      }
    },
    pipe_covers = pipecoverspictures()
  },
})
--Order Fix
data.raw.item["oil-refinery"].order = "d[refinery]-z"