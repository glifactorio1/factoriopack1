if mini.furnace then
  data.raw.item["mini-furnace"].icon = "__mini-machines__/graphics/furnace/mini-furnace-icon-new.png"
end
if mini.assembler1 then
  data.raw.item["mini-assembler-1"].icon = "__mini-machines__/graphics/assembler/mini-assembler-1-icon-new.png"
  if mini.assemblerplus then
    data.raw.item["mini-assembler-2"].icon = "__mini-machines__/graphics/assembler/mini-assembler-2-icon-new.png"
	data.raw.item["mini-assembler-3"].icon = "__mini-machines__/graphics/assembler/mini-assembler-3-icon-new.png"
  end
end
if mini.refinery then
  data.raw.item["mini-refinery"].icon = "__mini-machines__/graphics/refinery/mini-refinery-icon-new.png"
end