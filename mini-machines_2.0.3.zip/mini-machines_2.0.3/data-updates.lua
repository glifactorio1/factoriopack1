--Bob Electronics Mini Assembler 1 Recipe Consistency
if data.raw.item["basic-circuit-board"] then
  bobmods.lib.recipe.replace_ingredient("mini-assembler-1","electronic-circuit", "basic-circuit-board")
end

--Bob Assembly Check
if bobmods then if bobmods.assembly then
  if mini.assembler1 then
--Mini Assembler Power Consistency
    data.raw["assembling-machine"]["mini-assembler-1"].energy_usage = "100kW"
	if mini.assemblerplus then
	  data.raw["assembling-machine"]["mini-assembler-2"].energy_usage = "135kW"
--Mini Assembler 3 Recipe Consistency
	  data.raw.recipe["mini-assembler-3"].ingredients = {{"mini-assembler-2", 1},{"steel-plate", 3},{"advanced-circuit", 3}}
	  if data.raw.item["steel-gear-wheel"] then
	    bobmods.lib.recipe.add_ingredient("mini-assembler-3",{"steel-gear-wheel", 3})
	    else
	    bobmods.lib.recipe.add_ingredient("mini-assembler-3",{"iron-gear-wheel", 3})
	  end
--Mini Assembler Subgroup Consistency
	  data.raw.item["mini-assembler-1"].subgroup = "bob-assembly-machine"
	  data.raw.item["mini-assembler-2"].subgroup = "bob-assembly-machine"
	  data.raw.item["mini-assembler-3"].subgroup = "bob-assembly-machine"
	end
  end
--Mini Refinery Subgroup Consistency
  if mini.refinery then
    data.raw.item["mini-refinery"].order = "d[refinery-2]"
    data.raw.item["mini-refinery"].subgroup = "bob-refinery-machine"
  end
end end

--Balance Disabled
if not mini.balance then
  if mini.assembler1 then
    data.raw["assembling-machine"]["mini-assembler-1"].ingredient_count = 2
	if mini.assemblerplus then
	  data.raw["assembling-machine"]["mini-assembler-2"].ingredient_count = 4
	  data.raw["assembling-machine"]["mini-assembler-3"].ingredient_count = 6
	  data.raw["assembling-machine"]["mini-assembler-3"].module_specification.module_slots = 2
	  data.raw["assembling-machine"]["mini-assembler-3"].crafting_speed = 1.25
	end
  end
  if mini.refinery then
    data.raw["assembling-machine"]["mini-refinery"].crafting_speed = 1
    data.raw["assembling-machine"]["mini-refinery"].module_specification.module_slots = 2
  end
  if mini.furnace then
    data.raw["furnace"]["mini-furnace"].module_specification.module_slots = 2
  end
end