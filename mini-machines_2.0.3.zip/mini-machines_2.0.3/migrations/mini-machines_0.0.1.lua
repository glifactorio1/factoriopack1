for i, force in pairs(game.forces) do 
 if force.technologies["automation"].researched then 
   force.recipes["mini-assembler-1"].enabled = true
 end
 if force.technologies["automation-2"].researched then 
   force.recipes["mini-assembler-2"].enabled = true
 end
 if force.technologies["automation-3"].researched then 
   force.recipes["mini-assembler-3"].enabled = true
 end
 if force.technologies["advanced-material-processing"].researched then 
   force.recipes["mini-furnace"].enabled = true
 end
 if force.technologies["oil-processing"].researched then 
   force.recipes["mini-refinery"].enabled = true
 end
end
