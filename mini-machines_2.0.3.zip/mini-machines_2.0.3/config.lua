--Enables/Disables miniature versions of these machines
mini.furnace = true
mini.assembler1 = true
--Only applies if assembler1 is true, enables further tiers of mini-assemblers
mini.assemblerplus = true
mini.refinery=true
mini.newicons=true
mini.balance=true