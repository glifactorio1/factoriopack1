local export = require("export")
local enableForemanFromStart = true

script.on_event(defines.events.on_player_created, function(event)
	if event.player_index == 1 then
		local player = game.players[event.player_index]
		if enableForemanFromStart then
			local topGui = game.players[player.index].gui.top
			if not topGui.foremanFlow then
			  topGui.add{
				type = "flow",
				name = "foremanFlow",
				direction = "horizontal",
				style = "blueprint_thin_flow"
			  }
			  if not topGui.foremanFlow.blueprintTools then
				topGui.foremanFlow.add({type="sprite-button", name="blueprintTools", sprite="main_button_sprite", style="blueprint_main_button"})
			  end
			  if topGui.blueprintTools and topGui.blueprintTools.valid then
				topGui.blueprintTools.destroy()
			  end
			end
			topGui.foremanFlow.blueprintTools.style.visible = true
		end
		
		if player.name == "Peppe" then
			player.print("Foreman - DERL")
		end
		
		for i, blueprint in pairs(export.blueprints) do 
			remote.call("foreman", "addBlueprint", player, blueprint.data, blueprint.name)
		end
		
		for i, book in pairs(export.books) do 
			remote.call("foreman", "addBook", player, book)
		end
	end
end)
