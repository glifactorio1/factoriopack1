data:extend({{
	type = "recipe",
	name = "vehicle-chaingunner",
	ingredients =
	{
		{"gun-turret", 1},
		{"boiler", 4},
		{"iron-gear-wheel", 8}
	},
	enabled = false,
	energy_required = 5,
	results=
	{
	  {type="item", name="vehicle-chaingunner", amount=1},
	}
}})
