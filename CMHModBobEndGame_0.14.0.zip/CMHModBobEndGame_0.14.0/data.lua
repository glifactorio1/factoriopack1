require("prototypes.recipe.recipes")
require("prototypes.recipe.recipe-updates")
require("prototypes.technology-updates")
require("prototypes.items.items")
