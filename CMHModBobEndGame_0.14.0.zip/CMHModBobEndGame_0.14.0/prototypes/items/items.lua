data:extend({

 {
    type = "item",
    name = "rocket-engine",
    icon = "__CMHModBobEndGame__/graphics/icons/rocket-engine.png",
    flags = { "goes-to-main-inventory" },
    subgroup = "intermediate-product",
    stack_size= 5,
  },

})