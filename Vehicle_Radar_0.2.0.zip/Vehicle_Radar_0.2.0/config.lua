energy_usage = 1000.0 -- kilo Watt
refresh_time = 1.0 -- seconds
scanned_area = 10.0 -- tiles, that are scanned around the train
precognotion = 40.0 -- tiles