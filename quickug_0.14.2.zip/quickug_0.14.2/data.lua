data:extend({
  {
    type = "custom-input",
    name = "QuickUGEnableDisable",
    key_sequence = "CONTROL + u",
  }
})