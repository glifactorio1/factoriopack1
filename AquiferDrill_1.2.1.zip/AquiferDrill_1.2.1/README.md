How to download: Click the .zip file, then click "Raw" to download it  
How to install: Put the .zip file in this folder: C:\Users\your name here\AppData\Roaming\Factorio\mods

That's it!  
Unzipping is not necessary, but if you want to edit the files you can extract the AquiferDrill folder into the mods folder instead.

History:  
1.2.0: compatibility with Factorio 0.13, changed text  
1.1.0: added text, fixed bugs
