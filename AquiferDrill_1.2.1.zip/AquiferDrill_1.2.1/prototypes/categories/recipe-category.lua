data:extend(
{
	{
		type = "recipe-category",
		name = "aquifer-water"
	}
})