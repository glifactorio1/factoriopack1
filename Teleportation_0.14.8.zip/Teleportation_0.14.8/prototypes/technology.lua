data:extend({
  {
    type = "technology",
    name = "teleportation-tech",
    icon = "__Teleportation__/graphics/technology_icon.png",
	  effects =
	  {
	    {
        type = "unlock-recipe",
        recipe = "teleportation-beacon"
      }
	  },
    prerequisites = {"logistic-system", "alien-technology"},
    unit =
    {
      count = 500,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"alien-science-pack", 1}
      },
      time = 60
    }
  }
})
