data:extend({
 {
  type = "recipe",
  name = "sign-post",
  energy_required = 0.5,
  enabled = true,
  category = "crafting",
  ingredients =
  {
    {"iron-plate", 3}
  },
  result= "sign-post"
 }
})
