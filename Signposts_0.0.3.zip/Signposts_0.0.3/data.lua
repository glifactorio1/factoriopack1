require("prototypes.items")
require("prototypes.recipes")