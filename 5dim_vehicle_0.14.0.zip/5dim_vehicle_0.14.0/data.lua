require("config")
--Changes
require("prototypes.changes")
--Air plane
require("prototypes.air-plane")
--Boat
require("prototypes.boat")
--Truck
require("prototypes.truck")
--Tech
require("prototypes.tech")
