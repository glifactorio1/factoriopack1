--Define if vehicles is installed
vehicles = true --Default: True