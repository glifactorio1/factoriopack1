--Damage
globaldmg = 3

--Fire
firedmg = globaldmg*1
firesmalldmg = firedmg * 1
firemediumdmg = firedmg * 1.25
firebigdmg = firedmg * 1.50

--Rocket
rocketdmg = globaldmg*2
rocketsmalldmg = rocketdmg * 1
rocketmediumdmg = rocketdmg * 1.25
rocketbigdmg = rocketdmg * 1.50

--Explosive
explosivedmg = globaldmg*1
explosivesmalldmg = explosivedmg * 1
explosivemediumdmg = explosivedmg * 1.25
explosivebigdmg = explosivedmg * 1.50

--Spitter (normal)
spiterdmg = globaldmg*0.5
spitersmalldmg = spiterdmg * 1
spitermediumdmg = spiterdmg * 1.25
spiterbigdmg = spiterdmg * 1.50
spiterbehemothdmg = spiterdmg * 2

--Bitter (normal)
biterdmg = globaldmg*1
bitersmalldmg = biterdmg * 1
bitermediumdmg = biterdmg * 1.25
biterbigdmg = biterdmg * 1.50
biterbehemothdmg = biterdmg * 2

--Health
globalhp = 20

--Bitter
healthsmallbitter = globalhp
healthmediumbitter = globalhp*5
healthbigbitter = globalhp*20
healthbehemothbitter = globalhp*300

--Spitter
healthsmallspitter = healthsmallbitter*0.66
healthmediumspitter = healthmediumbitter*0.66
healthbigspitter = healthbigbitter*0.66
healthbehemothspitter = healthbehemothbitter*0.66


