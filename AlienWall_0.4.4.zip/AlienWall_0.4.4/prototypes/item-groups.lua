data:extend(
{

  {
    type = "item-subgroup",
    name = "structures",
    group = "combat",
    order = "i",
  },
  {
    type = "item-subgroup",
	name = "materials",
	group = "production",
	order = "i",
  }
})