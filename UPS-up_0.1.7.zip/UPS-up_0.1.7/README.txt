After using UPS-up, you must uninstall it for the related save before removing it. The reason for that is that most entities will remain in an inactive state forever. There are 3 ways to unistall UPS-up:

Option 1: 
1. Open your save and klick the UPS-up button.
2. Klick the uninstall button and wait for it to finisch
3. Save your map fast! Entities currently work way to fast and consume a lot of power.
4. Remove the Mod

Option 2: 
1. Remove the Mod
2. Open your save
3. Open the console and enter:
/c local t={"mining-drill", "assembling-machine", "furnace", "radar"} for k, surface in pairs(game.surfaces) do for k, n in pairs(t) do for k, e in pairs(surface.find_entities_filtered({type=n})) do e.active=true end end end

Option 3: 
1. Open the config.lua in the UPS-up mod folder and set "UPS_CONFIG.UNINSTALL" to true, than save
2. Restart Factorio and open your save
3. Wait until uninstalling is finisched an save your map again
4. Remove the Mod