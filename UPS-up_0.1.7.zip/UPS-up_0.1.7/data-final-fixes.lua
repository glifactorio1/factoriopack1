local function increase_energy_by_factor(entity, factor)
	local energystring = ""
	energystring = tostring(string.sub(entity.energy_usage, #entity.energy_usage-1, #entity.energy_usage-1))
	if (energystring == "k" or energystring == "K" or energystring == "M" or energystring == "G" or energystring == "T" or energystring == "P" or energystring == "E" or energystring == "Z" or energystring == "Y") then
		entity.energy_usage = tonumber(string.sub(entity.energy_usage, 1, (#entity.energy_usage - 2))) * factor .. string.sub(entity.energy_usage, (#entity.energy_usage - 1), #entity.energy_usage)
	else
		entity.energy_usage = tonumber(string.sub(entity.energy_usage, 1, (#entity.energy_usage - 1))) * factor .. string.sub(entity.energy_usage, (#entity.energy_usage), #entity.energy_usage)
	end
end

if not data.raw["resource"]["pollution-absorbtion"] then 
	data.raw["resource"]["pollution-absorbtion"] = {
	type = "resource",
	name = "pollution-absorbtion",
	flags = {"not-on-map"},
	emissions_per_tick = -32768,
	stage_counts = {0},
	stages =
	{
	  sheet =
	  {
		filename = "__UPS-up__/graphics/transparent-entity.png",
		priority = "very-low",
		width = 75,
		height = 61,
		frame_count = 4,
		variation_count = 1
	  }
	},
  } 
end

if UPS_CONFIG.SAVE_UPS_SMOKE and not UPS_CONFIG.UNINSTALL then
	data.raw["furnace"]["stone-furnace"].energy_source.smoke = nil
	data.raw["furnace"]["steel-furnace"].energy_source.smoke = nil
	data.raw["boiler"]["boiler"].burner.smoke = nil
	data.raw["generator"]["steam-engine"].smoke = nil
	data.raw["inserter"]["burner-inserter"].energy_source.smoke = nil
	data.raw["mining-drill"]["burner-mining-drill"].energy_source.smoke = nil
	data.raw["car"]["car"].burner.smoke = nil
	data.raw["car"]["tank"].burner.smoke = nil
	data.raw["locomotive"]["diesel-locomotive"].energy_source.smoke = nil
	data.raw["locomotive"]["diesel-locomotive"].stop_trigger = nil
	data.raw["locomotive"]["diesel-locomotive"].stop_trigger = 
	 {
      {
        type = "play-sound",
        sound =
        {
          {
            filename = "__base__/sound/train-breaks.ogg",
            volume = 0.6
          },
        }
      },
    }
end

if UPS_CONFIG.SAVE_UPS_DRAIN and not UPS_CONFIG.UNINSTALL then
	local factor = 1.05
	for key, entity in pairs(data.raw["electric-turret"]) do
		entity.energy_source.drain = "0kW"
	end
	local entity = data.raw["furnace"]["electric-furnace"]
		entity.energy_source.drain = "0kW"
		increase_energy_by_factor(entity, factor)

	for key, entity in pairs(data.raw["assembling-machine"]) do
		entity.energy_source.drain = "0kW"
		increase_energy_by_factor(entity, factor)
	end
	for key, entity in pairs(data.raw["inserter"]) do
		entity.energy_source.drain = "0kW"
		entity.energy_per_movement = entity.energy_per_movement * factor
		entity.energy_per_rotation = entity.energy_per_rotation * factor
	end
	for key, entity in pairs(data.raw["rocket-silo"]) do
		entity.energy_source.drain = "0kW"
	end
end

if UPS_CONFIG.SAVE_UPS_ASSEMBLING_MACHINE and not UPS_CONFIG.UNINSTALL then
	for key, recipe in pairs(data.raw["recipe"]) do
		if recipe.energy_required then
			if tonumber(recipe.energy_required) > 10 then
			elseif tonumber(recipe.energy_required) > 5 then
				recipe.overload_multiplier = 5
			elseif tonumber(recipe.energy_required) > 2 then
				recipe.overload_multiplier = 10
			elseif tonumber(recipe.energy_required) > 0.9 then
				recipe.overload_multiplier = 20
			else
				recipe.overload_multiplier = 30
			end
		else
			recipe.overload_multiplier = 30
		end
	end
	data.raw["recipe"]["rocket-silo"].overload_multiplier = 1
	data.raw["recipe"]["satellite"].overload_multiplier = 1
end