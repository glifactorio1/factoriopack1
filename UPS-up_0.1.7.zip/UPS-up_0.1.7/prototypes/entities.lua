-- This is only a speudo entity here. pollution-absorbtion is created for real in data final fixes for mod compatibility reasons.

-- data:extend(
-- {
-- --pollution-absorbtion-----------------------------------------   
  -- {
    -- type = "resource",
    -- name = "pollution-absorbtion",
    -- flags = {"not-on-map"},
	-- emissions_per_tick = -32768,
    -- stage_counts = {0},
    -- stages =
    -- {
      -- sheet =
      -- {
        -- filename = "__UPS-up__/graphics/transparent-entity.png",
        -- priority = "very-low",
        -- width = 75,
        -- height = 61,
        -- frame_count = 4,
        -- variation_count = 1
      -- }
    -- },
  -- }
  
-- }
-- )

