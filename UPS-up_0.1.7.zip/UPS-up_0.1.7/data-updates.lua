local function increase_energy_by_factor(entity, factor)
	local energystring = ""
	energystring = tostring(string.sub(entity.energy_usage, #entity.energy_usage-1, #entity.energy_usage-1))
	if (energystring == "k" or energystring == "K" or energystring == "M" or energystring == "G" or energystring == "T" or energystring == "P" or energystring == "E" or energystring == "Z" or energystring == "Y") then
		entity.energy_usage = tonumber(string.sub(entity.energy_usage, 1, (#entity.energy_usage - 2))) * factor .. string.sub(entity.energy_usage, (#entity.energy_usage - 1), #entity.energy_usage)
	else
		entity.energy_usage = tonumber(string.sub(entity.energy_usage, 1, (#entity.energy_usage - 1))) * factor .. string.sub(entity.energy_usage, (#entity.energy_usage), #entity.energy_usage)
	end
end

if UPS_CONFIG.SAVE_UPS_ELECTRIC_MINING_DRILL and not UPS_CONFIG.UNINSTALL then
	local entity = data.raw["mining-drill"]["electric-mining-drill"]
	local factor = CONST.LOOP_TIME_IN_TICKS["electric-mining-drill"] / CONST.ACTIVE_TIME_IN_TICKS["electric-mining-drill"]
	increase_energy_by_factor(entity, factor)
	entity.mining_speed = entity.mining_speed * factor
	entity.animations.north.animation_speed = 3
	entity.animations.east.animation_speed = 3
	entity.animations.south.animation_speed = 3
	entity.animations.west.animation_speed = 3
end

if UPS_CONFIG.SAVE_UPS_PUMPJACK and not UPS_CONFIG.UNINSTALL then
	local entity = data.raw["mining-drill"]["pumpjack"]
	local factor = CONST.LOOP_TIME_IN_TICKS["pumpjack"] / CONST.ACTIVE_TIME_IN_TICKS["pumpjack"]
	increase_energy_by_factor(entity, factor)
	entity.mining_speed = entity.mining_speed * factor
	entity.animations.north.animation_speed = 1
end

if UPS_CONFIG.SAVE_UPS_ASSEMBLING_MACHINE and not UPS_CONFIG.UNINSTALL then
	local factor = CONST.LOOP_TIME_IN_TICKS["assembling-machine"] / CONST.ACTIVE_TIME_IN_TICKS["assembling-machine"]
	local entity = data.raw["assembling-machine"]["assembling-machine-1"]
	increase_energy_by_factor(entity, factor)
	entity.energy_source.drain = "3kW"
	entity.crafting_speed = entity.crafting_speed * factor
	entity = data.raw["assembling-machine"]["assembling-machine-2"]
	increase_energy_by_factor(entity, factor)
	entity.energy_source.drain = "5kW"
	entity.crafting_speed = entity.crafting_speed * factor
	entity = data.raw["assembling-machine"]["assembling-machine-3"]
	increase_energy_by_factor(entity, factor)
	entity.energy_source.drain = "7kW"
	entity.crafting_speed = entity.crafting_speed * factor
end

if UPS_CONFIG.SAVE_UPS_FURNACE and not UPS_CONFIG.UNINSTALL then
	local factor = CONST.LOOP_TIME_IN_TICKS["furnace"] / CONST.ACTIVE_TIME_IN_TICKS["furnace"]
	local entity = data.raw["furnace"]["electric-furnace"]
	increase_energy_by_factor(entity, factor)
	entity.energy_source.drain = "6kW"
	entity.crafting_speed = entity.crafting_speed * factor
	entity = data.raw["furnace"]["steel-furnace"]
	increase_energy_by_factor(entity, factor)
	entity.crafting_speed = entity.crafting_speed * factor
	entity = data.raw["furnace"]["stone-furnace"]
	increase_energy_by_factor(entity, factor)
	entity.crafting_speed = entity.crafting_speed * factor
end

if UPS_CONFIG.SAVE_UPS_CHEMICAL_PLANT and not UPS_CONFIG.UNINSTALL then
	local factor = CONST.LOOP_TIME_IN_TICKS["chemical-plant"] / CONST.ACTIVE_TIME_IN_TICKS["chemical-plant"]
	local entity = data.raw["assembling-machine"]["chemical-plant"]
	increase_energy_by_factor(entity, factor)
	entity.energy_source.drain = "7kW"
	entity.crafting_speed = entity.crafting_speed * factor
end

if UPS_CONFIG.SAVE_UPS_OIL_REFINERY and not UPS_CONFIG.UNINSTALL then
	local factor = CONST.LOOP_TIME_IN_TICKS["oil-refinery"] / CONST.ACTIVE_TIME_IN_TICKS["oil-refinery"]
	local entity = data.raw["assembling-machine"]["oil-refinery"]
	increase_energy_by_factor(entity, factor)
	entity.energy_source.drain = "14kW"
	entity.crafting_speed = entity.crafting_speed * factor
end

if UPS_CONFIG.SAVE_UPS_RADAR and not UPS_CONFIG.UNINSTALL then
	data.raw["radar"]["radar"].energy_usage = "2500kW"
    data.raw["radar"]["radar"].energy_per_sector = "6MJ"
end

--Equalize power-spikes caused by the mod
data.raw["accumulator"]["accumulator"].energy_source.input_flow_limit = "900kW"
data.raw["accumulator"]["accumulator"].energy_source.output_flow_limit = "900kW"