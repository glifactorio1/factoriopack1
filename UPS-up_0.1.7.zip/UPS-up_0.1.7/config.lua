if not UPS_CONFIG then UPS_CONFIG = {} end
-- You can change this value to "true" and load your modded save to uninstall UPS-up on a save. Save the file and remove UPS-up afterwards. You may also use the ingame gui to uninstall UPS-up.
UPS_CONFIG.UNINSTALL = false

-- These options can only be set in this config file. Factorio needs to be restarted after change. Any change is global for all saves with this mod. 
-- Default value is true. Changing this will cause multiplayer compatibility issues, when running different values
UPS_CONFIG.SAVE_UPS_ELECTRIC_MINING_DRILL = true
UPS_CONFIG.SAVE_UPS_PUMPJACK = true
UPS_CONFIG.SAVE_UPS_ASSEMBLING_MACHINE = true
UPS_CONFIG.SAVE_UPS_FURNACE = true
UPS_CONFIG.SAVE_UPS_CHEMICAL_PLANT = true
UPS_CONFIG.SAVE_UPS_OIL_REFINERY = true
UPS_CONFIG.SAVE_UPS_BEACON = false -- not implemented yet
UPS_CONFIG.SAVE_UPS_RADAR = true
UPS_CONFIG.SAVE_UPS_SMOKE = true
UPS_CONFIG.SAVE_UPS_DRAIN = true
UPS_CONFIG.SHOWGUI = true -- changing not recommended, turn on "Hide Top-button 10 seconds after loading the save" in the ingame gui instead.





--------------------------------------------------------------------------------------

-- These options must be set ingame! You can only change the default value here. This will not affect saves that have the mod already installed.
UPS_CONFIG.REMOVE_DECORATIVES = true
UPS_CONFIG.REMOVE_FISH = true
UPS_CONFIG.REMOVE_CORPSES = true
UPS_CONFIG.REMOVE_ALIEN_ARTIFACTS_ON_GROUND = true
UPS_CONFIG.REMOVE_OTHER_ITEMS_ON_GROUND = true
UPS_CONFIG.REMOVE_POLLUTION = false
UPS_CONFIG.ADMIN_ONLY = false

-- Just some constants used by the mod
if not CONST											then CONST = {} end
if not CONST.LOOP_TIME_IN_TICKS							then CONST.LOOP_TIME_IN_TICKS = {} end
if not CONST.ACTIVE_TIME_IN_TICKS						then CONST.ACTIVE_TIME_IN_TICKS = {} end
CONST.LOOP_TIME_IN_TICKS["electric-mining-drill"] = 115 --Time of mining-drill activation/deactivation cycle
CONST.ACTIVE_TIME_IN_TICKS["electric-mining-drill"] = 10 --Therefrom the time that the miner is actually active
CONST.LOOP_TIME_IN_TICKS["pumpjack"] = 150
CONST.ACTIVE_TIME_IN_TICKS["pumpjack"] = 10
CONST.LOOP_TIME_IN_TICKS["assembling-machine"] = 150
CONST.ACTIVE_TIME_IN_TICKS["assembling-machine"] = 50
CONST.LOOP_TIME_IN_TICKS["furnace"] = 160
CONST.ACTIVE_TIME_IN_TICKS["furnace"] = 20
CONST.LOOP_TIME_IN_TICKS["chemical-plant"] = 300
CONST.ACTIVE_TIME_IN_TICKS["chemical-plant"] = 20
CONST.LOOP_TIME_IN_TICKS["oil-refinery"] = 120
CONST.ACTIVE_TIME_IN_TICKS["oil-refinery"] = 10
CONST.LOOP_TIME_IN_TICKS["beacon"] = 1000
CONST.ACTIVE_TIME_IN_TICKS["beacon"] = 1000
CONST.LOOP_TIME_IN_TICKS["radar"] = 300
CONST.ACTIVE_TIME_IN_TICKS["radar"] = 20
CONST.SELLOUT_DISPLAY_TICK = 216000 --Sellout after 1h
CONST.SELLOUT_RESET_TICK = 5400000 --Sellout every 25h
