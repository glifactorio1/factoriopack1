if not global.trigger									then global.trigger = {} end
if not global.trigger.on_options_changed 				then global.trigger.on_options_changed = {} end

if not global.option									then global.option = {} end
if global.option["column-name"] == nil 					then global.option["column-name"] = false end
if global.option["decorative"] == nil 					then global.option["decorative"] = UPS_CONFIG.REMOVE_DECORATIVES; global.trigger.on_options_changed["decorative"] = true end
if global.option["fish"] == nil 						then global.option["fish"] = UPS_CONFIG.REMOVE_FISH; global.trigger.on_options_changed["fish"] = true end
if global.option["corpse"] == nil 						then global.option["corpse"] = UPS_CONFIG.REMOVE_CORPSES; global.trigger.on_options_changed["corpse"] = true end
if global.option["alien-artifact-on-ground"] == nil 	then global.option["alien-artifact-on-ground"] = UPS_CONFIG.REMOVE_ALIEN_ARTIFACTS_ON_GROUND; global.trigger.on_options_changed["alien-artifact-on-ground"] = true end
if global.option["other-item-on-ground"] == nil 		then global.option["other-item-on-ground"] = UPS_CONFIG.REMOVE_OTHER_ITEMS_ON_GROUND; global.trigger.on_options_changed["other-item-on-ground"] = true end
if global.option["pollution-absorbtion"] == nil 		then global.option["pollution-absorbtion"] = UPS_CONFIG.REMOVE_POLLUTION; global.trigger.on_options_changed["pollution-absorbtion"] = true end
if global.option["admin-only"] == nil 					then global.option["admin-only"] = UPS_CONFIG.ADMIN_ONLY end
if global.option["smoke"] == nil 						then global.option["smoke"] = UPS_CONFIG.SAVE_UPS_SMOKE; global.trigger.on_options_changed["smoke"] = true end
if global.option["electric-mining-drill"] == nil 		then global.option["electric-mining-drill"] = UPS_CONFIG.SAVE_UPS_ELECTRIC_MINING_DRILL; global.trigger.on_options_changed["electric-mining-drill"] = true end
if global.option["pumpjack"] == nil 					then global.option["pumpjack"] = UPS_CONFIG.SAVE_UPS_PUMPJACK; global.trigger.on_options_changed["pumpjack"] = true end
if global.option["assembling-machine"] == nil 			then global.option["assembling-machine"] = UPS_CONFIG.SAVE_UPS_ASSEMBLING_MACHINE; global.trigger.on_options_changed["assembling-machine"] = true end
if global.option["furnace"] == nil 						then global.option["furnace"] = UPS_CONFIG.SAVE_UPS_FURNACE; global.trigger.on_options_changed["furnace"] = true end
if global.option["chemical-plant"] == nil 				then global.option["chemical-plant"] = UPS_CONFIG.SAVE_UPS_CHEMICAL_PLANT; global.trigger.on_options_changed["chemical-plant"] = true end
if global.option["oil-refinery"] == nil 				then global.option["oil-refinery"] = UPS_CONFIG.SAVE_UPS_OIL_REFINERY; global.trigger.on_options_changed["oil-refinery"] = true end
if global.option["beacon"] == nil 						then global.option["beacon"] = UPS_CONFIG.SAVE_UPS_BEACON; global.trigger.on_options_changed["beacon"] = true end
if global.option["drain"] == nil 						then global.option["drain"] = UPS_CONFIG.SAVE_UPS_DRAIN; global.trigger.on_options_changed["drain"] = true end
if global.option["radar"] == nil 						then global.option["radar"] = UPS_CONFIG.SAVE_UPS_RADAR; global.trigger.on_options_changed["radar"] = true end
if global.option["show-gui"] == nil 					then global.option["show-gui"] = UPS_CONFIG.SHOWGUI end
if global.option["uninstall"] == nil 					then global.option["showuninstallgui"] = UPS_CONFIG.UNINSTALL end

if not global.array 									then global.array = {} end
if not global.array["electric-mining-drill"] 			then global.array["electric-mining-drill"] = {} end
if not global.array["pumpjack"] 						then global.array["pumpjack"] = {} end
if not global.array["assembling-machine"] 				then global.array["assembling-machine"] = {} end
if not global.array["furnace"] 							then global.array["furnace"] = {} end
if not global.array["chemical-plant"] 					then global.array["chemical-plant"] = {} end
if not global.array["oil-refinery"] 					then global.array["oil-refinery"] = {} end
if not global.array["beacon"]							then global.array["beacon"] = {} end
if not global.array["radar"] 							then global.array["radar"] = {} end

if not global.counter 									then global.counter = {} end
if not global.counter.active							then global.counter.active = {} end
if not global.counter.inactive							then global.counter.inactive = {} end
if not global.counter.active["electric-mining-drill"]  	then global.counter.active["electric-mining-drill"] = CONST.ACTIVE_TIME_IN_TICKS["electric-mining-drill"] + 1 end
if not global.counter.inactive["electric-mining-drill"] then global.counter.inactive["electric-mining-drill"] = 1 end
if not global.counter.active["pumpjack"]  				then global.counter.active["pumpjack"] = CONST.ACTIVE_TIME_IN_TICKS["pumpjack"] + 1 end
if not global.counter.inactive["pumpjack"]  			then global.counter.inactive["pumpjack"] = 1 end
if not global.counter.active["assembling-machine"]  	then global.counter.active["assembling-machine"] = CONST.ACTIVE_TIME_IN_TICKS["assembling-machine"] + 1 end
if not global.counter.inactive["assembling-machine"]  	then global.counter.inactive["assembling-machine"] = 1 end
if not global.counter.active["furnace"]  				then global.counter.active["furnace"] = CONST.ACTIVE_TIME_IN_TICKS["furnace"] + 1 end
if not global.counter.inactive["furnace"]  				then global.counter.inactive["furnace"] = 1 end
if not global.counter.active["chemical-plant"]  		then global.counter.active["chemical-plant"] = CONST.ACTIVE_TIME_IN_TICKS["chemical-plant"] + 1 end
if not global.counter.inactive["chemical-plant"]  		then global.counter.inactive["chemical-plant"] = 1 end
if not global.counter.active["oil-refinery"]  			then global.counter.active["oil-refinery"] = CONST.ACTIVE_TIME_IN_TICKS["oil-refinery"] + 1 end
if not global.counter.inactive["oil-refinery"]  		then global.counter.inactive["oil-refinery"] = 1 end
if not global.counter.active["beacon"]  				then global.counter.active["beacon"] = CONST.ACTIVE_TIME_IN_TICKS["beacon"] + 1 end
if not global.counter.inactive["beacon"]  				then global.counter.inactive["beacon"] = 1 end
if not global.counter.active["radar"]  					then global.counter.active["radar"] = CONST.ACTIVE_TIME_IN_TICKS["radar"] + 1 end
if not global.counter.inactive["radar"]  				then global.counter.inactive["radar"] = 1 end
if not global.counter.slow_update  						then global.counter.slow_update = 1 end
if not global.counter.sellout  							then global.counter.sellout = 0 end



