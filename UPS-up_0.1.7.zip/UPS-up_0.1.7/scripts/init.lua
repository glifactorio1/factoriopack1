if not init then init = {} end


local function step_topbutton()
	gui.hide_topbutton("all") --Destroys the main butten at the top
	if global.option["show-gui"] then
		gui.show_topbutton("all") --Creates the main butten at the top
	end
end


local function UninstallUPS()
	global.array["electric-mining-drill"] = {}
	global.array["pumpjack"] = {}
	global.array["assembling-machine"] = {}
	global.array["furnace"] = {}
	global.array["beacon"] = {}
	global.array["chemical-plant"] = {}
	global.array["oil-refinery"] = {}
	global.array["radar"] = {}
	global.trigger = {}
	global.trigger.on_options_changed = {}
	global.initStep = nil
	global.option["uninstall"] = UPS_CONFIG.UNINSTALL
	util.remove_all({name="pollution-absorbtion"})
	for key, surface in pairs(game.surfaces) do
		for key, entity in pairs(surface.find_entities_filtered({name="pollution-absorbtion"})) do
			entity.destroy()
		end
		for key, entity in pairs(surface.find_entities_filtered({type="mining-drill"})) do
			entity.active=true
		end
		for key, entity in pairs(surface.find_entities_filtered({type="assembling-machine"})) do
			entity.active=true
		end
		for key, entity in pairs(surface.find_entities_filtered({type="furnace"})) do
			entity.active=true
		end
		for key, entity in pairs(surface.find_entities_filtered({type="beacon"})) do
			entity.active=true
		end
		for key, entity in pairs(surface.find_entities_filtered({name="radar"})) do
			entity.active=true
		end
	end
	util.print_admins({"message.PRINT_Uninstall-finished"})	
end


local function step_decoratives()
	local number_of_removed_entities 
	if global.option["decorative"] and global.trigger.full_install then
		number_of_removed_entities = util.remove_all({type="decorative", chunkwise=true})
		if number_of_removed_entities ~= 0 then
			util.print_admins({"message.PRINT_decoratives-removed", number_of_removed_entities})
		elseif number_of_removed_entities == 0 and global.trigger.on_options_changed["decorative"] then
			util.print_admins({"message.PRINT_decoratives-removed", 0})
		end
	else
		if global.trigger.on_options_changed["decorative"] then
			util.print_admins({"message.PRINT_Decoratives-are-not-removed-on-chunk-generation-anymore"})
		end
	end
	global.trigger.on_options_changed["decorative"] = nil
end

	
local function step_fish()
	local number_of_removed_entities 
	if global.option["fish"] and global.trigger.full_install then
		number_of_removed_entities = util.remove_all({name="fish"})
		if number_of_removed_entities ~= 0 then
			util.print_admins({"message.PRINT_fish-removed", number_of_removed_entities})
		elseif number_of_removed_entities == 0 and global.trigger.on_options_changed["fish"] then
			util.print_admins({"message.PRINT_fish-removed", 0})
		end
	else
		if global.trigger.on_options_changed["fish"] then
			util.print_admins({"message.PRINT_Fish-are-not-removed-on-chunk-generation-anymore"})
		end
	end
	global.trigger.on_options_changed["fish"] = nil
end	


function step_alienArtifactsOnGround()
	local number_of_removed_entities 
	if global.option["alien-artifact-on-ground"] then
		number_of_removed_entities = util.remove_all({name="alien-artifact"})
		if number_of_removed_entities ~= 0 then
			util.print_admins({"message.PRINT_alien-artifact-on-ground-removed", number_of_removed_entities})
		elseif number_of_removed_entities == 0 and global.trigger.on_options_changed["alien-artifact-on-ground"] then
			util.print_admins({"message.PRINT_alien-artifact-on-ground-removed", 0})
		end
	end
	global.trigger.on_options_changed["alien-artifact-on-ground"] = nil
end	


function step_otherItemsOnGround()
	local number_of_removed_entities 
	if global.option["other-item-on-ground"] then
		number_of_removed_entities = util.remove_all({name="other-item-on-ground"})
		if number_of_removed_entities ~= 0 then
			util.print_admins({"message.PRINT_other-items-on-ground-removed", number_of_removed_entities})
		elseif number_of_removed_entities == 0 and global.trigger.on_options_changed["other-item-on-ground"] then
			util.print_admins({"message.PRINT_other-items-on-ground-removed", 0})
		end
	end
	global.trigger.on_options_changed["other-item-on-ground"] = nil
end	


function step_corpses()
	local number_of_removed_entities 
	if global.option["corpse"] then
		number_of_removed_entities = util.remove_all({type="corpse"})
		if number_of_removed_entities ~= 0 then
			util.print_admins({"message.PRINT_corpses-removed", number_of_removed_entities})
		elseif number_of_removed_entities == 0 and global.trigger.on_options_changed["corpse"] then
			util.print_admins({"message.PRINT_corpses-removed", 0})
		end
	end
	global.trigger.on_options_changed["corpse"] = nil
end	


local function step_pollution() 
	if global.trigger.full_install then
		util.remove_all({name="pollution-absorbtion"})
		if global.option["pollution-absorbtion"] then
			for key, surface in pairs(game.surfaces) do
				for coord in surface.get_chunks() do 
					surface.create_entity{name="pollution-absorbtion", position={coord.x * 32+16, coord.y * 32+16}}
				end
			end
			util.print_admins({"message.PRINT_Pollution-disabled"})
		elseif global.trigger.on_options_changed["pollution-absorbtion"] then
			util.print_admins({"message.PRINT_Pollution-enabled"})
		end
	end
	global.trigger.on_options_changed["pollution-absorbtion"] = nil
end


local function step_electric_mining_drill()
	local array_length = 0
	if global.option["electric-mining-drill"] and (global.trigger.full_install or global.trigger.on_options_changed["electric-mining-drill"]) then
		global.array["electric-mining-drill"] = {}
		for key, surface in pairs(game.surfaces) do
			for key, entity in pairs(surface.find_entities_filtered({name="electric-mining-drill"})) do
				array_length = array_length + 1
				global.array["electric-mining-drill"][array_length] = entity
				entity.active = false	
			end
		end
		util.shuffle_array(global.array["electric-mining-drill"])
		util.print_admins({"message.PRINT_Made-electric-mining-drills-more-UPS-efficient", array_length})
	elseif global.option["electric-mining-drill"] == false then
		for i=1, #global.array["electric-mining-drill"] do
			global.array["electric-mining-drill"][i].active = true
		end
		global.array["electric-mining-drill"] = {}
		if global.trigger.on_options_changed["electric-mining-drill"] then
			util.print_admins({"message.PRINT_Reverted-behavior-of-electric-mining-drills-to-normal"})
		end
	end
	global.trigger.on_options_changed["electric-mining-drill"] = nil
end


local function step_pumpjack()
	local array_length = 0
	if global.option["pumpjack"] and (global.trigger.full_install or global.trigger.on_options_changed["pumpjack"]) then
		global.array["pumpjack"] = {}
		for key, surface in pairs(game.surfaces) do
			for key, entity in pairs(surface.find_entities_filtered({name="pumpjack"})) do
				array_length = array_length + 1
				global.array["pumpjack"][array_length] = entity
				entity.active = false	
			end
		end
		util.shuffle_array(global.array["pumpjack"])
		util.print_admins({"message.PRINT_Made-pumpjacks-more-UPS-efficient", array_length})
	elseif global.option["pumpjack"] == false then
		for i=1, #global.array["pumpjack"] do
			global.array["pumpjack"][i].active = true
		end
		global.array["pumpjack"] = {}
		if global.trigger.on_options_changed["pumpjack"] then
			util.print_admins({"message.PRINT_Reverted-behavior-of-pumpjacks-to-normal"})
		end
	end
	global.trigger.on_options_changed["pumpjack"] = nil
end


local function step_assembling_machine()
	local array_length = 0
	if global.option["assembling-machine"] and (global.trigger.full_install or global.trigger.on_options_changed["assembling-machine"]) then
		global.array["assembling-machine"] = {}
		for key, surface in pairs(game.surfaces) do
			for key, entity in pairs(surface.find_entities_filtered({type="assembling-machine"})) do
				if entity.name == "assembling-machine-1" or entity.name == "assembling-machine-2" or entity.name == "assembling-machine-3" then
					array_length = array_length + 1
					global.array["assembling-machine"][array_length] = entity
					entity.active = false	
				end
			end
		end
		util.print_admins({"message.PRINT_Made-assembling-machines-more-UPS-efficient", array_length})
	elseif global.option["assembling-machine"] == false then
		for i=1, #global.array["assembling-machine"] do
			global.array["assembling-machine"][i].active = true
		end
		util.shuffle_array(global.array["assembling-machine"])
		global.array["assembling-machine"] = {}
		if global.trigger.on_options_changed["assembling-machine"] then
			util.print_admins({"message.PRINT_Reverted-behavior-of-assembling-machines-to-normal"})
		end
	end
	global.trigger.on_options_changed["assembling-machine"] = nil
end


local function step_furnace()
	local array_length = 0
	if global.option["furnace"] and (global.trigger.full_install or global.trigger.on_options_changed["furnace"]) then
		global.array["furnace"] = {}
		for key, surface in pairs(game.surfaces) do
			for key, entity in pairs(surface.find_entities_filtered({type="furnace"})) do
				if entity.name == "electric-furnace" or entity.name == "steel-furnace" or entity.name == "stone-furnace" then
					array_length = array_length + 1
					global.array["furnace"][array_length] = entity
					entity.active = false	
				end
			end
		end
		util.shuffle_array(global.array["furnace"])
		util.print_admins({"message.PRINT_Made-furnaces-more-UPS-efficient", array_length})
	elseif global.option["furnace"] == false then
		for i=1, #global.array["furnace"] do
			global.array["furnace"][i].active = true
		end
		global.array["furnace"] = {}
		if global.trigger.on_options_changed["furnace"] then
			util.print_admins({"message.PRINT_Reverted-behavior-of-furnaces-to-normal"})
		end
	end
	global.trigger.on_options_changed["furnace"] = nil
end


local function step_chemical_plant()
	local array_length = 0
	if global.option["chemical-plant"] and (global.trigger.full_install or global.trigger.on_options_changed["chemical-plant"]) then
		global.array["chemical-plant"] = {}
		for key, surface in pairs(game.surfaces) do
			for key, entity in pairs(surface.find_entities_filtered({name="chemical-plant"})) do
				array_length = array_length + 1
				global.array["chemical-plant"][array_length] = entity
				entity.active = false	
			end
		end
		util.shuffle_array(global.array["chemical-plant"])
		util.print_admins({"message.PRINT_Made-chemical-plants-more-UPS-efficient", array_length})
	elseif global.option["chemical-plant"] == false then
		for i=1, #global.array["chemical-plant"] do
			global.array["chemical-plant"][i].active = true
		end
		global.array["chemical-plant"] = {}
		if global.trigger.on_options_changed["chemical-plant"] then
			util.print_admins({"message.PRINT_Reverted-behavior-of-chemical-plants-to-normal"})
		end
	end
	global.trigger.on_options_changed["chemical-plant"] = nil
end


local function step_oil_refinery()
	local array_length = 0
	if global.option["oil-refinery"] and (global.trigger.full_install or global.trigger.on_options_changed["oil-refinery"]) then
		global.array["oil-refinery"] = {}
		for key, surface in pairs(game.surfaces) do
			for key, entity in pairs(surface.find_entities_filtered({name="oil-refinery"})) do
				array_length = array_length + 1
				global.array["oil-refinery"][array_length] = entity
				entity.active = false	
			end
		end
		util.shuffle_array(global.array["oil-refinery"])
		util.print_admins({"message.PRINT_Made-oil-refineries-more-UPS-efficient", array_length})
	elseif global.option["oil-refinery"] == false then
		for i=1, #global.array["oil-refinery"] do
			global.array["oil-refinery"][i].active = true
		end
		global.array["oil-refinery"] = {}
		if global.trigger.on_options_changed["oil-refinery"] then
			util.print_admins({"message.PRINT_Reverted-behavior-of-oil-refineries-to-normal"})
		end
	end
	global.trigger.on_options_changed["oil-refinery"] = nil
end


local function step_beacon()
	local array_length = 0
	if global.option["beacon"] and (global.trigger.full_install or global.trigger.on_options_changed["beacon"]) then
		global.array["beacon"] = {}
		for key, surface in pairs(game.surfaces) do
			for key, entity in pairs(surface.find_entities_filtered({name="beacon"})) do
				array_length = array_length + 1
				global.array["beacon"][array_length] = entity
				entity.active = false	
			end
		end
		util.shuffle_array(global.array["beacon"])
		util.print_admins({"message.PRINT_Made-beacons-more-UPS-efficient", array_length})
	elseif global.option["beacon"] == false then
		for i=1, #global.array["beacon"] do
			global.array["beacon"][i].active = true
		end
		global.array["beacon"] = {}
		if global.trigger.on_options_changed["beacon"] then
			util.print_admins({"message.PRINT_Reverted-behavior-of-beacons-to-normal"})
		end
	end
	global.trigger.on_options_changed["beacon"] = nil
end


local function step_radar()
	local array_length = 0
	if global.option["radar"] and (global.trigger.full_install or global.trigger.on_options_changed["radar"]) then
		global.array["radar"] = {}
		for key, surface in pairs(game.surfaces) do
			for key, entity in pairs(surface.find_entities_filtered({name="radar"})) do
				array_length = array_length + 1
				global.array["radar"][array_length] = entity
				entity.active = false	
			end
		end
		util.shuffle_array(global.array["radar"])
		util.print_admins({"message.PRINT_Made-radars-more-UPS-efficient", array_length})
	elseif global.option["radar"] == false then
		for i=1, #global.array["radar"] do
			global.array["radar"][i].active = true
		end
		global.array["radar"] = {}
		if global.trigger.on_options_changed["radar"] then
			util.print_admins({"message.PRINT_Reverted-behavior-of-radars-to-normal"})
		end
	end
	global.trigger.on_options_changed["radar"] = nil
end


local function step_drain()
	if global.option["drain"] then
		if global.trigger.on_options_changed["drain"] then
			util.print_admins({"message.PRINT_Made-drain-more-UPS-efficient"})
		end
	elseif global.trigger.on_options_changed["drain"] then
		util.print_admins({"message.PRINT_Reverted-behavior-of-drain-to-normal"})
	end
	global.trigger.on_options_changed["drain"] = nil
end


local function step_smoke()
	if global.option["smoke"] then
		if global.trigger.on_options_changed["smoke"] then
			util.print_admins({"message.PRINT_Smoke-reduced"})
		end
	elseif global.trigger.on_options_changed["smoke"] then
		util.print_admins({"message.PRINT_Reverted-behavior-of-smoke-to-normal"})
	end
	global.trigger.on_options_changed["smoke"] = nil
end


local function step_admin_only()
	if global.option["admin-only"] then
		if global.trigger.on_options_changed["admin-only"] then
			util.print_admins({"message.PRINT_admin-only-mode-enabled"})
		end
	elseif global.trigger.on_options_changed["admin-only"] then
		util.print_admins({"message.PRINT_admin-only-mode-disabled"})
	end
	global.trigger.on_options_changed["admin-only"] = nil
end


function init.initialize() --called by events.on_tick()
--Mod initialization: Runs the first time the mod is started, the mod/Factorio is updated or the config has changed
	if global.initStep == nil then
		global.initStep = 0
	elseif global.initStep==0 then
		for key, allplayer in pairs(game.players) do
			allplayer.force.reset_recipes()
		end	
		global.initStep = 1
	elseif global.initStep==1 then		--Initialising text
		util.print_admins("----------------------------------------")
		util.print_admins({"message.PRINT_Initialising-Please-wait"})
		step_topbutton()
		if global.option["uninstall"] then
			UninstallUPS()
			return
		end
		global.initStep=2			
	elseif global.initStep==2 then
		step_electric_mining_drill()
		global.initStep=3
	elseif global.initStep==3 then
		step_pumpjack()
		global.initStep=4
	elseif global.initStep==4 then
		step_assembling_machine()
		global.initStep=5
	elseif global.initStep==5 then
		step_furnace()
		global.initStep=6
	elseif global.initStep==6 then
		step_chemical_plant()
		step_oil_refinery()
		global.initStep=7
	elseif global.initStep==7 then
		--step_beacon()
		step_radar()
		step_drain()
		step_smoke()
		global.initStep=15
	elseif global.initStep==15 then	--Triggers "UPS-up Options" gui
		if (global.option["show-gui"] and global.trigger.show_options) then
			for key, player in pairs(game.players) do
				if player.admin and player.connected then
					gui.show_options(player)
				end
			end	
			global.trigger.initialize = nil
			global.initStep = nil
		else
			global.initStep=21
		end
	elseif global.initStep==11 then	--fixes a bug of 0.1.3
		global.initStep=nil
	elseif global.initStep==20 then	--gui.lua will set global.initStep=20 when pressing the "done" button
		util.print_admins({"message.PRINT_Applying-changes-Please-wait"})
		global.initStep=21
	elseif global.initStep==21 then
		step_topbutton()
		step_decoratives()
		global.initStep=22
	elseif global.initStep==22 then
		step_fish()
		global.initStep=23
	elseif global.initStep==23 then
		step_alienArtifactsOnGround()
		step_otherItemsOnGround()
		step_corpses()
		global.initStep=24						
	elseif global.initStep==24 then
		step_pollution()
		step_admin_only()
		global.initStep=30				
	elseif global.initStep==30 then	--Initialising finished
		util.print_admins({"message.PRINT_Initialising-finished"})	
		global.trigger = {}
		global.trigger.on_options_changed = {}
		global.initStep = nil
	end
end