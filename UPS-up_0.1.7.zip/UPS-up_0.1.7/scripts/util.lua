if not util then util = {} end

function util.print_admins(massage)
	if global.option["admin-only"] then
		for key, player in pairs(game.players) do
			if player.admin and player.connected then
				player.print(massage)
			end
		end
	else
		for key, player in pairs(game.players) do
			if player.connected then
				player.print(massage)
			end
		end
	end
end

function util.remove_all(arg)
	-- Parameters: 
	-- name=String --Remove entity by name if set
	-- type=String --Remove entity by name if set and name is not set
	-- chunkwise=bool --Remove entity chunkwise (saves RAM, but slow. Use only for big number of entites)
--special cases
	local counter = 0
	if arg.name=="alien-artifact" then
		for key, surface in pairs(game.surfaces) do
			for key, entity in pairs(surface.find_entities_filtered({name ="item-on-ground"})) do
				if entity.stack.name=='alien-artifact' then
					entity.destroy()
					counter = counter+1
				end
			end
		end
	elseif arg.name=="other-item-on-ground" then
		for key, surface in pairs(game.surfaces) do
			for key, entity in pairs(surface.find_entities_filtered({name ="item-on-ground"})) do
				if entity.stack.name~='alien-artifact' then
					entity.destroy()
					counter = counter+1
				end
			end
		end
	elseif arg.type == "decorative" then
		for key, surface in pairs(game.surfaces) do
			for chunk in surface.get_chunks() do
				for key, entity in pairs(surface.find_entities_filtered{area = {{chunk.x*32, chunk.y*32}, {chunk.x*32+32, chunk.y*32+32}}, type=arg.type}) do
					if (
					entity.name == "brown-asterisk" or 
					entity.name == "brown-cane-cluster" or 
					entity.name == "brown-carpet-grass" or 
					entity.name == "brown-coral-mini" or
					entity.name == "brown-fluff" or 
					entity.name == "brown-fluff-dry" or 
					entity.name == "brown-hairy-grass" or
					entity.name == "garballo" or 
					entity.name == "garballo-mini-dry" or 
					entity.name == "green-asterisk" or
					entity.name == "green-bush-mini" or 
					entity.name == "green-carpet-grass" or 
					entity.name == "green-coral-mini" or
					entity.name == "green-hairy-grass" or 
					entity.name == "green-pita" or 
					entity.name == "green-pita-mini" or
					entity.name == "green-small-grass" or 
					entity.name == "orange-coral-mini" or 
					entity.name == "red-asterisk" or
					entity.name == "root-A" or
					entity.name == "small-rock"
					) then
						entity.destroy()
						counter = counter+1
					end
				end
			end
		end		
--chunkwise removing
	elseif arg.chunkwise then
		if arg.name then
			for key, surface in pairs(game.surfaces) do
				for chunk in surface.get_chunks() do
					for key, entity in pairs(surface.find_entities_filtered{area = {{chunk.x*32, chunk.y*32}, {chunk.x*32+32, chunk.y*32+32}}, name=arg.name}) do
						entity.destroy()
						counter = counter+1
					end
				end
			end	
		elseif arg.type then
			for key, surface in pairs(game.surfaces) do
				for chunk in surface.get_chunks() do
					for key, entity in pairs(surface.find_entities_filtered{area = {{chunk.x*32, chunk.y*32}, {chunk.x*32+32, chunk.y*32+32}}, type=arg.type}) do
						entity.destroy()
						counter = counter+1
					end
				end
			end	
		else
			util.print_admins("Error in function util.remove_all_name. Parameter not set (name or type)")
			return		
		end
--not chunkwise removing
	else
		if arg.name then
			for key, surface in pairs(game.surfaces) do	
				for key, entity in pairs(surface.find_entities_filtered({name=arg.name})) do
					entity.destroy()
					counter = counter+1
				end
			end
		elseif arg.type then
			for key, surface in pairs(game.surfaces) do	
				for key, entity in pairs(surface.find_entities_filtered({type=arg.type})) do
					entity.destroy()
					counter = counter+1
				end
			end	
		else
			util.print_admins("Error in function util.remove_all_name. Parameter not set (name or type)")
			return		
		end	
	end
	return counter
end

function util.shuffle_array( t )
    local j
    for i = #t, 2, -1 do
        j = math.random(1,i)
        t[i], t[j] = t[j], t[i]
    end
end