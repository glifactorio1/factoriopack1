if not events then events = {} end


local function check_config_changed() 
--check weather changes have been made to the global config
	if not global.trigger.initialize then
		if global.option["uninstall"] ~= UPS_CONFIG.UNINSTALL then
			global.trigger.on_options_changed["uninstall"] = true
			global.option["uninstall"] = UPS_CONFIG.UNINSTALL
			global.trigger.initialize = true
		end
	end
	if global.option["smoke"] ~= UPS_CONFIG.SAVE_UPS_SMOKE then
		global.trigger.on_options_changed["smoke"] = true
		global.option["smoke"] = UPS_CONFIG.SAVE_UPS_SMOKE
		global.trigger.initialize = true
	end
	if global.option["electric-mining-drill"] ~= UPS_CONFIG.SAVE_UPS_ELECTRIC_MINING_DRILL then
		global.trigger.on_options_changed["electric-mining-drill"] = true
		global.option["electric-mining-drill"] = UPS_CONFIG.SAVE_UPS_ELECTRIC_MINING_DRILL
		global.trigger.initialize = true
	end
	if global.option["pumpjack"] ~= UPS_CONFIG.SAVE_UPS_PUMPJACK then
		global.trigger.on_options_changed["pumpjack"] = true
		global.option["pumpjack"] = UPS_CONFIG.SAVE_UPS_PUMPJACK
		global.trigger.initialize = true
	end
	if global.option["assembling-machine"] ~= UPS_CONFIG.SAVE_UPS_ASSEMBLING_MACHINE then
		global.trigger.on_options_changed["assembling-machine"] = true
		global.option["assembling-machine"] = UPS_CONFIG.SAVE_UPS_ASSEMBLING_MACHINE
		global.trigger.initialize = true
	end
	if global.option["furnace"] ~= UPS_CONFIG.SAVE_UPS_FURNACE then
		global.trigger.on_options_changed["furnace"] = true
		global.option["furnace"] = UPS_CONFIG.SAVE_UPS_FURNACE
		global.trigger.initialize = true
	end
	if global.option["chemical-plant"] ~= UPS_CONFIG.SAVE_UPS_CHEMICAL_PLANT then
		global.trigger.on_options_changed["chemical-plant"] = true
		global.option["chemical-plant"] = UPS_CONFIG.SAVE_UPS_CHEMICAL_PLANT
		global.trigger.initialize = true
	end
	if global.option["oil-refinery"] ~= UPS_CONFIG.SAVE_UPS_OIL_REFINERY then
		global.trigger.on_options_changed["oil-refinery"] = true
		global.option["oil-refinery"] = UPS_CONFIG.SAVE_UPS_OIL_REFINERY
		global.trigger.initialize = true
	end
	if global.option["beacon"] ~= UPS_CONFIG.SAVE_UPS_BEACON then
		global.trigger.on_options_changed["beacon"] = true
		global.option["beacon"] = UPS_CONFIG.SAVE_UPS_BEACON
		global.trigger.initialize = true
	end
	if global.option["drain"] ~= UPS_CONFIG.SAVE_UPS_DRAIN then
		global.trigger.on_options_changed["drain"] = true
		global.option["drain"] = UPS_CONFIG.SAVE_UPS_DRAIN
		global.trigger.initialize = true
	end
	if global.option["radar"] ~= UPS_CONFIG.SAVE_UPS_RADAR then
		global.trigger.on_options_changed["radar"] = true
		global.option["radar"] = UPS_CONFIG.SAVE_UPS_RADAR
		global.trigger.initialize = true
	end
	if global.option["show-gui"] ~= UPS_CONFIG.SHOWGUI then
		global.trigger.on_options_changed["show-gui"] = true
		global.option["show-gui"] = UPS_CONFIG.SHOWGUI
		global.trigger.initialize = true
	end
end


local function array_remove_entity(array, index, active)
	--replace empty element with last element
	array[index], array[#array] = array[#array], nil
	if (array[index] and array[index].valid) then				
		array[index].active = active
	end
end


local function Update_global_array(entity_name)
	local ArrayLength = #global.array[entity_name]
	--Update entity to active
	for i=global.counter.active[entity_name], ArrayLength, CONST.LOOP_TIME_IN_TICKS[entity_name] do
		if not(global.array[entity_name][i] and global.array[entity_name][i].valid) then --is element invalid or nil?
			if i > #global.array[entity_name] then 
				--element out of bounds
				break
			else
				--replace empty element with last element
				global.array[entity_name][i], global.array[entity_name][#global.array[entity_name]] = global.array[entity_name][#global.array[entity_name]], nil
				if (global.array[entity_name][i] and global.array[entity_name][i].valid) then
					global.array[entity_name][i].active = true
				end
			end
		else
			global.array[entity_name][i].active = true
		end
	end 
	--Update entity to inactive
	for i=global.counter.inactive[entity_name], ArrayLength, CONST.LOOP_TIME_IN_TICKS[entity_name] do
		if not(global.array[entity_name][i] and global.array[entity_name][i].valid) then --is element invalid or nil?
			if i > #global.array[entity_name] then 
				--element out of bounds
				break
			else
				--replace empty element with last element
				global.array[entity_name][i], global.array[entity_name][#global.array[entity_name]] = global.array[entity_name][#global.array[entity_name]], nil
				if (global.array[entity_name][i] and global.array[entity_name][i].valid) then
					global.array[entity_name][i].active = false
				end
			end
		else
			global.array[entity_name][i].active = false
		end
	end 
	--Update Counter
	global.counter.active[entity_name] = global.counter.active[entity_name] + 1
	global.counter.inactive[entity_name] = global.counter.inactive[entity_name] + 1
	if global.counter.active[entity_name] > CONST.LOOP_TIME_IN_TICKS[entity_name] then
		--Reset global.ActiveRadarsGameTick
		global.counter.active[entity_name] = 1
	elseif global.counter.active[entity_name] == CONST.ACTIVE_TIME_IN_TICKS[entity_name]+1 then
		--Reset global.InactiveRadarsGameTick
		global.counter.inactive[entity_name] = 1
	end
end


function events.on_built_entity(event) 
--Fires on player/bot build entity
	if not global.option["uninstall"] then
		if event.created_entity.name == "electric-mining-drill" then
			if global.option["electric-mining-drill"] then
				global.array["electric-mining-drill"][#global.array["electric-mining-drill"]+1] = event.created_entity	
				event.created_entity.active = false		
			end		
		elseif event.created_entity.name == "pumpjack" then
			if global.option["pumpjack"] then
				global.array["pumpjack"][#global.array["pumpjack"]+1] = event.created_entity	
				event.created_entity.active = false
			end		
		elseif event.created_entity.name == "assembling-machine-1" or event.created_entity.name == "assembling-machine-2" or event.created_entity.name == "assembling-machine-3" then
			if global.option["assembling-machine"] then
				global.array["assembling-machine"][#global.array["assembling-machine"]+1] = event.created_entity	
				event.created_entity.active = false		
			end		
		elseif event.created_entity.name == "electric-furnace" or event.created_entity.name == "steel-furnace" or event.created_entity.name == "stone-furnace" then
			if global.option["furnace"] then
				global.array["furnace"][#global.array["furnace"]+1] = event.created_entity	
				event.created_entity.active = false		
			end		
		elseif event.created_entity.name == "chemical-plant" then
			if global.option["chemical-plant"] then
				global.array["chemical-plant"][#global.array["chemical-plant"]+1] = event.created_entity	
				event.created_entity.active = false		
			end	
		elseif event.created_entity.name == "oil-refinery" then
			if global.option["oil-refinery"] then
				global.array["oil-refinery"][#global.array["oil-refinery"]+1] = event.created_entity	
				event.created_entity.active = false		
			end	
		elseif event.created_entity.name == "beacon" then
			if global.option["beacon"] then
				global.array["beacon"][#global.array["beacon"]+1] = event.created_entity	
				event.created_entity.active = false		
			end					
		elseif event.created_entity.name == "radar" then
			if global.option["radar"] then
				global.array["radar"][#global.array["radar"]+1] = event.created_entity	
				event.created_entity.active = false		
			end		
		end
	end
end


function events.on_chunk_generated(event) --Fires on chunk exploration
	if not global.option["uninstall"] then
		--Remove decoratives
		if global.option["decorative"] then
			for key, entity in pairs(event.surface.find_entities_filtered{area = event.area, type="decorative"}) do
				entity.destroy()
			end
		end
		--Remove fish
		if global.option["fish"] then
			for key, entity in pairs(event.surface.find_entities_filtered{area = event.area, type="fish"}) do
				entity.destroy()
			end
		end
		--Remove pollution
		for key, entity in pairs(event.surface.find_entities_filtered{area = event.area, name="pollution-absorbtion"}) do
			entity.destroy()
		end
		if global.option["pollution-absorbtion"] then
			event.surface.create_entity{name="pollution-absorbtion", position={event.area.left_top.x+16, event.area.left_top.y+16}}
		end
	end
end


function events.on_init()
	global.trigger.initialize = true --will trigger initialization in the mainloop
	global.trigger.full_install = true
	global.trigger.show_options = true
end


function events.on_configuration_changed(data) --Runs when mod is started first time 
	local newFactorioVersion = data.old_version ~= data.new_version
	local newAnyModVersion = data.mod_changes ~= nil
	local newUPSversion = data.mod_changes["UPS-up"] ~= nil
	if data.mod_changes["UPS-up"] == nil then
		local UPSjustInstalled = false
	else
		local UPSjustInstalled = (data.mod_changes["UPS-up"].old_version == nil and data.mod_changes["UPS-up"].new_version ~= nil)
	end
	global.trigger.initialize = true --will trigger initialization in the mainloop
	global.trigger.full_install = true
	if UPSjustInstalled then
		util.print_admins({"message.PRINT_The-mod-UPS-up-was-added-to-the-game"})	
		global.trigger.show_options = true
	elseif newUPSversion then
		util.print_admins({"message.PRINT_The-mod-UPS-up-was-updated"})	
		global.trigger.show_options = true
	elseif newFactorioVersion then
		util.print_admins({"message.PRINT_Factorio-was-updated"})
	elseif newAnyModVersion then	
		util.print_admins({"message.PRINT_Other-mods-changed"})	
	end
end


function events.on_player_joined_game(event)
	local player = game.players[event.player_index]
	gui.hide_topbutton(player) --Destroys the main butten at the top
	if global.option["show-gui"] then
		gui.show_topbutton(player) --Creates the main butten at the top
	end
end


function events.on_tick()
--Checks for config changes
	check_config_changed()
--Mod initialization: Runs the first time the mod is started, the mod/Factorio is updated or the config has changed
	if global.trigger.initialize then 
		init.initialize()
	end
--Update entity-arrays
	Update_global_array("electric-mining-drill")
	Update_global_array("pumpjack")
	Update_global_array("assembling-machine")
	Update_global_array("furnace")
	Update_global_array("chemical-plant")
	Update_global_array("oil-refinery")
--	Update_global_array("beacon")
	Update_global_array("radar")
--Update slow-counter
	global.counter.slow_update = global.counter.slow_update + 1 
	if global.counter.slow_update > 500 then
		global.counter.slow_update = 1
		--Sellout Code
		global.counter.sellout = global.counter.sellout + 500
		if (global.counter.sellout >= CONST.SELLOUT_RESET_TICK) then 
			--Resets after (SELLOUT_LOOP) Ticks
			global.counter.sellout = 0 
		elseif (global.counter.sellout == CONST.SELLOUT_DISPLAY_TICK)then
			--Display Sellout after SELLOUT_FIRST Ticks
			util.print_admins({"message.PRINT_Sellout-msg"})
			util.print_admins({"message.PRINT_Sellout-url"})
		end		
	end
end