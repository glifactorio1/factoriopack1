if not gui then gui = {} end

local entity_names = {"decorative", "fish", "pollution-absorbtion", "alien-artifact-on-ground", "other-item-on-ground", "corpse", "electric-mining-drill", "pumpjack", "assembling-machine", "furnace", "chemical-plant", "oil-refinery", "radar", "smoke", "drain", "admin-only"}
local entity_names_read_only = {"electric-mining-drill", "pumpjack", "assembling-machine", "furnace", "chemical-plant", "oil-refinery", "radar", "smoke", "drain"}		
local entity_names_editable = {"decorative", "fish", "pollution-absorbtion", "alien-artifact-on-ground", "other-item-on-ground", "corpse", "admin-only"}

function gui.show_options(player)
	-- Title
	if not player.gui.center["UPS_options-frame"] then
		player.gui.center.add{type = "frame", name = "UPS_options-frame", direction = "vertical", caption = {"gui.TEXT_options_UPS-Options"}}
		local options_frame = player.gui.center["UPS_options-frame"]	
		-- Heading	
		options_frame.add{type = "label", 	name = "UPS_options-label_heading", caption = {"gui.TEXT_options_Select-which-options-you-want-to-enable"}}
		options_frame["UPS_options-label_heading"].style.font = "default-bold"
		-- Table checkboxes
		options_frame.add{type = "table", name = "UPS_options-table", colspan  = 3}
		local options_table = options_frame["UPS_options-table"]

--		options_table.add{type = "checkbox",name = "UPS_options-checkbox_column-name", state = global.option["column-name"]}
		options_table.add{type = "label", 	name = "UPS_options-checkbox_column-name", caption = {"gui.description_column-name"}}
		options_table.add{type = "label", 	name = "UPS_options-description_column-name", caption = {"gui.description_column-name"}}
		options_table.add{type = "label", 	name = "UPS_options-result_column-name", caption = {"gui.result_column-name"}, tooltip = {"gui.tooltip_column-name"}}
	
		for key, entity_name in pairs(entity_names) do
			local entity_is_read_only = false
			for key, entity_name_read_only in pairs(entity_names_read_only) do
				if entity_name == entity_name_read_only then
					entity_is_read_only = true
				end
			end
			if entity_is_read_only then
				options_table.add{type = "checkbox", name = "UPS_options-checkbox_" .. entity_name, state = global.option[entity_name], tooltip = {"gui.tooltip_read_only"}}	
			else
				options_table.add{type = "checkbox", name = "UPS_options-checkbox_" .. entity_name, state = global.option[entity_name]}	
			end
			options_table.add{type = "label", name = "UPS_options-description_" .. entity_name, caption = {"gui.description_" .. entity_name}, tooltip = {"gui.tooltip_" .. entity_name}}
			if entity_is_read_only then
				options_table["UPS_options-description_" .. entity_name].style.font_color = {r = 0.6, g = 0.6, b = 0.6}
			end
			options_table.add{type = "label", name = "UPS_options-result_" .. entity_name, caption = {"gui.result_" .. entity_name}}
		end
		options_table["UPS_options-checkbox_electric-mining-drill"].style.top_padding = 8
		options_table["UPS_options-description_electric-mining-drill"].style.top_padding = 8
		options_table["UPS_options-result_electric-mining-drill"].style.top_padding = 8
		
		options_table["UPS_options-checkbox_admin-only"].style.top_padding = 8
		options_table["UPS_options-description_admin-only"].style.top_padding = 8
		options_table["UPS_options-result_admin-only"].style.top_padding = 8
		
		options_table["UPS_options-description_assembling-machine"].style.right_padding = 8	
	
		-- Table Buttons
		options_frame.add{type = "table", name = "UPS_options-buttontable", colspan  = 5}
		local options_buttontable = options_frame["UPS_options-buttontable"]	
		-- Done button
		options_buttontable.add{type = "button", name = "UPS_options-button_done", caption = {"gui.TEXT_options_done"}}	
		options_buttontable["UPS_options-button_done"].style.right_padding = 10
		options_buttontable["UPS_options-button_done"].style.left_padding = 10
		-- Cancel button
		if not global.trigger.show_options then
			options_buttontable.add{type = "button", name = "UPS_options-button_cancel", caption = {"gui.TEXT_options_cancel"}}	
			options_buttontable["UPS_options-button_cancel"].style.right_padding = 10
			options_buttontable["UPS_options-button_cancel"].style.left_padding = 10
		else
			options_buttontable.add{type = "label", name = "UPS_options-label_cancel", caption = "                            "}
		end
		-- Support this Mod button
		options_buttontable.add{type = "button", name = "UPS_options-button_support", caption = {"gui.TEXT_options_support"}}	
		options_buttontable["UPS_options-button_support"].style.right_padding = 10
		options_buttontable["UPS_options-button_support"].style.left_padding = 10
		-- Debug button
		options_buttontable.add{type = "button", name = "UPS_options-button_debug", caption = {"gui.TEXT_options_debug"}}	
		options_buttontable["UPS_options-button_debug"].style.right_padding = 10
		options_buttontable["UPS_options-button_debug"].style.left_padding = 10
		-- Uninstall button
		options_buttontable.add{type = "button", name = "UPS_options-button_uninstall", caption = {"gui.TEXT_options_uninstall"}}	
		options_buttontable["UPS_options-button_uninstall"].style.right_padding = 10
		options_buttontable["UPS_options-button_uninstall"].style.left_padding = 10		
	end
end

function gui.show_support(player)
	-- Title
	if not player.gui.center["UPS_support-frame"] then
		player.gui.center.add{type = "frame", name = "UPS_support-frame", direction = "vertical", caption = {"gui.TEXT_support_title"}}
		local options_frame = player.gui.center["UPS_support-frame"]
		-- Heading	
		options_frame.add{type = "label", 	name = "UPS_support-label_heading1", caption = {"gui.TEXT_support_description1"}}
		options_frame.add{type = "label", 	name = "UPS_support-label_heading2", caption = {"gui.TEXT_support_description2"}}
		-- Cancel button
		options_frame.add{type = "button", name = "UPS_support-button_got_it", caption = {"gui.TEXT_support_got_it"}}	
		options_frame["UPS_support-button_got_it"].style.right_padding = 10
		options_frame["UPS_support-button_got_it"].style.left_padding = 10
	end
end

function gui.show_uninstalled(player)
	-- Title
	if not player.gui.center["UPS_uninstalled-frame"] then
		player.gui.center.add{type = "frame", name = "UPS_uninstalled-frame", direction = "vertical", caption = {"gui.TEXT_uninstalled_title"}}
		local options_frame = player.gui.center["UPS_uninstalled-frame"]
		-- Heading	
		options_frame.add{type = "label", 	name = "UPS_uninstalled-label_heading1", caption = {"gui.TEXT_uninstalled_description1"}}
		options_frame.add{type = "label", 	name = "UPS_uninstalled-label_heading2", caption = {"gui.TEXT_uninstalled_description2"}}
		-- Cancel button
		options_frame.add{type = "button", name = "UPS_uninstalled-button_got_it", caption = {"gui.TEXT_uninstalled_got_it"}}	
		options_frame["UPS_uninstalled-button_got_it"].style.right_padding = 10
		options_frame["UPS_uninstalled-button_got_it"].style.left_padding = 10
	end
end

function gui.on_gui_click(event)
	local element_name = event.element.name
	local player = game.players[event.element.player_index]
	--UPS-up Options "Done"
	if element_name == "UPS_options-button_done" then 
		local options_table = player.gui.center["UPS_options-frame"]["UPS_options-table"]	
		for key, entity_name_editable in pairs(entity_names_editable) do
			if global.option[entity_name_editable] ~= options_table["UPS_options-checkbox_" .. entity_name_editable].state then
				global.trigger.on_options_changed[entity_name_editable] = true
			end
			global.option[entity_name_editable] = options_table["UPS_options-checkbox_" .. entity_name_editable].state
		end
		player.gui.center["UPS_options-frame"].destroy() 
		global.trigger.initialize = true --will trigger initialization in the mainloop
		global.trigger.full_install = true
		global.trigger.show_options = nil
		global.initStep=20 --will skip initialization gui in the mainloop	
	-- UPS-up Options "Cancel"
	elseif element_name == "UPS_options-button_cancel" then 
		player.gui.center["UPS_options-frame"].destroy()
	-- UPS-up Options "Support this Mod"
	elseif element_name == "UPS_options-button_support" then 
		player.gui.center["UPS_options-frame"].destroy()	
		gui.show_support(player)
	-- UPS-up Options "Debug"
	elseif element_name == "UPS_options-button_debug" then 		
		player.gui.center["UPS_options-frame"].destroy()
		global.trigger.initialize = true --will trigger initialization in the mainloop
		global.trigger.full_install = true
		global.trigger.show_options = nil
		global.initStep = nil
		global.option["uninstall"] = nil
	-- UPS-up Options "Uninstall"
	elseif element_name == "UPS_options-button_uninstall" then
		player.gui.center["UPS_options-frame"].destroy()
		global.option["uninstall"] = true
		global.initStep = 0
		global.trigger.initialize = true --will trigger initialization in the mainloop
		gui.show_uninstalled(player)
	-- UPS-up Top-mainbutton clicked
	elseif element_name == "UPS_gui_top-button" then
		if not global.trigger.show_options then
			if (player.gui.center["UPS_options-frame"]) then
				player.gui.center["UPS_options-frame"].destroy()
			else
				gui.show_options(player)
			end
		end
	-- UPS-up Support "Got it"
	elseif element_name == "UPS_support-button_got_it" then
		player.gui.center["UPS_support-frame"].destroy()
		gui.show_options(player)
	-- UPS-up unisntall "Got it"
	elseif element_name == "UPS_uninstalled-button_got_it" then
		player.gui.center["UPS_uninstalled-frame"].destroy()
	-- Read Only checkboxes
	else
		for key, entity_name_read_only in pairs(entity_names_read_only) do
			if element_name == "UPS_options-checkbox_" .. entity_name_read_only then 									
				--UPS-up Options "checkbox_Reduce-smoke"
				local options_table = player.gui.center["UPS_options-frame"]["UPS_options-table"]
				options_table["UPS_options-checkbox_" .. entity_name_read_only].state = global.option[entity_name_read_only]
				player.print({"message.PRINT_options_Read_only"})
			end
		end				
	end
end

function gui.show_topbutton(player)
	if player == "all" then
		if global.option["admin-only"] then
			for key, allplayer in pairs(game.players) do
				if allplayer.admin and allplayer.connected then
					if (not allplayer.gui.top["UPS_gui_top-button"]) then
						allplayer.gui.top.add{type="button", name="UPS_gui_top-button", style="UPS_gui_top-button"}
					end
				end
			end
		else
			for key, allplayer in pairs(game.players) do
				if allplayer.connected then
					if (not allplayer.gui.top["UPS_gui_top-button"]) then
						allplayer.gui.top.add{type="button", name="UPS_gui_top-button", style="UPS_gui_top-button"}
					end
				end
			end
		end
	else
		if global.option["admin-only"] then
			if player.admin and player.connected then
				if (not player.gui.top["UPS_gui_top-button"]) then
					player.gui.top.add{type="button", name="UPS_gui_top-button", style="UPS_gui_top-button"}
				end
			end
		else
			if (not player.gui.top["UPS_gui_top-button"]) then
				player.gui.top.add{type="button", name="UPS_gui_top-button", style="UPS_gui_top-button"}
			end		
		end
	end
end

function gui.hide_topbutton(player)
	if player == "all" then
		for key, allplayer in pairs(game.players) do
			if allplayer.connected then
				if (allplayer.gui.top["UPS_gui_top-button"]) then
					allplayer.gui.top["UPS_gui_top-button"].destroy()
				end
			end
		end	
	elseif (player.gui.top["UPS_gui_top-button"]) then
		player.gui.top["UPS_gui_top-button"].destroy()
	end
end