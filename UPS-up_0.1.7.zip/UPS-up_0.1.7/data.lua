require("config")
require("prototypes.style")
require("prototypes.entities")