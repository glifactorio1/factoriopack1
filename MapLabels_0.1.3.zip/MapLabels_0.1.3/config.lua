-- Size of a region, in chunks (default is 56 to be a multiple of RSO's value)

RegionSize = 56



-- Search radius for finding neighbors in the same resource field (default is 1, max is 20 which is rather slow)

ResourceFieldSearchRadius = 1



-- Whether to search in all directions (default is false, not needed if find_entities_filtered returns results sorted by position)

ResourceFieldSearchAllDirections = false



-- Preferred names for resources on map, or blank to hide (default is to replace non-alphanumeric characters with space, upper-case the first letter, and prepend a tilde)

ResourceDisplayName = {}

--ResourceDisplayName[ "iron-ore" ] = "~Iron ore"
--ResourceDisplayName[ "copper-ore" ] = ""

ResourceDisplayName[ "crude-oil" ] = ""
