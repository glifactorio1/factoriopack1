data:extend(
{
  {
    type = "train-stop",
    name = "map-label",
    flags = {"player-creation", "filter-directions"},
    max_health = 1,
    collision_mask = {"ghost-layer"},
    animation_ticks_per_frame = 20,
    animations =
    {
      north =
      {
        filename = "__MapLabels__/trans.png",
        priority = "high",
        width = 1,
        height = 1,
        frame_count = 1,
        shift = { 0, 0 }
      },
      east =
      {
        filename = "__MapLabels__/trans.png",
        priority = "high",
        width = 1,
        height = 1,
        frame_count = 1,
        shift = { 0, 0 }
      },
      south =
      {
        filename = "__MapLabels__/trans.png",
        priority = "high",
        width = 1,
        height = 1,
        frame_count = 1,
        shift = { 0, 0 }
      },
      west =
      {
        filename = "__MapLabels__/trans.png",
        priority = "high",
        width = 1,
        height = 1,
        frame_count = 1,
        shift = { 0, 0 }
      }
    },
	
	circuit_wire_connection_points =
    {
      {
        shadow =
        {
          red = {-0.375, 1.21875},
          green = {-0.53125, 1.21875}
        },
        wire =
        {
          red = {-0.5, 1.09375},
          green = {-0.65625, 1.09375}
        }
      },     
    },
	
	circuit_connector_sprites =
    {
      get_circuit_connector_sprites({0.5625-1, 1.03125}, {0.5625-1, 1.03125}, 0), --N
      get_circuit_connector_sprites({-0.78125, 0.28125-1}, {-0.78125, 0.28125-1}, 6), --E
      get_circuit_connector_sprites({-0.28125+1, 0.28125}, {-0.28125+1, 0.28125}, 0), --S
      get_circuit_connector_sprites({0.03125, 0.28125+1}, {0.03125, 0.28125+1}, 6), --W
    },
    circuit_wire_max_distance = 0.01,
  }
})
