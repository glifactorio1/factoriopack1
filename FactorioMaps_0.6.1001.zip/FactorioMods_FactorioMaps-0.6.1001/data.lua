require "prototypes.style"
require "prototypes.fakePlayer"
