data:extend({{
	type = "recipe",
	name = "vehicle-hauler",
	ingredients =
	{
	  {"boiler", 4},
	  {"iron-plate", 20},
	  {"iron-gear-wheel", 10}
	},
	enabled = true,
	energy_required = 5,
	results=
	{
	  {type="item", name="vehicle-hauler", amount=1},
	},
}})
