

data:extend(
{
  --Item

  {
    type = "item",
    name = "a-bee",
    icon = "__NPBees__/graphics/icon/a-bee-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-beel",
    icon = "__NPBees__/graphics/icon/a-beel-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-copper-bee",
    icon = "__NPBees__/graphics/icon/a-copper-bee-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-copper-beel",
    icon = "__NPBees__/graphics/icon/a-copper-beel-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-iron-bee",
    icon = "__NPBees__/graphics/icon/a-iron-bee-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-iron-beel",
    icon = "__NPBees__/graphics/icon/a-iron-beel-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-coal-bee",
    icon = "__NPBees__/graphics/icon/a-coal-bee-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-coal-beel",
    icon = "__NPBees__/graphics/icon/a-coal-beel-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-stone-bee",
    icon = "__NPBees__/graphics/icon/a-stone-bee-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-stone-beel",
    icon = "__NPBees__/graphics/icon/a-stone-beel-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-wood-bee",
    icon = "__NPBees__/graphics/icon/a-wood-bee-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "a-wood-beel",
    icon = "__NPBees__/graphics/icon/a-wood-beel-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "b",
    stack_size = 100,

  },
  {
    type = "item",
    name = "n-honey",
    icon = "__NPBees__/graphics/icon/n-honey-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "a",
    stack_size = 200,

  },
  {
    type = "item",
    name = "n-mutate-propolis",
    icon = "__NPBees__/graphics/icon/n-mutate-propolis-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "a",
    stack_size = 200,

  },
  {
    type = "item",
    name = "n-clean-comb",
    icon = "__NPBees__/graphics/icon/n-clean-comb-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "c",
    stack_size = 200,

  },
  {
    type = "item",
    name = "n-copper-comb",
    icon = "__NPBees__/graphics/icon/n-copper-comb-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "c",
    stack_size = 200,

  },
  {
    type = "item",
    name = "n-iron-comb",
    icon = "__NPBees__/graphics/icon/n-iron-comb-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "c",
    stack_size = 200,

  },
  {
    type = "item",
    name = "n-coal-comb",
    icon = "__NPBees__/graphics/icon/n-coal-comb-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "c",
    stack_size = 200,

  },
  {
    type = "item",
    name = "n-stone-comb",
    icon = "__NPBees__/graphics/icon/n-stone-comb-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "c",
    stack_size = 200,

  },
  {
    type = "item",
    name = "n-wood-comb",
    icon = "__NPBees__/graphics/icon/n-wood-comb-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "c",
    stack_size = 200,

  },
  {
    type = "item",
    name = "n-copper-gen",
    icon = "__NPBees__/graphics/icon/n-copper-gen-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "d",
    stack_size = 20,

  },
  {
    type = "item",
    name = "n-iron-gen",
    icon = "__NPBees__/graphics/icon/n-iron-gen-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "d",
    stack_size = 20,

  },
  {
    type = "item",
    name = "n-coal-gen",
    icon = "__NPBees__/graphics/icon/n-coal-gen-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "d",
    stack_size = 20,

  },
  {
    type = "item",
    name = "n-stone-gen",
    icon = "__NPBees__/graphics/icon/n-stone-gen-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "d",
    stack_size = 20,

  },
  {
    type = "item",
    name = "n-wood-gen",
    icon = "__NPBees__/graphics/icon/n-wood-gen-icon.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "bees",
    order = "d",
    stack_size = 20,

  },
  

}
)


