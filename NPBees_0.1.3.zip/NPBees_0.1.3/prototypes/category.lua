data:extend(
{
  { type="item-group", name="NPBees", icon="__NPBees__/graphics/icon/NPB.png", inventory_order="f", order="f" },

  {type = "item-subgroup",name = "bees",group = "NPBees",order = "c"},
  {type = "item-subgroup",name = "bees-machine",group = "NPBees",order = "a"},
  
  {type = "recipe-category",name = "hive"},
  {type = "recipe-category",name = "hive2"},
  {type = "recipe-category",name = "bee-grow"},
  {type = "recipe-category",name = "n-centrifuge"},
  {type = "recipe-category",name = "n-g-maker"},
  {type = "recipe-category",name = "n-g-transposer"},

}
)

