data:extend(
{   --Items
	{
		type = "recipe",
		name = "a-bee",				
		energy_required = 32.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="alien-artifact", amount=1},
			{ type = "item", name = "science-pack-1" , amount = 20, },	
        },		
		result = "a-bee",
		result_count = 1,
		category = "n-g-transposer",
		icon = "__NPBees__/graphics/icon/a-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "a-copper-bee",				
		energy_required = 32.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-bee", amount=1},
			{ type = "item", name = "n-copper-gen" , amount = 1, },	
        },		
		result = "a-copper-bee",
		result_count = 1,
		category = "n-g-transposer",
		icon = "__NPBees__/graphics/icon/a-copper-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "a-iron-bee",				
		energy_required = 32.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-bee", amount=1},
			{ type = "item", name = "n-iron-gen" , amount = 1, },	
        },		
		result = "a-iron-bee",
		result_count = 1,
		category = "n-g-transposer",
		icon = "__NPBees__/graphics/icon/a-iron-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "a-coal-bee",				
		energy_required = 32.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-bee", amount=1},
			{ type = "item", name = "n-coal-gen" , amount = 1, },	
        },		
		result = "a-coal-bee",
		result_count = 1,
		category = "n-g-transposer",
		icon = "__NPBees__/graphics/icon/a-coal-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "a-stone-bee",				
		energy_required = 32.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-bee", amount=1},
			{ type = "item", name = "n-stone-gen" , amount = 1, },	
        },		
		result = "a-stone-bee",
		result_count = 1,
		category = "n-g-transposer",
		icon = "__NPBees__/graphics/icon/a-stone-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "a-wood-bee",				
		energy_required = 32.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-bee", amount=1},
			{ type = "item", name = "n-wood-gen" , amount = 1, },	
        },		
		result = "a-wood-bee",
		result_count = 1,
		category = "n-g-transposer",
		icon = "__NPBees__/graphics/icon/a-wood-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-copper-gen",				
		energy_required = 28.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="copper-ore", amount=50},
			{type="item", name="n-mutate-propolis", amount=30, },
			{ type = "item", name = "n-honey" , amount = 70, },	
        },		
		result = "n-copper-gen",
		result_count = 1,
		category = "n-g-maker",
		icon = "__NPBees__/graphics/icon/n-copper-gen-icon.png",
	  order = "b", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-iron-gen",				
		energy_required = 28.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="iron-ore", amount=50},
			{type="item", name="n-mutate-propolis", amount=30, },
			{ type = "item", name = "n-honey" , amount = 70, },	
        },		
		result = "n-iron-gen",
		result_count = 1,
		category = "n-g-maker",
		icon = "__NPBees__/graphics/icon/n-iron-gen-icon.png",
	  order = "b", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-coal-gen",				
		energy_required = 28.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="coal", amount=50},
			{type="item", name="n-mutate-propolis", amount=30, },
			{ type = "item", name = "n-honey" , amount = 70, },	
        },		
		result = "n-coal-gen",
		result_count = 1,
		category = "n-g-maker",
		icon = "__NPBees__/graphics/icon/n-coal-gen-icon.png",
	  order = "b", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-stone-gen",				
		energy_required = 28.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="stone", amount=50},
			{type="item", name="n-mutate-propolis", amount=30, },
			{ type = "item", name = "n-honey" , amount = 70, },	
        },		
		result = "n-stone-gen",
		result_count = 1,
		category = "n-g-maker",
		icon = "__NPBees__/graphics/icon/n-stone-gen-icon.png",
	  order = "b", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-wood-gen",				
		energy_required = 28.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="raw-wood", amount=50},
			{type="item", name="n-mutate-propolis", amount=30, },
			{ type= "item", name = "n-honey" , amount = 70, },	
        },		
		result = "n-wood-gen",
		result_count = 1,
		category = "n-g-maker",
		icon = "__NPBees__/graphics/icon/n-wood-gen-icon.png",
	  order = "b", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-clean-comb",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-bee", amount=1},
        },		
		results = {
        {type="item", name="n-clean-comb", amount=20, },
		{type="item", name="n-mutate-propolis", amount=1, },
		{type="item", name="a-beel", amount=1, },
	  },
		category = "hive",
		icon = "__NPBees__/graphics/icon/n-clean-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-copper-comb",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-copper-bee", amount=1},
        },		
		results = {
        {type="item", name="n-copper-comb", amount=15, },
		{type="item", name="a-copper-beel", amount=1, },
	  },
		category = "hive2",
		icon = "__NPBees__/graphics/icon/n-copper-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-iron-comb",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-iron-bee", amount=1},
        },		
		results = {
        {type="item", name="n-iron-comb", amount=15, },
		{type="item", name="a-iron-beel", amount=1, },
	  },
		category = "hive2",
		icon = "__NPBees__/graphics/icon/n-iron-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-coal-comb",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-coal-bee", amount=1},
        },		
		results = {
        {type="item", name="n-coal-comb", amount=15, },
		{type="item", name="a-coal-beel", amount=1, },
	  },
		category = "hive2",
		icon = "__NPBees__/graphics/icon/n-coal-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-stone-comb",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-stone-bee", amount=1},
        },		
		results = {
        {type="item", name="n-stone-comb", amount=15, },
		{type="item", name="a-stone-beel", amount=1, },
	  },
		category = "hive2",
		icon = "__NPBees__/graphics/icon/n-stone-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-wood-comb",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-wood-bee", amount=1},
        },		
		results = {
        {type="item", name="n-wood-comb", amount=15, },
		{type="item", name="a-wood-beel", amount=1, },
	  },
		category = "hive2",
		icon = "__NPBees__/graphics/icon/n-wood-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-copper-comb-v2",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-copper-bee", amount=1},
			{type="item", name="n-honey", amount=20},
        },		
		results = {
        {type="item", name="n-copper-comb", amount=30, },
		{type="item", name="a-copper-beel", amount=1, },
	  },
		category = "hive2",
		icon = "__NPBees__/graphics/icon/n-copper-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-iron-comb-v2",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-iron-bee", amount=1},
			{type="item", name="n-honey", amount=20},
        },		
		results = {
        {type="item", name="n-iron-comb", amount=30, },
		{type="item", name="a-iron-beel", amount=1, },
	  },
		category = "hive2",
		icon = "__NPBees__/graphics/icon/n-iron-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-coal-comb-v2",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-coal-bee", amount=1},
			{type="item", name="n-honey", amount=20},
        },		
		results = {
        {type="item", name="n-coal-comb", amount=30, },
		{type="item", name="a-coal-beel", amount=1, },
	  },
		category = "hive2",
		icon = "__NPBees__/graphics/icon/n-coal-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-stone-comb-v2",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-stone-bee", amount=1},
			{type="item", name="n-honey", amount=20},
        },		
		results = {
        {type="item", name="n-stone-comb", amount=30, },
		{type="item", name="a-stone-beel", amount=1, },
	  },
		category = "hive2",
		icon = "__NPBees__/graphics/icon/n-stone-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-wood-comb-v2",				
		energy_required = 12.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-wood-bee", amount=1},
			{type="item", name="n-honey", amount=20},
        },		
		results = {
        {type="item", name="n-wood-comb", amount=30, },
		{type="item", name="a-wood-beel", amount=1, },
	  },
		category = "hive2",
		icon = "__NPBees__/graphics/icon/n-wood-comb-icon.png",
	  order = "c", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-honey",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="n-clean-comb", amount=10},
        },		
		results = {
        {type="item", name="n-honey", amount=20, },
	  },
		category = "n-centrifuge",
		icon = "__NPBees__/graphics/icon/n-honey-icon.png",
	  order = "d", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-copper-ore",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="n-copper-comb", amount=10},
        },		
		results = {
        {type="item", name="copper-ore", amount=10, },
	  },
		category = "n-centrifuge",
		icon = "__base__/graphics/icons/copper-ore.png",
	  order = "e", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-iron-ore",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="n-iron-comb", amount=10},
        },		
		results = {
        {type="item", name="iron-ore", amount=10, },
	  },
		category = "n-centrifuge",
		icon = "__base__/graphics/icons/iron-ore.png",
	  order = "e", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-coal",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="n-coal-comb", amount=10},
        },		
		results = {
        {type="item", name="coal", amount=10, },
	  },
		category = "n-centrifuge",
		icon = "__base__/graphics/icons/coal.png",
	  order = "e", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-stone",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="n-stone-comb", amount=10},
        },		
		results = {
        {type="item", name="stone", amount=10, },
	  },
		category = "n-centrifuge",
		icon = "__base__/graphics/icons/stone.png",
	  order = "e", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "n-wood",				
		energy_required = 2.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="n-wood-comb", amount=10},
        },		
		results = {
        {type="item", name="raw-wood", amount=10, },

	  },
		category = "n-centrifuge",
		icon = "__base__/graphics/icons/raw-wood.png",
	  order = "e", group = "NPBees", subgroup = "bees",
	},
-----------------------------------------------
    {
		type = "recipe",
		name = "a-bee-2",				
		energy_required = 24.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-beel", amount=1},
        },		
		result = "a-bee",
		result_count = 1,
		category = "bee-grow",
		icon = "__NPBees__/graphics/icon/a-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "a-copper-bee-2",				
		energy_required = 24.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-copper-beel", amount=1},
        },		
		result = "a-copper-bee",
		result_count = 1,
		category = "bee-grow",
		icon = "__NPBees__/graphics/icon/a-copper-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "a-iron-bee-2",				
		energy_required = 24.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-iron-beel", amount=1},
        },		
		result = "a-iron-bee",
		result_count = 1,
		category = "bee-grow",
		icon = "__NPBees__/graphics/icon/a-iron-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "a-coal-bee-2",				
		energy_required = 24.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-coal-beel", amount=1},
        },		
		result = "a-coal-bee",
		result_count = 1,
		category = "bee-grow",
		icon = "__NPBees__/graphics/icon/a-coal-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "a-stone-bee-2",				
		energy_required = 24.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-stone-beel", amount=1},
        },		
		result = "a-stone-bee",
		result_count = 1,
		category = "bee-grow",
		icon = "__NPBees__/graphics/icon/a-stone-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	{
		type = "recipe",
		name = "a-wood-bee-2",				
		energy_required = 24.0,
		enabled = "true",
		ingredients = 
        {
            {type="item", name="a-wood-beel", amount=1},
        },		
		result = "a-wood-bee",
		result_count = 1,
		category = "bee-grow",
		icon = "__NPBees__/graphics/icon/a-wood-bee-icon.png",
	  order = "a", group = "NPBees", subgroup = "bees",
	},
	
}
)


