local dat = data.raw

-- factory stuff
dat.item["electric-mining-drill"].icon = "__IconFix__/graphics/icons/electric-mining-drill.png"
dat.item["solar-panel"].icon = "__IconFix__/graphics/icons/solar-panel.png"
dat.item["steel-chest"].icon = "__IconFix__/graphics/icons/steel-chest.png"
dat.container["steel-chest"].picture.filename = "__IconFix__/graphics/entity/steel-chest.png"

-- intermediates
dat.item["construction-robot"].icon = "__IconFix__/graphics/icons/construction-robot.png"
dat.item["logistic-robot"].icon = "__IconFix__/graphics/icons/logistic-robot.png"
dat.item["flying-robot-frame"].icon = "__IconFix__/graphics/icons/flying-robot-frame.png"
dat.item["alien-artifact"].icon = "__IconFix__/graphics/icons/alien-artifact.png"
dat.item["battery"].icon = "__IconFix__/graphics/icons/battery.png"
dat.item["explosives"].icon = "__IconFix__/graphics/icons/explosives.png"

-- military
dat.capsule["defender-capsule"].icon = "__IconFix__/graphics/icons/defender-capsule.png"
dat.capsule["distractor-capsule"].icon = "__IconFix__/graphics/icons/distractor-capsule.png"
dat.capsule["destroyer-capsule"].icon = "__IconFix__/graphics/icons/destroyer-capsule.png"
dat.item["gun-turret"].icon = "__IconFix__/graphics/icons/gun-turret.png"
dat.item["flamethrower-turret"].icon = "__IconFix__/graphics/icons/flamethrower-turret.png"
dat.item["laser-turret"].icon = "__IconFix__/graphics/icons/laser-turret.png"
dat.item["land-mine"].icon = "__IconFix__/graphics/icons/land-mine.png"
dat["land-mine"]["land-mine"].picture_safe.filename = "__IconFix__/graphics/entity/land-mine.png"
dat["land-mine"]["land-mine"].picture_set.filename = "__IconFix__/graphics/entity/land-mine-set.png"

-- equipment
dat.item["energy-shield-equipment"].icon = "__IconFix__/graphics/icons/energy-shield-equipment.png"
dat["energy-shield-equipment"]["energy-shield-equipment"].sprite.filename = "__IconFix__/graphics/equipment/energy-shield-equipment.png"
dat.item["energy-shield-mk2-equipment"].icon = "__IconFix__/graphics/icons/energy-shield-mk2-equipment.png"
dat["energy-shield-equipment"]["energy-shield-mk2-equipment"].sprite.filename = "__IconFix__/graphics/equipment/energy-shield-mk2-equipment.png"
dat.item["solar-panel-equipment"].icon = "__IconFix__/graphics/icons/solar-panel-equipment.png"
dat["solar-panel-equipment"]["solar-panel-equipment"].sprite.filename = "__IconFix__/graphics/equipment/solar-panel-equipment.png"
