local SW = SWConfig
---------------------------------------------------------------------------
-------------------------- Change Balance ---------------------------------
---------------------------------------------------------------------------
SW.DyTech = true --to fit DyTechWar (will only work if DyTechWar found)
SW.Custom = false --Custom Config (location: /conf/!custom.lua)
SW.BaseOverride = true
---------------------------------------------------------------------------
------------------------------- Toys --------------------------------------
---------------------------------------------------------------------------
SW.ExtraLoot = true --Extra Loot from Aliens (small-alien-artifact)
SW.SupremeOres = false --Currently only spawns a new resource
SW.newEvilForces = false --Not in the public version of the mod 