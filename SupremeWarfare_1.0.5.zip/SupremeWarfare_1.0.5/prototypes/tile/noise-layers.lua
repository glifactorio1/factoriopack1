data:extend(
{
  {
    type = "noise-layer",
    name = "ilmenit-ore"
  },
}
)