data:extend({
{
	type= "item",
	name= "small-alien-artifact",
	order= "r-a",
	stack_size= 500,
	flags= { "goes-to-main-inventory" },
	icon="__SupremeWarfare__/graphics/extra-loot/saa-icon.png",
	group = "extra-loot",
	},
})