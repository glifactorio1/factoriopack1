data:extend({
{
    type = "recipe",
    name = "alien-artifact",
    result= "alien-artifact",
    ingredients= { {"small-alien-artifact", 50} },
	energy_required= 10,
    enabled= "true",
	category= "crafting"
  },
})