data:extend({
 {
    type = "recipe",
    name = "titanium-ore",
    enabled = "true",
    ingredients = 
    {
      {type="item", name="ilmenit-ore", amount=3},
    },
    result = "titanium-ore",
  }
})