data:extend({

 {
    type = "item",
    name = "ilmenit-ore",
    icon = "__SupremeWarfare__/graphics/metallurgy/ilmenit/ore-icon.png",
    flags = { "goes-to-main-inventory" },
    subgroup = "sb-ores",
    stack_size= 200,
  },
  {
    type= "item",
    name= "titanium-ore",
    icon = "__SupremeWarfare__/graphics/ores/titanium/ore-icon.png",
    flags= { "goes-to-main-inventory" },
    subgroup = "sb-ores",
    stack_size= 200,
  },
})