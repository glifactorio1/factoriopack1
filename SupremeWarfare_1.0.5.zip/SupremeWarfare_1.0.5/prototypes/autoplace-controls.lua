data:extend(
{
  {
    type = "autoplace-control",
    name = "metallurgy-ores",
    richness = true,
    order = "m-o"
  },
}
)
