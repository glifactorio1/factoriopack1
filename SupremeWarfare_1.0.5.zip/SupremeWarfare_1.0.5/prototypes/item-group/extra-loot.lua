data:extend(
{
  {
    type = "item-group",
    name = "sb-extra-loot",
    order = "d-e",
    inventory_order = "s",
    icon = "__SupremeWarfare__/graphics/item-group/core.png"
  },
  {
    type = "item-subgroup",
    name = "sb-loot",
    group = "sb-extra-loot",
    order = "01"
  },

}
)