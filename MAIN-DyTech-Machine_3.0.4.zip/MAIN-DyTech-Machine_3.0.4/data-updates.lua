require "config"

if Config.Tools then
require("prototypes.tools.item")
require("prototypes.tools.recipe")
require("prototypes.tools.tech")

end