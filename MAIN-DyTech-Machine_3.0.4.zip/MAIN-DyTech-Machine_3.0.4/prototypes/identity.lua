data:extend(
{
	{
    type = "item",
    name = "machines-active",
    icon = "__CORE-DyTech-Core__/graphics/intermediates/temp.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "metallurgy-intermediates",
    order = "silicon",
    stack_size = 1
  },
}
)