data:extend(
{
  {
    type = "item-with-entity-data",
    name = "car2",
    icon = "__MAIN-DyTech-Machine__/graphics/cars/car2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "dytech-machines-transport",
    order = "a-[armored-car]",
    place_result = "car2",
    stack_size = 10
  },
}
)