data:extend({{
	type = "item-with-entity-data",
	name = "vehicle-miner",
	icon = "__aai-vehicles-miner__/graphics/icons/miner.png",
	flags = {"goes-to-quickbar"},
	subgroup="transport",
    order = "ab[industrial]-a[miner]",
    stack_size = 1,
	place_result = "vehicle-miner",
}})
