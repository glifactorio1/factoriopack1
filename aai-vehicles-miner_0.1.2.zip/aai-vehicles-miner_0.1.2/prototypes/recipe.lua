data:extend({{
	type = "recipe",
	name = "vehicle-miner",
	ingredients =
	{
	  {"burner-mining-drill", 4},
	  {"iron-plate", 10},
	  {"iron-gear-wheel", 5}
	},
	enabled = true,
	energy_required = 5,
	results=
	{
	  {type="item", name="vehicle-miner", amount=1},
	}
}})
