data:extend({{
	type = "car",
	name = "vehicle-miner",
	order = "z[programmable]", -- programmable in programmable-vehicles
	icon = "__aai-vehicles-miner__/graphics/icons/miner.png",
	flags = {"pushable", "placeable-neutral", "player-creation", "placeable-off-grid"},
	minable = {mining_time = 1, result = "vehicle-miner"},
	max_health = 600,
	corpse = "medium-remnants",
	dying_explosion = "medium-explosion",
	energy_per_hit_point = 0.5,
	resistances = {
		{
			type = "fire",
			decrease = 15,
			percent = 50
		},
		{
			type = "physical",
			decrease = 15,
			percent = 30
		},
		{
			type = "impact",
			decrease = 50,
			percent = 60
		},
	},
	selection_box = {{-2, -2.4}, {2, 2.4}},
	collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
	burner =
	{
		effectivity = 1,
		fuel_inventory_size = 2,
		smoke = {
			{
			  name = "tank-smoke",
			  deviation = {0.25, 0.25},
			  frequency = 50,
			  position = {0, 1.5},
			  starting_frame = 0,
			  starting_frame_deviation = 60
			}
		}
	},
	effectivity = 2,
	weight = 15000,
	consumption = "50kW",
	braking_power = "50kW",
	terrain_friction_modifier = 0.01,
	friction = 0.03,
	rotation_speed = 0.003,
	turret_rotation_speed = 0.01,
	turret_return_timeout = 300,
	tank_driving = true,
	light =
	{
        {
          intensity = 0.6,
          minimum_darkness = 0.3,
          size = 30
        },
	  {
		type = "oriented",
		minimum_darkness = 0.3,
		picture =
		{
		  filename = "__core__/graphics/light-cone.png",
		  priority = "medium",
		  scale = 2,
		  width = 200,
		  height = 200
		},
		shift = {0, -14},
		size = 2,
		intensity = 0.6
	  }
	},
	animation =
    {
      layers =
      {
        {
          width = 1952/8,
		  height = 1688/8,
          frame_count = 2,
          direction_count = 64,
		  shift = {0.0, -0.88125},
		  animation_speed = 1200,
          animation_speed = 8,
          max_advance = 1,
          stripes =
          {
            {
             filename = "__aai-vehicles-miner__/graphics/entity/miner/miner-b.png",
             width_in_frames = 8,
             height_in_frames = 8,
            },
            {
             filename = "__aai-vehicles-miner__/graphics/entity/miner/miner-a.png",
             width_in_frames = 8,
             height_in_frames = 8,
            }
          }
        },
        {
          width = 1952/8,
		  height = 1688/8,
          frame_count = 2,
          apply_runtime_tint = true,
          direction_count = 64,
		  shift = {0.0, -0.88125},
		  animation_speed = 1200,
          max_advance = 1,
          line_length = 8,
          stripes =
          {
            {
             filename = "__aai-vehicles-miner__/graphics/entity/miner/miner-mask-b.png",
             width_in_frames = 8,
             height_in_frames = 8,
            },
            {
             filename = "__aai-vehicles-miner__/graphics/entity/miner/miner-mask-a.png",
             width_in_frames = 8,
             height_in_frames = 8,
            }
          }
        },
		{
          width = 1084/4,
          height = 1392/8,
          frame_count = 2,
          draw_as_shadow = true,
          direction_count = 64,
          shift = {0.9, 0.15},
          animation_speed = 60,
		  max_advance = 1,
		  stripes =
		  {
			{ filename = "__aai-vehicles-miner__/graphics/entity/miner/miner-shadow-3.png", width_in_frames = 4, height_in_frames = 8, },
			{ filename = "__aai-vehicles-miner__/graphics/entity/miner/miner-shadow-4.png", width_in_frames = 4, height_in_frames = 8, },
			{ filename = "__aai-vehicles-miner__/graphics/entity/miner/miner-shadow-1.png", width_in_frames = 4, height_in_frames = 8, },
			{ filename = "__aai-vehicles-miner__/graphics/entity/miner/miner-shadow-2.png", width_in_frames = 4, height_in_frames = 8, },
		  }
        }
      }
    },
	stop_trigger_speed = 0.2,
	sound_no_fuel = { { filename = "__base__/sound/fight/tank-no-fuel-1.ogg", volume = 0.6 }, },
	stop_trigger = { { type = "play-sound", sound = { { filename = "__base__/sound/car-breaks.ogg", volume = 0.6  }, } }, },
	sound_minimum_speed = 0.15;
	vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
	working_sound =
	{
	  sound = { filename = "__base__/sound/fight/tank-engine.ogg", volume = 0.6 },
	  activate_sound = { filename = "__base__/sound/fight/tank-engine-start.ogg", volume = 0.6 },
	  deactivate_sound = { filename = "__base__/sound/fight/tank-engine-stop.ogg", volume = 0.6 },
	  match_speed_to_activity = true,
	},
	open_sound = { filename = "__base__/sound/car-door-open.ogg", volume=0.7 },
	close_sound = { filename = "__base__/sound/car-door-close.ogg", volume = 0.7 },
	inventory_size = 60,
},
{
    type = "mining-drill",
    name = "vehicle-miner-attachment",
	order = "z-z",
    icon = "__base__/graphics/icons/burner-mining-drill.png",
    flags = {"placeable-neutral", "placeable-off-grid", "not-blueprintable", "not-deconstructable"},
    resource_categories = {"basic-solid"},
	max_health = 1000,
	healing_per_tick = 1000,
    corpse = "medium-remnants",
    collision_box = {{ -0, -0}, {0, 0}},
    selection_box = {{ -0.5, -0.5}, {0.5, 0.5}},
	collision_mask = {"not-colliding-with-itself"},
    mining_speed = 2,
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/burner-mining-drill.ogg",
        volume = 1
      },
    },
    energy_source =
    {
      type = "burner",
      effectivity = 1.5,
      fuel_inventory_size = 1,
      emissions = 0.1 / 3,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0.1, 0.1},
          frequency = 3
        }
      }
    },
    energy_usage = "1200kW",
    mining_power = 2.5,
    animations =
    {
	  north =
      {
        priority = "extra-high",
        width = 1,
        height = 1,
        line_length = 1,
        shift = {0, 0},
        filename = "__aai-vehicles-miner__/graphics/blank.png",
        frame_count = 1,
        animation_speed = 1,
      },
      east =
      {
        priority = "extra-high",
        width = 1,
        height = 1,
        line_length = 1,
        shift = {0, 0},
        filename = "__aai-vehicles-miner__/graphics/blank.png",
        frame_count = 1,
        animation_speed = 1,
      },
      south =
      {
        priority = "extra-high",
        width = 1,
        height = 1,
        line_length = 1,
        shift = {0, 0},
        filename = "__aai-vehicles-miner__/graphics/blank.png",
        frame_count = 1,
        animation_speed = 1,
      },
      west =
      {
        priority = "extra-high",
        width = 1,
        height = 1,
        line_length = 1,
        shift = {0, 0},
        filename = "__aai-vehicles-miner__/graphics/blank.png",
        frame_count = 1,
        animation_speed = 1,
      }
    },
    vector_to_place_result = {0,1},
    resource_searching_radius = 2.49,
}})
