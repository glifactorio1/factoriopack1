local vehicle_name = "vehicle-miner"
local attachment_name = "vehicle-miner-attachment"
local once = false

require("data-util")
require("util")



--[[
The mining attachment is supposed to pull energy from vehicle
but if a vehicle is stationary it won't consume fuel even if it's energy is 0.
Instead, pull a burnable item from the vehicle's inventory and add it ti a lua energy buffer.
feed the enrgy buffer into the attachment. 
]]--

function manage_new_entity (entity)
	if entity.valid and entity.name == vehicle_name then
		safe()
		local miner = {
			entity = entity,
			energy = 1000000, -- miner attachment takes energy from this
			attachment = nil, -- miner attachment goes here
			attachment_idle = 0, -- counter to destroy attachment
		}
		global.miners[entity.unit_number] = miner
	end
end

function on_entity_deployed(event)
	manage_new_entity(event.entity)
end

function on_built_entity(event)
	manage_new_entity(event.created_entity)
end


function on_entity_replaced(event)
	if global.miners[event.old_entity_unit_number] then
		local miner = global.miners[event.old_entity_unit_number]
		global.miners[event.old_entity_unit_number] = nil
		global.miners[event.new_entity_unit_number] = miner
		miner.entity = event.new_entity
	end
end

function on_player_created(event)
	-- players should start with a miner
	safe()
	game.players[event.player_index].insert{name=vehicle_name, count = 1}
	global.players_given_miners[event.player_index] = true
end

function safe()
	if not global.miners then global.miners = {} end
	if not global.players_given_miners then global.players_given_miners = {} end
end

function on_tick(event)
	global.tick = event.tick
	safe()
	if not once then
		once = true
		for player_index, player in pairs(game.players) do
			if not global.players_given_miners[player_index] then
				player.insert{name=vehicle_name, count = 1}
				global.players_given_miners[player_index] = true
			end
		end
	end
	for unit_number, miner in pairs(global.miners) do 
		if not miner.entity.valid then
			-- destroy
			if miner.attachment and miner.attachment.valid then
				miner.attachment.destroy()
			end
			global.miners[unit_number] = nil
		else 
			if not miner.attachment or not miner.attachment.valid then
				miner.attachment = miner.entity.surface.create_entity{
					name=attachment_name, 
					position=miner.entity.position, 
					force=miner.entity.force
				}
				miner.attachment.destructible = false
				miner.attachment.energy = 10000
			else
				miner.attachment.teleport(miner.entity.position)
				if miner.energy < 20000 then
					consume_fuel(miner)
				end
				if miner.energy > 0 then
					-- force animationa
					local min_speed = 0.002
					if miner.entity.energy > 0 and (miner.entity.speed < min_speed and miner.entity.speed > -min_speed and not miner.entity.passenger) then 
						if math.random() < 0.5 then 
							miner.entity.speed = min_speed
						else
							miner.entity.speed = -min_speed
						end
					end
					local attachment_energy = miner.attachment.energy
					miner.attachment.energy = 10000000
					local attachment_energy_used = miner.attachment.energy - attachment_energy
					mining_particles(miner)
					if attachment_energy_used > 0 then 
						miner.attachment_idle = 0
						miner.energy = miner.energy - attachment_energy_used
					else
						-- if a miner goes off ore it permenantly shuts down
						miner.attachment_idle = miner.attachment_idle + 1 
						if miner.attachment_idle > 60 then
							miner.energy = miner.energy + miner.attachment.energy
							miner.attachment.destroy()
							miner.attachment = nil
						end
					end
				end
			end
			collect_floor_items(miner)
		end
	end
end

function consume_fuel(miner)
	local inventory = miner.entity.get_inventory(defines.inventory.car_fuel)
	if inventory and not inventory.is_empty() then
		for fuel_name, count in pairs(inventory.get_contents()) do
			local item_type = game.item_prototypes[fuel_name]
			if item_type and item_type.fuel_value then
				miner.energy = miner.energy + item_type.fuel_value
				inventory.remove({name=fuel_name, count=1})
			end
		end
	end
end

function mining_particles(miner)
	if miner.attachment and miner.attachment.valid and miner.attachment.mining_target then
		local forward = orientation_to_vector(miner.entity.orientation, 1)
		-- smoke
		if (global.tick + miner.entity.unit_number) % 3 == 0 then
			miner.entity.surface.create_entity{
				name = "smoke",
				position = vectors_add(miner.entity.position, vectors_add({x=0, y=-0.4}, {x= forward.x * -0.25, y=forward.y * -0.25})),   
				source = miner.entity, 
				speed = 0.1,
				movement = {(math.random() - 0.5)*0.1, (math.random() - 0.5)*0.1},
				frame_speed = 1,
				vertical_speed = 0.1,
				height = 0.1} -- needs more testing
		end
		-- particle
		if (global.tick + miner.entity.unit_number) % 3 == 0 and miner.attachment.mining_target.prototype.mineable_properties and
			miner.attachment.mining_target.prototype.mineable_properties.miningparticle then
			local height = math.random()
			local fm = 0.9 + math.random() * 0.1
			miner.entity.surface.create_entity{
				name = miner.attachment.mining_target.prototype.mineable_properties.miningparticle,
				position = vectors_add(miner.entity.position, {x = (math.random() - 0.5) * 0.75 + fm * forward.x * 3, y = (math.random() - 0.5) * 0.75 +fm * forward.y * 3}),
				source = miner.entity, 
				speed = 0.1,
				movement = {(math.random() - 0.5)*0.15 + forward.x / 20, (math.random() - 0.5)*0.15 + forward.y / 20},
				frame_speed = 1,
				vertical_speed = height*0.1,
				height = height*0.1} -- needs more testing
		end
	end 
end

function collect_floor_items(miner)
	local inventory = miner.entity.get_inventory(defines.inventory.car_trunk)
	local burner = miner.entity.get_inventory(defines.inventory.car_fuel)
	local ground_items = miner.entity.surface.find_entities_filtered{
		name="item-on-ground", 
		area={{x=miner.entity.position.x-2,y=miner.entity.position.y-2},{x=miner.entity.position.x+2,y=miner.entity.position.y+2}}}
	for _, i in pairs(ground_items) do 
		--send_message(i.stack.name)
		local inserted_count = inventory.insert({name=i.stack.name, count=i.stack.count})
		local remaining_count = i.stack.count - inserted_count
		if remaining_count < 1 then
			i.destroy()
		else
			i.stack.count = remaining_count
		end
	end
	if global.tick % 6 == 0 then
		local fm = global.tick % 6 == 1 and 2.5 or 0
		local forward = orientation_to_vector(miner.entity.orientation, fm)
		local tree_range = 2.5
		local trees = miner.entity.surface.find_entities_filtered{
			type="tree", 
			area={{x=forward.x + miner.entity.position.x-tree_range,y=forward.y + miner.entity.position.y-tree_range},
				{x=forward.x + miner.entity.position.x+tree_range,y=forward.y + miner.entity.position.y+tree_range}}}
		for _, tree in pairs(trees) do 
			for _2, product in pairs(tree.prototype.mineable_properties.products) do 
				if (not product.probablility) or math.random() < product.probablility then
					if product.amount_min and product.amount_max then
						inserted = burner.insert({name=product.name, count=math.random(product.amount_min, product.amount_max)})
						if inserted < 1 then
							inventory.insert({name=product.name, count=math.random(product.amount_min, product.amount_max)})
						end
					else 
						inserted = burner.insert({name=product.name, count=product.amount})
						if inserted < 1 then
							inventory.insert({name=product.name, count=product.amount})
						end
					end
				end
			end
			tree.die()
		end
	end
end

-- core events
script.on_event(defines.events.on_player_created, on_player_created)
script.on_event(defines.events.on_tick, on_tick)
script.on_event(defines.events.on_built_entity, on_built_entity)

-- custom events
remote.add_interface("aai-vehicles-miner",
	{ 
		on_entity_deployed = -- sent by aai-programmable-structures
			function(event) return on_entity_deployed(event) end ,
		on_entity_replaced = -- sent by aai-programmable-vehicles -- replaced by equivalent
			function(event) return on_entity_replaced(event) end ,
	
	}
)
