data:extend(
{
  {
    type = "item",
    name = "equalizer-chest",
    icon = "__Equalizer_Chests__/graphics/icons/equalizer-chest.png",
    flags = {"goes-to-quickbar"},
    subgroup = "storage",
    order = "a[items]-d[equalizer-chest]",
    place_result = "equalizer-chest",
    stack_size = 50
  },
}
)