data:extend(
{
    {
    type = "recipe",
    name = "equalizer-chest",
    enabled = "false",
    ingredients = {
      {"advanced-circuit", 4},
      {"fast-inserter", 4},
      {"steel-chest", 1}
    },
    result = "equalizer-chest"
  },
}
)