require("prototypes.technology")
require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipes")