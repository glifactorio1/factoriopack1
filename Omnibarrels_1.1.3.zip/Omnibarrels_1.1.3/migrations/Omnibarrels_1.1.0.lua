-- Reload recipes and technologies
for i, player in ipairs(game.players) do
  player.force.reset_recipes()
  player.force.reset_technologies()
end

-- if fluid handling already researched, unlock all recipes in subgroup "barrel"
for i, force in pairs(game.forces) do
  if force.technologies["fluid-handling"].researched then
    for k, recipe in pairs(force.recipes) do
      if recipe.subgroup.name == "barrel" or
         recipe.subgroup.name == "empty-barrel" or 
         recipe.subgroup.name == "fill-barrel" then
        recipe.enabled = true
      end
    end
  end
end