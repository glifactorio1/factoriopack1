barrel_size = 25 -- default 25
barrel_stack = 10 -- default 10
barrel_fill_energy = 1
barrel_empty_energy = 1

-- if there are more fluids than this number, all barrel filling recipes move to new tab
-- base game has 7 fluids
new_tab_threshold = 7

-- use alternative, bright colour overlay?
high_contrast = false

-- opacity of colour overlay
body_alpha = 0.75
hoop_alpha = 0.75

if high_contrast then
  body_mask = "__Omnibarrels__/graphics/icon/barrel-body-mask-white.png"
  hoop_mask = "__Omnibarrels__/graphics/icon/barrel-hoop-mask-white.png"
else
  body_mask = "__Omnibarrels__/graphics/icon/barrel-side-mask.png"
  hoop_mask = "__Omnibarrels__/graphics/icon/barrel-hoop-lid-mask.png"
end

-- use tidied-up icon for empty barrels
data.raw.item["empty-barrel"].icon = "__Omnibarrels__/graphics/icon/empty-barrel.png"
data.raw.item["empty-barrel"].stack_size = barrel_stack

-- remove crude oil barrels from fluid handling, going to be re-adding them below
-- not strictly necessary, but tidy
for i,e in pairs(data.raw["technology"]["fluid-handling"].effects) do
  if e["recipe"] == "fill-crude-oil-barrel" or
    e["recipe"] == "empty-crude-oil-barrel" then
    data.raw["technology"]["fluid-handling"].effects[i] = nil
  end
end

-- get total number of fluids
fluid_count = 0
for i, f in pairs(data.raw.fluid) do
  fluid_count = fluid_count + 1
end

barrel_subgroup = "barrel"
fill_subgroup = "barrel"
empty_subgroup = "barrel"

if fluid_count > new_tab_threshold then
  data:extend({
    {
      type = "item-subgroup",
      name = "fill-barrel",
      group = "fluids",
      order = "b"
    },
    {
      type = "item-subgroup",
      name = "empty-barrel",
      group = "fluids",
      order = "c"
    }
  })
  fill_subgroup = "fill-barrel"
  empty_subgroup = "empty-barrel"
end

-- generate filled barrel item and recipes for each fluid
for i, f in pairs(data.raw.fluid) do
  fluid_count = fluid_count + 1
  -- barrel colours from fluid colour
  local body_tint = util.table.deepcopy(f.base_color)
  body_tint["a"] = body_alpha
  local hoop_tint = util.table.deepcopy(f.flow_color)
  hoop_tint["a"] = hoop_alpha
  
  -- generate item, fill recipe and empty recipe for each fluid
  data:extend({
    {
      type = "item",
      name = f.name.."-barrel",
      localised_name = {"item-name.filled-barrel", {"fluid-name." .. f.name}},
      icons =
      {
        {
          icon = "__Omnibarrels__/graphics/icon/empty-barrel.png"
        },
        {
          icon = body_mask,
          tint = body_tint
        },
        {
          icon = hoop_mask,
          tint = hoop_tint
        }
      },
      flags = {"goes-to-main-inventory"},
      subgroup = barrel_subgroup,
      order = "b["..f.name.."-barrel]",
      stack_size = barrel_stack
    },
    {
      type = "recipe",
      name = "fill-"..f.name.."-barrel",
      localised_name = {"recipe-name.fill-barrel", {"fluid-name." .. f.name}},
      category = "crafting-with-fluid",
      energy_required = barrel_fill_energy,
      subgroup = fill_subgroup,
      order = "b[fill-"..f.name.."-barrel]",
      enabled = false,
      icons =
      {
        {icon = f.icon},
        {icon = "__Omnibarrels__/graphics/icon/fill-barrel-recipe.png"}
      },
      ingredients =
      {
        {type="fluid", name=f.name, amount=barrel_size},
        {type="item", name="empty-barrel", amount=1},
      },
      results=
      {
        {type="item", name=f.name.."-barrel", amount=1}
      }
    },
    {
      type = "recipe",
      name = "empty-"..f.name.."-barrel",
      localised_name = {"recipe-name.empty-filled-barrel", {"fluid-name." .. f.name}},
      category = "crafting-with-fluid",
      energy_required = barrel_empty_energy,
      subgroup = empty_subgroup,
      order = "c[empty-"..f.name.."-barrel]",
      enabled = false,
      icons =
      {
        {icon = f.icon},
        {icon = "__Omnibarrels__/graphics/icon/empty-barrel-recipe.png"}
      },
      ingredients =
      {
        {type="item", name= f.name.."-barrel", amount=1}
      },
      results=
      {
        {type="fluid", name=f.name, amount=barrel_size},
        {type="item", name="empty-barrel", amount=1}
      }
    }
  })
  
  -- add recipe unlocks to fluid handling technology
  table.insert
  (
    data.raw["technology"]["fluid-handling"].effects,
    {type = "unlock-recipe", recipe = "fill-"..f.name.."-barrel"}
  )
  table.insert
  (
    data.raw["technology"]["fluid-handling"].effects,
    {type = "unlock-recipe", recipe = "empty-"..f.name.."-barrel"}
  )
end