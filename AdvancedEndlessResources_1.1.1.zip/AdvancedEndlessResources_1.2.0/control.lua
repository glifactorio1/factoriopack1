require "util"


remote.add_interface("InfOres", {
redo = function()
reset100()
end
})


function onInit()
reset101 = 1
end

 script.on_event(defines.events.on_tick, function(event)
   onTick()
 end)
  script.on_init(function()
   onInit()
 end)

function onTick()
	if reset101 == 1 then
	reset101 = 0
	reset100()
	end
end

function reset100()
for k, v in pairs(game.surfaces["nauvis"].find_entities_filtered{type="resource"}) do 
	if v.amount < 100000 then
	v.amount = 100000 end
	end
end



