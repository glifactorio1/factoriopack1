require "util"

for k, v in pairs(data.raw.resource) do
   data.raw.resource[k].infinite = true
   data.raw.resource[k].minimum  = 100000
   data.raw.resource[k].normal   = 100000
end



