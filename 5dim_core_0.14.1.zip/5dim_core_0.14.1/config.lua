--Stack changes, if it is true you make the biggest stacks
stackchanges = true --Default: True

--Inventory size changes, if it is true, your inventory size is more big
inventorychanges = true --Default: True

--Enable ores, if it is true it will add more ores
dimoresenable = false --Default: True