script.on_event("rotate-inserter-pickup", function(event)
local selection = game.players[event.player_index].selected
if selection and selection.type == "inserter" then
  RotatePickupDirection(selection, event)
end
end)

script.on_event("cycle-inserter-drop", function(event)
local selection = game.players[event.player_index].selected
if selection and selection.type == "inserter" then
  CycleInserterDrop(selection, event)
end
end)

script.on_event("toggle-inserter-drop", function(event)
local selection = game.players[event.player_index].selected
if selection and selection.type == "inserter" then
  ToggleInserterDrop(selection, event)
end
end)

function RotatePickupDirection(entity, event)
  local px = entity.pickup_position.x - entity.position.x
  local py = entity.pickup_position.y - entity.position.y
  -- NOTE: inserter drop location is opposite to orientation direction
  if py < 0 then -- is north
    if entity.direction == defines.direction.west then -- skip east, go south
      entity.pickup_position = {entity.position.x, entity.position.y - py}
    else -- go east
      entity.pickup_position = {entity.position.x - py, entity.position.y}
    end
  elseif  px > 0 then -- is east, go south
    if entity.direction == defines.direction.north then -- skip south, go west
      entity.pickup_position = {entity.position.x - px, entity.position.y}
    else -- go south
      entity.pickup_position = {entity.position.x, entity.position.y + px}
    end
  elseif py > 0 then -- is south, go west
    if entity.direction == defines.direction.east then -- skip west, go north
      entity.pickup_position = {entity.position.x, entity.position.y - py}
    else
      entity.pickup_position = {entity.position.x - py, entity.position.y}
    end
  elseif px < 0 then -- is west, go north
    if entity.direction == defines.direction.south then -- skip north, go east
      entity.pickup_position = {entity.position.x - px, entity.position.y}
    else
      entity.pickup_position = {entity.position.x, entity.position.y + px}
    end
  end
  -- set direction to force update of pickup direction when inserter is waiting
  entity.direction = entity.direction
end

function ToggleInserterDrop(entity, event)
  local OFFSET = 0.3125
  local dx = entity.drop_position.x - entity.position.x
  local dy = entity.drop_position.y - entity.position.y
  if entity.direction == defines.direction.south or entity.direction == defines.direction.north then
    if dy % 1 > 0.5 then
      dy = dy + OFFSET
    else
      dy = dy - OFFSET
    end
  elseif entity.direction == defines.direction.west or entity.direction == defines.direction.east then
    if dx % 1 > 0.5 then
      dx = dx + OFFSET
    else
      dx = dx - OFFSET
    end
  end
  entity.drop_position = {entity.position.x + dx, entity.position.y + dy}
  -- set direction to force update of insert location when hand is already full
  entity.direction = entity.direction
end

function CycleInserterDrop(entity, event)
  local OFFSET = 0.15625
  local dx = entity.drop_position.x - entity.position.x
  local dy = entity.drop_position.y - entity.position.y
  if entity.direction == defines.direction.south then
    if dx > 0 then
      dx = 0 - OFFSET
    else
      dx = dx + OFFSET
    end
  elseif entity.direction == defines.direction.west then
    if dy > 0 then
      dy = 0 - OFFSET
    else
      dy = dy + OFFSET
    end
  elseif entity.direction == defines.direction.north then
    if dx < 0 then
      dx = OFFSET
    else
      dx = dx - OFFSET
    end
  elseif entity.direction == defines.direction.east then
    if dy < 0 then
      dy = OFFSET
    else
      dy = dy - OFFSET
    end
  end
  entity.drop_position = {entity.position.x + dx, entity.position.y + dy}
  -- set direction to force update of insert location when hand is already full
  entity.direction = entity.direction
end