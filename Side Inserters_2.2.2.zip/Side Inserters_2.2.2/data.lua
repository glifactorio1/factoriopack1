data:extend({
  {
    type = "custom-input",
    name = "toggle-inserter-drop",
    key_sequence = "SHIFT + N",
    consuming = "all"
  },
  {
    type = "custom-input",
    name = "cycle-inserter-drop",
    key_sequence = "SHIFT + F",
    consuming = "all"
  },
  {
    type = "custom-input",
    name = "rotate-inserter-pickup",
    key_sequence = "SHIFT + R",
    consuming = "script-only"
  }
})