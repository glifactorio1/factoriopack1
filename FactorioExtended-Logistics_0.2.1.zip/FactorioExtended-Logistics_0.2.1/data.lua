require("prototypes.item.item-logistics")

require("prototypes.recipe.recipe-logistics")

require("prototypes.entity.entity-logistics")

require("prototypes.technology.technology-logistical-engineer")
require("prototypes.technology.technology-logistic-slots")
require("prototypes.technology.technology-logistic-trash-slots")
require("prototypes.technology.technology-robot-speed")
require("prototypes.technology.technology-robot-storage")
