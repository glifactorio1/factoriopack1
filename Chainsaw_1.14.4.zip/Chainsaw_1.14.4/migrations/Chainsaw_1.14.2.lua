for _, player in pairs(game.players) do
  player.print('==========================')
  player.print('======= UPDATED MOD =======')
  player.print('Chainsaw mod 1.14.2 : Now with a shortcut to toggle between the chainsaw and your fastest mining tool. (default: Tab)')
end
