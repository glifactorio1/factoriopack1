require "prototypes.item.item"
require "prototypes.recipe.recipe"
require "prototypes.entity.entities"
require "prototypes.technology.technology"

data:extend({
  {
    type = "custom-input",
    name = "chainsaw-toggle",
    key_sequence = "tab"
  }
})
