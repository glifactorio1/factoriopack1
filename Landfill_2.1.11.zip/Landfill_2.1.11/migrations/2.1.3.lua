for _,force in pairs(game.forces) do
	force.recipes["water-be-gone"].reload()
end