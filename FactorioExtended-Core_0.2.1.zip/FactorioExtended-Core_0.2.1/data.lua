if not factorioextended then factorioextended = {} end
if not factorioextended.core then factorioextended.core = {} end


require("prototypes.recipe.recipe-functions")
require("prototypes.item.item-groups")
require("prototypes.item.items")
require("prototypes.recipe.recipes")
require("prototypes.technology.technology")