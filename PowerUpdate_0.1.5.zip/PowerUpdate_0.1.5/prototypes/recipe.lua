data:extend({
  {
    type = "recipe",
    name = "solar-panel-mk2",
    energy_required = 15,
    enabled = false,
    ingredients =
    {
      {"solar-panel", 1},
	  {"processing-unit", 5},
      {"steel-plate", 20}
    },
    result = "solar-panel-mk2"
  },
  {
    type = "recipe",
    name = "accumulator-mk2",
    energy_required = 15,
    enabled = false,
    ingredients =
    {
	  {"accumulator", 4},
      {"advanced-circuit", 5}
    },
    result = "accumulator-mk2"
  }
})
