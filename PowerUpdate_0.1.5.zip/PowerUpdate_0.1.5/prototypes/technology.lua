data:extend(
{
  {
    type = "technology",
    name = "solar-energy-2",
    icon = "__base__/graphics/technology/solar-energy.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "solar-panel-mk2"
      }
    },
    prerequisites = {"solar-energy", "alien-technology", "advanced-electronics-2"},
    unit =
    {
      count = 250,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
      },
      time = 40
    },
    order = "a-h-c",
  },
  {
    type = "technology",
    name = "electric-energy-accumulators-2",
    icon = "__base__/graphics/technology/electric-energy-acumulators.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "accumulator-mk2"
      }
    },
    prerequisites = {"electric-energy-accumulators-1", "alien-technology", "advanced-electronics-2"},
    unit =
    {
      count = 200,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
      },
      time = 40
    },
    order = "c-e-a",
  }
})
