data:extend({
  {
    type = "item",
    name = "solar-panel-mk2",
    icon = "__PowerUpdate__/graphics/icons/solar-panel-mk2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy",
    order = "f",
    place_result = "solar-panel-mk2",
    stack_size = 50
  },
  {
    type = "item",
    name = "accumulator-mk2",
    icon = "__PowerUpdate__/graphics/icons/accumulator-mk2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy",
    order = "f",
    place_result = "accumulator-mk2",
    stack_size = 50
  }
})
