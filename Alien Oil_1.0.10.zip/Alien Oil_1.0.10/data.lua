require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.projectiles")

table.insert(data.raw["technology"]["alien-technology"].effects,{type="unlock-recipe",recipe="alien-compass"})