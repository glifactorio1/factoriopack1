data:extend(
	{
		{
			type = "recipe",
			name = "alien-compass",
			enabled = "false",
			ingredients =
			{
				{"alien-artifact", 10},
				{"processing-unit", 2},
				{"iron-plate", 2}
			},
			result_count = 2,
			result = "alien-compass"
		}
	}
)
