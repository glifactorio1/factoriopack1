if not angelsmods then angelsmods = {} end
if not angelsmods.refining then angelsmods.refining = {} end
angelsmods.refining.furnacetrigger = true