--Define if decoration is installed
decoration = true --Default: True