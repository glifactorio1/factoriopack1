data:extend(
{
  {
    type = "item",
    name = "roboportmk2",
    icon = "__base__/graphics/icons/roboport.png",
    flags = {"goes-to-quickbar"},
    subgroup = "logistic-network",
    order = "c[signal]-a[roboport]",
    place_result = "roboportmk2",
    stack_size = 5
  }
}
)
