data:extend(
{
  {
    type = "recipe",
    name = "pipe-to-ground-v2",
	energy_required = 10,
    ingredients =
    {
      {"pipe", 30},
      {"iron-plate", 20}
    },
    result_count = 2,
    result = "pipe-to-ground-v2",
	enabled = "false"
  },
  {
    type = "recipe",
    name = "pipe-to-ground-v3", 
	energy_required = 30,
	category = "advanced-crafting",
    ingredients =
    {
      {"pipe", 50},
      {"steel-plate", 30}
    },
    result_count = 2,
    result = "pipe-to-ground-v3",
	enabled = "false"
  }
})