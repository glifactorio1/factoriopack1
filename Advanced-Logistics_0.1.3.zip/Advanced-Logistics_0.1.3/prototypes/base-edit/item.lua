data.raw["item"]["underground-belt"].icon = "__Advanced-Logistics__/graphics/icons/underground-belt-v1.png"
data.raw["item"]["fast-underground-belt"].icon = "__Advanced-Logistics__/graphics/icons/fast-underground-belt-v1.png"
data.raw["item"]["express-underground-belt"].icon = "__Advanced-Logistics__/graphics/icons/express-underground-belt-v1.png"
data.raw["item"]["pipe-to-ground"].icon = "__Advanced-Logistics__/graphics/icons/pipe-to-ground-v1.png"

data.raw["underground-belt"]["underground-belt"].max_distance = 10
data.raw["underground-belt"]["fast-underground-belt"].max_distance = 10
data.raw["underground-belt"]["express-underground-belt"].max_distance = 10