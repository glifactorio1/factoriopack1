data:extend(
{
	{
    type = "technology",
    name = "logistics-upgrade-1",
    icon = "__Advanced-Logistics__/graphics/icons/underground-belt-v2.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "underground-belt-v2"
      }
    },
    prerequisites = {"logistics"},
    unit =
    {
      count = 40,
      ingredients =
      {
        {"science-pack-1", 1}
      },
      time = 15
    },
    order = "a-f-b",
  },
  {
    type = "technology",
    name = "logistics-upgrade-2",
    icon = "__Advanced-Logistics__/graphics/icons/underground-belt-v3.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "underground-belt-v3"
      }
    },
    prerequisites = {"logistics-upgrade-1", "steel-processing"},
    unit =
    {
      count = 80,
      ingredients =
      {
        {"science-pack-1", 1},
		{"science-pack-2", 1}
      },
      time = 30
    },
    order = "a-f-b",
  },
  {
    type = "technology",
    name = "logistics-2-upgrade-1",
    icon = "__Advanced-Logistics__/graphics/icons/fast-underground-belt-v2.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "fast-underground-belt-v2"
      }
    },
    prerequisites = {"logistics-2"},
    unit =
    {
      count = 40,
      ingredients =
      {
        {"science-pack-1", 1},
		{"science-pack-2", 1}
      },
      time = 15
    },
    order = "a-f-b",
  },
  {
    type = "technology",
    name = "logistics-2-upgrade-2",
    icon = "__Advanced-Logistics__/graphics/icons/fast-underground-belt-v3.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "fast-underground-belt-v3"
      }
    },
    prerequisites = {"logistics-2-upgrade-1", "steel-processing"},
    unit =
    {
      count = 80,
      ingredients =
      {
        {"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1}
      },
      time = 30
    },
    order = "a-f-b",
  },
  {
    type = "technology",
    name = "logistics-3-upgrade-1",
    icon = "__Advanced-Logistics__/graphics/icons/express-underground-belt-v2.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "express-underground-belt-v2"
      }
    },
    prerequisites = {"logistics-3"},
    unit =
    {
      count = 40,
      ingredients =
      {
        {"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1}
      },
      time = 15
    },
    order = "a-f-b",
  },
  {
    type = "technology",
    name = "logistics-3-upgrade-2",
    icon = "__Advanced-Logistics__/graphics/icons/express-underground-belt-v3.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "express-underground-belt-v3"
      }
    },
    prerequisites = {"logistics-3-upgrade-1", "steel-processing"},
    unit =
    {
      count = 80,
      ingredients =
      {
        {"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1}
      },
      time = 30
    },
    order = "a-f-b",
  }
})