require("prototypes.base-edit.item")
--underground transport belt
require("prototypes.entity.transport-belt")
require("prototypes.recipe.transport-belt")
require("prototypes.item.transport-belt")
require("prototypes.technology.transport-belt")
--underground pipes
require("prototypes.entity.pipe")
require("prototypes.recipe.pipe")
require("prototypes.item.pipe")
require("prototypes.technology.pipe")
--roboport mk2
require("prototypes.entity.upgraded-roboport")
require("prototypes.item.upgraded-roboport")
require("prototypes.recipe.upgraded-roboport")
require("prototypes.technology.upgraded-roboport")


data:extend({
    {
        type = "item-subgroup",
        name = "underground-belt",
        group = "logistics",
        order = "b",
    },
	{
        type = "item-subgroup",
        name = "underground-pipe",
        group = "logistics",
        order = "d",
    }
})
data.raw.recipe["underground-belt"].subgroup = "underground-belt"
data.raw.recipe["underground-belt"].order = "a[underground-belt]-a[underground-belt]"
data.raw.recipe["fast-underground-belt"].subgroup = "underground-belt"
data.raw.recipe["fast-underground-belt"].order = "b[fast-underground-belt]-a[fast-underground-belt]"
data.raw.recipe["express-underground-belt"].subgroup = "underground-belt"
data.raw.recipe["express-underground-belt"].order = "c[express-underground-belt]-a[express-underground-belt]"
data.raw.recipe["pipe-to-ground"].subgroup = "underground-pipe"
data.raw.recipe["pipe-to-ground"].order = "a[underground-pipe]-a[underground-pipe]"
data.raw.recipe["pipe-to-ground-v2"].subgroup = "underground-pipe"
data.raw.recipe["pipe-to-ground-v2"].order = "b[pipe-to-ground-v2]-b[pipe-to-ground-v2]"
data.raw.recipe["pipe-to-ground-v3"].subgroup = "underground-pipe"
data.raw.recipe["pipe-to-ground-v3"].order = "c[pipe-to-ground-v3]-c[pipe-to-ground-v3]"