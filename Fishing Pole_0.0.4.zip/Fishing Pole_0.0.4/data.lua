require "prototypes.entity"
require "prototypes.items"
require "prototypes.recipe"
require "prototypes.tech"
