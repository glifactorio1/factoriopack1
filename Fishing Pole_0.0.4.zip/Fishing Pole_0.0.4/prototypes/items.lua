data:extend(
{
  {
    type = "item",
    name = "fishing-pole",
    icon = "__Fishing Pole__/graphics/icons/fishing-pole.png",
    flags = {"goes-to-quickbar"},
    subgroup = "inserter",
    order = "c[fishing-pole]",
    place_result = "fishing-pole",
    stack_size = 50
  },
})