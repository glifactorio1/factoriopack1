data:extend(
{
    {
        type = "recipe",
        name = "fishing-pole",
        enabled = false,
        energy_required = 10,
        ingredients =
        {
            {"iron-plate", 10},
            {"electronic-circuit", 4},
            {"wood", 10},
            {"copper-cable", 20},
        },
        result = "fishing-pole"
    },
})