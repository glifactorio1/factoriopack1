require("prototypes.ore-eraser")
