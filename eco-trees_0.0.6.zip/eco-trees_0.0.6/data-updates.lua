require "config"

----All Trees---- EVEN MOD TREES 
--
for k,tree in pairs(data.raw["tree"]) do
	if tree.emissions_per_tick then
		local Emissions = tree.emissions_per_tick
		tree.emissions_per_tick = Emissions * EmissionsFactor
	end	--trees have negative emissions so they soak up polution
end

----Forest easyer to walk through----
if TreeCollision then
	for _,tree in pairs(data.raw["tree"]) do
		tree.collision_box = {{-0.2, -0.2}, {0.2, 0.2}}
	end
end

