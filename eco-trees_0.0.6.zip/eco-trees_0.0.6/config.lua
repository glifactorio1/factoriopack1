----Pollution Clean Factor----
EmissionsFactor = 10
--put a negative number ex:-100 to make trees produce pollution.

----Tree Collision Fix----
TreeCollision = true
--This makes it easyer to walk through forest.



