data:extend(
{
  {
    type = "item-subgroup",
    name = "programmable-structures",
    group = "logistics",
    order = "g-b"
  }
}
)