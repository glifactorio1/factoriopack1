data.raw["technology"]["circuit-network"].unit = {
	count = 100,
	ingredients =
	{
		{"science-pack-1", 1},
	},
	time = 10
}

--table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "unit-scan"})
--table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "unit-control"})
--table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "unitdata-scan"})
--table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "unitdata-control"})
table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "zone-scan"})
table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "zone-control"})
table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "tile-scan"})
