require("util")
require("remote")

--[[
type = "input-output" has a combinator in and out (both optional) 
]]--

struct_types = {
	unit_scan = { 
		name = "unit_scan",
		type = "input-output",
		struct_main = "unit-scan",
		struct_input = "struct-generic-input",
		struct_output = "struct-generic-output",
	},
	unitdata_scan = { 
		name = "unitdata_scan",
		type = "input-output",
		struct_main = "unitdata-scan",
		struct_input = "struct-generic-input",
		struct_output = "struct-generic-output",
	},
	zone_scan = { 
		name = "zone_scan",
		type = "input-output",
		struct_main = "zone-scan",
		struct_input = "struct-generic-input",
		struct_output = "struct-generic-output",
	},
	tile_scan = { 
		name = "tile_scan",
		type = "input-output",
		struct_main = "tile-scan",
		struct_input = "struct-generic-input",
		struct_output = "struct-generic-output",
	},
	unit_control = { 
		name = "unit_control",
		type = "input-output",
		struct_main = "unit-control",
	},
	unitdata_control = { 
		name = "unitdata_control",
		type = "input-output",
		struct_main = "unitdata-control",
	},
	zone_control = { 
		name = "zone_control",
		type = "input-output",
		struct_main = "zone-control",
	},
	vehicle_deployer = { 
		name = "vehicle_deployer",
		type = "vehicle-deployer",
		struct_main = "vehicle-deployer",
		struct_overlay = "vehicle-deployer-overlay",
		struct_belt = "vehicle-deployer-belt",
		struct_reserved = "vehicle-deployer-reserved",
		deploy_start_offset = 0,
		deploy_end_offset = 6,
		deploy_time = 3 * 60, -- 2 seconds
		deployer_overlay_offset = 4,
		deployer_chest_offset = 0,
		deployer_belt_offset = -2,
	},
}

max_structs_per_tick = 10
composite_suffix = "-_-" -- used to filter out sub-units (i.e. "-" would break most units)

-- unit properties
signal_for_speed = {type = "virtual", name = "signal-speed"} -- * 1000
signal_for_angle = {type = "virtual", name = "signal-angle"} -- * 360 degrees
signal_for_position_x_tiles = {type = "virtual", name = "signal-x-tile"} -- x tiles
signal_for_position_y_tiles = {type = "virtual", name = "signal-y-tile"} -- y tiles
signal_for_position_x_sub = {type = "virtual", name = "signal-x-sub"} -- * 100 x tiles
signal_for_position_y_sub = {type = "virtual", name = "signal-y-sub"} -- * 100 y tiles
signal_for_health = {type = "virtual", name = "signal-health"}
signal_for_time_target = {type = "virtual", name = "signal-time-target"}
signal_for_time_move = {type = "virtual", name = "signal-time-move"}
signal_for_time_command = {type = "virtual", name = "signal-time-command"}
signal_for_energy = {type = "virtual", name = "signal-energy"}

-- other signals
signal_for_player = {type = "virtual", name = "signal-player"}
signal_for_player_cursor = {type = "virtual", name = "signal-player-cursor"}
signal_for_enemy_unit = {type = "virtual", name = "signal-enemy-unit"}
signal_for_enemy_unit_spawner = {type = "virtual", name = "signal-enemy-unit-spawner"}
signal_for_enemy_turret = {type = "virtual", name = "signal-enemy-turret"}
signal_for_land = {type = "virtual", name = "signal-land"}
signal_for_water = {type = "virtual", name = "signal-water"}
signal_for_count = {type = "virtual", name = "signal-count"}
signal_for_range = {type = "virtual", name = "signal-range"}

function struct_force_update() 
	
	if not global.struct then
		global.struct = {}
	end
	if not global.struct.entities_pending_manage then
		-- delayed buffer of on_built_entity so that the script can handle assignment if responsible for creation
		global.struct.entities_pending_manage = {}
	end
	if not global.struct.unit_numbers then
		-- convert a unit_number to a unit_id
		global.struct.unit_numbers = {}
	end
	if not global.struct.next_struct_id then
		global.struct.next_struct_id = 1
	end
	if not global.struct.structs then
		global.struct.structs = {}
	end
	if not global.struct.ghosts then
		global.struct.ghosts = {}
	end

end

function struct_on_destroy_entity(entity)
	if(entity.unit_number) then
		global.struct.unit_numbers[entity.unit_number] = nil
	end
end

function struct_on_built_entity(event)
	local entity = event.created_entity
	for _,struct_type in pairs(struct_types) do 
		if entity.name == struct_type.struct_main then
			struct_manage_new(entity)
		elseif entity.name == "entity-ghost" and entity.ghost_name == struct_type.struct_main then
			global.struct.ghosts[entity.unit_number] = {
				struct_type = _,
				entity = entity,
				position = {x = entity.position.x, y = entity.position.y},
				surface = entity.surface,
				force = entity.force
			}
		end
	end
end

function struct_on_entity_died(event)
	struct_unmanage_by_entity(event.entity)
end

function struct_manage_new(entity) 
	if entity.backer_name then
		entity.backer_name = ""
	end
	
	for _, struct_type in pairs(struct_types) do 
		if entity.name == struct_type.struct_main then
			local struct_id = global.struct.next_struct_id
			--send_message("unit_manage_new [" .. entity.name .. "]: " .. struct_id)
			local struct = {
				struct_id = struct_id,
				struct_type = struct_type,
				struct_main = entity,
				--struct_input = nil, -- input-output
				--struct_output = nil, -- input-output
				--struct_overlay = nil, -- vehicle-deployer
				--struct_chest = nil, -- vehicle-deployer
				--struct_belt = nil, -- vehicle-deployer
				--deploy_entity = nil, -- vehicle-deployer
			}
			entity.energy = 0
			if(struct_type.type == "input-output") then
				struct.struct_main.operable = false
				global.struct.unit_numbers[entity.unit_number] = struct_id
				-- should scan for ghost entities in the placement zone and fast-replace on those to preserve connections if rotated
				if struct_type.struct_input then
					struct.struct_input = struct_create_or_revive(
						struct_type.struct_input, 
						entity.surface, 
						struct_sub_search_area(entity.position), 
						{entity.position.x - 1.2,entity.position.y + 0.2}, 
						entity.force)
					struct.struct_input.destructible = false
					global.struct.unit_numbers[struct.struct_input.unit_number] = struct_id
				end
				if struct_type.struct_output then
					struct.struct_output = struct_create_or_revive(
						struct_type.struct_output, 
						entity.surface, 
						struct_sub_search_area(entity.position),
						{entity.position.x+1.2, entity.position.y+0.2}, 
						entity.force)
					struct.struct_output.destructible = false
					global.struct.unit_numbers[struct.struct_output.unit_number] = struct_id
				end
				global.struct.next_struct_id = global.struct.next_struct_id + 1
				global.struct.structs[struct_id] = struct
			elseif(struct_type.type == "vehicle-deployer") then
				struct.struct_main = entity
				global.struct.unit_numbers[struct.struct_main.unit_number] = struct_id
				
				struct.struct_overlay = entity.surface.create_entity{name=struct_type.struct_overlay, position={x= entity.position.x, y= entity.position.y+struct.struct_type.deployer_overlay_offset}, force=entity.force}
				struct.struct_overlay.destructible = false
				if(struct.struct_overlay.unit_number) then -- simple_entity
					global.struct.unit_numbers[struct.struct_overlay.unit_number] = struct_id
				end
				
				struct.struct_belt = entity.surface.create_entity{name=struct_type.struct_belt, position={x= entity.position.x, y= entity.position.y+struct.struct_type.deployer_belt_offset}, force=entity.force, direction=defines.direction.south}
				struct.struct_belt.destructible = false
				global.struct.unit_numbers[struct.struct_belt.unit_number] = struct_id
				
				global.struct.next_struct_id = global.struct.next_struct_id + 1
				global.struct.structs[struct_id] = struct
			end
		end
	end

end

function struct_create_or_revive(entity_type, surface, area, position, force)
	-- position MUST be in area for revive return to work
	local ghost = false
	local ghosts = surface.find_entities_filtered{
		area=area,
		name="entity-ghost",
		force=force}
	for _, each_ghost in pairs(ghosts) do
		if each_ghost.valid and each_ghost.ghost_name == entity_type then 
			if ghost then
				each_ghost.destroy()
			else 
				local result = each_ghost.revive()
				if not each_ghost.valid then
					ghost = true
				else 
					each_ghost.destroy()
				end
			end
		end
	end
	
	if ghost then 
		local entities = surface.find_entities_filtered{
			area=area,
			name=entity_type,
			force=force}
		for _, entity in pairs(entities) do
			entity.direction = defines.direction.south
			entity.teleport(position)
			return entity
		end
	else
		return surface.create_entity{
			name=entity_type, 
			position=position, 
			force=force,
			fast_replace = true}
	end
end

function struct_unmanage_by_entity(entity) 
	-- this structure is dead
	local struct = struct_find_from_entity(entity)
	struct_unmanage(struct)
end

function struct_unmanage(struct) 
	-- this unit is dead
	if struct then
		if struct.struct_main then
			struct.struct_main = destroy_entity(struct.struct_main)
		end
		if struct.struct_input then
			struct.struct_input = destroy_entity(struct.struct_input)
		end
		if struct.struct_output then
			struct.struct_output = destroy_entity(struct.struct_output)
		end
		if struct.struct_overlay then
			struct.struct_overlay = destroy_entity(struct.struct_overlay)
		end
		if struct.struct_belt then
			struct.struct_belt = destroy_entity(struct.struct_belt)
		end
		global.struct.structs[struct.struct_id] = nil
	end
end

function struct_on_tick(event) 
	global.tick = event.tick
	
	struct_force_update()
	
	for unit_number, entity in pairs(global.struct.entities_pending_manage) do 
		struct_manage_new(entity)
		global.struct.entities_pending_manage[unit_number] = nil
	end
	
	-- only process 1 struct per frame for performance reasons
	local last_struct_id_processed = global.last_struct_id_processed or 0
	local at_end = true
	local count = 0
	for _,struct in pairs(global.struct.structs) do 
		if struct.struct_id > last_struct_id_processed then
			count = count + 1
			global.last_struct_id_processed = struct.struct_id
			struct_update_state(struct)
			at_end = false
			if count >= max_structs_per_tick then
				break
			end
		end
	end
	if at_end then 
		global.last_struct_id_processed = 0
	end
	
	-- cleanup orphaned ghosts
	for _, ghostset in pairs(global.struct.ghosts) do
		if not ghostset.entity.valid then
			local ghosts = ghostset.surface.find_entities_filtered{
				area=struct_sub_search_area(ghostset.position),
				name="entity-ghost",
				ghostset.force}
			for _, each_ghost in pairs(ghosts) do
				if each_ghost.ghost_name == struct_types[ghostset.struct_type].struct_input or 
						each_ghost.ghost_name == struct_types[ghostset.struct_type].struct_output then
					each_ghost.destroy()
				end
			end
			global.struct.ghosts[_] = nil
		end
	end
end

function struct_sub_search_area(position)
	return {{position.x - 1.5, position.y - 1.5}, {position.x + 1.5, position.y + 1.5}}
end

function struct_update_state(struct) 
	-- delete if invalid
	if(struct.struct_type.type == "input-output")then
		if not struct.struct_main or not struct.struct_main.valid then
			struct_unmanage(struct)
			return
		end
	elseif (struct.struct_type.type == "vehicle-deployer") then
		if not struct.struct_main or not struct.struct_main.valid then
			struct_unmanage(struct)
			return
		end
	end
	
	if(struct.struct_type.type == "input-output") then
		struct_process_input_output(struct)
	elseif(struct.struct_type.type == "vehicle-deployer") then
		struct_process_vehicle_deployer(struct)
	end
	
end

function struct_process_vehicle_deployer(struct) 
	if struct.struct_main and struct.struct_main.valid then
		if struct.deploy_entity then 
			-- keep deploying the entity
			if(struct.deploy_entity.valid) then
				local y = struct.struct_main.position.y + struct.struct_type.deploy_start_offset 
						+ (-struct.struct_type.deploy_start_offset + struct.struct_type.deploy_end_offset) * struct.deploy_time / struct.struct_type.deploy_time
				struct.deploy_entity.teleport({struct.struct_main.position.x, y})
				struct.deploy_time = struct.deploy_time + 1
				if struct.deploy_time > struct.struct_type.deploy_time then
					send_custom_event("on_entity_deployed", {entity = struct.deploy_entity, signals=struct.deployment_signals})
					struct.deploy_time = 0
					struct.deploy_entity = nil
					if(struct.reserved_entity) then
						struct.reserved_entity.destroy()
						struct.reserved_entity = nil
					end
				end
			else
				struct.deploy_entity = nil
				struct.reserved_entity.destroy()
				struct.reserved_entity = nil
			end
		else
			-- deploy an entity if there is an item
			local inventory = struct.struct_main.get_inventory(defines.inventory.chest)
			for item_type, count in pairs(inventory.get_contents()) do
				local item_stack = inventory.find_item_stack(item_type)
				--send_message(item_stack.prototype.place_result.type)
				if(item_stack.prototype and item_stack.prototype.place_result and item_stack.prototype.place_result.type and item_stack.prototype.place_result.type == "car") then
					if(struct.struct_main.surface.can_place_entity{
						name=struct.struct_type.struct_reserved,
						position = {x= struct.struct_main.position.x, y= struct.struct_main.position.y+struct.struct_type.deploy_end_offset},
						direction=defines.direction.south
					}) then
						struct.reserved_entity = struct.struct_main.surface.create_entity{
							name=struct.struct_type.struct_reserved,
							position = {x= struct.struct_main.position.x, y= struct.struct_main.position.y+struct.struct_type.deploy_end_offset},
							direction=defines.direction.south}
						struct.reserved_entity.destructible = false
						struct.deploy_entity = struct.struct_main.surface.create_entity{
							name=item_stack.prototype.place_result.name, 
							position={x= struct.struct_main.position.x, y= struct.struct_main.position.y+struct.struct_type.deploy_start_offset}, 
							force=struct.struct_main.force,
							direction=defines.direction.south}
						struct.deployment_signals = struct_get_circuit_inputs(struct) -- get signals
						inventory.remove({name=item_type, count=1})
						struct.deploy_time = 0
						break
					else
						--send_message("exit blocked")
					end
				else 
					--send_message("invalid item")
				end
			end
		end
	end
end

function struct_process_input_output(struct) 
	if struct.struct_main.energy < 10 then return end -- minimum power
	-- get unit data based on unidt type and index based on unit number
	-- inputs are signal containers : [type][name]
	local inputs = struct_get_circuit_inputs(struct)
	local outputs = {} -- outputs["copper-plate"] = 5
	--send_message("struct " .. struct.struct_type.name)
	----------------------------------------------------------------------------------
	-- UNIT SCAN ---------------------------------------------------------------------
	if struct.struct_type.name == "unit_scan" then
		--struct_debug_signals(inputs)
		--outputs = inputs
		local player_signal = signal_container_get(inputs, signal_for_player_cursor)
		local use_cursor = false
		if player_signal then
			use_cursor = true
		else
			player_signal = signal_container_get(inputs, signal_for_player)
		end
		
		if player_signal then
			-- return players count
			struct_add_to_signal_container(outputs, signal_for_count, #game.players)
						
			-- look for player
			local player_index = player_signal.count
			if game.players[player_index] then
				local player = game.players[player_index]
				if player and player.character and player.character.valid then
					local position = player.position
					if use_cursor and player.selected then
						position = player.selected.position
					end
					struct_add_to_signal_container(outputs, player_signal.signal, player_signal.count)
					struct_add_to_signal_container(outputs, signal_for_health, player.character.health)
					struct_add_to_signal_container(outputs, signal_for_position_x_sub, position.x * 100)
					struct_add_to_signal_container(outputs, signal_for_position_y_sub, position.y * 100)
					struct_add_to_signal_container(outputs, signal_for_position_x_tiles, position.x)
					struct_add_to_signal_container(outputs, signal_for_position_y_tiles, position.y)
					
					struct_add_inventory_to_signal_container(outputs, player, defines.inventory.player_quickbar)
					struct_add_inventory_to_signal_container(outputs, player, defines.inventory.player_main)
					struct_add_inventory_to_signal_container(outputs, player, defines.inventory.player_guns)
					struct_add_inventory_to_signal_container(outputs, player, defines.inventory.player_ammo)
					struct_add_inventory_to_signal_container(outputs, player, defines.inventory.player_armor)
					struct_add_inventory_to_signal_container(outputs, player, defines.inventory.player_tools)
					struct_add_inventory_to_signal_container(outputs, player, defines.inventory.player_tools)
				end
			end
		else -- cannot get player so get unit
			local result = struct_find_unit_from_signals(struct, inputs)
			if result then 
				-- get unit data
				local unit = result.unit
				local vehicle = unit.vehicle
				
				local type_count = remote.call("aai-programmable-vehicles", "get_unit_count_by_type", unit.unit_type)
				struct_add_to_signal_container(outputs, signal_for_count, type_count) -- send back unit type count for easy looping
				struct_add_to_signal_container(outputs, result.signal, result.count) -- send unit type id back for easy connecting
				
				struct_add_to_signal_container(outputs, signal_for_speed, vehicle.speed * 1000)
				struct_add_to_signal_container(outputs, signal_for_angle, ((vehicle.orientation * 360 + 359) % 360) +1) -- 1-360
				struct_add_to_signal_container(outputs, signal_for_health, vehicle.health)
				struct_add_to_signal_container(outputs, signal_for_position_x_sub, vehicle.position.x * 100)
				struct_add_to_signal_container(outputs, signal_for_position_y_sub, vehicle.position.y * 100)
				struct_add_to_signal_container(outputs, signal_for_position_x_tiles, vehicle.position.x)
				struct_add_to_signal_container(outputs, signal_for_position_y_tiles, vehicle.position.y)
				struct_add_to_signal_container(outputs, signal_for_energy, unit.energy)
				
				struct_add_to_signal_container(outputs, signal_for_time_target, 1 + global.tick - unit.target_last_tick)
				struct_add_to_signal_container(outputs, signal_for_time_move, 1 + global.tick - unit.move_last_tick)
				struct_add_to_signal_container(outputs, signal_for_time_command, 1 + global.tick - unit.order_last_tick)
				
				struct_add_inventory_to_signal_container(outputs, vehicle, defines.inventory.car_fuel)
				struct_add_inventory_to_signal_container(outputs, vehicle, defines.inventory.car_trunk)
				struct_add_inventory_to_signal_container(outputs, vehicle, defines.inventory.car_ammo)
					
					
				if remote.interfaces["aai-zones"]["get_zone_for_position"] then
					local zone = remote.call("aai-zones", "get_zone_for_position", {
						force = struct.struct_main.force,
						position = {x = vehicle.position.x, y = vehicle.position.y} 
					})
					if zone then 
						struct_add_to_signal_container(outputs, {type="virtual", name=zone}, 1)
					end
				end
			
			end
		end
		
	----------------------------------------------------------------------------------
	-- UNIT CONTROL ------------------------------------------------------------------
	elseif struct.struct_type.name == "unit_control" then
		local result = struct_find_unit_from_signals(struct, inputs)
		if result then 
			local unit = result.unit
			if unit and unit.mode ~= "drive" then -- can't affect in drive mode
			
				-- do orders
				local angle = signal_container_get(inputs, signal_for_angle)
				local speed = signal_container_get(inputs, signal_for_speed)
				local position_x_sub = signal_container_get(inputs, signal_for_position_x_sub)
				local position_y_sub = signal_container_get(inputs, signal_for_position_y_sub)
				local position_x_tiles = signal_container_get(inputs, signal_for_position_x_tiles)
				local position_y_tiles = signal_container_get(inputs, signal_for_position_y_tiles)
				
				local command_data = {unit_id = unit.unit_id}
				if angle then -- look for angle and speed -- mode to vehicle modes
					command_data.target_angle = (angle.count / 360) % 1
					command_data.target_speed = speed and speed.count / 1000 or 0
					remote.call("aai-programmable-vehicles", "set_unit_command", command_data)
				elseif position_x_sub or position_y_sub then
					-- look for u and v and convert to angle and speed -- mode to vehicle mode
					local dx = position_x_sub and position_x_sub.count or 0
					local dy = position_y_sub and position_y_sub.count or 0
					local angle = vector_to_orientation_xy(dx, dy)
					command_data.target_angle = angle
					command_data.target_speed = math.max(0, (vector_length_xy(dx, dy) - 250) / 10000) -- auto speed by vector length
					if speed then --  speed override
						command_data.target_speed = speed.count / 1000
					end
					remote.call("aai-programmable-vehicles", "set_unit_command", command_data)
				elseif position_x_tiles or position_x_tiles then
					-- look for x and y mode to unit mode
					local new_position = {
						x = math.floor(position_x_tiles and position_x_tiles.count or 0),
						y = math.floor(position_y_tiles and position_y_tiles.count or 0)
					}
					command_data.target_position = new_position
					remote.call("aai-programmable-vehicles", "set_unit_command", command_data)
				end
				-- need values on unit for target_position, target_relative_position, target_angle
			end
		end
		
	----------------------------------------------------------------------------------
	-- UNITDATA SCAN -----------------------------------------------------------------
	elseif struct.struct_type.name == "unitdata_scan" then
		local result = struct_find_unit_from_signals(struct, inputs)
		if result then 
			local unit = result.unit
			if unit then
				local type_count = remote.call("aai-programmable-vehicles", "get_unit_count_by_type", unit.unit_type)
				struct_add_to_signal_container(outputs, signal_for_count, type_count) -- send back unit type count for easy looping
				struct_add_to_signal_container(outputs, result.signal, result.count) -- send unit type id back for easy connecting
				for signal_type, signals in pairs(unit.data) do
					for signal_name, signal_count in pairs(signals) do
						if not (signal_count.signal.type == signal_for_count.type and signal_name == signal_for_count.name) then
							struct_add_to_signal_container(outputs, signal_count.signal, signal_count.count)
						end
					end
				end
			end
		end
		
	----------------------------------------------------------------------------------
	-- UNITDATA CONTROL --------------------------------------------------------------
	elseif struct.struct_type.name == "unitdata_control" then
		local result = struct_find_unit_from_signals(struct, inputs)
		if result then 
			local unit = result.unit
			if unit then
				unit.data = {} -- clear data
				for signal_type, signals in pairs(inputs) do
					for signal_name, signal_count in pairs(signals) do
						if (not string.find(signal_name, composite_suffix.."signal", 1, true))
							and not (signal_count.signal.type == signal_for_count.type and signal_name == signal_for_count.name) then 
							-- don't add the generic count or a unit virtual signal
							signal_container_add(unit.data, signal_count.signal, signal_count.count)
						end
					end
				end
				remote.call("aai-programmable-vehicles", "set_unit_data", {unit_id = unit.unit_id, data = unit.data})
			end
		end
		
	----------------------------------------------------------------------------------
	-- ZONE SCAN ---------------------------------------------------------------------
	elseif struct.struct_type.name == "zone_scan" then
		if remote.interfaces["aai-zones"]["get_zone_types"] and inputs.virtual then
			
			for signal_name, signal_count in pairs(inputs.virtual) do
				if remote.call("aai-zones", "is_zone_type", signal_name) then
					struct_add_to_signal_container(outputs, signal_for_count, 
						remote.call("aai-zones", "get_zone_count_of_type", {
							force = struct.struct_main.force,
							type = signal_name })) -- send back count of type
							
				
					-- get the zone
					--local zone = zone_by_type_and_index(zone.name, zone_signal.count)
					local zone_tile = remote.call("aai-zones", "get_zone_by_index", {
						force=struct.struct_main.force, type=signal_name, index=signal_count.count})
						
					if zone_tile and zone_tile.entity then
						struct_add_to_signal_container(outputs, {type="virtual", name=signal_name}, zone_tile.index) -- send type
						struct_add_to_signal_container(outputs, signal_for_position_x_sub, zone_tile.position.x * 100)
						struct_add_to_signal_container(outputs, signal_for_position_y_sub, zone_tile.position.y * 100)
						struct_add_to_signal_container(outputs, signal_for_position_x_tiles, zone_tile.position.x)
						struct_add_to_signal_container(outputs, signal_for_position_y_tiles, zone_tile.position.y)
					end
					break
				end
			end
		end
		
	----------------------------------------------------------------------------------
	-- ZONE CONTROL ------------------------------------------------------------------
	elseif struct.struct_type.name == "zone_control" then
		if remote.interfaces["aai-zones"]["get_zone_types"] then
		
			local position_x_tiles = signal_container_get(inputs, signal_for_position_x_tiles)
			local position_y_tiles = signal_container_get(inputs, signal_for_position_y_tiles)
			
			if position_x_tiles and position_y_tiles then
				local apply_zone = nil -- can be nil to remove
				local x = position_x_tiles.count
				local y = position_y_tiles.count
				
				local zone_options = remote.call("aai-zones", "get_zone_types")
				for _,zone_option in pairs(zone_options) do
					local zone_signal = signal_container_get(inputs, {type="virtual", name=zone_option.name})
					if zone_signal then
						apply_zone = zone_option.name
						break
					end
				end
				
				-- apply the zone to the tile or remove if no zone
				-- surface, force, area, zone_type
				remote.call("aai-zones", "apply_zone_to_area", {
					force = struct.struct_main.force,
					type = apply_zone, -- can be nil to remove
					surface = struct.struct_main.surface,
					area = {left_top={x=x,y=y},right_bottom={x=x,y=y}}
				})
			end
		end
		
	----------------------------------------------------------------------------------
	-- TILE SCAN ---------------------------------------------------------------------
	elseif struct.struct_type.name == "tile_scan" then
		
		local position_x_tiles = signal_container_get(inputs, signal_for_position_x_tiles)
		local position_y_tiles = signal_container_get(inputs, signal_for_position_y_tiles)
		local range_signal = signal_container_get(inputs, signal_for_range)
		
		if (position_x_tiles and position_y_tiles) or range_signal then
			
			local x = position_x_tiles and position_x_tiles.count or struct.struct_main.position.x
			local y = position_y_tiles and position_y_tiles.count or struct.struct_main.position.y
			
			local tile_scanner_random_range = range_signal and range_signal.count or 0
			
			x = math.floor(x + (math.random() - 0.5) * 2 * math.random() * tile_scanner_random_range)
			y = math.floor(y + (math.random() - 0.5) * 2 * math.random() * tile_scanner_random_range)

			-- send position back to verify
			struct_add_to_signal_container(outputs, signal_for_position_x_tiles, x)
			struct_add_to_signal_container(outputs, signal_for_position_y_tiles, y)
			
			local tile = struct.struct_main.surface.get_tile(x,y)
			if tile and tile.valid then -- require a tile, otherwise this is outside the created world
				if string.find(tile.name, "water", 1, true) then
					struct_add_to_signal_container(outputs, signal_for_water, 1)
				else
					struct_add_to_signal_container(outputs, signal_for_land, 1)
				end
				
				if tile.prototype.mineable_properties and tile.prototype.mineable_properties.mineable and tile.prototype.mineable_properties.products then 
					for _, product in pairs(tile.prototype.mineable_properties.products) do 
						struct_add_to_signal_container(outputs, {type=product.type, name=product.name}, product.amount_max and product.amount_max or product.amount)
					end
				end
				
				-- scan this tile for entities
				local entities = struct.struct_main.surface.find_entities({{x,y},{x + 0.99,y + 0.99}});
				for _, entity in pairs(entities) do 
					local has_item = false
					
					-- use item to palce as signal
					if(entity.prototype.items_to_place_this) then
						for name, item in pairs(entity.prototype.items_to_place_this) do 
							has_item = true
							struct_add_to_signal_container(outputs, {type = "item", name = name}, 1)
						end
					end
					
					-- use mineable result(s) as signal(s)
					if has_item == false and entity.prototype.mineable_properties and 
						entity.prototype.mineable_properties and entity.prototype.mineable_properties.products then
						for _, product in pairs(entity.prototype.mineable_properties.products) do 
							struct_add_to_signal_container(outputs, {type=product.type, name=product.name}, product.amount_max and product.amount_max or product.amount)
							has_item = true
						end
					end
					
					-- use preset signal
					if has_item == false then
						if entity.type == "unit" then
							struct_add_to_signal_container(outputs, signal_for_enemy_unit, 1)
						elseif entity.type == "unit-spawner" then 
							struct_add_to_signal_container(outputs, signal_for_enemy_unit_spawner, 1)
						elseif entity.type == "turret" then 
							struct_add_to_signal_container(outputs, signal_for_enemy_turret, 1)
						elseif entity.name == "item-on-ground" then 
							struct_add_to_signal_container(outputs, {type="item", name=entity.stack.name}, entity.stack.count)
						end
					end
				end
				
				if remote.interfaces["aai-zones"]["get_zone_for_position"] then
					local zone = remote.call("aai-zones", "get_zone_for_position", {
						force = struct.struct_main.force,
						position = {x = x, y = y} 
					})
					if zone then 
						struct_add_to_signal_container(outputs, {type="virtual", name=zone}, 1)
					end
				end
			end
		end
	end
		
	----------------------------------------------------------------------------------
	-- OUTPUTS -----------------------------------------------------------------------
	if struct.struct_type.name ~= "zone_control" and
		struct.struct_type.name ~= "unit_control" and
		struct.struct_type.name ~= "unitdata_control"  then
		struct_export_outputs_to_constants(struct.struct_output, outputs)
	end
end

function struct_add_inventory_to_signal_container(container, entity, inventory)
	signal_container_add_inventory(container, entity, inventory)
end

function struct_add_to_signal_container(output, signal, count)
	if count == nil then
		count = 1
	end
	signal_container_add(output, signal, count)
end

function struct_get_circuit_inputs(struct)
	local entity = struct.struct_main
	if(struct.struct_input) then
		entity = struct.struct_input
	end
	if entity and entity.valid then
		local inputs = {} 
		local network = entity.get_circuit_network(defines.wire_type.red)
		if network then
			for _, signal_count in pairs(network.signals) do
				signal_container_add(inputs, signal_count.signal, signal_count.count)
			end
		end
		network = entity.get_circuit_network(defines.wire_type.green)
		if network then
			for _, signal_count in pairs(network.signals) do
				signal_container_add(inputs, signal_count.signal, signal_count.count)
			end
		end
		return inputs
	end
end

function struct_find_unit_from_signals(struct, signal_container)
	for signal_type, signals in pairs(signal_container) do
	
		for signal_name, signal_count in pairs(signals) do
			local unit = remote.call("aai-programmable-vehicles", "get_unit_by_signal", {
				signal = signal_count.signal, 
				count = signal_count.count})
			if unit then 
				return {unit = unit, signal = signal_count.signal, count = signal_count.count} 
			end
		end
	end
end

function struct_export_outputs_to_constants(entity, signal_container)
	if entity and signal_container then
		local parameters = {}
		local index = 1;
		for signal_type, signals in pairs(signal_container) do
			for signal_name, signal_count in pairs(signals) do
				parameters[index] = {index=index, signal=signal_count.signal, count= math.floor(signal_count.count)}
				index = index + 1
			end
		end
		entity.get_control_behavior().parameters = {parameters = parameters}
	end
end


function struct_find_from_entity(entity)
	if entity.valid and global.struct then
		local struct_id = global.struct.unit_numbers[entity.unit_number]
		if struct_id then
			return global.struct.structs[struct_id]
		end
	end
end

function destroy_entity(entity)
	if entity.valid then
		struct_on_destroy_entity(entity)
		entity.destroy()
	end
	return nil
end

script.on_event(defines.events.on_tick, struct_on_tick)
script.on_event(defines.events.on_built_entity, struct_on_built_entity)
script.on_event(defines.events.on_robot_built_entity, struct_on_built_entity) 
script.on_event(defines.events.on_entity_died, struct_on_entity_died)

script.on_configuration_changed(function()
	for _, force in pairs(game.forces) do
		force.reset_recipes()
		force.reset_technologies()
		for tech_name, tech in pairs(force.technologies) do
			if tech.researched then
				tech.researched = false
				tech.researched = true
			end
		end
	end
end)

