--CUSTOM EVENTS
--[[
currently sent events are:
on_entity_deployed : {entity = LuaEntity, signals = {signaltype={signalname={signal="", count=#}}}}
]]--
function send_custom_event(event_name, event_data) 
	for interface_name, interface_functions in pairs(remote.interfaces) do
		if interface_functions[event_name] then
			remote.call(interface_name, event_name, event_data)
		end
	end
end

--Interfaces
--remote.add_interface("aai-programmable-structures",
	--{ get_structs = function() return global.struct.structs end }
--)