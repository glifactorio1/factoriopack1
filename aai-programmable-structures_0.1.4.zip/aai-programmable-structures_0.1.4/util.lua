
function send_message(text)
	for _, player in pairs(game.players) do
		player.print(text)
	end
end

function remove_from_table(list, item)
	local index = 0
	for _,_item in ipairs(list) do
		if item == _item then
			index = _	
			break
		end
	end
	if index > 0 then
		table.remove(list, index)
	end
end

function transfer_inventory (entity_a, entity_b, inventory_type)
	local inv_a = entity_a.get_inventory(inventory_type)
	local inv_b = entity_b.get_inventory(inventory_type)
	local contents = inv_a.get_contents()
	for item_type, item_count in pairs(contents) do
		inv_b.insert({name=item_type, count=item_count})
	end
end

function position_to_xy_string(position)
	return xy_to_string(position.x, position.y)
end

function xy_to_string(x, y)
	return math.floor(x) .. "_" .. math.floor(y)
end

function lerp_angles(a, b, alpha)
	local da = b - a

	if da < -0.5 then
		da = da + 1
	elseif da > 0.5 then
		da = da - 1
	end
	local na = a + da * alpha
	if na < 0 then
		na = na + 1
	elseif na > 1 then
		na = na - 1
	end
	return na
end

function array_to_vector(array)
	return {x = array[1], y = array[2]}
end

function vectors_delta(a, b)
	return {x = b.x - a.x, y = b.y - a.y}
end

function vectors_delta_length(a, b)
	return vector_length_xy(b.x - a.x, b.y - a.y)
end

function vector_length(a)
	return math.sqrt(a.x * a.x + a.y * a.y)
end

function vector_length_xy(x, y)
	return math.sqrt(x * x + y * y)
end

function vector_dot(a, b)
	return a.x * b.x + a.y * b.y
end

function vector_dot_projection(a, b)
	local n = vector_normalise(a)
	local d = vector_dot(n, b)
	return {x = n.x * d, y = n.y * d}
end

function vector_normalise(a)
	local length = vector_length(a)
	return {x = a.x/length, y = a.y/length}
end

function orientation_from_to(a, b)
	return vector_to_orientation_xy(b.x - a.x, b.y - a.y)
end

function orientation_to_vector(orientation, length)
	return {x = length * math.sin(orientation * 2 * math.pi), y = -length * math.cos(orientation * 2 * math.pi)}
end

function vectors_add(a, b)
	return {x = a.x + b.x, y = a.y + b.y}
end

function lerp_vectors(a, b, alpha)
	return {x = a.x + (b.x - a.x) * alpha, y = a.y + (b.y - a.y) * alpha}
end

function move_to(a, b, max_distance, eliptical)
	-- move rfom a to b with max_distance.
	-- if eliptical, reduce y change (i.e. turret muzzle flash offset)
	local eliptical_scale = 0.9
	local delta = vectors_delta(a, b)
	if eliptical then
		delta.y = delta.y / eliptical_scale 
	end
	local length = vector_length(delta)
	if (length > max_distance) then
		local partial = max_distance / length
		delta = {x = delta.x * partial, y = delta.y * partial}
	end
	if eliptical then
		delta.y = delta.y * eliptical_scale 
	end
	return {x = a.x + delta.x, y = a.y + delta.y}
end

function vector_to_orientation(v)
	return vector_to_orientation_xy(v.x, v.y)
end
function vector_to_orientation_xy(x, y)
	if x == 0 then
		if y > 0 then
			return 0.5
		else
			return 0
		end	
	elseif y == 0 then
		if x < 0 then
			return 0.75
		else
			return 0.25
		end
	else
		if y < 0 then
			if x > 0 then
				return math.atan(x / -y) / math.pi / 2
			else 
				return 1 + math.atan(x / -y) / math.pi / 2
			end
		else
			return 0.5 + math.atan(x / -y) / math.pi / 2
		end
	end
end

function direction_to_orientation(direction)
	if direction == defines.direction.north	then
		return 0
	elseif direction == defines.direction.northeast then
		return 0.125
	elseif direction == defines.direction.east then
		return 0.25
	elseif direction == defines.direction.southeast then
		return 0.375
	elseif direction == defines.direction.south then
		return 0.5
	elseif direction == defines.direction.southwest then
		return 0.625
	elseif direction == defines.direction.west then
		return 0.75
	elseif direction == defines.direction.northwest then
		return 0.875
	end
	return 0
end

function signal_to_string(signal)
	return signal.type .. "__" .. signal.name
end

function signal_container_add_inventory(container, entity, inventory)
	local inv = entity.get_inventory(inventory)
	if inv then 
		local contents = inv.get_contents()
		for item_type, item_count in pairs(contents) do
			signal_container_add(container, {type="item", name=item_type}, item_count)
		end
	end
end

function signal_container_add(container, signal, count)
	if signal then 
		if not container[signal.type] then
			container[signal.type] = {}
		end
		if container[signal.type][signal.name] then
			container[signal.type][signal.name].count = container[signal.type][signal.name].count + count
		else 
			container[signal.type][signal.name] = {signal = signal, count = count}
		end
	end
end

function signal_container_get(container, signal)
	if container[signal.type] and container[signal.type][signal.name] then
		return container[signal.type][signal.name]
	end
end