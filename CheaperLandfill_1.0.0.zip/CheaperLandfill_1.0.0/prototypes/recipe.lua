data:extend({
  {
    type = "recipe",
    name = "landfill",
    energy_required = 0.5,
    enabled = false,
    category = "crafting",
    ingredients =
    {
      {"stone", 10}
    },
    result = "landfill",
    result_count = 1
  }
})