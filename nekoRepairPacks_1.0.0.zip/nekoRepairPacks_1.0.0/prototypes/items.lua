data:extend ({
	{
		type="repair-tool",
		name="repair-pack-mk2",
		icon="__nekoRepairPacks__/graphics/repair-pack-mk2.png",
		flags = {"goes-to-quickbar"},
		subgroup= "tool",
		order = "b[repair]-a[repair-pack]",
		speed = 2.5,
		durability = 300,
		stack_size= 100
	},
	{
		type = "repair-tool",
		name = "repair-pack-mk3",
		icon = "__nekoRepairPacks__/graphics/repair-pack-mk3.png",
		flags = {"goes-to-quickbar"},
		subgroup = "tool",
		order = "b[repair]-a[repair-pack]",
		speed = 4.5,
		durability = 500,
		stack_size = 100
	},
	{
		type="repair-tool",
		name="repair-pack-mk4",
		icon="__nekoRepairPacks__/graphics/repair-pack-mk4.png",
		flags = {"goes-to-quickbar"},
		subgroup="tool",
		order="b[repair]-a[repair-pack]",
		speed = 5.0,
		durability=1000,
		stack_size=100
	}
})
