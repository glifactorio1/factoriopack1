--[[require("prototypes.override-functions")
require("prototypes.prototype-creation")

AddRecipeToTech("boilers-1", "high-boiler-mk2")
AddRecipeToTech("boilers-2", "high-boiler-mk3")
AddRecipeToTech("boilers-3", "high-boiler-mk4")
AddRecipeToTech("boilers-4", "high-boiler-mk5")]]