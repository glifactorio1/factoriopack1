glob.itemcount = {}

glob.itemcount.rawwood = glob.entityinfo[glob.entitycount].EntityInv.getitemcount("raw-wood")
glob.itemcount.uranium = glob.entityinfo[glob.entitycount].EntityInv.getitemcount("u-253-"..l)