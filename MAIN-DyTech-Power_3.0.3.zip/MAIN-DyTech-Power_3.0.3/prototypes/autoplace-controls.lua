data:extend(
{
  {
	type = "autoplace-control",
	name = "uraniumdioxide",
	richness = true,
	order = "m-p"
  }
}
)