function GetRecipe(item)
if item == "chemical-processor" then
return
	{"stone", 1}
elseif item == "nuclear-reactor" then
return
	{"electronic-circuit", 1}
end
end