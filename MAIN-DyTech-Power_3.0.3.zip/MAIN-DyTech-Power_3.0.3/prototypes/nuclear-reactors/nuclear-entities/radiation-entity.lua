data:extend(
{
  {
	type = "smoke",
	name = "radiation-cloud",
	show_when_smoke_off = true,
	animation =
	{
		filename = 