data:extend(
{
  {
	type = "noise-layer",
	name = "uraniumdioxide"
  },
  {
	type = "noise-layer",
	name = "fluorite"
  }
})