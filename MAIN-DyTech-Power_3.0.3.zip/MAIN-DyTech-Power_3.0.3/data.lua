require "config"

require("prototypes.identity")
