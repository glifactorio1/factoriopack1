require("config")
--Changes
require("prototypes.changes")
--Roboport
require("prototypes.roboport")
--Logistic robot
require("prototypes.robot-cons")
--Construction robot
require("prototypes.robot-logic")
--Chest
require("prototypes.passive")
require("prototypes.active")
require("prototypes.requester")
require("prototypes.storage")
--Repair pack
require("prototypes.repair-2")
--Technology
require("prototypes.tech")
