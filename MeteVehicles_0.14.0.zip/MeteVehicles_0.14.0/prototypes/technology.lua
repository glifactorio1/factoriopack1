data:extend(
{
  {
    type = "technology",
    name = "armored-car",
    icon = "__MeteVehicles__/graphics/technology/armored-car.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "armored-car"
      },
    },
    prerequisites = {"automobilism"},
    unit =
    {
      count = 25,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1}
      },
      time = 60
    },
    order = "e-b-b"
  },
  {
    type = "technology",
    name = "armored-car-mk2",
    icon = "__MeteVehicles__/graphics/technology/armored-car-mk2.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "armored-car-mk2"
      },
    },
    prerequisites = {"armored-car", "advanced-electronics"},
    unit =
    {
      count = 25,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 90
    },
    order = "e-b-c"
  },
  {
    type = "technology",
    name = "armored-car-mk3",
    icon = "__MeteVehicles__/graphics/technology/armored-car-mk3.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "armored-car-mk3"
      },
    },
    prerequisites = {"armored-car-mk2", "solar-energy", "electric-engine", "battery"},
    unit =
    {
      count = 25,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"alien-science-pack", 1}
      },
      time = 120
    },
    order = "e-b-d"
  }
})
