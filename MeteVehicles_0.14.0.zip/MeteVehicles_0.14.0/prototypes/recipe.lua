data:extend({
  {
    type = "recipe",
    name = "armored-car",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {"car", 1},
      {"engine-unit", 6},
      {"iron-gear-wheel", 10},
      {"steel-plate", 25},
      {"electronic-circuit", 10}
    },
    result = "armored-car"
  },
  {
    type = "recipe",
    name = "armored-car-mk2",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"armored-car", 1},
      {"engine-unit", 6},
      {"iron-gear-wheel", 10},
      {"plastic-bar", 25},
      {"advanced-circuit", 10}
    },
    result = "armored-car-mk2"
  },
  {
    type = "recipe",
    name = "armored-car-mk3",
    enabled = false,
    energy_required = 30,
    ingredients =
    {
      {"armored-car-mk2", 1},
      {"electric-engine-unit", 25},
      {"battery", 10},
      {"solar-panel", 5},
      {"processing-unit", 10},
      {"alien-artifact", 25}
    },
    result = "armored-car-mk3"
  }
})
