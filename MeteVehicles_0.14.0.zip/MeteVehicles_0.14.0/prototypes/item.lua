data:extend({
  {
    type = "item",
    name = "armored-car",
    icon = "__MeteVehicles__/graphics/icons/armored-car.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "b[personal-transport]-b[armored-car]-a",
    place_result = "armored-car",
    stack_size = 1
  },
  {
    type = "item",
    name = "armored-car-mk2",
    icon = "__MeteVehicles__/graphics/icons/armored-car-mk2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "b[personal-transport]-b[armored-car]-b",
    place_result = "armored-car-mk2",
    stack_size = 1
  },
   {
     type = "item",
     name = "armored-car-mk3",
     icon = "__MeteVehicles__/graphics/icons/armored-car-mk3.png",
     flags = {"goes-to-quickbar"},
     subgroup = "transport",
     order = "b[personal-transport]-b[armored-car]-c",
     place_result = "armored-car-mk3",
     stack_size = 1
   }
})