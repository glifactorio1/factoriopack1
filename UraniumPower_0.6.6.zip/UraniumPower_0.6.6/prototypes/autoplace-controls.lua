data:extend(
{
  {
    type = "autoplace-control",
    name = "uraninite",
    richness = true,
    order = "b-e"
  },
  {
    type = "autoplace-control",
    name = "fluorite",
    richness = true,
    order = "b-f"
  },
}
)
