data:extend(
{
	{
		type = "item-subgroup",
		name = "uranium-ammo",
		group = "uranium",
		order = "a",
	}
})