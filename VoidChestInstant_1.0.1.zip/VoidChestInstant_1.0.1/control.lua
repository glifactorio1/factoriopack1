require "defines"
require "util"

--[[ globs and functions defined

global.AlyxVC_MasterList
	List of all Void Chests

--]]



-------------------
function AlyxVC_Initialize(event)
	if global.AlyxVC_MasterList == nil then
		global.AlyxVC_MasterList = {}
	end
	
end

-------------------
function AlyxVC_CreateVC(event)
	if event.created_entity.name == "void-chest" then
		local entity = event.created_entity
		table.insert(global.AlyxVC_MasterList, entity);
	end
	
end

-------------------
function AlyxVC_RunStep(event)
		for index, voidChest in pairs(global.AlyxVC_MasterList) do
		
			if voidChest.valid then
				voidChest.get_inventory(1).clear()
			
			else
				global.AlyxVC_MasterList[index] = nil
			
			end
		end
end

script.on_init(AlyxVC_Initialize)
script.on_event(defines.events.on_tick, AlyxVC_RunStep)
script.on_event(defines.events.on_built_entity, AlyxVC_CreateVC)
script.on_event(defines.events.on_robot_built_entity, AlyxVC_CreateVC)
