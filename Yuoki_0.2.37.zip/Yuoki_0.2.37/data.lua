require "util"

--require("prototypes.groups")
require("prototypes.item-group.yuoki")
require("prototypes.entity.e_storeage")
require("prototypes.entity.e_defense")
require("prototypes.entity.e_defense_f12")
require("prototypes.entity.e_walls")
require("prototypes.entity.e_pipes")
require("prototypes.entity.e_electric")
require("prototypes.entity.e_energy-gen")
require("prototypes.entity.y_entities")
require("prototypes.entity.e_projectiles")
require("prototypes.entity.resources.y_mine1")
require("prototypes.entity.resources.y_mine2")


require("prototypes.item.i_ores")
require("prototypes.item.i_fluids")
require("prototypes.item.ir_atomics")
require("prototypes.item.i_electric")
require("prototypes.item.i_energy")
require("prototypes.item.i_pipes")
require("prototypes.item.y_items")
require("prototypes.item.i_defense")
require("prototypes.item.ir_ammo")
require("prototypes.item.ir_storeage")
require("prototypes.item.ir_parts")
require("prototypes.item.ir_process-machines")
require("prototypes.item.ir_tools")
require("prototypes.item.ir_stargate")

require("prototypes.recipe.r_defense")
require("prototypes.recipe.r_metal-process")
require("prototypes.recipe.r_fluids")
require("prototypes.recipe.r_electric")
require("prototypes.recipe.r_energy")
require("prototypes.recipe.y_recipies")

require("prototypes.objects.y-lamps")
require("prototypes.objects.y-module")
require("prototypes.objects.y-inserter")

--require("prototypes.objects.y_tiles1")
--require("prototypes.objects.y_railway")


require("prototypes.technology.y_technology")

-- autobuilds
require("prototypes.fluids")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.technology")

require("Yuoki_0234_data-updates")



--require("prototypes.objects.y-spawn_ress")
--require("prototypes.technology.t_defense_turms")


--[[
if data.raw.item["white-wood"] then -- should be F-Mod - i hope
--require("prototypes.integration.yi-f-mod")
else

end
]]

--[[
if data.raw.item["silicon-wafer"] then -- should be Silica 
require("prototypes.integration.yi-silica") -- wraps no silica spawn
else

end
]]

--[[
if data.raw.item["stone-crusher-2"] then -- should be Treefarm - i hope
require("prototypes.integration.yi-treefarm")
else

end
]]
