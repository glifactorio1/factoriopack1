require("prototypes.item.item-weapons")

require("prototypes.recipe.recipe-weapons")

require("prototypes.entity.entity-weapons")

require("prototypes.technology.technology-weapons")
