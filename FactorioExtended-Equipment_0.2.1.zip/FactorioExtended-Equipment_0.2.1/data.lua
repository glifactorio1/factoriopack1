require("prototypes.item.item-equipment")

require("prototypes.recipe.recipe-equipment")

require("prototypes.entity.entity-equipment")

require("prototypes.technology.technology-equipment")
