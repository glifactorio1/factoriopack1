if not tobymods then tobymods={} end
if not tobymods.varioustiles then tobymods.varioustiles = {} end
require("config")
require("prototypes.noise-layers")
require("prototypes.pump")
require("prototypes.tiles")