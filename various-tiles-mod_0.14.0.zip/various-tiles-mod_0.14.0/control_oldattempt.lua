require("util")



script.on_event(defines.events.on_built_entity, function(event)
    
   local entity = event.created_entity
  
	if(entity.name == "offshore-pump") then 
		handlePumpPlaced(event)
	end
	
  
end)


script.on_event(defines.events.on_robot_built_entity, function(event)
	local entity = event.created_entity
	if(entity.name == "offshore-pump") then 
		handlePumpPlaced(event)
	end

end)

function handlePumpPlaced(event)
	local entity = event.created_entity
	pos={entity.position}
	for i=-1, 3, 1 do
		for j=-1, 3, 1 do
			pos[#pos+1]=pos[1]
			pos[#pos].x=pos[#pos].x+i
			pos[#pos].y=pos[#pos].y+j
		end
	end
	for i, posish in pairs(pos) do
		if entity.surface.get_tile(posish).name=="lava" or entity.surface.get_tile(posish).name=="deeplava" then
			if global.lavaPumps == nil then global.lavaPumps = {} end
			global.lavaPumps[#global.lavaPumps+1]=entity
			return
		end
	end
	
end

function stepLavaPumps(event)
	if global.lavaPumps then
		for i, lavaPump in pairs(global.lavaPumps) do
			if not lavaPump.valid then global.lavaPumps[i]=nil
			else
				if lavaPump.fluidbox[1] ~= nil then
					local fluid = {
						type = "lava",
						amount = lavaPump.fluidbox[1].amount,
						temperature = lavaPump.fluidbox[1].temperature
					}
					
					lavaPump.fluidbox[1]=fluid
				end
			end
		end
	end
end

script.on_event(defines.events.on_tick, function(event)
	stepLavaPumps(event)
	end
)