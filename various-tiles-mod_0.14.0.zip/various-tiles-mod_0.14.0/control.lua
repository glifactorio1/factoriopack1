require("util")



script.on_event(defines.events.on_built_entity, function(event)
    
   local entity = event.created_entity
  
	if(entity.name == "offshore-pump") then 
		handlePumpPlaced(event)
	end
	
  
end)


script.on_event(defines.events.on_robot_built_entity, function(event)
	local entity = event.created_entity
	if(entity.name == "offshore-pump") then 
		handlePumpPlaced(event)
	end

end)

function handlePumpPlaced(event)
	local entity = event.created_entity
	local pos={entity.position}
	for i=-1, 1, 1 do
		for j=-1, 1, 1 do
			--game.players[1].print("i")
			--game.players[1].print(i)
			--game.players[1].print("j")
			--game.players[1].print(j)
			pos[#pos+1]=pos[1]
			if pos[1].x and pos[1].y then
				pos[#pos].x=pos[#pos].x+i
				pos[#pos].y=pos[#pos].y+j
			else
				pos[#pos][1]=pos[#pos][1]+i
				pos[#pos][2]=pos[#pos][2]+j
			end
			
		end
	end
	for i, posish in pairs(pos) do
		if (entity and entity.valid) then
		--game.players[1].print(entity.surface.get_tile(posish).name)
		if entity.surface.get_tile(posish).name=="lava" or entity.surface.get_tile(posish).name=="deeplava" or entity.surface.get_tile(posish).name=="obsidian" then
			
			if (entity and entity.valid) then handleLavaPump(event) end
		end
		end
	end
	
end

function handleLavaPump(event)
	local entity = event.created_entity
	local newent = entity.surface.create_entity({name="offshore-pump-lava", position=entity.position, direction=entity.direction, fast_replace=true, force=entity.force, player=event.player_index})--fast_replace=true, 
	if (entity) then entity.destroy() end
	--event.created_entity=newent
end