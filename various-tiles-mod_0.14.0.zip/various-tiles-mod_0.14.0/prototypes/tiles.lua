local autoplace_utils = require("autoplace_utils")
local lavatemp= tobymods.varioustiles.lavatemp or 34
local lavawater= tobymods.varioustiles.lavawater or 0.35
local lavadry=0.1
local stoneamount= tobymods.varioustiles.stoneamount or 250




local function autoplace_settings(noise_layer, rectangles)
  local ret = {}

  if noise_layer then
    ret = {
      {
        influence = 0.1,
        noise_layer = noise_layer,
        noise_persistence = 0.7,
        octaves_difference = -1
      }
    }
  end

  autoplace_utils.peaks(rectangles, ret)

  return { peaks = ret }
end

local grass_vehicle_speed_modifier = 1.6
local dirt_vehicle_speed_modifer = 1.4
local sand_vehicle_speed_modifier = 1.8
local stone_path_vehicle_speed_modifier = 1.1
local concrete_vehicle_speed_modifier = 0.8

function water_autoplace_settings(from_depth, rectangles)
  local rect = rectangles[1]
  local temp_center = (rect[2][1] + rect[1][1]) / 2
  local temp_range = math.abs(rect[2][1] - rect[1][1]) / 2
  local water_center = (rect[2][2] + rect[1][2]) / 2
  local water_range = math.abs(rect[2][2] - rect[1][2]) / 2
  local ret =
  {
    {
      -- Water and deep water have absolute priority. We simulate this by giving
      -- them absurdly large influence
      influence = 1e3 + 10 + stoneamount + from_depth,
      elevation_optimal = -5000 - from_depth,
      elevation_range = 5000,
      elevation_max_range = 5000, -- everywhere below elevation 0 and nowhere else
	  
      temperature_optimal = temp_center,
      temperature_range = temp_range,
      temperature_max_range = temp_range + 2,
      water_optimal = water_center,
      water_range = water_range,
      water_max_range = water_range + 0.05,
    }
  }

  if rectangles == nil then
    ret[2] = { influence = 1 }
  end

  --autoplace_utils.peaks(rectangles, ret)--comment out?

  return { peaks = ret }
end
function water_autoplace_settings2(from_depth, rectangles)
  local rect = rectangles[1]
  local temp_center = (rect[2][1] + rect[1][1]) / 2
  local temp_range = math.abs(rect[2][1] - rect[1][1]) / 2
  local water_center = (rect[2][2] + rect[1][2]) / 2
  local water_range = math.abs(rect[2][2] - rect[1][2]) / 2
  local ret =
  {
    {
      -- Water and deep water have absolute priority. We simulate this by giving
      -- them absurdly large influence
      influence = 1e3 + 10 + stoneamount + from_depth,
      elevation_optimal = -5000 - from_depth,
      elevation_range = 5000,
      elevation_max_range = 5000 - from_depth, -- everywhere below elevation 0 and nowhere else
	  
      temperature_optimal = temp_center,
      temperature_range = temp_range,
      temperature_max_range = temp_range + 2,
      water_optimal = water_center,
      water_range = water_range,
      water_max_range = water_range + 0.05,
    }
  }

  if rectangles == nil then
    ret[2] = { influence = 1 }
  end

  --autoplace_utils.peaks(rectangles, ret)--comment out?

  return { peaks = ret }
end

data:extend(
{
  {
    type = "tile",
    name = "obsidian",
    collision_mask = {"ground-tile"},
    --autoplace = autoplace_settings("obsidian", {{{35, 0.35}, {lavatemp+2, 0}, (default_influence or 1)*1.05}}),--
	autoplace = water_autoplace_settings2((-1*stoneamount), {{{35, lavawater}, {lavatemp, lavadry}}}),
    layer = 34,------WHAT DO
    variants =
    {
      main =
      {
        {
          picture = "__various-tiles-mod__/graphics/terrain/obsidian/stone-path-1.png",
          count = 16,
          size = 1
        },
        {
          picture = "__various-tiles-mod__/graphics/terrain/obsidian/stone-path-2.png",
          count = 4,
          size = 2,
          probability = 0.39,
        },
        {
          picture = "__various-tiles-mod__/graphics/terrain/obsidian/stone-path-4.png",
          count = 4,
          size = 4,
          probability = 1,
        },
      },
      inner_corner =
      {
        picture = "__various-tiles-mod__/graphics/terrain/obsidian/stone-path-inner-corner.png",
        count = 8
      },
      outer_corner =
      {
        picture = "__various-tiles-mod__/graphics/terrain/obsidian/stone-path-outer-corner.png",
        count = 1
      },
      side =
      {
        picture = "__various-tiles-mod__/graphics/terrain/obsidian/stone-path-side.png",
        count = 10
      },
      u_transition =
      {
        picture = "__various-tiles-mod__/graphics/terrain/obsidian/stone-path-u.png",
        count = 10
      },
      o_transition =
      {
        picture = "__various-tiles-mod__/graphics/terrain/obsidian/stone-path-o.png",
        count = 10
      }
    },
    walking_sound =
    {
      {
        filename = "__base__/sound/walking/concrete-01.ogg",
        volume = 0.8
      },
      {
        filename = "__base__/sound/walking/concrete-02.ogg",
        volume = 0.8
      },
      {
        filename = "__base__/sound/walking/concrete-03.ogg",
        volume = 0.8
      },
      {
        filename = "__base__/sound/walking/concrete-04.ogg",
        volume = 0.8
      }
    },
	--allowed_neighbors = {"sand", "dark-sand"},
    map_color={r=160, g=160, b=160},
    ageing=0.00025,---------WHAT DO
    --vehicle_friction_modifier = sand_vehicle_speed_modifier
  },
  {
    type = "tile",
    name = "deeplava",
    collision_mask =
    {
      "water-tile",
      "resource-layer",
      "item-layer",
      "player-layer",
      "doodad-layer"
    },
    autoplace = water_autoplace_settings(250, {{{35, lavawater}, {lavatemp, lavadry}}}),
	--autoplace = autoplace_settings("deeplava", {{{35, 0.5}, {27, 0}}}),
    layer = 60,
    variants =
    {
      main =
      {
        {
          picture = "__various-tiles-mod__/graphics/terrain/deeplava/deepwater1.png",
          count = 8,
          size = 1
        },
        {
          picture = "__various-tiles-mod__/graphics/terrain/deeplava/deepwater2.png",
          count = 8,
          size = 2
        },
        {
          picture = "__various-tiles-mod__/graphics/terrain/deeplava/deepwater4.png",
          count = 6,
          size = 4
        }
      },
      inner_corner =
      {
        picture = "__various-tiles-mod__/graphics/terrain/deeplava/deepwater-inner-corner.png",
        count = 6
      },
      outer_corner =
      {
        picture = "__various-tiles-mod__/graphics/terrain/deeplava/deepwater-outer-corner.png",
        count = 6
      },
      side =
      {
        picture = "__various-tiles-mod__/graphics/terrain/deeplava/deepwater-side.png",
        count = 8
      }
    },
    allowed_neighbors = { "lava" },
    map_color={r=148, g=27, b=18},
    ageing=0.0005
  },
  {
    type = "tile",
    name = "lava",
    collision_mask =
    {
      "water-tile",
      "item-layer",
      "resource-layer",
      "player-layer",
      "doodad-layer"
    },
    autoplace = water_autoplace_settings(0, {{{35, lavawater}, {lavatemp, lavadry}}}),
	--autoplace = autoplace_settings("lava", {{{35, 0.5}, {27, 0}}}),
    layer = 55,
    variants =
    {
      main =
      {
        {
          picture = "__various-tiles-mod__/graphics/terrain/lava/water1.png",
          count = 8,
          size = 1
        },
        {
          picture = "__various-tiles-mod__/graphics/terrain/lava/water2.png",
          count = 8,
          size = 2
        },
        {
          picture = "__various-tiles-mod__/graphics/terrain/lava/water4.png",
          count = 6,
          size = 4
        }
      },
      inner_corner =
      {
        picture = "__various-tiles-mod__/graphics/terrain/lava/water-inner-corner.png",
        count = 6
      },
      outer_corner =
      {
        picture = "__various-tiles-mod__/graphics/terrain/lava/water-outer-corner.png",
        count = 6
      },
      side =
      {
        picture = "__various-tiles-mod__/graphics/terrain/lava/water-side.png",
        count = 8
      }
    },
    allowed_neighbors = { "obsidian" },
    map_color={r=148, g=27, b=18},
    ageing=0.0005
  }
})