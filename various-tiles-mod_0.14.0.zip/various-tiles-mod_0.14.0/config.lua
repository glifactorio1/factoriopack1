tobymods.varioustiles.lavatemp=34--decreasing this makes lava areas more common
tobymods.varioustiles.lavawater=0.35--increasing this makes lava areas more common
tobymods.varioustiles.stoneamount=220--increasing this makes the stone areas around lava pools bigger