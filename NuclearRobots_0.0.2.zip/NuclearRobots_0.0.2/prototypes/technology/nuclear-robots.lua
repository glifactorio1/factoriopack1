data:extend(
{
  {
    type = "technology",
    name = "nuclear-robotics",
    icon = "__NuclearRobots__/graphics/technology/nuclear-robotics.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "construction-robot-nuclear"
      },
      {
        type = "unlock-recipe",
        recipe = "logistic-robot-nuclear"
      },
    },
    prerequisites = {"construction-robotics", "logistic-robotics","rtg-equipment"},
    unit =
    {
      count = 450,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 30
    },
    order = "c-k-b",
  },
})