data:extend(
{
  {
	type = "generator",
    name = "energy-receiver",
    icon = "__base__/graphics/icons/accumulator.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "energy-receiver"},
    max_health = 750,
    corpse = "medium-remnants",
    collision_box = {{-0.9, -0.9}, {0.9, 0.9}},
    selection_box = {{-1, -1}, {1, 1}},
    effectivity = 44,  -- Cannot get fluid energy density to work. So just messing with the generator efficiency instead.
    fluid_usage_per_tick = 0.1,
    resistances = 
    {
      {
        type = "fire",
        percent = 70
      }
    },
    fluid_box =
    {
      base_area = 1,
      pipe_covers = pipecoverspictures(),
      pipe_connections = { },
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-output"
    },
    horizontal_animation =
    {
      filename = "__base__/graphics/entity/accumulator/accumulator-charge-animation.png",
      width = 138,
      height = 135,
      line_length = 8,
      frame_count = 24,
      shift = {0.482, -0.638},
      animation_speed = 0.5
    },
    vertical_animation =
    {
      filename = "__base__/graphics/entity/accumulator/accumulator-charge-animation.png",
      width = 138,
      height = 135,
      line_length = 8,
      frame_count = 24,
      shift = {0.482, -0.638},
      animation_speed = 0.5
    },
    smoke = { },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/accumulator-working.ogg",
        volume = 1
      },
      max_sounds_per_type = 5
    },
    min_perceived_performance = 0.25,
    performance_to_sound_speedup = 0.5
  },
  {
    type = "fluid",
    name = "beamedenergy",
    default_temperature = 1,
    max_temperature = 100,
    heat_capacity = "1KJ",
    base_color = {r=0.9, g=0.9, b=0.0},
    flow_color = {r=0.7, g=0.7, b=0.0},
    icon = "__base__/graphics/icons/solar-panel.png",
    order = "a[fluid]-a[beamedenergy]",
    pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
  }
})
