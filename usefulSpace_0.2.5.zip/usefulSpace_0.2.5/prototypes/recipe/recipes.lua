data:extend(
{
  {
    type = "recipe",
    name = "energy-receiver",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
      {"steel-plate", 40},
	  {"radar", 1},
      {"advanced-circuit", 35},
    },
    result = "energy-receiver"
  },
})
 