data:extend(
{
  	{
		type = "item",
		name = "energy-receiver",
		icon = "__base__/graphics/icons/iron-chest.png",
		flags = {"goes-to-quickbar"},
		subgroup = "extraction-machine",
		order = "a[items]-b[basic-mining-drill]",
		place_result = "energy-receiver",
		stack_size = 5
	},
})
