data:extend({

	
	-- Hive Buster Turret
	
		{
	type = "item",
	name = "Bio_Cannon_Area",
	icon = "__Bio_Industries__/graphics/icons/biocannon_icon.png",
	flags = { "goes-to-quickbar" },
	subgroup = "defensive-structure",
	order = "b-b",
	place_result = "Bio_Cannon_Area",
	stack_size = 1,
	},
	
})