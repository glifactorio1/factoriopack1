data:extend({

-- Hive Buster Turret
 {
    type = "recipe",
    name = "Bio_Cannon",
    enabled = false,
	energy_required = 50,
	ingredients = {{"advanced-circuit", 25},{"radar", 1}, {"steel-plate", 80}, {"electric-engine-unit", 5}},
	--ingredients = {{"processing-unit", 5},{"radar", 1}, {"steel-plate", 80}},
	
    result = "Bio_Cannon_Area"
 },
})