data:extend({

	--- Bio Solar Farm
	{
		type = "recipe",
		name = "bi_bio_Solar_Farm",
		enabled = false,
		energy_required = 20,
		ingredients = 
		{
			{"solar-panel",20},
			{"medium-electric-pole",10},
			{"concrete",40},
					
		},
		result = "bi_bio_Solar_Farm"
	},
	
	
	
 })

