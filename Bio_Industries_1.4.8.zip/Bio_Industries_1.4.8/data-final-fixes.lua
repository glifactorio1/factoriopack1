


---- Inrease Wood Stack Size
if data.raw.item["raw-wood"].stack_size < 400 then
	data.raw.item["raw-wood"].stack_size = 400
end