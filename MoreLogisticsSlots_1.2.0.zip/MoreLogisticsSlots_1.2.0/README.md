# MoreLogisticSlots
A mod for [Factorio](http://www.factorio.com/), that adds more logistics slots to the player via research 

* Adds 5 rows, or 25 logistic slots for requests from the logistic network
* Each row requires research
* See the link in the description for more info and pics

Created by Wenihal (http://www.factorioforums.com/forum/memberlist.php?mode=viewprofile&u=5761) - whom I don't know,
but since he stoped updating the mod, I took it upon myself to import it into github for the convinience of the community.

 Version 1.0.1 - updated to confirm with #Factorio 0.12.7 (adding the 5th row) by narc0tiq
