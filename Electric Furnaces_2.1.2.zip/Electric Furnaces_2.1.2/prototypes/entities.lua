-- Electric Stone Furnace ****************************************************************
electricstone = util.table.deepcopy(data.raw["furnace"]["stone-furnace"])
electricstone.name = "electric-stone-furnace"
electricstone.icon = "__Electric Furnaces__/graphics/icons/electric-stone-furnace.png"
electricstone.minable = {mining_time = 1, result = "electric-stone-furnace"}
electricstone.working_sound =
{
  sound =
  {
    filename = "__base__/sound/electric-furnace.ogg",
    volume = 0.7
  },
  apparent_volume = 1.5
}
-- electricstone.energy_usage = "135kW"
electricstone.energy_usage = "180kW"
electricstone.crafting_speed = 1
electricstone.energy_source =
{
  type = "electric",
  usage_priority = "secondary-input",
  emissions = 0.005
}
electricstone.animation.filename = "__Electric Furnaces__/graphics/entity/electric-stone-furnace/electric-stone-furnace.png"
electricstone.working_visualisations =
{
  {
    animation =
    {
      filename = "__Electric Furnaces__/graphics/entity/electric-stone-furnace/electric-stone-furnace-heater.png",
      priority = "extra-high",
      width = 8,
      height = 11,
      frame_count = 12,
      shift = {0.046875, 0.565625}
    },
    light = {intensity = 0.4, size = 6}
  }
}

-- Electric Steel Furnace ****************************************************************
electricsteel = util.table.deepcopy(electricstone)
electricsteel.name = "electric-steel-furnace"
electricsteel.icon = "__Electric Furnaces__/graphics/icons/electric-steel-furnace.png"
electricsteel.minable = {mining_time = 1, result = "electric-steel-furnace"}
electricsteel.energy_usage = "180kW"
electricsteel.crafting_speed = 2
electricsteel.animation =
{
  filename = "__Electric Furnaces__/graphics/entity/electric-steel-furnace/electric-steel-furnace.png",
  priority = "high",
  width = 84,
  height = 66,
  frame_count = 1,
  shift = {0.5, -0.2375}
}
electricsteel.working_visualisations =
{
  {
    animation =
    {
      filename = "__base__/graphics/entity/electric-furnace/electric-furnace-heater.png",
      priority = "high",
      width = 25,
      height = 15,
      frame_count = 12,
      animation_speed = 0.5,
      shift = {0.09375, 0.371875}
    },
    light = {intensity = 0.4, size = 6, shift = {0.0, 1.0}}
  }
}

-- Electric Furnace 2 ********************************************************************
electric2 = util.table.deepcopy(data.raw["furnace"]["electric-furnace"])
electric2.name = "electric-furnace-2"
electric2.icon = "__Electric Furnaces__/graphics/icons/electric-furnace-2.png"
electric2.minable = {mining_time = 1, result = "electric-furnace-2"}
electric2.module_specification.module_slots = 2
electric2.energy_usage = "180kW"
electric2.crafting_speed = 3
electric2.animation.filename = "__Electric Furnaces__/graphics/entity/electric-furnace-2/electric-furnace-2-base.png"

-- Electric Furnace 3 ********************************************************************
electric3 = util.table.deepcopy(data.raw["furnace"]["electric-furnace"])
electric3.name = "electric-furnace-3"
electric3.icon = "__Electric Furnaces__/graphics/icons/electric-furnace-3.png"
electric3.minable = {mining_time = 1, result = "electric-furnace-3"}
electric3.module_specification.module_slots = 4
electric3.energy_usage = "240kW"
electric3.crafting_speed = 4
electric3.animation.filename = "__Electric Furnaces__/graphics/entity/electric-furnace-3/electric-furnace-3-base.png"

data:extend(
{
  electricstone,
  electricsteel,
  electric2,
  electric3
})