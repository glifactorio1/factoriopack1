## README

welcome to this mod. With its help you can easily create a web statistic view.

Either you write your own, or you can just download my simple web view.

Goto to this github page: https://github.com/schaeftide/statisticWebView

Download and extract the package in a webroot, 
enable the cronjob (every minute) and write your factorio base path to the config file.

HAVE FUN :)

If you have the easy Teams mod (https://forums.factorio.com/viewtopic.php?f=92&t=29465)
the web view will adapt your titles and colors from the teams.