require("prototypes.config")

concrete = {}
concrete.type = "recipe"
concrete.name = "concrete-gold"
concrete.enabled = true
concrete.ingredients = {{"gold-plate",25}}
concrete.energy_required = 3
concrete.result = "concrete-gold"
concrete.result_count = 5

data:extend({ concrete })
