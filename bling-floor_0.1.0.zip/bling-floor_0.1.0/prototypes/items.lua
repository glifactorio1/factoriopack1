require("prototypes.config")

concrete = util.table.deepcopy(data.raw["item"]["concrete"])
concrete.name = "concrete-gold"
concrete.icon = MOD_NAME.."/graphics/concrete.png"
concrete.place_as_tile.result = "concrete-gold"
concrete.order = "c-aa-gold"

data:extend({ concrete })
