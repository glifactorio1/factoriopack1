require("prototypes.config")

concrete = util.table.deepcopy(data.raw["tile"]["concrete"])
concrete.name                           = "concrete-gold"
concrete.variants.main[1].picture       = MOD_NAME.."/graphics/concrete1.png"
concrete.variants.main[2].picture       = MOD_NAME.."/graphics/concrete2.png"
concrete.variants.main[3].picture       = MOD_NAME.."/graphics/concrete4.png"
concrete.variants.inner_corner.picture  = MOD_NAME.."/graphics/concrete-inner-corner.png"
concrete.variants.outer_corner.picture  = MOD_NAME.."/graphics/concrete-outer-corner.png"
concrete.variants.side.picture          = MOD_NAME.."/graphics/concrete-side.png"
concrete.variants.u_transition.picture  = MOD_NAME.."/graphics/concrete-u.png"
concrete.variants.o_transition.picture  = MOD_NAME.."/graphics/concrete-o.png"
concrete.walking_speed_modifier = 3
RGB={r=1.0, g=1.0, b=0.1}
S=0.5
concrete.map_color = {
	r = (RGB["r"] * S),
	g = (RGB["g"] * S),
	b = (RGB["b"] * S)
}
concrete.minable["result"] = "concrete-gold"

data:extend({ concrete })
