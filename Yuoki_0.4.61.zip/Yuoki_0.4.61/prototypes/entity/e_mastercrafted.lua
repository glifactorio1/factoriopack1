data:extend(
{  

	--y-obninsk-reactor
	{
		type = "recipe",
		name = "y_obninsk_mc_recipe",
		ingredients = {{"y-obninsk-reactor", 1}, {"y_rwtechsign", 10000},},
		result = "y_obninsk_mc",
		group = "yuoki-energy",
		subgroup = "y_mastercrafted",		
		order="b-a5",
	},
	{
		type = "item",
		name = "y_obninsk_mc",
		icon = "__Yuoki__/graphics/entity/obninsk_mc_icon.png",
		flags = {"goes-to-quickbar"},
		group = "yuoki-energy",
		subgroup = "y_mastercrafted",		
		order = "b[steam-power]-a5",
		place_result = "y_obninsk_mc",
		stack_size = 5,
	},
	
	{
		type = "boiler",
		name = "y_obninsk_mc",
		icon = "__Yuoki__/graphics/entity/obninsk_mc_icon.png",
		flags = {"placeable-player", "player-creation"},
		minable = {hardness = 0.3, mining_time = 0.5, result = "y_obninsk_mc"},
		max_health = 1500,
		corpse = "big-remnants",
		resistances = 
		{
			{
				type = "fire",
				percent = 80
			}
		},		
		collision_box = {{-2.25, -2.25}, {2.25, 2.25}},
		selection_box = {{-2.5, -2.5}, {2.5, 2.5}},
		fluid_box =
		{
			base_area = 50,
			pipe_connections =
			{
				{ position = { -1.0, -3.0} },
				{ position = {  1.0, -3.0} },
				{ position = { -1.0,  3.0} },
				{ position = {  1.0,  3.0} },				
			},
		},
		energy_consumption = "30MW",
		burner =
		{
			effectivity = 1.15,
			fuel_inventory_size = 2,
			fuel_inventory_count = 100,
			emissions = 0.001,
			smoke = {{	name = "smoke",deviation = {0.1, 0.1},frequency = 0.1,}}
		},
		structure =
		{
			left = 
			{
				filename = "__Yuoki__/graphics/entity/obninsk_mc.png", priority = "extra-high", width = 420, height = 360, shift = {0.6, 0.2}, scale = 0.5,
			},
			down =
			{
				filename = "__Yuoki__/graphics/entity/obninsk_mc.png", priority = "extra-high", width = 420, height = 360, shift = {0.6, 0.2}, scale = 0.5,
			},
			left_down =
			{
				filename = "__Yuoki__/graphics/entity/obninsk_mc.png", priority = "extra-high", width = 420, height = 360, shift = {0.6, 0.2},	scale = 0.5,
			},
			right_down =
			{
				filename = "__Yuoki__/graphics/entity/obninsk_mc.png", priority = "extra-high", width = 420, height = 360, shift = {0.6, 0.2},	scale = 0.5,
			},
			left_up =
			{
				filename = "__Yuoki__/graphics/entity/obninsk_mc.png", priority = "extra-high", width = 420, height = 360, shift = {0.6, 0.2},	scale = 0.5,	
			},
			right_up =
			{
				filename = "__Yuoki__/graphics/entity/obninsk_mc.png", priority = "extra-high", width = 420, height = 360, shift = {0.6, 0.2},	scale = 0.5,
			},
			t_down =
			{
				filename = "__Yuoki__/graphics/entity/obninsk_mc.png", priority = "extra-high", width = 420, height = 360, shift = {0.6, 0.2},	scale = 0.5,
			},
			t_up =
			{
				filename = "__Yuoki__/graphics/entity/obninsk_mc.png", priority = "extra-high", width = 420, height = 360, shift = {0.6, 0.2}, scale = 0.5,
			},			
		},
		fire ={},
		burning_cooldown = 500,
		-- these are the pipe pictures - boiler is a pipe as well
		pictures = pipepictures()
	},

	-- big master-steam-turbine
	{
		type = "recipe",
		name = "y_steam_turbine_mc_recipe",
		icon = "__Yuoki__/graphics/entity/steam_turbine_n3mc_icon.png",
		ingredients = {{"y-steam-turbine",1},{"y_rwtechsign",1000},},		
		results = { {type="item", name="y_steam_turbine_mc", amount=1,}, },		
		enabled = "true",				
		group = "yuoki-energy",
		subgroup = "y_mastercrafted",		
		order="g-b2",	
	},	

	{
		type = "item",
		name = "y_steam_turbine_mc",
		icon = "__Yuoki__/graphics/entity/steam_turbine_n3mc_icon.png",
		flags = {"goes-to-quickbar"},
		group = "yuoki-energy",
		subgroup = "y_mastercrafted",		
		place_result = "y_steam_turbine_mc",
		stack_size = 20, default_request_amount = 5, 
	},
				
	{
		type = "generator",
		name = "y_steam_turbine_mc",
		icon = "__Yuoki__/graphics/entity/steam_turbine_n3mc_icon.png",
		flags = {"placeable-neutral","player-creation"},
		minable = {mining_time = 1, result = "y_steam_turbine_mc"},
		max_health = 400,
		corpse = "big-remnants",
		effectivity = 1.425,
		fluid_usage_per_tick = 0.3302,
		resistances =
		{
			{
				type = "fire",
				percent = 70
			}
		},
		collision_box = {{-1.3, -1.7}, {1.3, 1.7}},
		selection_box = {{-1.5, -2.0}, {1.5, 2.0}},
		fluid_box =
		{
			base_area = 3,			
			pipe_connections =
			{
				{ position = {0, 2.5} },
				{ position = {0,-2.5} },
			},
			
		},
		energy_source =
		{
			type = "electric",
			usage_priority = "secondary-output"
		},
		horizontal_animation =
		{
			filename = "__Yuoki__/graphics/entity/steam_turb_h3mc_sheet.png",
			width = 320,
			height = 320,
			frame_count = 10,
			line_length = 5,
			shift = {0.475,-0.95},
			scale = 0.5,
		},
		vertical_animation =
		{
			filename = "__Yuoki__/graphics/entity/steam_turb_v3mc_sheet.png",
			width = 320,
			height = 320,
			frame_count = 10,
			line_length = 5,
			shift = {1.0,-0.25},
			scale = 0.5,			
		},					
		smoke = {
			{ name = "smoke", north_position = {-1.1, -2.2}, east_position = {1.7, -1}, height = 0.3, deviation = {0.1, 0.1}, frequency = 0.25, 					
					height_deviation = 0.2,
					starting_vertical_speed = 0.2,
					starting_vertical_speed_deviation = 0.06, },
			{ name = "smoke", north_position = {1.1, -2.2}, east_position = {1.7, 0}, height = 0.3, deviation = {0.1, 0.1}, frequency = 0.25, 					
					height_deviation = 0.2,
					starting_vertical_speed = 0.2,
					starting_vertical_speed_deviation = 0.06, },
		},
	},   

	-- Mastercrafted-Special Drill
	{
		type = "recipe",
		name = "y_mc_underground_drill_recipe",
		icon = "__Yuoki__/graphics/entity/mc_digger_icon.png",
		ingredients = {{"y-underground-drill",1},{"y_rwtechsign", 4000},},		
		results = { {type="item", name="y_mc_underground_drill", amount=1,}, },		
		enabled = "true",				
		group = "yuoki-energy",
		subgroup = "y_mastercrafted",		
		order="g-b2",	
	},	

	{
		type = "item",
		name = "y_mc_underground_drill",
		icon = "__Yuoki__/graphics/entity/mc_digger_icon.png",
		flags = {"goes-to-quickbar"},
		group = "yuoki-energy",
		subgroup = "y_mastercrafted",		
		place_result = "y_mc_underground_drill",
		stack_size = 20, default_request_amount = 5, 
	},
	
	{
		type = "assembling-machine",
		name = "y_mc_underground_drill", minable = {hardness = 0.2,mining_time = 0.5,result = "y_mc_underground_drill"},
		icon = "__Yuoki__/graphics/entity/mc_digger_icon.png",
		flags = {"placeable-neutral","player-creation"},		
		max_health = 600,
		--resistances = {{type = "fire",percent = 70}},
		collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
		selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
	    working_sound = { sound = { filename = "__base__/sound/electric-mining-drill.ogg", volume = 0.75 }, apparent_volume = 1.5,},
		animation = {
			filename = "__Yuoki__/graphics/entity/mc_digger_sheet.png",
			priority = "medium",
			width = 256,
			height = 256,
			frame_count = 16,		
			line_length =4,
			scale = 0.5, 	
			shift = {0.5, -0.4}
		},					
		crafting_categories = {"yuoki-raw-material-recipe"},
		crafting_speed = 2,
		energy_source = {type = "electric",input_priority = "secondary", usage_priority = "secondary-input", emissions = 0.005},
		energy_usage = "400kW",
		ingredient_count = 1,
		module_specification =
		{
			module_slots = 2
		},
		allowed_effects = {"consumption", "speed", "productivity", "pollution"},
		
	},	

	-- Mastercrafted Washer
	{
		type = "recipe",
		name = "y_mc_dirtwasher_recipe",
		icon = "__Yuoki__/graphics/entity/mc_washer_icon.png",
		ingredients = {{"y-dirtwasher",1},{"y_rwtechsign",2500},},		
		results = { {type="item", name="y_mc_dirtwasher", amount=1,}, },		
		enabled = "true",				
		group = "yuoki-energy",
		subgroup = "y_mastercrafted",		
		order="g-b2",	
	},	

	{
		type = "item",
		name = "y_mc_dirtwasher",
		icon = "__Yuoki__/graphics/entity/mc_washer_icon.png",
		flags = {"goes-to-quickbar"},
		group = "yuoki-energy",
		subgroup = "y_mastercrafted",		
		place_result = "y_mc_dirtwasher",
		stack_size = 20, default_request_amount = 5, 
	},
	
	{
		type = "assembling-machine",
		name = "y_mc_dirtwasher",
		icon = "__Yuoki__/graphics/entity/mc_washer_icon.png",
		flags = {"placeable-neutral","player-creation"},
		minable = {hardness = 0.2,mining_time = 0.5,result = "y_mc_dirtwasher"},
		max_health = 300,
		--resistances = {{type = "fire",percent = 70}},
		collision_box = {{-1.3,-1.3},{1.3,1.3}},
		selection_box = {{-1.5,-1.5},{1.5,1.5}},
		animation = {
			north =
			{
				filename = "__Yuoki__/graphics/entity/washer_mc_ns_sheet.png",
				priority = "medium", width = 256, height = 256, frame_count = 16, line_length=4, shift = {0.5, -0.25}, animation_speed=0.7, scale=0.5,
			},
			east =
			{
				filename = "__Yuoki__/graphics/entity/washer_mc_we_sheet.png",
				priority = "medium", width = 256, height = 256, frame_count = 16, line_length=4, shift = {0.47, 0}, animation_speed=0.7, scale=0.5,				
			},
			south =
			{
				filename = "__Yuoki__/graphics/entity/washer_mc_ns_sheet.png",
				priority = "medium", width = 256, height = 256, frame_count = 16, line_length=4, shift = {0.5, -0.25}, animation_speed=0.7, scale=0.5,
			},
			west =
			{
				filename = "__Yuoki__/graphics/entity/washer_mc_we_sheet.png",
				priority = "medium", width = 256, height = 256, frame_count = 16, line_length=4, shift = {0.47, 0}, animation_speed=0.7, scale=0.5,
			},			
		},					
		crafting_categories = {"yuoki-archaeology-wash"},
		crafting_speed = 2,
		energy_source = {type = "electric",input_priority = "secondary", usage_priority = "secondary-input", emissions = 0.005},
		energy_usage = "500kW",
		ingredient_count = 3,
		fluid_boxes =
		{
			{
				production_type = "input",
				pipe_covers = pipecoverspictures(),
				base_area = 10,
				base_level = -1,
				pipe_connections = {{ type="input", position = {-1, -2} }}
			},
			{
				production_type = "input",
				pipe_covers = pipecoverspictures(),
				base_area = 10,
				base_level = -1,
				pipe_connections = {{ type="input", position = {1, -2.0} }}
			},
			{
				production_type = "output",
				pipe_covers = pipecoverspictures(),
				base_level = 1,
				pipe_connections = {{ position = {1, 2} }}
			},
			{
				production_type = "output",
				pipe_covers = pipecoverspictures(),
				base_level = 1,
				pipe_connections = {{ position = {-1, 2} }}
			},
			off_when_no_fluid_recipe = true,
		},	  
		module_specification =
		{
			module_slots = 2
		},
		allowed_effects = {"consumption", "speed", "productivity", "pollution"},
	},
		
	-- Mastercrafted Mining Drill
	{
		type = "recipe",
		name = "y_mc_e2_mining_drill_recipe",
		icon = "__Yuoki__/graphics/entity/mc_miner_icon.png",
		ingredients = {{"y-mining-drill-e2",1},{"y_rwtechsign",3500},},		
		results = { {type="item", name="y_mc_e2_mining_drill", amount=1,}, },		
		enabled = "true",				
		group = "yuoki-energy",
		subgroup = "y_mastercrafted",		
		order="g-b2",	
	},	

	{
		type = "item",
		name = "y_mc_e2_mining_drill",
		icon = "__Yuoki__/graphics/entity/mc_miner_icon.png",
		flags = {"goes-to-quickbar"},
		group = "yuoki-energy",
		subgroup = "y_mastercrafted",		
		place_result = "y_mc_e2_mining_drill",
		stack_size = 20, default_request_amount = 5, 
	},
	{
		type = "mining-drill",
		name = "y_mc_e2_mining_drill",
		icon = "__Yuoki__/graphics/entity/mc_miner_icon.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {mining_time = 1, result = "y_mc_e2_mining_drill"},
		max_health = 900,
		resource_categories = {"basic-solid"},
		corpse = "big-remnants",
		collision_box = {{ -2.2, -2.2}, {2.2, 2.2}},
		selection_box = {{ -2.5, -2.5}, {2.5, 2.5}},
	    working_sound = { sound = { filename = "__base__/sound/electric-mining-drill.ogg", volume = 0.75 }, apparent_volume = 1.5,},
		animations =
		{
				priority = "extra-high",
				width = 448,
				height = 448,
				line_length = 4,
				shift = {0, -0.5},
				filename = "__Yuoki__/graphics/entity/miners/mc_miner_sheet.png",
				frame_count = 16,
				animation_speed = 0.5,
				scale = 0.5,
		},		
		mining_speed = 3.0,
		energy_source =
		{
			type = "electric",
			usage_priority = "secondary-input",
			emissions = 0.02, 		
		},
		energy_usage = "400kW",
		mining_power = 6,
		resource_searching_radius = 4.49,
		vector_to_place_result = {0, -2.75},
		module_specification =
		{
			module_slots = 3,
		},
		allowed_effects = {"consumption", "speed", "productivity", "pollution"},
		radius_visualisation_picture =
		{
			filename = "__base__/graphics/entity/electric-mining-drill/electric-mining-drill-radius-visualization.png",
			width = 16,
			height = 16
		},
		fast_replaceable_group = "mining-drill",
	},
		
})