data:extend({

	{
		type = "recipe",
		name = "y_old_bodenlampe_recipe",
		enabled = true,
		ingredients = 
		{    
			{"stone-brick", 1},
			{"iron-plate", 1},
			{"copper-cable", 3},				
		},
		group = "yuoki",
		subgroup = "y_lamps_deco",	
		result = "y_old_bodenlampe",
		order = "gf1",
	},
	
	{
		type = "item",
		name = "y_old_bodenlampe",
		icon = "__Yuoki__/graphics/entity/lamps/gf_lamp1_icon.png",
		flags = {"goes-to-quickbar"},
		group = "yuoki",
		subgroup = "y-lamps",
		place_result = "y_old_bodenlampe",
		stack_size = 40,
	},

	{
		type = "lamp",
		name = "y_old_bodenlampe",
		icon = "__Yuoki__/graphics/entity/lamps/gf_lamp1_icon.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "y_old_bodenlampe"},
		max_health = 50,
		corpse = "small-remnants",
		collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},		
		energy_source = {type = "electric",input_priority = "secondary",usage_priority = "secondary-input",},				
		energy_usage = "350kW",
		energy_usage_per_tick = "50W",
		light = {intensity = 1.0, size = 50},
		--light = {intensity = 0.25, size = 10, color = {r=0.0, g=0.35, b=1.0} },
		picture_off =
		{
			filename = "__Yuoki__/graphics/entity/lamps/gf_lamp1_off.png",
			priority = "high",
			width = 64,
			height = 64,
			shift = {0, 0},
			scale= 0.5,
		},
		picture_on =
		{
			filename = "__Yuoki__/graphics/entity/lamps/gf_lamp1_on.png",
			priority = "high",
			width = 64,
			height = 64,			
			shift = {0, 0},
			scale= 0.5,
		},
		--circuit_wire_max_distance = 9.5,
		collision_mask = {"ghost-layer"},
	},	

	{
		type = "recipe",
		name = "y_lampe_neotix_recipe",
		enabled = true,
		ingredients = 
		{    
			{"stone-brick", 1},
			{"iron-plate", 1},
			{"copper-cable", 3},				
		},
		group = "yuoki",
		subgroup = "y_lamps_deco",	
		result = "y_lampe_neotix",
		order = "gf2",
	},
	
	{
		type = "item",
		name = "y_lampe_neotix",
		icon = "__Yuoki__/graphics/entity/lamps/gf_lamp2(N)_icon.png",
		flags = {"goes-to-quickbar"},
		group = "yuoki",
		subgroup = "y-lamps",
		place_result = "y_lampe_neotix",
		stack_size = 40,
	},

	{
		type = "lamp",
		name = "y_lampe_neotix",
		icon = "__Yuoki__/graphics/entity/lamps/gf_lamp2(N)_icon.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "y_lampe_neotix"},
		max_health = 50,
		corpse = "small-remnants",
		collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},		
		energy_source = {type = "electric",input_priority = "secondary",usage_priority = "secondary-input",},				
		energy_usage_per_tick = "10W",
		light = {intensity = 1.0, size = 50},
		--light = {intensity = 0.25, size = 10, color = {r=0.0, g=0.75, b=1.0} },
		picture_off =
		{
			filename = "__Yuoki__/graphics/entity/lamps/gf_lamp2(N)_off.png",
			priority = "high",
			width = 64,
			height = 64,
			shift = {0, 0},
			scale= 0.5,
		},
		picture_on =
		{
			filename = "__Yuoki__/graphics/entity/lamps/gf_lamp2(N)_on.png",
			priority = "high",
			width = 64,
			height = 64,			
			shift = {0, 0},
			scale= 0.5,
		},
		circuit_wire_max_distance = 9.5,
		collision_mask = {"ghost-layer"},
	},	

	{
		type = "recipe",
		name = "y_lampe_yuoki_recipe",
		enabled = true,
		ingredients = 
		{    
			{"stone-brick", 1},
			{"iron-plate", 1},
			{"copper-cable", 3},				
		},
		group = "yuoki",
		subgroup = "y_lamps_deco",	
		result = "y_lampe_yuoki",
		order = "gf3",
	},
	
	{
		type = "item",
		name = "y_lampe_yuoki",
		icon = "__Yuoki__/graphics/entity/lamps/gf_lamp3_icon.png",
		flags = {"goes-to-quickbar"},
		group = "yuoki",
		subgroup = "y-lamps",
		place_result = "y_lampe_yuoki",
		stack_size = 40,
	},

	{
		type = "lamp",
		name = "y_lampe_yuoki",
		icon = "__Yuoki__/graphics/entity/lamps/gf_lamp3_icon.png",
		flags = {"placeable-neutral", "player-creation"},
		minable = {hardness = 0.2, mining_time = 0.5, result = "y_lampe_yuoki"},
		max_health = 50,
		corpse = "small-remnants",
		collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},		
		energy_source = {type = "electric",input_priority = "secondary",usage_priority = "secondary-input",},				
		--energy_source = {type = "burner", effectivity = 0.95,fuel_inventory_size = 1,emissions = 0,},				
		energy_usage_per_tick = "10W",
		light = {intensity = 1.0, size = 50},
		--light = {intensity = 0.25, size = 10, color = {r=1.0, g=0.98, b=0.4} },
		picture_off =
		{
			filename = "__Yuoki__/graphics/entity/lamps/gf_lamp3_off.png",
			priority = "high",
			width = 64,
			height = 64,
			shift = {0, 0},
			scale= 0.5,
		},
		picture_on =
		{
			filename = "__Yuoki__/graphics/entity/lamps/gf_lamp3_on.png",
			priority = "high",
			width = 64,
			height = 64,			
			shift = {0, 0},
			scale= 0.5,
		},
		circuit_wire_max_distance = 9.5,
		collision_mask = {"ghost-layer"},
	},	

	
})	