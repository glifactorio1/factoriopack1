
if Inserters_Item_Group then
data:extend(
{
  {
    type = "item-group",
    name = "inserters",
    order = "bb",
    inventory_order = "gc",
    icon = "__andrew-library__/graphics/item-group/automatization.png",
  },
  {
    type = "item-subgroup",
    name = "burner-inserters",
    group = "inserters",
    order = "1"
  },
  {
    type = "item-subgroup",
    name = "inserters",
    group = "inserters",
    order = "2"
  },
  {
    type = "item-subgroup",
    name = "fast-inserters",
    group = "inserters",
    order = "3"
  },
  {
    type = "item-subgroup",
    name = "filter-inserters",
    group = "inserters",
    order = "4"
  },
  {
    type = "item-subgroup",
    name = "stack-inserters",
    group = "inserters",
    order = "5"
  },
  {
    type = "item-subgroup",
    name = "stack-filter-inserters",
    group = "inserters",
    order = "6"
  },
  {
    type = "item-subgroup",
    name = "inserters-express",
    group = "inserters",
    order = "7"
  },
}
)

-- Automatization--

data.raw.item["burner-inserter"].subgroup = "burner-inserters"
data.raw.item["burner-inserter"].order = "a"

data.raw.item["inserter"].subgroup = "inserters"
data.raw.item["inserter"].order = "a"

data.raw.item["long-handed-inserter"].subgroup = "inserters"
data.raw.item["long-handed-inserter"].order = "b"

data.raw.item["fast-inserter"].subgroup = "fast-inserters"
data.raw.item["fast-inserter"].order = "a"

data.raw.item["filter-inserter"].subgroup = "filter-inserters"
data.raw.item["filter-inserter"].order = "a"

data.raw.item["stack-inserter"].subgroup = "stack-inserters"
data.raw.item["stack-inserter"].order = "a"

data.raw.item["stack-filter-inserter"].subgroup = "stack-filter-inserters"
data.raw.item["stack-filter-inserter"].order = "a"

else

if data.raw.item["fast-long-handed-inserter"] then

data.raw.item["express-inserter"].subgroup = "inserter"
data.raw.item["express-inserter"].order = "c"

data.raw.item["burner-long-handed-inserter"].subgroup = "inserter"
data.raw.item["burner-long-handed-inserter"].order = "z"

data.raw.item["filter-long-handed-inserter"].subgroup = "inserter"
data.raw.item["filter-long-handed-inserter"].order = "z"

data.raw.item["stack-long-handed-inserter"].subgroup = "inserter"
data.raw.item["stack-long-handed-inserter"].order = "z"

data.raw.item["stack-filter-long-handed-inserter"].subgroup = "inserter"
data.raw.item["stack-filter-long-handed-inserter"].order = "z"

data.raw.item["fast-long-handed-inserter"].subgroup = "inserter"
data.raw.item["fast-long-handed-inserter"].order = "z"

end
end
