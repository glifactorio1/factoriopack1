
if Defense_Item_Group then
data:extend(
{
  {
    type = "item-group",
    name = "defense",
    order = "gv",
    inventory_order = "gv",
    icon = "__andrew-library__/graphics/item-group/defense.png",
  },
  {
    type = "item-subgroup",
    name = "defense-flame",
    group = "defense",
    order = "1"
  },
  {
    type = "item-subgroup",
    name = "defense-gun",
    group = "defense",
    order = "2"
  },
  {
    type = "item-subgroup",
    name = "defense-laser",
    group = "defense",
    order = "3"
  },
  {
    type = "item-subgroup",
    name = "defense-wall",
    group = "defense",
    order = "4"
  },
  {
    type = "item-subgroup",
    name = "defense-gate",
    group = "defense",
    order = "5"
  },
  {
    type = "item-subgroup",
    name = "defense-radar",
    group = "defense",
    order = "6"
  },
}
)

-- Defense --

data.raw.item["laser-turret"].subgroup = "defense-laser"
data.raw.item["laser-turret"].order = "b"

data.raw.item["flamethrower-turret"].subgroup = "defense-gun"
data.raw.item["flamethrower-turret"].order = "b"

data.raw.item["gun-turret"].subgroup = "defense-flame"
data.raw.item["gun-turret"].order = "b"

data.raw.item["stone-wall"].subgroup = "defense-wall"
data.raw.item["stone-wall"].order = "a"

data.raw.item["gate"].subgroup = "defense-gate"
data.raw.item["gate"].order = "a"

data.raw.item["radar"].subgroup = "defense-radar"
data.raw.item["radar"].order = "a"

else

if data.raw.item["reinforced-wall"] then
data.raw.item["reinforced-wall"].subgroup = "defensive-structure"
data.raw.item["reinforced-wall"].order = "d"

data.raw.item["reinforced-gate"].subgroup = "defensive-structure"
data.raw.item["reinforced-gate"].order = "d"
end

if data.raw.item["clay-brick"] then
data.raw.item["clay-wall"].subgroup = "defensive-structure"
data.raw.item["clay-wall"].order = "c"

data.raw.item["clay-gate"].subgroup = "defensive-structure"
data.raw.item["clay-gate"].order = "c"
end

end
