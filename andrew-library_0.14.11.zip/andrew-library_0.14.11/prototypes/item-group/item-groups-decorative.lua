
if Decorative_Item_Group then
data:extend(
{
  {
    type = "item-group",
    name = "decoration",
    order = "gz",
    inventory_order = "gz",
    icon = "__andrew-library__/graphics/item-group/decorative.png",
  },
  {
    type = "item-subgroup",
    name = "decoration-floor",
    group = "decoration",
    order = "1"
  },
  {
    type = "item-subgroup",
    name = "landfill",
    group = "decoration",
    order = "2"
  },
}
)

-- Decoration --

data.raw.item["stone-brick"].subgroup = "decoration-floor"
data.raw.item["stone-brick"].order = "a-a"

data.raw.item["concrete"].subgroup = "decoration-floor"
data.raw.item["concrete"].order = "a-b"

data.raw.item["hazard-concrete"].subgroup = "decoration-floor"
data.raw.item["hazard-concrete"].order = "a-c"

data.raw.item["landfill"].subgroup = "landfill"
data.raw.item["landfill"].order = "a-a"

else

if data.raw.item["clay-brick"] then
data.raw.item["clay-brick"].subgroup = "terrain"
data.raw.item["clay-brick"].order = "a-a"

end
end
