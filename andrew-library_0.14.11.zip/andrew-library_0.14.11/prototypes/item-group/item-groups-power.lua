
if Power_Item_Group then
data:extend(
{
  {
    type = "item-group",
    name = "power",
    order = "dd",
    inventory_order = "gb",
    icon = "__andrew-library__/graphics/item-group/power.png",
  },
  {
    type = "item-subgroup",
    name = "medium-pole-powers",
    group = "power",
    order = "aa"
  },
  {
    type = "item-subgroup",
    name = "big-pole-powers",
    group = "power",
    order = "ab"
  },
  {
    type = "item-subgroup",
    name = "substation-pole-powers",
    group = "power",
    order = "ac"
  },
  {
    type = "item-subgroup",
    name = "lamp-powers",
    group = "power",
    order = "ad"
  },
  {
    type = "item-subgroup",
    name = "steam-engine-powers",
    group = "power",
    order = "b"
  },
  {
    type = "item-subgroup",
    name = "boiler-powers",
    group = "power",
    order = "c"
  },
  {
    type = "item-subgroup",
    name = "offshore-pump-powers",
    group = "power",
    order = "d"
  },
  {
    type = "item-subgroup",
    name = "small-pump-powers",
    group = "power",
    order = "e"
  },
  {
    type = "item-subgroup",
    name = "l-accumulator-powers",
    group = "power",
    order = "fa"
  },
  {
    type = "item-subgroup",
    name = "accumulator-powers",
    group = "power",
    order = "fb"
  },
  {
    type = "item-subgroup",
    name = "h-accumulator-powers",
    group = "power",
    order = "fc"
  },
  {
    type = "item-subgroup",
    name = "s-solar-panel-powers",
    group = "power",
    order = "ga"
  },
  {
    type = "item-subgroup",
    name = "solar-panel-powers",
    group = "power",
    order = "gb"
  },
  {
    type = "item-subgroup",
    name = "l-solar-panel-powers",
    group = "power",
    order = "gc"
  },
}
)

-- power --

data.raw.item["substation"].subgroup = "substation-pole-powers"
data.raw.item["substation"].order = "a"

data.raw.item["big-electric-pole"].subgroup = "big-pole-powers"
data.raw.item["big-electric-pole"].order = "a"

data.raw.item["medium-electric-pole"].subgroup = "medium-pole-powers"
data.raw.item["medium-electric-pole"].order = "a"

data.raw.item["small-electric-pole"].subgroup = "lamp-powers"
data.raw.item["small-electric-pole"].order = "a"

data.raw.item["solar-panel"].subgroup = "solar-panel-powers"
data.raw.item["solar-panel"].order = "a"

data.raw.item["accumulator"].subgroup = "accumulator-powers"
data.raw.item["accumulator"].order = "a"

data.raw.item["boiler"].subgroup = "boiler-powers"
data.raw.item["boiler"].order = "a"

data.raw.item["steam-engine"].subgroup = "steam-engine-powers"
data.raw.item["steam-engine"].order = "a"

data.raw.item["small-lamp"].subgroup = "lamp-powers"
data.raw.item["small-lamp"].order = "a"

data.raw.item["offshore-pump"].subgroup = "offshore-pump-powers"
data.raw.item["offshore-pump"].order = "a"

data.raw.item["small-pump"].subgroup = "small-pump-powers"
data.raw.item["small-pump"].order = "a"

end
