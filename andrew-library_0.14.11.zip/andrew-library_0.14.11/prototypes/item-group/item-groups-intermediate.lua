
if Intermediate_Item_Group then
data:extend(
{
  {
    type = "item-group",
    name = "intermediate",
    order = "gab",
    inventory_order = "gc",
    icon = "__andrew-library__/graphics/item-group/intermediate.png",
  },
  {
    type = "item-subgroup",
    name = "intermediate-misc",
    group = "intermediate",
    order = "1"
  },
  {
    type = "item-subgroup",
    name = "intermediate-gear",
    group = "intermediate",
    order = "2"
  },
  {
    type = "item-subgroup",
    name = "intermediate-wire",
    group = "intermediate",
    order = "3"
  },
  {
    type = "item-subgroup",
    name = "intermediate-chip",
    group = "intermediate",
    order = "4"
  },
  {
    type = "item-subgroup",
    name = "intermediate-silo",
    group = "intermediate",
    order = "5"
  },
  {
    type = "item-subgroup",
    name = "intermediate-lab",
    group = "intermediate",
    order = "6"
  },
}
)


-- Intermediate --

data.raw.item["iron-stick"].subgroup = "intermediate-misc"
data.raw.item["iron-stick"].order = "a"

data.raw.item["engine-unit"].subgroup = "intermediate-misc"
data.raw.item["engine-unit"].order = "b"

data.raw.item["electric-engine-unit"].subgroup = "intermediate-misc"
data.raw.item["electric-engine-unit"].order = "c"

data.raw.item["explosives"].subgroup = "intermediate-misc"
data.raw.item["explosives"].order = "f"

data.raw.item["battery"].subgroup = "intermediate-misc"
data.raw.item["battery"].order = "e"

data.raw.tool["science-pack-1"].subgroup = "intermediate-lab"
data.raw.tool["science-pack-1"].order = "a"

data.raw.tool["science-pack-2"].subgroup = "intermediate-lab"
data.raw.tool["science-pack-2"].order = "b"

data.raw.tool["science-pack-3"].subgroup = "intermediate-lab"
data.raw.tool["science-pack-3"].order = "c"

data.raw.tool["alien-science-pack"].subgroup = "intermediate-lab"
data.raw.tool["alien-science-pack"].order = "e"

data.raw.item["electronic-circuit"].subgroup = "intermediate-chip"
data.raw.item["electronic-circuit"].order = "a"

data.raw.item["advanced-circuit"].subgroup = "intermediate-chip"
data.raw.item["advanced-circuit"].order = "b"

data.raw.item["processing-unit"].subgroup = "intermediate-chip"
data.raw.item["processing-unit"].order = "c"

data.raw.item["iron-gear-wheel"].subgroup = "intermediate-gear"
data.raw.item["iron-gear-wheel"].order = "a"

data.raw.item["low-density-structure"].subgroup = "intermediate-silo"
data.raw.item["low-density-structure"].order = "b"

data.raw.item["rocket-fuel"].subgroup = "intermediate-silo"
data.raw.item["rocket-fuel"].order = "c"

data.raw.item["rocket-control-unit"].subgroup = "intermediate-silo"
data.raw.item["rocket-control-unit"].order = "d"

data.raw.item["rocket-part"].subgroup = "intermediate-silo"
data.raw.item["rocket-part"].order = "e"

data.raw.item["satellite"].subgroup = "intermediate-silo"
data.raw.item["satellite"].order = "f"

data.raw.item["rocket-silo"].subgroup = "intermediate-silo"
data.raw.item["rocket-silo"].order = "a"

data.raw.item["copper-cable"].subgroup = "intermediate-wire"
data.raw.item["copper-cable"].order = "a"

else

data:extend(
{
  {
    type = "item-subgroup",
    name = "chip",
    group = "intermediate-products",
    order = "d"
  },
}
)

data.raw.item["electronic-circuit"].subgroup = "chip"
data.raw.item["electronic-circuit"].order = "a"

data.raw.item["advanced-circuit"].subgroup = "chip"
data.raw.item["advanced-circuit"].order = "b"

data.raw.item["processing-unit"].subgroup = "chip"
data.raw.item["processing-unit"].order = "c"

data.raw.item["advanced-processing-unit"].subgroup = "chip"
data.raw.item["advanced-processing-unit"].order = "d"

data.raw.item["computer-chip"].subgroup = "chip"
data.raw.item["computer-chip"].order = "e"

data.raw.item["advanced-computer-chip"].subgroup = "chip"
data.raw.item["advanced-computer-chip"].order = "f"

data.raw.item["computer-processing-chip"].subgroup = "chip"
data.raw.item["computer-processing-chip"].order = "g"

data.raw.item["advanced-computer-processing-chip"].subgroup = "chip"
data.raw.item["advanced-computer-processing-chip"].order = "h"

if data.raw.item["gunpowder"] then
data.raw.item["gunpowder"].subgroup = "intermediate-product"
data.raw.item["gunpowder"].order = "c"
end

data.raw.item["charcoal"].subgroup = "intermediate-product"
data.raw.item["charcoal"].order = "c"
data.raw.item["steel-gear-wheel"].subgroup = "intermediate-product"
data.raw.item["steel-gear-wheel"].order = "c"

data.raw.item["steel-bearing-ball"].subgroup = "intermediate-product"
data.raw.item["steel-bearing-ball"].order = "c"

data.raw.item["cpu"].subgroup = "intermediate-product"
data.raw.item["cpu"].order = "c"

data.raw.item["insulated-wire"].subgroup = "intermediate-product"
data.raw.item["insulated-wire"].order = "c"

data.raw.item["steel-bearing"].subgroup = "intermediate-product"
data.raw.item["steel-bearing"].order = "c"
end
