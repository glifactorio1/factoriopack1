
if Transport_Item_Group then
data:extend(
{
  {
    type = "item-group",
    name = "transport",
    order = "aa",
    inventory_order = "gd",
    icon = "__andrew-library__/graphics/item-group/transport.png",
  },
  {
    type = "item-subgroup",
    name = "transport-belt",
    group = "transport",
    order = "1"
  },
  {
    type = "item-subgroup",
    name = "transport-ground",
    group = "transport",
    order = "2"
  },
  {
    type = "item-subgroup",
    name = "transport-splitters",
    group = "transport",
    order = "3"
  },
  {
    type = "item-subgroup",
    name = "transport-loader",
    group = "transport",
    order = "4"
  },
  {
    type = "item-subgroup",
    name = "transport-tank",
    group = "transport",
    order = "5"
  },
  {
    type = "item-subgroup",
    name = "transport-pipe",
    group = "transport",
    order = "6"
  },
  {
    type = "item-subgroup",
    name = "transport-pipe-ground",
    group = "transport",
    order = "7"
  },
}
)

-- Transport --

data.raw.item["splitter"].subgroup = "transport-splitters"
data.raw.item["splitter"].order = "a"

data.raw.item["fast-splitter"].subgroup = "transport-splitters"
data.raw.item["fast-splitter"].order = "b"

data.raw.item["express-splitter"].subgroup = "transport-splitters"
data.raw.item["express-splitter"].order = "c"

data.raw.item["transport-belt"].subgroup = "transport-belt"
data.raw.item["transport-belt"].order = "a"

data.raw.item["fast-transport-belt"].subgroup = "transport-belt"
data.raw.item["fast-transport-belt"].order = "b"

data.raw.item["express-transport-belt"].subgroup = "transport-belt"
data.raw.item["express-transport-belt"].order = "c"

data.raw.item["underground-belt"].subgroup = "transport-ground"
data.raw.item["underground-belt"].order = "a"

data.raw.item["fast-underground-belt"].subgroup = "transport-ground"
data.raw.item["fast-underground-belt"].order = "b"

data.raw.item["express-underground-belt"].subgroup = "transport-ground"
data.raw.item["express-underground-belt"].order = "c"

data.raw.item["pipe"].subgroup = "transport-pipe"
data.raw.item["pipe"].order = "a"

data.raw.item["pipe-to-ground"].subgroup = "transport-pipe-ground"
data.raw.item["pipe-to-ground"].order = "a"

data.raw.item["loader"].subgroup = "transport-loader"
data.raw.item["loader"].order = "a"

data.raw.item["fast-loader"].subgroup = "transport-loader"
data.raw.item["fast-loader"].order = "b"

data.raw.item["express-loader"].subgroup = "transport-loader"
data.raw.item["express-loader"].order = "c"

else

data:extend(
{
  {
    type = "item-subgroup",
    name = "transport-belt",
    group = "logistics",
    order = "a-1"
  },
  {
    type = "item-subgroup",
    name = "transport-ground",
    group = "logistics",
    order = "a-2"
  },
  {
    type = "item-subgroup",
    name = "transport-splitters",
    group = "logistics",
    order = "a-3"
  },
  {
    type = "item-subgroup",
    name = "transport-loader",
    group = "logistics",
    order = "a-4"
  },
}
)

data.raw.item["splitter"].subgroup = "transport-splitters"
data.raw.item["splitter"].order = "a"

data.raw.item["fast-splitter"].subgroup = "transport-splitters"
data.raw.item["fast-splitter"].order = "b"

data.raw.item["express-splitter"].subgroup = "transport-splitters"
data.raw.item["express-splitter"].order = "c"

data.raw.item["transport-belt"].subgroup = "transport-belt"
data.raw.item["transport-belt"].order = "a"

data.raw.item["fast-transport-belt"].subgroup = "transport-belt"
data.raw.item["fast-transport-belt"].order = "b"

data.raw.item["express-transport-belt"].subgroup = "transport-belt"
data.raw.item["express-transport-belt"].order = "c"

data.raw.item["underground-belt"].subgroup = "transport-ground"
data.raw.item["underground-belt"].order = "a"

data.raw.item["fast-underground-belt"].subgroup = "transport-ground"
data.raw.item["fast-underground-belt"].order = "b"

data.raw.item["express-underground-belt"].subgroup = "transport-ground"
data.raw.item["express-underground-belt"].order = "c"

data.raw.item["loader"].subgroup = "transport-loader"
data.raw.item["loader"].order = "a"

data.raw.item["fast-loader"].subgroup = "transport-loader"
data.raw.item["fast-loader"].order = "b"

data.raw.item["express-loader"].subgroup = "transport-loader"
data.raw.item["express-loader"].order = "c"

if data.raw.item["ultra-transport-belt"] then

data.raw.item["ultra-splitter"].subgroup = "transport-splitters"
data.raw.item["ultra-splitter"].order = "d"

data.raw.item["ultra-transport-belt"].subgroup = "transport-belt"
data.raw.item["ultra-transport-belt"].order = "d"

data.raw.item["ultra-underground-belt"].subgroup = "transport-ground"
data.raw.item["ultra-underground-belt"].order = "d"

data.raw.item["ultra-loader"].subgroup = "transport-loader"
data.raw.item["ultra-loader"].order = "d"
end

if data.raw.item["super-transport-belt"] then

data.raw.item["super-splitter"].subgroup = "transport-splitters"
data.raw.item["super-splitter"].order = "e"

data.raw.item["super-transport-belt"].subgroup = "transport-belt"
data.raw.item["super-transport-belt"].order = "e"

data.raw.item["super-underground-belt"].subgroup = "transport-ground"
data.raw.item["super-underground-belt"].order = "e"

data.raw.item["super-loader"].subgroup = "transport-loader"
data.raw.item["super-loader"].order = "e"
end

if data.raw.item["hyper-transport-belt"] then

data.raw.item["hyper-splitter"].subgroup = "transport-splitters"
data.raw.item["hyper-splitter"].order = "f"

data.raw.item["hyper-transport-belt"].subgroup = "transport-belt"
data.raw.item["hyper-transport-belt"].order = "f"

data.raw.item["hyper-underground-belt"].subgroup = "transport-ground"
data.raw.item["hyper-underground-belt"].order = "f"

data.raw.item["hyper-loader"].subgroup = "transport-loader"
data.raw.item["hyper-loader"].order = "f"
end

if data.raw.item["copper-pipe"] then

data.raw.item["copper-pipe"].subgroup = "energy-pipe-distribution"
data.raw.item["copper-pipe"].order = "z"

data.raw.item["copper-pipe-to-ground"].subgroup = "energy-pipe-distribution"
data.raw.item["copper-pipe-to-ground"].order = "z"

data.raw.item["plastic-pipe"].subgroup = "energy-pipe-distribution"
data.raw.item["plastic-pipe"].order = "z"

data.raw.item["plastic-pipe-to-ground"].subgroup = "energy-pipe-distribution"
data.raw.item["plastic-pipe-to-ground"].order = "z"

data.raw.item["steel-pipe"].subgroup = "energy-pipe-distribution"
data.raw.item["steel-pipe"].order = "z"

data.raw.item["steel-pipe-to-ground"].subgroup = "energy-pipe-distribution"
data.raw.item["steel-pipe-to-ground"].order = "z"

data.raw.item["stone-pipe"].subgroup = "energy-pipe-distribution"
data.raw.item["stone-pipe"].order = "z"

data.raw.item["stone-pipe-to-ground"].subgroup = "energy-pipe-distribution"
data.raw.item["stone-pipe-to-ground"].order = "c"

end

if data.raw.item["clay-brick"] then
data.raw.item["clay-pipe"].subgroup = "energy-pipe-distribution"
data.raw.item["clay-pipe"].order = "z"

data.raw.item["clay-pipe-to-ground"].subgroup = "energy-pipe-distribution"
data.raw.item["clay-pipe-to-ground"].order = "z"
end
end

