
if Liquids_Item_Group then
data:extend(
{
  {
    type = "item-group",
    name = "liquid",
    order = "gac",
    inventory_order = "gaa",
    icon = "__andrew-library__/graphics/item-group/liquids.png",
  },
  {
    type = "item-subgroup",
    name = "liquid-recipe",
    group = "liquid",
    order = "aa"
  },
  {
    type = "item-subgroup",
    name = "liquid-processing",
    group = "liquid",
    order = "ab"
  },
  {
    type = "item-subgroup",
    name = "liquid-fill",
    group = "liquid",
    order = "ba"
  },
  {
    type = "item-subgroup",
    name = "liquid-empty",
    group = "liquid",
    order = "bb"
  },
  {
    type = "item-subgroup",
    name = "liquid-barrels",
    group = "liquid",
    order = "bc"
  },
  {
    type = "item-subgroup",
    name = "liquid-store",
    group = "liquid",
    order = "c"
  },
  {
    type = "item-subgroup",
    name = "liquid-pumpjack",
    group = "liquid",
    order = "d-a"
  },
  {
    type = "item-subgroup",
    name = "liquid-n-pumpjack",
    group = "liquid",
    order = "d-b"
  },
  {
    type = "item-subgroup",
    name = "liquid-refinery",
    group = "liquid",
    order = "e"
  },
  {
    type = "item-subgroup",
    name = "liquid-plant",
    group = "liquid",
    order = "f"
  },
}
)

-- liquid --
data.raw.item["chemical-plant"].subgroup = "liquid-plant"
data.raw.item["chemical-plant"].order = "a"

data.raw.item["oil-refinery"].subgroup = "liquid-refinery"
data.raw.item["oil-refinery"].order = "a"

data.raw.item["pumpjack"].subgroup = "liquid-pumpjack"
data.raw.item["pumpjack"].order = "a"

data.raw.item["storage-tank"].subgroup = "liquid-store"
data.raw.item["storage-tank"].order = "a"

data.raw.recipe["sulfuric-acid"].subgroup = "liquid-recipe"

data.raw.recipe["basic-oil-processing"].subgroup = "liquid-processing"

data.raw.recipe["advanced-oil-processing"].subgroup = "liquid-processing"

data.raw.recipe["heavy-oil-cracking"].subgroup = "liquid-recipe"

data.raw.recipe["light-oil-cracking"].subgroup = "liquid-recipe"

data.raw.recipe["sulfuric-acid"].subgroup = "liquid-recipe"

data.raw.recipe["solid-fuel-from-light-oil"].subgroup = "liquid-recipe"

data.raw.recipe["solid-fuel-from-petroleum-gas"].subgroup = "liquid-recipe"

data.raw.recipe["solid-fuel-from-heavy-oil"].subgroup = "liquid-recipe"

data.raw.recipe["lubricant"].subgroup = "liquid-recipe"

data.raw.recipe["fill-crude-oil-barrel"].subgroup = "liquid-fill"
data.raw.recipe["fill-crude-oil-barrel"].order = "a"

data.raw.recipe["empty-crude-oil-barrel"].subgroup = "liquid-empty"
data.raw.recipe["empty-crude-oil-barrel"].order = "a"

data.raw.item["crude-oil-barrel"].subgroup = "liquid-barrels"
data.raw.item["crude-oil-barrel"].order = "a"

else

data:extend(
{
  {
    type = "item-subgroup",
    name = "liquid-plant",
    group = "production",
    order = "f"
  },
}
)

data.raw.item["chemical-plant"].subgroup = "liquid-plant"
data.raw.item["chemical-plant"].order = "b-a"

data.raw.item["oil-refinery"].subgroup = "liquid-plant"
data.raw.item["oil-refinery"].order = "a"

if data.raw.item["chemical-plant-2"] then

data.raw.item["chemical-plant-2"].subgroup = "liquid-plant"
data.raw.item["chemical-plant-2"].order = "b-b"

end

if data.raw.item["chemical-plant-3"] then

data.raw.item["chemical-plant-3"].subgroup = "liquid-plant"
data.raw.item["chemical-plant-3"].order = "b-c"

end

if data.raw.item["chemical-plant-4"] then

data.raw.item["chemical-plant-4"].subgroup = "liquid-plant"
data.raw.item["chemical-plant-4"].order = "b-d"

end

data.raw.recipe["empty-crude-oil-barrel"].subgroup = "barrel"
data.raw.recipe["empty-crude-oil-barrel"].order = "a-a"

data.raw.recipe["fill-crude-oil-barrel"].subgroup = "barrel"
data.raw.recipe["fill-crude-oil-barrel"].order = "b-a"

data.raw.item["crude-oil-barrel"].subgroup = "barrel"
data.raw.item["crude-oil-barrel"].order = "c-a"

if data.raw.recipe["empty-heavy-oil-barrel"] then

data.raw.recipe["empty-heavy-oil-barrel"].subgroup = "barrel"
data.raw.recipe["empty-heavy-oil-barrel"].order = "a-b"

data.raw.recipe["fill-heavy-oil-barrel"].subgroup = "barrel"
data.raw.recipe["fill-heavy-oil-barrel"].order = "b-b"

data.raw.item["heavy-oil-barrel"].subgroup = "barrel"
data.raw.item["heavy-oil-barrel"].order = "c-b"

end

if data.raw.recipe["empty-light-oil-barrel"] then

data.raw.recipe["empty-light-oil-barrel"].subgroup = "barrel"
data.raw.recipe["empty-light-oil-barrel"].order = "a-c"

data.raw.recipe["fill-light-oil-barrel"].subgroup = "barrel"
data.raw.recipe["fill-light-oil-barrel"].order = "b-c"

data.raw.item["light-oil-barrel"].subgroup = "barrel"
data.raw.item["light-oil-barrel"].order = "c-c"

end

if data.raw.recipe["empty-lubricant-barrel"] then

data.raw.recipe["empty-lubricant-barrel"].subgroup = "barrel"
data.raw.recipe["empty-lubricant-barrel"].order = "a-d"

data.raw.recipe["fill-lubricant-barrel"].subgroup = "barrel"
data.raw.recipe["fill-lubricant-barrel"].order = "b-d"

data.raw.item["lubricant-barrel"].subgroup = "barrel"
data.raw.item["lubricant-barrel"].order = "c-d"

end

if data.raw.recipe["empty-petroleum-gas-barrel"] then

data.raw.recipe["empty-petroleum-gas-barrel"].subgroup = "barrel"
data.raw.recipe["empty-petroleum-gas-barrel"].order = "a-e"

data.raw.recipe["fill-petroleum-gas-barrel"].subgroup = "barrel"
data.raw.recipe["fill-petroleum-gas-barrel"].order = "b-e"

data.raw.item["petroleum-gas-barrel"].subgroup = "barrel"
data.raw.item["petroleum-gas-barrel"].order = "c-e"

end

if data.raw.recipe["empty-sulfuric-acid-barrel"] then

data.raw.recipe["empty-sulfuric-acid-barrel"].subgroup = "barrel"
data.raw.recipe["empty-sulfuric-acid-barrel"].order = "a-f"

data.raw.recipe["fill-sulfuric-acid-barrel"].subgroup = "barrel"
data.raw.recipe["fill-sulfuric-acid-barrel"].order = "b-f"

data.raw.item["sulfuric-acid-barrel"].subgroup = "barrel"
data.raw.item["sulfuric-acid-barrel"].order = "c-f"

end

if data.raw.recipe["empty-water-barrel"] then

data.raw.recipe["empty-water-barrel"].subgroup = "barrel"
data.raw.recipe["empty-water-barrel"].order = "a-g"

data.raw.recipe["fill-water-barrel"].subgroup = "barrel"
data.raw.recipe["fill-water-barrel"].order = "b-g"

data.raw.item["water-barrel"].subgroup = "barrel"
data.raw.item["water-barrel"].order = "c-g"

end

if data.raw.fluid["advanced-lubricant"] then

data.raw.fluid["advanced-lubricant"].subgroup = "fluid-recipes"
data.raw.fluid["advanced-lubricant"].order = "z"

data.raw.recipe["empty-advanced-lubricant-barrel"].subgroup = "barrel"
data.raw.recipe["empty-advanced-lubricant-barrel"].order = "a-h"

data.raw.recipe["fill-advanced-lubricant-barrel"].subgroup = "barrel"
data.raw.recipe["fill-advanced-lubricant-barrel"].order = "b-h"

data.raw.item["advanced-lubricant-barrel"].subgroup = "barrel"
data.raw.item["advanced-lubricant-barrel"].order = "c-h"

end
end
