
data:extend(
{
  {
    type = "custom-input",
    name = "copy-loader-entity-settings",
    key_sequence = "SHIFT + mouse-button-2"
  },
  {
    type = "custom-input",
    name = "paste-loader-entity-settings",
    key_sequence = "SHIFT + mouse-button-1"
  },
}
)
