
script.on_event("copy-loader-entity-settings", function(event)	
  if global.F==nil then global.F={} end
  local E_P = event.player_index
  local G_P = game.players[E_P].selected
  if G_P and G_P.filter_slot_count>0 then global.F[E_P]=Filter_Loader(G_P) end
script.on_event("paste-loader-entity-settings", function(event)	
  if global.F==nil then global.F={} end
  local E_P = event.player_index
  local G_P = game.players[E_P].selected
  if G_P and G_P.filter_slot_count>0 then
	if global.F[E_P] then
	  for Z=1, G_P.filter_slot_count do G_P.set_filter(Z,global.F[E_P][Z]) end
	else
	  for Z=1, G_P.filter_slot_count do G_P.set_filter(Z,nil) end
	end
  end
end)
end)

function Filter_Loader(E_C_E)
	local F={}
	for Y=1, E_C_E.filter_slot_count do
		if E_C_E.get_filter(Y) then
			table.insert(F,Y,E_C_E.get_filter(Y))
		end
	end
	if #F==0 then F=false end
	return F	
end
