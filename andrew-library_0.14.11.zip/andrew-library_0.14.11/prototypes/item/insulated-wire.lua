-- insulated-wire --
data:extend(
{
  {
    type = "item",
    name = "insulated-wire",
    icon = "__andrew-library__/graphics/icons/insulated-wire.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-wire",
    order = "b[insulated-wire]",
    stack_size = 200
  },
}
)