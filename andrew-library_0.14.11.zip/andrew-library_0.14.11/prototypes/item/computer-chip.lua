-- computer-chip --
data:extend(
{
  {
    type = "item",
    name = "computer-chip",
    icon = "__andrew-library__/graphics/icons/computer-chip.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-chip",
    order = "e[computer-chip]",
    stack_size = 200
  },
}
)