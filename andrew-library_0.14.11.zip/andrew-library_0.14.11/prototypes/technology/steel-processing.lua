
Add_Recipe_To_Tech("steel-processing", "steel-gear-wheel")
Add_Recipe_To_Tech("steel-processing", "steel-bearing-ball")
Add_Recipe_To_Tech("steel-processing", "steel-bearing")