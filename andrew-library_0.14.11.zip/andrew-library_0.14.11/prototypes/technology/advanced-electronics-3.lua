-- advanced-electronics-3 --
data:extend(
{  
  {
    type = "technology",
    name = "advanced-electronics-3",
    icon = "__andrew-library__/graphics/technology/advanced-electronics-3.png",
    upgrade = true,
	icon_size = 128,
    order = "g-c-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "insulated-wire"
      },
      {
        type = "unlock-recipe",
        recipe = "advanced-processing-unit"
      },
      {
        type = "unlock-recipe",
        recipe = "computer-chip"
      },
    },
    prerequisites =
    {
      "advanced-electronics-2",
    },
    unit =
    {
      count = 100,
	  time = 30,
      ingredients = science4()
    },
  },
}
)