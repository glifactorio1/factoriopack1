
Add_Recipe_To_Tech("effect-transmission", "mini-beacon")