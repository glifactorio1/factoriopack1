-- advanced-electronics-4 --
data:extend(
{  
  {
    type = "technology",
    name = "advanced-electronics-4",
    icon = "__andrew-library__/graphics/technology/advanced-electronics-4.png",
    upgrade = true,
	icon_size = 128,
    order = "g-c-e",
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "cpu"
      },
      {
        type = "unlock-recipe",
        recipe = "advanced-computer-chip"
      },
	  {
        type = "unlock-recipe",
        recipe = "computer-processing-chip"
      },
	  {
        type = "unlock-recipe",
        recipe = "advanced-computer-processing-chip"
      },
    },
    prerequisites =
    {
      "advanced-electronics-3",
    },
    unit =
    {
      count = 200,
	  time = 30,
      ingredients = science4()
    },
  },
}
)