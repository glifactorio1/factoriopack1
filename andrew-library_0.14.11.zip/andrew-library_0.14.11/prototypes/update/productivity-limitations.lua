add_productivity_limitation("advanced-processing-unit")
add_productivity_limitation("computer-chip")
add_productivity_limitation("advanced-computer-chip")
add_productivity_limitation("computer-processing-chip")
add_productivity_limitation("advanced-computer-processing-chip")
add_productivity_limitation("insulated-wire")
add_productivity_limitation("cpu")
add_productivity_limitation("steel-gear-wheel")
add_productivity_limitation("steel-bearing-ball")
add_productivity_limitation("steel-bearing")




