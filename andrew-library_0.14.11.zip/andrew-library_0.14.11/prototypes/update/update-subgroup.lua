

if Logistic_Item_Group then
if data.raw["blueprint-book"]["blueprint-book-2"] then
    data.raw["blueprint-book"]["blueprint-book-2"].subgroup = "logistic-plan"
end
end

if Mining_Item_Group then
if data.raw.item["small-factory"] then
	data.raw.item["small-factory"].subgroup = "assembling-machine"
	data.raw.item["small-factory"].order = "y"
end

if data.raw.item["small-power-plant"] then
	data.raw.item["small-power-plant"].subgroup = "assembling-machine"
	data.raw.item["small-power-plant"].order = "z"
end
end

if Trains_Item_Group then
if data.raw.item["rail-tanker"] then
	data.raw.item["rail-tanker"].subgroup = "trains-cargo"
	data.raw.item["rail-tanker"].order = "z"
end

if data.raw.item["farl"] then
	data.raw.item["farl"].subgroup = "trains-locomotive"
	data.raw.item["farl"].order = "z"
end
end

if Mining_Item_Group then
if data.raw.item["resource-monitor"] then
	data.raw.item["resource-monitor"].subgroup = "repair"
	data.raw.item["resource-monitor"].order = "z"
end
end
