-- advanced-computer-processing-chip --
data:extend(
{
  {
    type = "recipe",
    name = "advanced-computer-processing-chip",
    category = "crafting-with-fluid",
    enabled = false,
    energy_required = 90,
    result = "advanced-computer-processing-chip",
	result_count = 1,	
    ingredients = 
	{
	  {"computer-processing-chip",2},
	  {"advanced-computer-chip",10},
	  {"cpu",1},
	},
  },
}
)