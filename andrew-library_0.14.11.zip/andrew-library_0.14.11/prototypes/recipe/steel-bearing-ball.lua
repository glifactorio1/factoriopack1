-- steel-bearing-ball --
data:extend(
{
  {
    type = "recipe",
    name = "steel-bearing-ball",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "steel-bearing-ball",
    result_count = 12,	
    ingredients =
    {
      {"steel-plate", 1},
    },
  },
}
)