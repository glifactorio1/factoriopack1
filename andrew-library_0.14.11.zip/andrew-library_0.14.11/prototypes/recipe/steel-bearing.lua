-- steel-bearing --
data:extend(
{
  {
    type = "recipe",
    name = "steel-bearing",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "steel-bearing",
    result_count = 2,	
    ingredients =
    {
      {"steel-plate", 1},
      {"steel-bearing-ball", 16},
    },
  },
}
)