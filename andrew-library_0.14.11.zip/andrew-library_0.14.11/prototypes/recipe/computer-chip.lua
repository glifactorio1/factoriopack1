-- computer-chip --
data:extend(
{
  {
    type = "recipe",
    name = "computer-chip",
    category = "crafting-with-fluid",
    enabled = false,
    energy_required = 30,
    result = "computer-chip",
	result_count = 1,
    ingredients =
    {
      {"processing-unit", 10},
      {"advanced-processing-unit", 2},
	  {"insulated-wire", 3},
    },
  },
}
)
