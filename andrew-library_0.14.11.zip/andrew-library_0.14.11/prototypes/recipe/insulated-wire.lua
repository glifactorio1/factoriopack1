-- insulated-wire --
data:extend(
{
  {
    type = "recipe",
    name = "insulated-wire",
    category = "crafting",
    enabled = false,
    energy_required = 0.5,
    result = "insulated-wire",
    result_count = 5,	
    ingredients =
    {
	  {"plastic-bar", 5},
      {"copper-cable", 15},
    },
  },
}
)