-- advanced-computer-chip --
data:extend(
{
  {
    type = "recipe",
    name = "advanced-computer-chip",
    category = "crafting-with-fluid",
    enabled = false,
    energy_required = 60,
    result = "advanced-computer-chip",
	result_count = 1,	
    ingredients = 
	{
	  {"advanced-processing-unit",10},
	  {"computer-chip",2},
	  {"insulated-wire", 3},
	},
  },
}
)

















