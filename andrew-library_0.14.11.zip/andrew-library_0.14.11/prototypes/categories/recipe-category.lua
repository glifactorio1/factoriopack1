data:extend(
{
  {
    type = "recipe-category",
    name = "crafting-machine"
  },
  {
    type = "recipe-category",
    name = "electronics"
  },
  {
    type = "recipe-category",
    name = "electronics-machine"
  },
  {
    type = "recipe-category",
    name = "advanced-oil-processing"
  },
  {
    type = "recipe-category",
    name = "crusher"
  },
}
)