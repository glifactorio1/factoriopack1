
function pipe_to_ground(Tint)
return 
  {
    up =
    {
      filename = "__andrew-logistics__/graphics/entity/pipe/pipe-to-ground-up.png",
      priority = "high",
      width = 44,
      height = 32,
      tint = Tint,
    },
    down =
    {
      filename = "__andrew-logistics__/graphics/entity/pipe/pipe-to-ground-down.png",
      priority = "high",
      width = 40,
      height = 32,
      tint = Tint,
    },
    left =
    {
      filename = "__andrew-logistics__/graphics/entity/pipe/pipe-to-ground-left.png",
      priority = "high",
      width = 32,
      height = 42,
      tint = Tint,
    },
    right =
    {
      filename = "__andrew-logistics__/graphics/entity/pipe/pipe-to-ground-right.png",
      priority = "high",
      width = 32,
      height = 40,
      tint = Tint,
    },
  }
end