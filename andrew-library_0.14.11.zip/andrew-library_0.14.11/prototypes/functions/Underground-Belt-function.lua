
local Mod_Name_G1 = "__andrew-logistics__/graphics"

function Underground_Belt(name)
return 
  {
    direction_in =
    {
      sheet =
      {
        filename = Mod_Name_G1.."/entity/underground-belt/"..name.."-underground-belt/"..name.."-underground-belt-structure.png",
        priority = "extra-high",
        shift = {0.26, 0},
        width = 57,
        height = 43,
        y = 43
      }
    },
    direction_out =
    {
      sheet =
      {
        filename = Mod_Name_G1.."/entity/underground-belt/"..name.."-underground-belt/"..name.."-underground-belt-structure.png",
        priority = "extra-high",
        shift = {0.26, 0},
        width = 57,
        height = 43
      }
    }
  }
end
