
function Add_Recipe_To_Tech(technology_Name, Recipe_Name)
	table.insert(data.raw["technology"][technology_Name].effects,
	{type = "unlock-recipe",recipe = Recipe_Name})
end

function science1()
return 
  {
    {"science-pack-1",1},
  }
end

function science2()
return 
  {
    {"science-pack-1",1},
    {"science-pack-2",1},
  }
end

function science3()
return 
  {
    {"science-pack-1",1},
    {"science-pack-2",1},
    {"science-pack-3",1},
  }
end

function science4()
return 
  {
    {"science-pack-1",1},
    {"science-pack-2",1},
    {"science-pack-3",1},
    {"alien-science-pack",1},
  }
end
