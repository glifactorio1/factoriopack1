
local Mod_Name_G = "__andrew-library__/graphics"
local Mod_Name_G1 = "__andrew-logistics__/graphics"

function Loader_Base(name)
return
{
  direction_in =
  {
    sheet =
    {
      filename = Mod_Name_G.."/entity/"..name.."-structure.png",
      priority = "extra-high",
      width = 64,
      height = 64,
    },
  },
  direction_out =
  {
    sheet =
    {
      filename = Mod_Name_G.."/entity/"..name.."-structure.png",
      priority = "extra-high",
      width = 64,
      height = 64,
      y = 64,
    },
  },
}
end

function loader(name)
return 
{
  direction_in =
  {
    sheet =
    {
      filename = Mod_Name_G1.."/entity/loader/"..name.."-loader-structure.png",
      priority = "extra-high",
      width = 64,
      height = 64,
    },
  },
  direction_out =
  {
    sheet =
    {
      filename = Mod_Name_G1.."/entity/loader/"..name.."-loader-structure.png",
      priority = "extra-high",
      width = 64,
      height = 64,
      y = 64,
    },
  },
}
end