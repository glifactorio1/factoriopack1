
local Mod_Name_G1 = "__andrew-logistics__/graphics"

function splitter(name)
return 
  {
    north =
    {
      filename = Mod_Name_G1.."/entity/splitter/"..name.."-splitter/"..name.."-splitter-north.png",
      frame_count = 32,
      line_length = 16,
      priority = "extra-high",
      width = 80,
      height = 35,
      shift = {0.225, 0}
    },
    east =
    {
      filename = Mod_Name_G1.."/entity/splitter/"..name.."-splitter/"..name.."-splitter-east.png",
      frame_count = 32,
      line_length = 16,
      priority = "extra-high",
      width = 46,
      height = 81,
      shift = {0.075, 0}
    },
    south =
    {
      filename = Mod_Name_G1.."/entity/splitter/"..name.."-splitter/"..name.."-splitter-south.png",
      frame_count = 32,
      line_length = 16,
      priority = "extra-high",
      width = 82,
      height = 36,
      shift = {0.075, 0}
    },
    west =
    {
      filename = Mod_Name_G1.."/entity/splitter/"..name.."-splitter/"..name.."-splitter-west.png",
      frame_count = 32,
      line_length = 16,
      priority = "extra-high",
      width = 47,
      height = 79,
      shift = {0.25, 0.05}
    },
  }
end


