
-- productivity-module-4 --
data:extend(
{
  {
    type = "module",
    name = "productivity-module-4",
    icon = "__andrew-modules__/graphics/modules/productivity-module-4.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "productivity-module",
    category = "productivity",
    tier = 4,
    order = "m-p-4",
    stack_size = 50,
    default_request_amount = 10,
    effect = 
	 {
	   productivity = {bonus = 0.14},
	   consumption = {bonus = 1.0},
	   pollution = {bonus = 0.6},
	   speed = {bonus = -0.20},
	 },
    limitation = productivitymodulelimitation(),
    limitation_message_key = "production-module-usable-only-on-intermediates"
  },
}
)

-- productivity-module-5 --
data:extend(
{
   {
    type = "module",
    name = "productivity-module-5",
    icon = "__andrew-modules__/graphics/modules/productivity-module-5.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "productivity-module",
    category = "productivity",
    tier = 5,
    order = "m-p-5",
    stack_size = 50,
    default_request_amount = 10,
    effect =
	 {
       productivity = {bonus = 0.16},
	   consumption = {bonus = 1.2},
	   pollution = {bonus = 0.7},
	   speed = {bonus = -0.25}
	 },
    limitation = productivitymodulelimitation(),
    limitation_message_key = "production-module-usable-only-on-intermediates"
  },
}
)
data:extend(
{
  {
    type = "module",
    name = "productivity-module-6",
    icon = "__andrew-modules__/graphics/modules/productivity-module-6.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "productivity-module",
    category = "productivity",
    tier = 6,
    order = "m-p-6",
    stack_size = 50,
    default_request_amount = 10,
    effect =
	 {
	   productivity = {bonus = 0.18},
	   consumption = {bonus = 1.4},
	   pollution = {bonus = 0.8},
	   speed = {bonus = -0.30}
	 },
    limitation = productivitymodulelimitation(),
    limitation_message_key = "production-module-usable-only-on-intermediates"
  },
}
)
data:extend(
{
  {
    type = "module",
    name = "productivity-module-7",
    icon = "__andrew-modules__/graphics/modules/productivity-module-7.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "productivity-module",
    category = "productivity",
    tier = 7,
    order = "m-p-7",
    stack_size = 50,
    default_request_amount = 10,
    effect =
	 {
	   productivity = {bonus = 0.20},
	   consumption = {bonus = 1.6},
	   pollution = {bonus = 0.9},
	   speed = {bonus = -0.35}
	 },
    limitation = productivitymodulelimitation(),
    limitation_message_key = "production-module-usable-only-on-intermediates"
  },
}
)
data:extend(
{
  {
    type = "module",
    name = "productivity-module-8",
    icon = "__andrew-modules__/graphics/modules/productivity-module-8.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "productivity-module",
    category = "productivity",
    tier = 8,
    order = "m-p-8",
    stack_size = 50,
    default_request_amount = 10,
    effect =
	 {
	   productivity = {bonus = 0.24},
	   consumption = {bonus = 2.0},
	   pollution = {bonus = 1.0},
	   speed = {bonus = -0.40}
	 },
    limitation = productivitymodulelimitation(),
    limitation_message_key = "production-module-usable-only-on-intermediates"
  },
}
)
