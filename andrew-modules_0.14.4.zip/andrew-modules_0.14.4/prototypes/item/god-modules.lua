
--god-module-1--
data:extend(
{
  {
    type = "module",
    name = "god-module-1",
    icon = "__andrew-modules__/graphics/modules/god-module-1.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "god-module",
    category = "god",
    tier = 1,
    order = "m-god-1",
    stack_size = 50,
    effect = 
	{
	  consumption = {bonus = 0.40},
	  speed = {bonus = 0.10},
	  productivity = {bonus = 0.05},
	  pollution = {bonus = 0.40},
	},
  },
}
)

-- god-module-2 --
data:extend(
{
  {
    type = "module",
    name = "god-module-2",
    icon = "__andrew-modules__/graphics/modules/god-module-2.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "god-module",
    category = "god",
    tier = 2,
    order = "m-god-2",
    stack_size = 50,
    effect = 
	{
	  consumption = {bonus = 0.50},
	  speed = {bonus = 0.20},
	  productivity = {bonus = 0.10},
	  pollution = {bonus = 0.50}
	},
  },
}
)

-- god-module-3 --
data:extend(
{
   {
    type = "module",
    name = "god-module-3",
    icon = "__andrew-modules__/graphics/modules/god-module-3.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "god-module",
    category = "god",
    tier = 3,
    order = "m-god-3",
    stack_size = 50,
    effect = 
	{
	  consumption = {bonus = 0.60},
	  speed = {bonus = 0.30},
	  productivity = {bonus = 0.15},
	  pollution = {bonus = 0.60}
	},
  },
}
)

-- god-module-4 --
data:extend(
{
   {
    type = "module",
    name = "god-module-4",
    icon = "__andrew-modules__/graphics/modules/god-module-4.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "god-module",
    category = "god",
    tier = 4,
    order = "m-god-4",
    stack_size = 50,
    effect =  
	{
	  consumption = {bonus = 0.70},
	  speed = {bonus = 0.40},
	  productivity = {bonus = 0.20},
	  pollution = {bonus = 0.70}
	},
  },
}
)

-- god-module-5 --
data:extend(
{
   {
    type = "module",
    name = "god-module-5",
    icon = "__andrew-modules__/graphics/modules/god-module-5.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "god-module",
    category = "god",
    tier = 5,
    order = "m-god-5",
    stack_size = 50,
    effect =  
	{
	  consumption = {bonus = 0.80},
	  speed = {bonus = 0.50},
	  productivity = {bonus = 0.25},
	  pollution = {bonus = 0.80}
	},
  },
 }
)

-- god-module-6 --
data:extend(
{
  {
    type = "module",
    name = "god-module-6",
    icon = "__andrew-modules__/graphics/modules/god-module-6.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "god-module",
    category = "god",
    tier = 6,
    order = "m-god-6",
    stack_size = 50,
    effect =  
	{
	  consumption = {bonus = 0.90},
	  speed = {bonus = 0.60},
	  productivity = {bonus = 0.30},
	  pollution = {bonus = 0.90}
	},
  },
 }
)

-- god-module-7 --
data:extend(
{
  {
    type = "module",
    name = "god-module-7",
    icon = "__andrew-modules__/graphics/modules/god-module-7.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "god-module",
    category = "god",
    tier = 7,
    order = "m-god-7",
    stack_size = 50,
    effect = 
	{
	  consumption = {bonus = 1.00},
	  speed = {bonus = 0.70},
	  productivity = {bonus = 0.35},
	  pollution = {bonus = 1.00}
	},
  },
}
)

-- god-module-8 --
data:extend(
{
   {
    type = "module",
    name = "god-module-8",
    icon = "__andrew-modules__/graphics/modules/god-module-8.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "god-module",
    category = "god",
    tier = 8,
    order = "m-god-8",
    stack_size = 50,
    effect =
	{
	  consumption = {bonus = 1.10},
	  speed = {bonus = 0.80},
	  productivity = {bonus = 0.40},
	  pollution = {bonus = 1.10}
	},
  },
}
)
