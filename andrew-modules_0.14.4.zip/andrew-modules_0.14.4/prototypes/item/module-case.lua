
-- module-case --
data:extend(
{
  {
    type = "item",
    name = "module-case",
    icon = "__andrew-modules__/graphics/modules/module-case.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "module-case",
    order = "a[gold-processing-unit]",
    stack_size = 200
  },
}
)

-- advanced-module-case --
data:extend(
{
  {
    type = "item",
    name = "advanced-module-case",
    icon = "__andrew-modules__/graphics/modules/advanced-module-case.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "module-case",
    order = "b",
    stack_size = 200
  },
}
)