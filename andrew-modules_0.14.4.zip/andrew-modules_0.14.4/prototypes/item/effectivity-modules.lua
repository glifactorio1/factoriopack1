
-- effectivity-module-4 --
data:extend(
{
  {
    type = "module",
    name = "effectivity-module-4",
    icon = "__andrew-modules__/graphics/modules/effectivity-module-4.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "effectivity-module",
    category = "effectivity",
    tier = 4,
    order = "m-e-4",
    stack_size = 50,
    effect = 
	{ 
	  consumption = {bonus = -0.6}
	},
  },
}
)

-- effectivity-module-5 --
data:extend(
{
  {
    type = "module",
    name = "effectivity-module-5",
    icon = "__andrew-modules__/graphics/modules/effectivity-module-5.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "effectivity-module",
    category = "effectivity",
    tier = 5,
    order = "m-e-5",
    stack_size = 50,
    effect = 
	{ 
	  consumption = {bonus = -0.8}
	},
  },
}
)

-- effectivity-module-6 --
data:extend(
{
   {
    type = "module",
    name = "effectivity-module-6",
    icon = "__andrew-modules__/graphics/modules/effectivity-module-6.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "effectivity-module",
    category = "effectivity",
    tier = 6,
    order = "m-e-6",
    stack_size = 50,
    effect = 
	{ 
	  consumption = {bonus = -1.0}
	},
  },
}
)

-- effectivity-module-7 --
data:extend(
{
   {
    type = "module",
    name = "effectivity-module-7",
    icon = "__andrew-modules__/graphics/modules/effectivity-module-7.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "effectivity-module",
    category = "effectivity",
    tier = 7,
    order = "m-e-7",
    stack_size = 50,
    effect = 
	{ 
	  consumption = {bonus = -1.5}
	},
  },
 }
)

-- effectivity-module-8 --
data:extend(
{
  {
    type = "module",
    name = "effectivity-module-8",
    icon = "__andrew-modules__/graphics/modules/effectivity-module-8.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "effectivity-module",
    category = "effectivity",
    tier = 8,
    order = "m-e-8",
    stack_size = 50,
    effect = 
	{ 
	  consumption = {bonus = -2.0}
	},
  },
}
)





