
-- pollution-clean-module-1 --
data:extend(
{
  {
    type = "module",
    name = "pollution-clean-module-1",
    icon = "__andrew-modules__/graphics/modules/pollution-clean-module-1.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "pollution-clean-module",
    category = "pollution-clean",
    tier = 1,
    order = "m-p-cl-1",
    stack_size = 50,
    effect = 
	{
	  pollution = {bonus = -0.2}
	},
  },
}
)

-- pollution-clean-module-2 --
data:extend(
{
   {
    type = "module",
    name = "pollution-clean-module-2",
    icon = "__andrew-modules__/graphics/modules/pollution-clean-module-2.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "pollution-clean-module",
    category = "pollution-clean",
    tier = 2,
    order = "m-p-cl-2",
    stack_size = 50,
    effect = 
	{
	  pollution = {bonus = -0.3}
	},
  },
}
)

-- pollution-clean-module-3 --
data:extend(
{
   {
    type = "module",
    name = "pollution-clean-module-3",
    icon = "__andrew-modules__/graphics/modules/pollution-clean-module-3.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "pollution-clean-module",
    category = "pollution-clean",
    tier = 3,
    order = "m-p-cl-3",
    stack_size = 50,
    effect = 
	{
	  pollution = {bonus = -0.4}
	},
  },
}
)

-- pollution-clean-module-4 --
data:extend(
{
   {
    type = "module",
    name = "pollution-clean-module-4",
    icon = "__andrew-modules__/graphics/modules/pollution-clean-module-4.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "pollution-clean-module",
    category = "pollution-clean",
    tier = 4,
    order = "m-p-cl-4",
    stack_size = 50,
    effect = 
	{
	  pollution = {bonus = -0.5}
	},
  },
}
)

-- pollution-clean-module-5 --
data:extend(
{
   {
    type = "module",
    name = "pollution-clean-module-5",
    icon = "__andrew-modules__/graphics/modules/pollution-clean-module-5.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "pollution-clean-module",
    category = "pollution-clean",
    tier = 5,
    order = "m-p-cl-5",
    stack_size = 50,
    effect = 
	{
	  pollution = {bonus = -0.6}
	},
  },
}
)

-- pollution-clean-module-6 --
data:extend(
{
   {
    type = "module",
    name = "pollution-clean-module-6",
    icon = "__andrew-modules__/graphics/modules/pollution-clean-module-6.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "pollution-clean-module",
    category = "pollution-clean",
    tier = 6,
    order = "m-p-cl-6",
    stack_size = 50,
    effect = 
	{
	  pollution = {bonus = -0.7}
	},
  },
}
)

-- pollution-clean-module-7 --
data:extend(
{
   {
    type = "module",
    name = "pollution-clean-module-7",
    icon = "__andrew-modules__/graphics/modules/pollution-clean-module-7.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "pollution-clean-module",
    category = "pollution-clean",
    tier = 7,
    order = "m-p-cl-7",
    stack_size = 50,
    effect = 
	{
	  pollution = {bonus = -0.8}
	},
  },
}
)

-- pollution-clean-module-8 --
data:extend(
{
   {
    type = "module",
    name = "pollution-clean-module-8",
    icon = "__andrew-modules__/graphics/modules/pollution-clean-module-8.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "pollution-clean-module",
    category = "pollution-clean",
    tier = 8,
    order = "m-p-cl-8",
    stack_size = 50,
    effect = 
	{
	  pollution = {bonus = -0.9}
	},
  },
}
)
