
-- Speed-Module-4 --
data:extend(
{
  {
    type = "module",
    name = "speed-module-4",
    icon = "__andrew-modules__/graphics/modules/speed-module-4.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "speed-module",
    category = "speed",
    tier = 4,
    order = "m-s-4",
    stack_size = 50,
    effect = { speed = {bonus = 0.6}, consumption = {bonus = 0.9}}
  },
}
)

-- Speed-Module-5 --
data:extend(
{
  {
    type = "module",
    name = "speed-module-5",
    icon = "__andrew-modules__/graphics/modules/speed-module-5.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "speed-module",
    category = "speed",
    tier = 5,
    order = "m-s-5",
    stack_size = 50,
    effect = { speed = {bonus = 0.8}, consumption = {bonus = 1.2}}
  },
}
)

-- Speed-Module-6 --
data:extend(
{
  {
    type = "module",
    name = "speed-module-6",
    icon = "__andrew-modules__/graphics/modules/speed-module-6.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "speed-module",
    category = "speed",
    tier = 6,
    order = "m-s-6",
    stack_size = 50,
    effect = { speed = {bonus = 1.1}, consumption = {bonus = 1.5}}
  },
}
)

-- Speed-Module-7 --
data:extend(
{
  {
    type = "module",
    name = "speed-module-7",
    icon = "__andrew-modules__/graphics/modules/speed-module-7.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "speed-module",
    category = "speed",
    tier = 7,
    order = "m-s-7",
    stack_size = 50,
    effect = { speed = {bonus = 1.5}, consumption = {bonus = 1.8}}
  },
}
)

-- Speed-Module-8 --
data:extend(
{
  {
    type = "module",
    name = "speed-module-8",
    icon = "__andrew-modules__/graphics/modules/speed-module-8.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "speed-module",
    category = "speed",
    tier = 8,
    order = "m-s-8",
    stack_size = 50,
    effect = { speed = {bonus = 2.0}, consumption = {bonus = 2.4}}
  },
}
)
 