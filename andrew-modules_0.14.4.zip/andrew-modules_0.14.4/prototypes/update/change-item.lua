
local D_R_M = data.raw.module
local D_R_I = data.raw.item
local D_R = data.raw
local Mod_Name_G = "__andrew-modules__/graphics"

D_R_M["effectivity-module"].icon = Mod_Name_G.."/modules/effectivity-module.png"
D_R_M["effectivity-module-2"].icon = Mod_Name_G.."/modules/effectivity-module-2.png"
D_R_M["effectivity-module-3"].icon = Mod_Name_G.."/modules/effectivity-module-3.png"

D_R_M["effectivity-module"].effect = {
consumption = {bonus = -0.3}}
   
D_R_M["effectivity-module-2"].effect = {
consumption = {bonus = -0.4}}

D_R_M["effectivity-module-3"].effect = {
consumption = {bonus = -0.5}}

D_R_M["productivity-module"].icon = Mod_Name_G.."/modules/productivity-module.png"
D_R_M["productivity-module-2"].icon = Mod_Name_G.."/modules/productivity-module-2.png"
D_R_M["productivity-module-3"].icon = Mod_Name_G.."/modules/productivity-module-3.png"

D_R_M["productivity-module"].effect = {
consumption = {bonus = 0.4},
productivity = {bonus = 0.04},  
pollution = {bonus = 0.3}, 
speed = {bonus = -0.15}}

D_R_M["productivity-module-2"].effect = {
consumption = {bonus = 0.6},
productivity = {bonus = 0.06},
pollution = {bonus = 0.4},
speed = {bonus = -0.15}}

D_R_M["productivity-module-3"].effect = {
consumption = {bonus = 0.8},
productivity = {bonus = 0.10},
pollution = {bonus = 0.5},
speed = {bonus = -0.15}}

D_R_M["speed-module"].icon = Mod_Name_G.."/modules/speed-module.png"
D_R_M["speed-module-2"].icon = Mod_Name_G.."/modules/speed-module-2.png"
D_R_M["speed-module-3"].icon = Mod_Name_G.."/modules/speed-module-3.png"

D_R_M["speed-module"].effect = {
consumption = {bonus = 0.5},
speed = {bonus = 0.2}}

D_R_M["speed-module-2"].effect = {
consumption = {bonus = 0.6},
speed = {bonus = 0.3}}

D_R_M["speed-module-3"].effect = {
consumption = {bonus = 0.7},
speed = {bonus = 0.5}}


