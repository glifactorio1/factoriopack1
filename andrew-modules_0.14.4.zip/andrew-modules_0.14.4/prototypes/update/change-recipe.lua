
if data.raw.item["aluminium-plate"] then
Change_Recipe("module-case", "steel-plate", "aluminium-plate", 1)
Change_Recipe("advanced-module-case", "steel-plate", "aluminium-plate", 1)
end

Change_Recipe("productivity-module-3", "productivity-module-2", "productivity-module-2", 4)

Add_Item_To_Recipe("effectivity-module", "module-case", 1)
Add_Item_To_Recipe("effectivity-module-2", "module-case", 1)
Add_Item_To_Recipe("effectivity-module-3", "module-case", 1)

data.raw.recipe["effectivity-module"].energy_required = 10
data.raw.recipe["effectivity-module-2"].energy_required = 20
data.raw.recipe["effectivity-module-3"].energy_required = 30

Add_Item_To_Recipe("productivity-module", "module-case", 1)
Add_Item_To_Recipe("productivity-module-2", "module-case", 1)
Add_Item_To_Recipe("productivity-module-3", "module-case", 1)

data.raw.recipe["productivity-module"].energy_required = 10
data.raw.recipe["productivity-module-2"].energy_required = 20
data.raw.recipe["productivity-module-3"].energy_required = 30

Add_Item_To_Recipe("speed-module", "module-case", 1)
Add_Item_To_Recipe("speed-module-2", "module-case", 1)
Add_Item_To_Recipe("speed-module-3", "module-case", 1)

data.raw.recipe["speed-module"].energy_required = 10
data.raw.recipe["speed-module-2"].energy_required = 20
data.raw.recipe["speed-module-3"].energy_required = 30
