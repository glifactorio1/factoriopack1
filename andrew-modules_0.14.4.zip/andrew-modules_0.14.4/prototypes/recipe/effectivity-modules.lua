
-- effectivity-module-4 --
data:extend(
{
  {
    type = "recipe",
    name = "effectivity-module-4",
    enabled = false,
    energy_required = 40,	
    result = "effectivity-module-4",
    result_count = 1,	
    ingredients =
    {
      {"effectivity-module-3", 4},
      {"processing-unit", 5},
      {"advanced-processing-unit", 5},
	  {"module-case", 1},
    },
  },
}
)

-- effectivity-module-5 --
data:extend(
{
  {
    type = "recipe",
    name = "effectivity-module-5",
    enabled = false,
    energy_required = 50,
    result = "effectivity-module-5",
    result_count = 1,	
    ingredients =
    {
      {"effectivity-module-4", 4},
	  {"computer-chip", 5},
      {"advanced-processing-unit", 5},
	  {"module-case", 1},
    },
  },
}
)

-- effectivity-module-6 --
data:extend(
{
   {
    type = "recipe",
    name = "effectivity-module-6",
    enabled = false,
    energy_required = 60,
    result = "effectivity-module-6",
    result_count = 1,
    ingredients =
    {
      {"effectivity-module-5", 4},
	  {"computer-chip", 5},
	  {"advanced-computer-chip", 5},
	  {"module-case", 1},
    },
  },
}
)

-- effectivity-module-7 --
data:extend(
{
   {
    type = "recipe",
    name = "effectivity-module-7",
    enabled = false,
    energy_required = 70,
    result = "effectivity-module-7",	
    result_count = 1,	
    ingredients =
    {
      {"effectivity-module-6", 4},
	  {"advanced-computer-chip", 5},
	  {"computer-processing-chip", 5},
	  {"module-case", 1},
    },
  },
}
)

-- effectivity-module-8 --
data:extend(
{
   {
    type = "recipe",
    name = "effectivity-module-8",
    enabled = false,
    energy_required = 80,
    result = "effectivity-module-8",	
    result_count = 1,
    ingredients =
    {
      {"effectivity-module-7", 4},
	  {"advanced-computer-processing-chip", 5},
	  {"computer-processing-chip", 5},
	  {"advanced-module-case", 1},
    },
  },
}
)