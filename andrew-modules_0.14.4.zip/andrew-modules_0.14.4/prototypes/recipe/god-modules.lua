
-- god-module-1 --
data:extend(
{
  {
    type = "recipe",
    name = "god-module-1",
    enabled = false,
	energy_required = 20,
    result = "god-module-1",
	result_count = 1,
    ingredients =
    {
      {"speed-module", 2},
	  {"effectivity-module", 2},
	  {"productivity-module", 2},
	  {"pollution-clean-module-1", 2},
	  {"module-case", 1},
    },
  },
}
)
  
-- god-module-2 --
data:extend(
{
   {
    type = "recipe",
    name = "god-module-2",
    enabled = false,
    energy_required = 40,
    result = "god-module-2",
    result_count = 1,	
    ingredients =
    {
      {"god-module-1", 1},
      {"speed-module-2", 2},
	  {"effectivity-module-2", 2},
	  {"productivity-module-2", 2},
	  {"pollution-clean-module-2", 2},
	  {"module-case", 1},
    },
  }, 
}
)
  
-- god-module-3 --
data:extend(
{
  {
    type = "recipe",
    name = "god-module-3",	
    enabled = false,
    energy_required = 60,
    result = "god-module-3",
    result_count = 1,
    ingredients =
    {
      {"god-module-2", 1},
	  {"speed-module-3", 2},
	  {"effectivity-module-3", 2},
	  {"productivity-module-3", 2},
	  {"pollution-clean-module-3", 2},
	  {"module-case", 1},
    },
  },
}
)
  
-- god-module-4 --
data:extend(
{
  {
    type = "recipe",
    name = "god-module-4",
    enabled = false,
    energy_required = 80,
    result = "god-module-4",
    result_count = 1,	
    ingredients =
    {
      {"god-module-3", 1},
	  {"speed-module-4", 2},
	  {"effectivity-module-4", 2},
	  {"productivity-module-4", 2},
	  {"pollution-clean-module-4", 2},
	  {"module-case", 1},
    },
  },  
}
)
  
-- god-module-5 --
data:extend(
{
  {
    type = "recipe",
    name = "god-module-5",
    enabled = false,
	energy_required = 100,
    result = "god-module-5",
    result_count = 1,	
    ingredients =
    {
      {"god-module-4", 1},
	  {"speed-module-5", 2},
	  {"effectivity-module-5", 2},
	  {"productivity-module-5", 2},
	  {"pollution-clean-module-5", 2},
	  {"module-case", 1},
    },
  },
}
)
  
-- god-module-6 --
data:extend(
{
  {
    type = "recipe",
    name = "god-module-6",
    enabled = false,
	energy_required = 120,
    result = "god-module-6",
    result_count = 1,	
    ingredients =
    {
      {"god-module-5", 1},
      {"speed-module-6", 2},
	  {"effectivity-module-6", 2},
	  {"productivity-module-6", 2},
	  {"pollution-clean-module-6", 2},
	  {"module-case", 1},
    },
  },
}
)
  
-- god-module-7 --
data:extend(
{
  {
    type = "recipe",
    name = "god-module-7",
    enabled = false,
    energy_required = 140,
    result = "god-module-7",
    result_count = 1,	
    ingredients =
    {
      {"god-module-6", 1},
      {"speed-module-7", 2},
	  {"effectivity-module-7", 2},
	  {"productivity-module-7", 2},
	  {"pollution-clean-module-7", 2},
	  {"module-case", 1},
    },
  },
}
)
  
-- god-module-8 --
data:extend(
{
  {
    type = "recipe",
    name = "god-module-8",
    enabled = false,
    energy_required = 160,
    result = "god-module-8",
    result_count = 1,	
    ingredients =
    {
      {"god-module-7", 1},
      {"speed-module-8", 2},
	  {"effectivity-module-8", 2},
	  {"productivity-module-8", 2},
	  {"pollution-clean-module-8", 2},
	  {"advanced-module-case", 1},
    },
  },
}
)