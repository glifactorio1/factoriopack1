
-- module-case --
data:extend(
{
  {
    type = "recipe",
    name = "module-case",
    enabled = false,
    energy_required = 1,	
    result = "module-case",
    result_count = 1,	
    ingredients =
    {
      {"iron-plate", 2},
	  {"steel-plate", 1},
    },
  },
}
)

-- advanced-module-case --
data:extend(
{
  {
    type = "recipe",
    name = "advanced-module-case",
    enabled = false,
    energy_required = 1,	
    result = "advanced-module-case",
    result_count = 1,	
    ingredients =
    {
	   
	  {"module-case", 1},
      {"iron-plate", 2},
	  {"steel-plate", 1},
    },
  },
}
)

