
-- productivity-module-4 --
data:extend(
{  
  {
    type = "technology",
    name = "productivity-module-4",
    icon = "__andrew-modules__/graphics/technology/productivity-module.png",
    upgrade = true,
    order = "m-p-4",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "productivity-module-4"
      },
    },
    prerequisites =
    {
      "productivity-module-3",
	  "advanced-electronics-3",
    },
    unit =
    {
      count = 400,
	  time = 30,
      ingredients = science4()
    },
  },
}
)

-- productivity-module-5 --
data:extend(
{  
  {
    type = "technology",
    name = "productivity-module-5",
    icon = "__andrew-modules__/graphics/technology/productivity-module.png",
    upgrade = true,
    order = "m-p-4",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "productivity-module-5"
      },
    },
    prerequisites =
    {
      "productivity-module-4",
    },
    unit =
    {
      count = 450,
	  time = 30,
      ingredients = science4()
    },
  },
}
)

-- productivity-module-6 --
data:extend(
{  
  {
    type = "technology",
    name = "productivity-module-6",
    icon = "__andrew-modules__/graphics/technology/productivity-module.png",
    upgrade = true,
    order = "m-p-4",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "productivity-module-6"
      },
    },
    prerequisites =
    {
      "productivity-module-5",
	  "advanced-electronics-4",
    },
    unit =
    {
      count = 500,
	  time = 30,
      ingredients = science4()
    },
  },
}
)

-- effectivity-module-7 --
data:extend(
{  
  {
    type = "technology",
    name = "productivity-module-7",
    icon = "__andrew-modules__/graphics/technology/productivity-module.png",
    upgrade = true,
    order = "m-p-4",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "productivity-module-7"
      },
    },
    prerequisites =
    {
      "productivity-module-6",
    },
    unit =
    {
      count = 550,
	  time = 30,
      ingredients = science4()
    },
  },
}
)

-- productivity-module-8 --
data:extend(
{  
  {
    type = "technology",
    name = "productivity-module-8",
    icon = "__andrew-modules__/graphics/technology/productivity-module.png",
    upgrade = true,
    order = "m-p-4",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "productivity-module-8"
      },
    },
    prerequisites =
    {
      "productivity-module-7",
	  "modules-2",
    },
    unit =
    {
      count = 600,
	  time = 30,
      ingredients = science4()
    },
  },
}
)
