
-- God-Modules-1 --
data:extend(
{  
  {
    type = "technology",
    name = "god-module",
    icon = "__andrew-modules__/graphics/technology/god-module.png",
    upgrade = true,
    order = "m-g-1",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "god-module-1"
      },
    },
    prerequisites =
    {
      "modules",
	  "speed-module",
	  "effectivity-module",
	  "pollution-clean-module",
	  "productivity-module"
    },
    unit =
    {
      count = 400,
	  time = 60,
      ingredients = science4()
    },
  },
}
)

-- God-Modules-2 --
data:extend(
{  
  {
    type = "technology",
    name = "god-module-2",
    icon = "__andrew-modules__/graphics/technology/god-module.png",
    upgrade = true,
    order = "m-g-2",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "god-module-2"
      },
    },
    prerequisites =
    {
      "god-module",
    },
    unit =
    {
      count = 500,
	  time = 60,
      ingredients = science4()
    },
  },
}
)

-- God-Modules-3 --
data:extend(
{  
  {
    type = "technology",
    name = "god-module-3",
    icon = "__andrew-modules__/graphics/technology/god-module.png",
    upgrade = true,
    order = "m-g-3",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "god-module-3"
      },
    },
    prerequisites =
    {
      "god-module-2",
    },
    unit =
    {
      count = 600,
	  time = 60,
      ingredients = science4()
    },
  },
}
)

-- God-Modules-4 --
data:extend(
{  
  {
    type = "technology",
    name = "god-module-4",
    icon = "__andrew-modules__/graphics/technology/god-module.png",
    upgrade = true,
    order = "m-g-4",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "god-module-4"
      },
    },
    prerequisites =
    {
      "god-module-3",
    },
    unit =
    {
      count = 700,
	  time = 60,
      ingredients = science4()
    },
  },
}
)

-- God-Modules-5 --
data:extend(
{  
  {
    type = "technology",
    name = "god-module-5",
    icon = "__andrew-modules__/graphics/technology/god-module.png",
    upgrade = true,
    order = "m-g-5",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "god-module-5"
      },
    },
    prerequisites =
    {
      "god-module-4",
    },
    unit =
    {
      count = 800,
	  time = 60,
      ingredients = science4()
    },
  },
}
)

-- God-Modules-6 --
data:extend(
{  
  {
    type = "technology",
    name = "god-module-6",
    icon = "__andrew-modules__/graphics/technology/god-module.png",
    upgrade = true,
    order = "m-g-6",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "god-module-6"
      },
    },
    prerequisites =
    {
      "god-module-5",
    },
    unit =
    {
      count = 900,
	  time = 60,
      ingredients = science4()
    },
  },
}
)

-- God-Modules-7 --
data:extend(
{  
  {
    type = "technology",
    name = "god-module-7",
    icon = "__andrew-modules__/graphics/technology/god-module.png",
    upgrade = true,
    order = "m-g-7",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "god-module-7"
      },
    },
    prerequisites =
    {
      "god-module-6",
    },
    unit =
    {
      count = 1000,
	  time = 60,
      ingredients = science4()
    },
  },
}
)

-- God-Modules-8 --
data:extend(
{  
  {
    type = "technology",
    name = "god-module-8",
    icon = "__andrew-modules__/graphics/technology/god-module.png",
    upgrade = true,
    order = "m-g-8",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "god-module-8"
      },
    },
    prerequisites =
    {
      "god-module-7",
	  "modules-2",
    },
    unit =
    {
      count = 1100,
	  time = 60,
      ingredients = science4()
    },
  },
}
)