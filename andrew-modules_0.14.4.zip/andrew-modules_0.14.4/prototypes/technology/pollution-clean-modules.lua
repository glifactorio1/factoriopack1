
-- Pollution-Cleaning-Modules-1 --
data:extend(
{  
  {
    type = "technology",
    name = "pollution-clean-module",
    icon = "__andrew-modules__/graphics/technology/pollution-clean-module.png",
    upgrade = true,
    order = "m-p-cl-1",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "pollution-clean-module-1"
      },
    },
    prerequisites =
    {
      "modules",
    },
    unit =
    {
      count = 250,
	  time = 30,
      ingredients = science2()
    },
  },
}
)

-- Pollution-Cleaning-Modules-2 --
data:extend(
{  
  {
    type = "technology",
    name = "pollution-clean-module-2",
    icon = "__andrew-modules__/graphics/technology/pollution-clean-module.png",
    upgrade = true,
    order = "m-p-cl-2",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "pollution-clean-module-2"
      },
    },
    prerequisites =
    {
      "pollution-clean-module",
    },
    unit =
    {
      count = 75,
	  time = 30,
      ingredients = science3()
    },
  },
}
)

-- Pollution-Cleaning-Modules-3 --
data:extend(
{  
  {
    type = "technology",
    name = "pollution-clean-module-3",
    icon = "__andrew-modules__/graphics/technology/pollution-clean-module.png",
    upgrade = true,
    order = "m-p-cl-3",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "pollution-clean-module-3"
      },
    },
    prerequisites =
    {
      "pollution-clean-module-2",
    },
    unit =
    {
      count = 300,
	  time = 30,
      ingredients = science4()
    },
  },
}
)

-- Pollution-Cleaning-Modules-4 --
data:extend(
{  
  {
    type = "technology",
    name = "pollution-clean-module-4",
    icon = "__andrew-modules__/graphics/technology/pollution-clean-module.png",
    upgrade = true,
    order = "m-p-cl-4",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "pollution-clean-module-4"
      },
    },
    prerequisites =
    {
      "pollution-clean-module-3",
	  "advanced-electronics-3",
    },
    unit =
    {
      count = 350,
	  time = 30,
      ingredients = science4()
    },
  },
}
)

-- Pollution-Cleaning-Modules-5 --
data:extend(
{  
  {
    type = "technology",
    name = "pollution-clean-module-5",
    icon = "__andrew-modules__/graphics/technology/pollution-clean-module.png",
    upgrade = true,
    order = "m-p-cl-5",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "pollution-clean-module-5"
      },
    },
    prerequisites =
    {
      "pollution-clean-module-4",
    },
    unit =
    {
      count = 400,
	  time = 30,
      ingredients = science4()
    },
  },
}
)

-- Pollution-Cleaning-Modules-6 --
data:extend(
{  
  {
    type = "technology",
    name = "pollution-clean-module-6",
    icon = "__andrew-modules__/graphics/technology/pollution-clean-module.png",
    upgrade = true,
    order = "m-p-cl-6",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "pollution-clean-module-6"
      },
    },
    prerequisites =
    {
      "pollution-clean-module-5",
	  "advanced-electronics-4",
    },
    unit =
    {
      count = 450,
	  time = 30,
      ingredients = science4()
    },
  },
}
)

-- Pollution-Cleaning-Modules-7 --
data:extend(
{  
  {
    type = "technology",
    name = "pollution-clean-module-7",
    icon = "__andrew-modules__/graphics/technology/pollution-clean-module.png",
    upgrade = true,
    order = "m-p-cl-7",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "pollution-clean-module-7"
      },
    },
    prerequisites =
    {
      "pollution-clean-module-6",
    },
    unit =
    {
      count = 550,
	  time = 30,
      ingredients = science4()
    },
  },
}
)

-- Pollution-Cleaning-Modules-8 --
data:extend(
{  
  {
    type = "technology",
    name = "pollution-clean-module-8",
    icon = "__andrew-modules__/graphics/technology/pollution-clean-module.png",
    upgrade = true,
    order = "m-p-cl-8",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "pollution-clean-module-8"
      },
    },
    prerequisites =
    {
      "pollution-clean-module-7",
	  "modules-2",
    },
    unit =
    {
      count = 600,
	  time = 30,
      ingredients = science4()
    },
  },
}
)