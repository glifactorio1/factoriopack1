
-- modules --
data:extend(
{  
  {
    type = "technology",
    name = "modules",
    icon = "__base__/graphics/technology/module.png",
    upgrade = true,
    order = "i-a",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "module-case"
      },
    },
	prerequisites = 
	{
	  "advanced-electronics"
	},
	unit =
    {
      count = 100,
      time = 30,
      ingredients = science2()
    },
  },
}
)

-- modules-2 --
data:extend(
{  
  {
    type = "technology",
    name = "modules-2",
    icon = "__base__/graphics/technology/module.png",
    upgrade = true,
    order = "i-a",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "advanced-module-case"
      },
    },
	prerequisites = 
	{
	  "modules",
	},
	unit =
    {
      count = 1000,
      time = 60,
      ingredients = science4()
    },
  },
}
)
