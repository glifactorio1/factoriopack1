
-- item --
require("prototypes.item.module-case")
require("prototypes.item.effectivity-modules")
require("prototypes.item.god-modules")
require("prototypes.item.pollution-clean-modules")
require("prototypes.item.productivity-modules")
require("prototypes.item.speed-modules")

-- recipe --

require("prototypes.recipe.module-case")
require("prototypes.recipe.effectivity-modules")
require("prototypes.recipe.god-modules")
require("prototypes.recipe.pollution-clean-modules")
require("prototypes.recipe.productivity-modules")
require("prototypes.recipe.speed-modules")


-- technology --
require("prototypes.technology.module-case")
require("prototypes.technology.effectivity-modules")
require("prototypes.technology.god-modules")
require("prototypes.technology.pollution-clean-modules")
require("prototypes.technology.productivity-modules")
require("prototypes.technology.speed-modules")
