data:extend(
{
  {
	type = "recipe",
	name = "item-collector",
	enabled = true,
	ingredients =
	{
	  {"steel-chest", 1},
	  {"electronic-circuit", 20},
	},
	result = "item-collector-area"
  }
})