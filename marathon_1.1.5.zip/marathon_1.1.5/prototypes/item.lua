data.raw["item"]["raw-wood"].fuel_value = "2MJ"
data.raw["item"]["wood"].fuel_value = "1MJ"
data.raw["item"]["small-electric-pole"].fuel_value = "2MJ"
data.raw["item"]["coal"].fuel_value = "4MJ"
data.raw["item"]["solid-fuel"].fuel_value = "10MJ"

data.raw["item"]["pipe"].stack_size = 100
