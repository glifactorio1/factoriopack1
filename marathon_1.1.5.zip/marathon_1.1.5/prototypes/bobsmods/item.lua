if data.raw.item["carbon"] then
    data.raw.item["carbon"].fuel_value = "2.5MJ"
end
if data.raw.item["liquid-fuel-canister"] then
    data.raw.item["liquid-fuel-canister"].fuel_value = "50MJ"
end
