for i, force in pairs(game.forces) do 
    force.reset_recipes()
end
