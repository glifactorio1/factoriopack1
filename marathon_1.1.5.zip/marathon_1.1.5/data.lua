require("prototypes.item")
require("prototypes.recipe-ammo")
require("prototypes.recipe-armor")
require("prototypes.recipe-chemistry")
require("prototypes.recipe-circuit")
require("prototypes.recipe-intermediate")
require("prototypes.recipe-logistics")
require("prototypes.recipe-other")
require("prototypes.recipe-production")
require("prototypes.recipe-science")
require("prototypes.recipe-smelting")
require("prototypes.recipe-weapon")

marathon = {}
