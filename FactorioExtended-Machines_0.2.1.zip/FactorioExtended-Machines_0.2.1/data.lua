
require("prototypes.item.item-machine")
require("prototypes.recipe.recipe-machine")
require("prototypes.entity.entity-machine")
require("prototypes.technology.technology-machine")
