autohide_time = 180 -- time to auto-hide sticky note in ticks (180 = 3sec)
text_color = {r=1,g=1,b=0}