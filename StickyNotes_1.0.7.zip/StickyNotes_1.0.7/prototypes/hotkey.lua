data:extend(
	{
		{
			type = "custom-input",
			name = "notes_hotkey",
			key_sequence = "ENTER",
			consuming = "script-only"
		},
	}
)