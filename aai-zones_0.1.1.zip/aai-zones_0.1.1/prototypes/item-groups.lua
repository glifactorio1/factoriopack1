data:extend(
{
  {
    type = "item-group",
    name = "zones",
    order = "f",
    icon = "__aai-zones__/graphics/zones-group.png"
  },
  {
    type = "item-subgroup",
    name = "zones-main",
    group = "zones",
    order = "c",
  }
}
)