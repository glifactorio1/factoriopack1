data:extend({
	{
		type = "recipe",
		name = "zone-planner",
		category = "crafting",
		enabled = false,
		energy_required = 2,
		ingredients =
		{
		  {type="item", name="electronic-circuit", amount=5}
		},
		results=
		{
		  {type="item", name="zone-planner", amount=1},
		},
	},
})