zone_patterns = {"diagonal-left", "diagonal-right", "horizontal", "vertical", "box", "plus", "x", "circle", "disc",
	"arrow-n", "arrow-e", "arrow-s", "arrow-w", "arrow-ne", "arrow-se", "arrow-sw", "arrow-nw"}
zone_colours = {"black", "green", "teal", "cyan", "blue", "purple", "magenta", "red", "orange", "yellow", "olive", "white"}
zones = {}
zones_by_name = {}

for _, pattern in ipairs(zone_patterns) do
	for _, colour in ipairs(zone_colours) do
		local zone = {
			name="zone-" .. pattern .. "-" .. colour, 
			localised_name = { "zone-name", { "pattern-"..pattern }, { "colour-"..colour } }
		}
		table.insert(zones, zone)
		zones_by_name[zone.name] = zone
		
	end 
end 
	