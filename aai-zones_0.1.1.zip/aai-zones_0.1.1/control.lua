require("util")
require("zone-options")

function get_zone_for_position(data)
	return zone_for_xy(data.force, data.position.x, data.position.y)
end

function zone_count_of_type(data) 
	zone_force_update()
	local force = data.force
	local zone_name = data.type
	if global.forces[force.name].zones_by_type[zone_name] then
		return #global.forces[force.name].zones_by_type[zone_name]
	end
	return 0
end

function zone_force_update() 
	if not global.forces then
		global.forces = {}
	end
		
	for _, force in pairs(game.forces) do 
		if not global.forces[force.name] then
			global.forces[force.name] = {}
		end
		if not global.forces[force.name].zones then
			global.forces[force.name].zones = {} -- by x_y string. each element is {type = name, position = position, entity = zone}
		end
		if not global.forces[force.name].zones_by_type then
			global.forces[force.name].zones_by_type = {} -- {zone-diagonal-blue = { 0 = 5_175, 1 = 35_-123}}
		end
		for _,zone in ipairs(zones) do
			if not global.forces[force.name].zones_by_type[zone.name] then
				global.forces[force.name].zones_by_type[zone.name] = {} -- by indexed as x_y string
			end
		end
	end

	if not global.player_zone_selection then
		global.player_zone_selection = {} -- just the zone name
	end
end 

function zone_on_player_cursor_stack_changed(event)
	local player = game.players[event.player_index]
	if player.cursor_stack and player.cursor_stack.valid and player.cursor_stack.valid_for_read then
		if player.cursor_stack.name == "zone-planner" then
			zone_show_gui(player)
		else
			zone_hide_gui(player)
		end
	else
		zone_hide_gui(player)
	end
end

function zone_show_gui(player)
	zone_force_update() 
	if player.gui.left.zone == nil then
		local zone_frame = player.gui.left.add{type = "frame", name = "zone", caption = {"text-zone-planner"}, direction = "vertical"}
		
		local zone_colour_table = zone_frame.add{type ="table", name = "zone_colour_table", colspan = 6, style = "zones-table"}
		local zone_colour_table = zone_frame.add{type ="table", name = "zone_pattern_table", colspan = 6, style = "zones-table"}
		
		zone_gui_rebuild(player)
		
		zone_frame.add{type ="label", name = "zones_alt_tip", caption = {"text-zone-planner-alt"}}
	end
end

function zone_gui_rebuild(player)

	local selection = zone_get_player_selection(player.index)
	local frame = player.gui.left.zone
	
	for	_, child_name in pairs(frame.zone_colour_table.children_names) do 
		frame.zone_colour_table[child_name].destroy()
	end
	for	_, child_name in pairs(frame.zone_pattern_table.children_names) do 
		frame.zone_pattern_table[child_name].destroy()
	end
	
	for _, colour in ipairs(zone_colours) do
		frame.zone_colour_table.add{
			type = "sprite-button",
			name = colour, 
			sprite="virtual-signal/".."zone-"..selection.pattern.."-"..colour, 
			tooltip = colour, 
			style= colour == selection.colour and "zone-button-active" or "zone-button"}
	end
	
	for _, pattern in ipairs(zone_patterns) do
		frame.zone_pattern_table.add{
			type = "sprite-button",
			name = pattern, 
			sprite="virtual-signal/".."zone-"..pattern.."-"..selection.colour, 
			tooltip = pattern, 
			style= pattern == selection.pattern and "zone-button-active" or "zone-button"}
	end
	
end


function zone_hide_gui(player)
	if player.gui.left.zone ~= nil then
		player.gui.left.zone.destroy()
	end
end

function zone_on_gui_click(event)
	local player_index = event.player_index
	local player = game.players[player_index];
	if game.players[player_index].gui.left.zone ~= nil and event.element.parent then -- avoid looping if menu is closed
		if event.element.parent.name == "zone_colour_table" then
			zone_set_player_selection(player_index, nil, event.element.name)
			zone_gui_rebuild(player)
		elseif event.element.parent.name == "zone_pattern_table" then
			zone_set_player_selection(player_index, event.element.name, nil)
			zone_gui_rebuild(player)
		end
	end
end

function zone_set_player_selection(player_index, pattern, colour)
	local selection = zone_get_player_selection(player_index)
	if pattern then selection.pattern = pattern end
	if colour then selection.colour = colour end
	global.player_zone_selection[player_index] = selection
end

function zone_get_player_selection(player_index)
	if not global.player_zone_selection then global.player_zone_selection = {} end
	local selection
	if global.player_zone_selection[player_index] 
			and global.player_zone_selection[player_index].colour 
			and global.player_zone_selection[player_index].pattern then
		selection = global.player_zone_selection[player_index] 
	else 
		selection = {pattern = zone_patterns[1], colour = zone_colours[1]}
	end
	selection.zone = "zone-"..selection.pattern.."-"..selection.colour
	return selection
end


function zone_on_player_selected_area(event)
	zone_player_selected_area(event, false)
end

function zone_on_player_alt_selected_area(event)
	zone_player_selected_area(event, true)
end

function zone_player_selected_area(event, alt)
	if (event.item == "zone-planner") then
		local player = game.players[event.player_index];
		zone_force_update() 
		local zone_name = nil
		if alt == false then
			zone_name = zone_get_player_selection(event.player_index).zone
		end
		zone_apply_to_area({
			surface = game.players[event.player_index].surface,
			force = game.players[event.player_index].force, 
			area = event.area, 
			type = zone_name})
		
	end
end

function zone_apply_to_area(data)
	local surface = data.surface
	local force = data.force
	local area = data.area
	local zone_name = data.type
	
	if surface and force and area then
		-- if zone_name is nil the action will be remove only
		zone_force_update() 
		
		local minX = math.floor(area.left_top.x);
		local maxX = math.floor(area.right_bottom.x);
		if maxX - minX <= 0 then
			maxX = minX
		end
		local minY = math.floor(area.left_top.y);
		local maxY = math.floor(area.right_bottom.y);
		if maxY - minY <= 0 then
			maxY = minY
		end
		
		for x = minX, maxX, 1 do
			for y = minY, maxY, 1 do
				local xy_string = xy_to_string(x, y)
				if global.forces[force.name].zones[xy_string] then
					local zone = global.forces[force.name].zones[xy_string]
					if global.forces[force.name].zones_by_type[zone.type] then
						remove_from_table(global.forces[force.name].zones_by_type[zone.type], xy_string)
					end
					if zone.entity.valid then
						zone.entity.destroy()
					end
					global.forces[force.name].zones[xy_string] = nil
				end
			end
		end

		if zone_name then
			for x = minX, maxX, 1 do
				for y = minY, maxY, 1 do
					local xy_string = xy_to_string(x, y)
					local newzone = surface.create_entity{name = zone_name, position={x+0.5,y+0.5}, force = force}
					global.forces[force.name].zones[xy_string] = {
						type = zone_name,
						position = newzone.position,
						entity = newzone, -- may get removed by concrete but the zone will still work without the entity
					}
					if not global.forces[force.name].zones_by_type[zone_name] then
						global.forces[force.name].zones_by_type[zone_name] = {}
					end
					table.insert(global.forces[force.name].zones_by_type[zone_name], xy_string)
				end
			end
		end
	end
end

function zone_for_xy(force, x, y)
	zone_force_update() 
	local xy_string = xy_to_string(x,y)
	if global.forces[force.name].zones[xy_string] then
		return global.forces[force.name].zones[xy_string].type
	end
end

function zone_by_type_and_index(force, zone_type, index)
	zone_force_update() 
	if global.forces[force.name].zones_by_type[zone_type] and #global.forces[force.name].zones_by_type[zone_type] > 0 then
		local xy_string = nil
		local real_index = nil
		if index > 0 and index <= #global.forces[force.name].zones_by_type[zone_type] then
			real_index = index
		elseif index < 0 and -index <= #global.forces[force.name].zones_by_type[zone_type] then
			real_index = #global.forces[force.name].zones_by_type[zone_type] + index + 1
		end
		xy_string = global.forces[force.name].zones_by_type[zone_type][real_index]
		if xy_string and global.forces[force.name].zones[xy_string] then
			local zone = global.forces[force.name].zones[xy_string]
			return {type = zone.type,
				position = zone.position,
				entity = zone.entity,
				index = real_index}
				
		end
	end
end

function position_to_xy_string(position)
	return xy_to_string(position.x or position[1], position.y or position[2])
end

function xy_to_string(x, y)
	return math.floor(x or 0) .. "_" .. math.floor(y or 0)
end

script.on_event(defines.events.on_player_selected_area, zone_on_player_selected_area)
script.on_event(defines.events.on_player_alt_selected_area, zone_on_player_alt_selected_area)
script.on_event(defines.events.on_gui_click, zone_on_gui_click)
script.on_event(defines.events.on_player_cursor_stack_changed, zone_on_player_cursor_stack_changed)

remote.add_interface("aai-zones", {
	get_zone_types = function() return zones end,
	is_zone_type = function(zone_type) return zones_by_name[zone_type] ~= nil end,
	apply_zone_to_area = function(data) return zone_apply_to_area(data) end,
	get_zone_for_position = function (data) return get_zone_for_position(data) end, -- data.force, data.position, Returns: zone_type string
	get_zone_count_of_type = function (data) return zone_count_of_type(data) end, -- data.force, data.type
	get_zone_by_index = function (data) return zone_by_type_and_index(data.force, data.type, data.index) end,-- data.force, data.type, data.index
})
