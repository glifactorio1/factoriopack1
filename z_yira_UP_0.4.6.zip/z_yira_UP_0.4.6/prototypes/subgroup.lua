
data:extend({
	{ type="item-subgroup", group="yuoki_railway", order="x", name="yir_uranium_power", }, -- mod themed line
})