require("utils")
require("prototypes/styles")
require("prototypes/entities")
require("prototypes/signals")