FDP_DEFAULT_FILTER_MODE = "normal"
FDP_EVENTS = {
  on_gui_clicked = script.generate_event_name(),
  on_mode_changed = script.generate_event_name(),
  on_button_filter_clicked = script.generate_event_name(),
  on_button_eyedropper_clicked = script.generate_event_name(),
  on_button_clear_clicked = script.generate_event_name()
}
