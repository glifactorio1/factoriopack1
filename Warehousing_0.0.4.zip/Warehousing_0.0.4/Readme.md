Warehousing
---
Current version 0.0.4

Word of warning, the warehouses have been changed to 6x6 as per a suggestion, this will make all current warehouses potentially overlap and not come out right ... you have been warned!

Also, increased the number of slots to 220
---
Adds 6x6 warehouses that allow you to store a lot of items
only limted down to 159 because there's not enough space on the screen for all of the slots

Also adds logistic versions (passive provider and storage)

Graphics by Nova Kast, please do not use without permission! (just message me for this if you want)
Also with shadows
