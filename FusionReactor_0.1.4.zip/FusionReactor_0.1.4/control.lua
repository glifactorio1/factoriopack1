require "util"

script.on_event(defines.events.on_tick, function(event)
		check_generators()
end)

script.on_event(defines.events.on_built_entity, function(event)

	if event.created_entity.name == "fusion-reactor" then	
			local fusion_reactor = event.created_entity
						if global.fusion_reactor == nil
						then global.fusion_reactor = {}
						end
					table.insert(global.fusion_reactor, fusion_reactor)
					fusion_reactor.fluidbox[1] = {type="deuterium-fluid", amount=100, temperature=100}

	end
end)


script.on_event(defines.events.on_robot_built_entity, function(event)

	if event.created_entity.name == "fusion-reactor" then		
			local fusion_reactor = event.created_entity
						if global.fusion_reactor == nil
						then global.fusion_reactor = {}
						end
					table.insert(global.fusion_reactor, fusion_reactor)
					fusion_reactor.fluidbox[1] = {type="deuterium-fluid", amount=100, temperature=100}
	end
end)



function check_generators()
   if global.fusion_reactor ~= nil then

  	    for k,gen in pairs(global.fusion_reactor) do
      		if k % 125 == game.tick % 125 then

				if gen.valid then
         			if gen.fluidbox[1] ~= nil then 

         					local pot = gen.fluidbox[1]
							pot["amount"] = 10				
							pot["temperature"] = 100
							gen.fluidbox[1] = pot
							
					else table.remove(global.fusion_reactor, k)

					end				
				end
			end
		end
	end
end