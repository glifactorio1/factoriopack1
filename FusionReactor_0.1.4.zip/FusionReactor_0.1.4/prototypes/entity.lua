data:extend({
	{
		type = "generator",
		name = "fusion-reactor",
		icon = "__FusionReactor__/graphics/entity/Temp_Reactor_Texture_V2compressedMini.png",
		flags = {"placeable-neutral","player-creation"},
		minable = {mining_time = 3, result = "fusion-reactor"},
		max_health = 300,
		corpse = "big-remnants",
		effectivity = 2250,
		fluid_usage_per_tick = 0.001,
		emissions = 0.4,
		resistances =
		{
			{
				type = "fire",
				percent = 40
			}
		},
		collision_box = {{-2.8, -2.8}, {2.8, 2.8}},
		selection_box = {{-3.0, -3.0}, {3.0, 3.0}},
		fluid_box =
		{
			base_area = 1,
			pipe_connections =
			{
			},
		},
		energy_source =
		{
			type = "electric",
			usage_priority = "primary-output",
		},	
		horizontal_animation =
		{
			filename = "__FusionReactor__/graphics/entity/Temp_Reactor_Texture_V2compressedMini.png",
			width = 198,
			height = 198,
			frame_count = 1,
			line_length = 1,
		},
		vertical_animation =
		{
			filename = "__FusionReactor__/graphics/entity/Temp_Reactor_Texture_V2compressedMini.png",
			width = 198,
			height = 198,
			frame_count = 1,
			line_length = 1,
		},
	smoke ={},
	working_sound =
    {
      sound =
      {
		filename = "__base__/sound/train-wheels.ogg",
        volume = 0.6
      },
      match_speed_to_activity = true
    },
	min_perceived_performance = 0.25,
    performance_to_sound_speedup = 0.2
	}
})