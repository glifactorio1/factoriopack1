data:extend(
{
	{
    type = "item",
    name = "reactor-plate",
    icon = "__FusionReactor__/graphics/icons/reactor_plate.png",
    flags = {"goes-to-quickbar"},
    subgroup = "intermediate-product",
	order = "k-[reactor-plate]",
    stack_size = 50
    },
	{
    type = "item",
    name = "deuterium-capsule",
    icon = "__FusionReactor__/graphics/icons/deuterium_capsule.png",
    flags = {"goes-to-quickbar"},
    subgroup = "intermediate-product",
	order = "j-[deuterium-capsule]",
    stack_size = 50
    },
	{
    type = "item",
	name = "fusion-reactor",
	icon = "__FusionReactor__/graphics/icons/Temp_Reactor_Texture_Icon.png",
	flags = {"goes-to-quickbar"},
	subgroup = "energy",
	order = "e[fusion-reactor]",
	place_result = "fusion-reactor",
	stack_size = 5
	}
}
)