data:extend({
	{
		type = "recipe",
		name = "deuterium-capsule",
		category = "chemistry",
		energy_required = 20,
		enabled = false,
		ingredients = 
		{
			{type = "item", name = "iron-plate", amount = 2},
			{type = "fluid", name = "water", amount = 10}
		},
		results = 
		{
			{type = "item", name = "deuterium-capsule", amount = 1}
		},
	},
	{
		type = "recipe",
		name = "deuterium-fluid",
		category = "chemistry",
		energy_required = 20,
		enabled = false,
		ingredients = 
		{
			{type = "fluid", name = "water", amount = 10}
		},
		results = 
		{
			{type = "fluid", name = "deuterium-fluid", amount = 1}
		}
	}
})