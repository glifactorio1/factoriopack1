data:extend({
  {
      type = "technology",
      name = "fuel-processing",
      icon = "__FusionReactor__/graphics/icons/deuterium_capsule.png",
	  icon_size = 128,
      effects =
      {
        {
            type = "unlock-recipe",
            recipe = "deuterium-capsule"
        }
      },
	  prerequisites = {"oil-processing"},
      unit =
      {
        count = 100,
        ingredients =
        {
          {"science-pack-1", 1},
          {"science-pack-2", 1},
          {"science-pack-3", 1}
        },
        time = 30
      }
  },
  {
      type = "technology",
      name = "fusion-reactor",
      icon = "__FusionReactor__/graphics/icons/Temp_Reactor_Texture_Icon.png",
	  icon_size = 128,
      effects =
      {
        {
            type = "unlock-recipe",
            recipe = "reactor-plate"
        },
		{
			type = "unlock-recipe",
			recipe = "fusion-reactor"
		}
      },
	  prerequisites = {"fuel-processing","laser"},
      unit =
      {
        count = 200,
        ingredients =
        {
          {"science-pack-1", 1},
          {"science-pack-2", 1},
          {"science-pack-3", 1}
        },
        time = 30
      }
  }
})