data:extend({
	{
    type = "recipe",
    name = "reactor-plate",
    enabled = false,
	energy_required = 3,
    ingredients = 
		{
			{"copper-plate", 5},
			{"iron-plate", 10},
			{"plastic-bar", 2}
		},
    result = "reactor-plate"
	},
	{
	type = "recipe",
	name = "fusion-reactor",
	enabled = false,
	energy_required = 10,
	ingredients =
		{
			{"steel-plate", 200},
			{"iron-plate", 500},
			{"copper-cable", 100},
			{"electronic-circuit", 200},
			{"advanced-circuit", 100},
			{"processing-unit", 40},
			{"battery", 20},
			{"reactor-plate", 100},
			{"deuterium-capsule", 20}
		},
	result = "fusion-reactor"
	}
})