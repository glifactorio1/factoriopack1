data:extend({
  {
    type = "fluid",
    name = "deuterium-fluid",
    default_temperature = 0,
	max_temperature = 100,
    heat_capacity = "1KJ",
    base_color = {r=0, g=0, b=0},
    flow_color = {r=0.3, g=0.3, b=0.3},
    icon = "__FusionReactor__/graphics/icons/deuterium.png",
    pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
	subgroup = "intermediate-product",
    order = "i[deuterium-fluid]"
  }
})