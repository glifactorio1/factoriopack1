----Tree Farm Mod Compatibility----
--10x the pollution absorbtion
data.raw["tree"]["alien-plant-seed"].emissions_per_tick = -0.001
data.raw["tree"]["small-alien-plant"].emissions_per_tick = -0.002
data.raw["tree"]["medium-alien-plant"].emissions_per_tick = -0.003
data.raw["tree"]["mature-alien-plant"].emissions_per_tick = -0.003