----Tree Farm Mod Compatibility----
--10x the pollution absorbtion
data.raw["tree"]["tf-germling"].emissions_per_tick = -0.001
data.raw["tree"]["tf-very-small-tree"].emissions_per_tick = -0.002
data.raw["tree"]["tf-small-tree"].emissions_per_tick = -0.003
data.raw["tree"]["tf-medium-tree"].emissions_per_tick = -0.004
data.raw["tree"]["tf-mature-tree"].emissions_per_tick = -0.005
data.raw["tree"]["tf-coral-seed"].emissions_per_tick = -0.001
data.raw["tree"]["tf-small-coral"].emissions_per_tick = -0.002
data.raw["tree"]["tf-medium-coral"].emissions_per_tick = -0.003
data.raw["tree"]["tf-mature-coral"].emissions_per_tick = -0.003