----Tree Farm Mod Caffine Addon Compatibility----
--10x the pollution absorbtion
data.raw["tree"]["tf-coffee-seed"].emissions_per_tick = -0.001
data.raw["tree"]["tf-small-coffee-plant"].emissions_per_tick = -0.002
data.raw["tree"]["tf-medium-coffee-plant"].emissions_per_tick = -0.003
data.raw["tree"]["tf-mature-coffee-plant"].emissions_per_tick = -0.003
data.raw["tree"]["tf-tea-seed"].emissions_per_tick = -0.001
data.raw["tree"]["tf-small-tea-bush"].emissions_per_tick = -0.002
data.raw["tree"]["tf-medium-tea-bush"].emissions_per_tick = -0.003
data.raw["tree"]["tf-mature-tea-bush"].emissions_per_tick = -0.003

--Emissions for Coffee was not mirriored to that of the Tea Plant.
--I suspect it was an error, so made them uniform.