--require "demo-trees" 

----Base Code Edit----
--10x the pollution absorbtion
data.raw["tree"]["tree-01"].emissions_per_tick = -0.005
data.raw["tree"]["tree-02"].emissions_per_tick = -0.005
data.raw["tree"]["tree-02-red"].emissions_per_tick = -0.005
data.raw["tree"]["tree-03"].emissions_per_tick = -0.005
data.raw["tree"]["tree-04"].emissions_per_tick = -0.005
data.raw["tree"]["tree-05"].emissions_per_tick = -0.005
data.raw["tree"]["tree-06"].emissions_per_tick = -0.005
data.raw["tree"]["tree-06-brown"].emissions_per_tick = -0.005
data.raw["tree"]["tree-07"].emissions_per_tick = -0.005
data.raw["tree"]["tree-08"].emissions_per_tick = -0.005
data.raw["tree"]["tree-08-brown"].emissions_per_tick = -0.005
data.raw["tree"]["tree-08-red"].emissions_per_tick = -0.005
data.raw["tree"]["tree-09"].emissions_per_tick = -0.005
data.raw["tree"]["tree-09-brown"].emissions_per_tick = -0.005
data.raw["tree"]["tree-09-red"].emissions_per_tick = -0.005

--Some Trees Have Identifiers which are colours, but are a completly different entity