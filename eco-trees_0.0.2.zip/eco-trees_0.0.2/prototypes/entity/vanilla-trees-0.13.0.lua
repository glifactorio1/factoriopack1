--require "demo-trees" 

----Base Code Edit----
--10x the pollution absorbtion
--This tree is currently deactivated on vanilla code for 0.12.0
data.raw["tree"]["tree-01-brown"].emissions_per_tick = -0.005