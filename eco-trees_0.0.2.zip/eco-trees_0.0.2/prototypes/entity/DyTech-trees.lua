----DyTech Mod Compatibility----
--10x the pollution absorbtion
data.raw["tree"]["rubber-seed"].emissions_per_tick = -0.001
data.raw["tree"]["small-rubber-tree"].emissions_per_tick = -0.002
data.raw["tree"]["medium-rubber-tree"].emissions_per_tick = -0.003
data.raw["tree"]["mature-rubber-tree"].emissions_per_tick = -0.005

data.raw["tree"]["sulfur-seed"].emissions_per_tick = -0.001
data.raw["tree"]["small-sulfur-tree"].emissions_per_tick = -0.002
data.raw["tree"]["medium-sulfur-tree"].emissions_per_tick = -0.003
data.raw["tree"]["mature-sulfur-tree"].emissions_per_tick = -0.005

--I havn't played the DyTech but I am confused with what that authur was going for
--with his tree emissions levels.  The numbers seem random.
--So I made them conform to normal treefarm 