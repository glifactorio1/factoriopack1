
script.on_event(defines.events.on_tick, function(event)
	check_torches()
end)




script.on_event(defines.events.on_built_entity, function(event)

	if event.created_entity.name == "torch" then	
			local torch = event.created_entity
						if global.torch == nil
						then global.torch = {}
						end
					table.insert(global.torch, torch)
			torch.insert{name="coal", count=1}
			torch.fluidbox[1] = {type="water", amount=10, temperature = 98}
			--torch.fluidbox[1]["temperature"] = 100
			local s = torch.surface
			local p = torch.position
			local f = game.forces.neutral
		s.create_entity{name = "torchlight", position = {p.x , p.y }, force=f}
		s.create_entity{name = "torchpole", position = {p.x  , p.y}, force=f}
		local power = s.create_entity{name = "torchpower", position = {p.x  , p.y}, force=f}
			power.fluidbox[1] = {type="water", amount=1, temperature = 98}
			
	end
end)


script.on_event(defines.events.on_robot_built_entity, function(event)

	if event.created_entity.name == "torch" then	
			local torch = event.created_entity
						if global.torch == nil
						then global.torch = {}
						end
					table.insert(global.torch, torch)
			torch.insert{name="coal", count=1}
			torch.fluidbox[1] = {type="water", amount=10, temperature = 98}
			--torch.fluidbox[1]["temperature"] = 100
			local s = torch.surface
			local p = torch.position
			local f = game.forces.neutral
		s.create_entity{name = "torchlight", position = {p.x , p.y }, force=f}
		s.create_entity{name = "torchpole", position = {p.x  , p.y}, force=f}
		local power = s.create_entity{name = "torchpower", position = {p.x  , p.y}, force=f}
			power.fluidbox[1] = {type="water", amount=1, temperature = 98}
			
	end
end)


function check_torches()
   if global.torch ~= nil then
      for k,torch in pairs(global.torch) do
      	if (k + game.tick) % 120 == 0 then
					if torch.valid then
										if torch.energy ~= 0 then
										local X = torch.position.x
										local Y = torch.position.y
										lid = {}
									lid =	torch.surface.find_entities_filtered{area = {{X -0.5, Y - 0.5 }, {X + 0.5  , Y +0.5 }}, name= "torchpower"}
									if lid[1] ~= nil then
									local 	top = lid[1].fluidbox[1]
																		if top == nil then 	top = {type="water", amount=1, temperature=15} end
									if top ~= nil then
										if torch.fluidbox[1] ~= nil then 
										bot = torch.fluidbox[1]



									t1 = top["temperature"]
									v1 = top["amount"] * 100
									t2 = bot["temperature"]
									v2 = bot["amount"]
									dv = v2 - v1

							
									if v1 < 98 then
										v1 = 100 end
										t2 = 99			

										bot["temperature"] = t2
										torch.fluidbox[1] = bot
										top["amount"]= v1/100
										top["temperature"] = 100
										lid[1].fluidbox[1] = top
											end
					end
end
end

else table.remove(global.torch, k) --game.players[1].print("torch removed")
end
end
end	
end
end


script.on_event(defines.events.on_preplayer_mined_item , function(event)

	if event.entity.name == "torch" then
	local X = event.entity.position.x 
	local Y = event.entity.position.y
	
		local poles = {}		
		poles =	game.players[1].surface.find_entities_filtered{area = {{X -0, Y - 0 }, {X + 0.6  , Y + 0.6 }}, name= "torchpole"}
		if poles[1] ~= nil then
		poles[1].destroy()	end
		
		local power = {}		
		panels =	game.players[1].surface.find_entities_filtered{area = {{X -0.2, Y - 0.2 }, {X + 0.2  , Y +0.2 }}, name= "torchpower"}
		if panels[1] ~= nil then
		panels[1].destroy()	end
		
		local light = {}		
		light =	game.players[1].surface.find_entities_filtered{area = {{X -0, Y - 0 }, {X + 0.6 , Y + 0.6 }}, name= "torchlight"}
		if light[1] ~= nil then
		light[1].destroy()	end
		
	end


end)





script.on_event(defines.events.on_entity_died , function(event)

if event.entity.name == "torch" then
	local X = event.entity.position.x 
	local Y = event.entity.position.y
	
		local poles = {}		
		poles =	game.players[1].surface.find_entities_filtered{area = {{X -0, Y - 0 }, {X + 0.6  , Y + 0.6 }}, name= "torchpole"}
		if poles[1] ~= nil then
		poles[1].destroy()	end
		
		local power = {}		
		panels =	game.players[1].surface.find_entities_filtered{area = {{X -0.2, Y - 0.2 }, {X + 0.2  , Y +0.2 }}, name= "torchpower"}
		if panels[1] ~= nil then
		panels[1].destroy()	end
		
		local light = {}		
		light =	game.players[1].surface.find_entities_filtered{area = {{X -0, Y - 0 }, {X + 0.6 , Y + 0.6 }}, name= "torchlight"}
		if light[1] ~= nil then
		light[1].destroy()	end
		
	end


end)







script.on_event(defines.events.on_robot_pre_mined  , function(event)

  if event.entity.name == "torch" then
	local X = event.entity.position.x 
	local Y = event.entity.position.y
	
		local poles = {}		
		poles =	game.players[1].surface.find_entities_filtered{area = {{X -0, Y - 0 }, {X + 0.6  , Y + 0.6 }}, name= "torchpole"}
		if poles[1] ~= nil then
		poles[1].destroy()	end
		
		local power = {}		
		panels =	game.players[1].surface.find_entities_filtered{area = {{X -0.2, Y - 0.2 }, {X + 0.2  , Y +0.2 }}, name= "torchpower"}
		if panels[1] ~= nil then
		panels[1].destroy()	end
		
		local light = {}		
		light =	game.players[1].surface.find_entities_filtered{area = {{X -0, Y - 0 }, {X + 0.6 , Y + 0.6 }}, name= "torchlight"}
		if light[1] ~= nil then
		light[1].destroy()	end
		
	end


end)

