data:extend({

  {
    type = "item",
    name = "torch",
    icon = "__Torches__/graphics/icons/torchicon.png",
    flags = {"goes-to-quickbar"},
	fuel_value = "6MJ",
    subgroup = "energy",
    order = "c-a",
    place_result = "torch",
    stack_size = 64
  },
    {
    type = "item",
    name = "torchpole",
    icon = "__Torches__/graphics/icons/torchicon.png",
    flags = {"goes-to-quickbar", "hidden"},
    subgroup = "inserter",
    order = "d-j",
    place_result = "torchpole",
    stack_size = 50
  },
    {
    type = "item",
    name = "torchpower",
    icon = "__Torches__/graphics/icons/torchicon.png",
    flags = {"goes-to-quickbar", "hidden"},
    subgroup = "inserter",
    order = "d-j",
    place_result = "torchpower",
    stack_size = 50
  },
    {
    type = "item",
    name = "torchlight",
    icon = "__Torches__/graphics/icons/torchicon.png",
    flags = {"goes-to-quickbar", "hidden"},
    subgroup = "inserter",
    order = "d-j",
    place_result = "torchlight",
    stack_size = 50
  },
  {
    type = "recipe",
    name = "torch",
    enabled = "true",
    ingredients =
    {
      {"wood", 3},
      {"coal", 1}
    },
    result = "torch"
  },

   {
    type = "boiler",
    name = "torch",
    icon = "__Torches__/graphics/icons/torchicon.png",
    flags = {"placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.2, result = "wood", count = 3},
    fast_replaceable_group = "torches",
    max_health = 25,
    corpse = "small-remnants",
    resistances = 
    {
      --{
       -- type = "fire",
       -- percent = 80
      --}
    },
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    fluid_box =
    {
      base_area = 10.0,
      pipe_connections =
      {
        --{ position = {0, -0.8} },
 --       { position = {1, 0} },
 --       { position = {0, 1} },
 --       { position = {-1, 0} }
      },
      
    },
    energy_consumption = "5kW",
    burner =
    {
      effectivity = 0.2,
      fuel_inventory_size = 1,
      emissions = 0.1 / 10,
      smoke =
      {
        {
          name = "smoke",
          deviation = {0, 0},
          position = {0.1, -1.3},
          frequency = 1
        }
      }
    },
     working_sound =
    {
      sound =
      {
        filename = "__Torches__/sounds/torch.ogg",
        volume = 0.8
      },
      max_sounds_per_type = 3
    },
    structure =
    {
      left =
      {
        filename = "__Torches__/graphics/entity/torch.png",
        priority = "extra-high",
        width = 75,
        height = 80,
        shift = {-0.06,-0.9}
        },
      down =
      {
        filename = "__Torches__/graphics/entity/torch.png",
        priority = "extra-high",
        width = 75,
        height = 80,
        shift = {-0.06,-0.9}
        },
      left_down =
      {
        filename = "__Torches__/graphics/entity/torch.png",
        priority = "extra-high",
        width = 75,
        height = 80,
        shift = {-0.06,-0.9}
        },
      right_down =
      {
        filename = "__Torches__/graphics/entity/torch.png",
        priority = "extra-high",
        width = 75,
        height = 80,
        shift = {-0.06,-0.9}
        },
      left_up =
      {
        filename = "__Torches__/graphics/entity/torch.png",
        priority = "extra-high",
        width = 75,
        height = 80,
        shift = {-0.06,-0.9}
        },
      right_up =
      {
        filename = "__Torches__/graphics/entity/torch.png",
        priority = "extra-high",
        width = 75,
        height = 80,
        shift = {-0.06,-0.9}
        },
      t_down =
      {
        filename = "__Torches__/graphics/entity/torch.png",
        priority = "extra-high",
        width = 75,
        height = 80,
        shift = {-0.06,-0.9}
        
        },
      t_up =
      {
        filename = "__Torches__/graphics/entity/torch.png",
        priority = "extra-high",
        width = 75,
        height = 80,
        shift = {-0.06,-0.9}
      }
    },
    fire =
    {
      left =
      {
        filename = "__Torches__/graphics/entity/torchfire.png",
        priority = "extra-high",
        width = 10,
        height = 22,
        frame_count = 29,
                shift = { 0 , -1.2}
        },
      down =
      {
        filename = "__Torches__/graphics/entity/torchfire.png",
        priority = "extra-high",
        width = 10,
        height = 22,
        frame_count = 29,
                shift = { 0 , -1.2}
        },
      left_down =
      {
        filename = "__Torches__/graphics/entity/torchfire.png",
        priority = "extra-high",
        width = 10,
        height = 22,
        frame_count = 29,
                shift = { 0 , -1.2}
        },
      right_down =
      {
        filename = "__Torches__/graphics/entity/torchfire.png",
        priority = "extra-high",
        width = 10,
        height = 22,
        frame_count = 29,
                shift = { 0 , -1.2}
        },
      left_up =
      {
        filename = "__Torches__/graphics/entity/torchfire.png",
        priority = "extra-high",
        width = 8,
        height = 8,
        frame_count = 10,
                shift = { 0 , -1.2}
        },
      right_up =
      {
        filename = "__Torches__/graphics/entity/torchfire.png",
        priority = "extra-high",
        width = 10,
        height = 22,
        frame_count = 29,
                shift = { 0 , -1.2}
        },
      t_down =
      {
        filename = "__Torches__/graphics/entity/torchfire.png",
        priority = "extra-high",
        width = 10,
        height = 22,
        frame_count = 29,
                shift = { 0 , -1.2}
        },
      t_up =
      {
        filename = "__Torches__/graphics/entity/torchfire.png",
        priority = "extra-high",
        width = 10,
        height = 22,
        frame_count = 29,
        shift = { 0 , -1.2}
        }
    },
    burning_cooldown = 20,
    pictures = pipepictures()
  },



  {
    type = "lamp",
    name = "torchlight",
    icon = "__Torches__/graphics/icons/torchicon.png",
    flags = {"placeable-neutral", "player-creation", "placeable-off-grid", "not-on-map"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "torch"},
    max_health = 55,
    corpse = "small-remnants",
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selectable_in_game = false,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input"
    },
    energy_usage_per_tick = "5KW",
    light = {intensity = 0.6, size = 24, color = {r=0, g=0, b=0, a=0}},
    picture_off =
    {
      filename = "__Torches__/graphics/entity/blank.png",
      width = 50,
      height = 50,
      frame_count = 1,
      line_length = 8,
      shift = {1.34, -0.06}
    },
    picture_on =
    {
      filename = "__Torches__/graphics/entity/blank.png",
      width = 50,
      height = 50,
      frame_count = 1,
      line_length = 8,
      shift = {1.34, -0.06}
    },
  },
  

  {
    type = "generator",
    name = "torchpower",
    icon = "__Torches__/graphics/icons/torchicon.png",
    flags = {"placeable-neutral", "player-creation", "placeable-off-grid", "not-on-map"},
    minable = {mining_time = 1, result = "torch"},
    max_health = 300,
    corpse = "small-remnants",
    effectivity = 1.1,
    fluid_usage_per_tick = 0.001,
    resistances = 
    {
      --{
      --  type = "fire",
      --  percent = 70
      --}
    },
    fast_replaceable_group =  "steam-engine",
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selectable_in_game = false,
    fluid_box =
    {
      base_area = 1,
      pipe_connections =
      {
        --{ position = {0, 0.8} }
      },
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-output"
    },
    horizontal_animation =
    {
      filename = "__Torches__/graphics/entity/blank.png",
      width = 50,
      height = 50,
      frame_count = 1,
      line_length = 8,
      shift = {1.34, -0.06}
    },
    vertical_animation =
    {
      filename = "__Torches__/graphics/entity/blank.png",
      width = 60,
      height = 60,
      frame_count = 1,
      line_length = 8,
      shift = {0.812, 0.031}
    },
    smoke =
    {
      {
        name = "smoke",
        north_position = {0, -1.3},
        east_position = {0, -1.3},
        deviation = {0, 0},
        frequency = 0.001,
        starting_vertical_speed = 0
      }
    },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/steam-engine-90bpm.ogg",
        volume = 0
      },
      match_speed_to_activity = true,
    },
    min_perceived_performance = 0.25,
    performance_to_sound_speedup = 0.5
  },
  
  
 
  {
    type = "electric-pole",
    name = "torchpole",
    icon = "__Torches__/graphics/icons/torchicon.png",
    flags = {"placeable-neutral", "player-creation", "placeable-off-grid", "not-on-map",},
    minable = {hardness = 0.2, mining_time = 0.5, result = "torch"},
    max_health = 150,
    corpse = "medium-remnants",
    resistances = 
    {
      --{
      --  type = "fire",
      --  percent = 100
      --}
    },
    collision_box = {{-0.2, -0.2}, {0.2, 0.2}},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selectable_in_game = false,
    --drawing_box = {{-0.0,-0.0}, {0.0,0.0}},
    maximum_wire_distance = 0,
    supply_area_distance = 0.5,
    pictures =
    {
      filename = "__Torches__/graphics/entity/blank.png",
      priority = "extra-high",
      width = 12,
      height = 12,
      axially_symmetrical = false,
      direction_count = 4,
      shift = {0, 0}
    },
    connection_points =
    {
      {
        shadow =
        {
          copper = {2.7, 0},
          green = {1.8, 0},
          red = {3.6, 0}
        },
        wire =
        {
          copper = {0, -3.1},
          green = {-0.6,-3.1},
          red = {0.6,-3.1}
        }
      },
      {
        shadow =
        {
          copper = {3.1, 0.2},
          green = {2.3, -0.3},
          red = {3.8, 0.6}
        },
        wire =
        {
          copper = {-0.08, -3.15},
          green = {-0.55, -3.5},
          red = {0.3, -2.87}
        }
      },
      {
        shadow =
        {
          copper = {2.9, 0.06},
          green = {3.0, -0.6},
          red = {3.0, 0.8}
        },
        wire =
        {
          copper = {-0.1, -3.1},
          green = {-0.1, -3.55},
          red = {-0.1, -2.8}
        }
      },
      {
        shadow =
        {
          copper = {3.1, 0.2},
          green = {3.8, -0.3},
          red = {2.35, 0.6}
        },
        wire =
        {
          copper = {0, -3.25},
          green = {0.45, -3.55},
          red = {-0.54, -3.0}
        }
      }
    },
    copper_wire_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/copper-wire.png",
      priority = "extra-high-no-scale",
      width = 224,
      height = 46
    },
    green_wire_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/green-wire.png",
      priority = "extra-high-no-scale",
      width = 224,
      height = 46
    },
    radius_visualisation_picture =
    {
      filename = "__Torches__/graphics/entity/blank.png",
      width = 12,
      height = 12
    },
    red_wire_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/red-wire.png",
      priority = "extra-high-no-scale",
      width = 224,
      height = 46
    },
    wire_shadow_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/wire-shadow.png",
      priority = "extra-high-no-scale",
      width = 224,
      height = 46
    }
  },
}
)