if reach_mod and data.raw.player.player.build_distance < 12 then
	data.raw.player.player.build_distance = 12 
	data.raw.player.player.reach_distance = 10 
end