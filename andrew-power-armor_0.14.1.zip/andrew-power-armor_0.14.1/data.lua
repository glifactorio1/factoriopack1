-- entity --
require("prototypes.entity.color-laser")


-- equipment --
require("prototypes.equipment.active-defense-equipment")
require("prototypes.equipment.battery-equipment")
require("prototypes.equipment.energy-shield")
require("prototypes.equipment.exoskeleton")
require("prototypes.equipment.fusion-reactor")
require("prototypes.equipment.night-vision")
require("prototypes.equipment.personal-roboport")
require("prototypes.equipment.solar-panel-equipment")
require("prototypes.equipment.equipment-grid")


-- item --
require("prototypes.item.active-defense-equipment")
require("prototypes.item.battery-equipment")
require("prototypes.item.energy-shield")
require("prototypes.item.exoskeleton")
require("prototypes.item.fusion-reactor")
require("prototypes.item.night-vision")
require("prototypes.item.personal-roboport")
require("prototypes.item.power-armor")
require("prototypes.item.solar-panel-equipment")


-- recipe --
require("prototypes.recipe.active-defense-equipment")
require("prototypes.recipe.battery-equipment")
require("prototypes.recipe.energy-shield")
require("prototypes.recipe.exoskeleton")
require("prototypes.recipe.fusion-reactor")
require("prototypes.recipe.night-vision-equipment")
require("prototypes.recipe.personal-roboport")
require("prototypes.recipe.power-armor")
require("prototypes.recipe.solar-panel-equipment")


-- technology --
require("prototypes.technology.basic-laser-defense")
require("prototypes.technology.battery-equipment")
require("prototypes.technology.energy-shield")
require("prototypes.technology.exoskeleton")
require("prototypes.technology.fusion-reactor")
require("prototypes.technology.night-vision")
require("prototypes.technology.personal-roboport")
require("prototypes.technology.power-armor")
require("prototypes.technology.solar-panel-equipment")
