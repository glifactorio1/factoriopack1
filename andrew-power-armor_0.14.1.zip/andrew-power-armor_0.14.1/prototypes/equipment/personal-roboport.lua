-- personal-roboport-mk2 --
data:extend(
{
   {
    type = "roboport-equipment",
    name = "personal-roboport-mk2",
    take_result = "personal-roboport-mk2",
    categories = {"armor"},
    sprite =
    {
      filename = "__andrew-power-armor__/graphics/equipment/personal-roboport-equipment.png",
      width = 64,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = 2,
      height = 2,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      buffer_capacity = "70MJ",
      input_flow_limit = "7MW",
      usage_priority = "secondary-input"
    },
    charging_energy = "4000kW",
    energy_consumption = "40kW",

    robot_limit = 15,
    construction_radius = 20,
    spawn_and_station_height = 0.4,
    charge_approach_distance = 2.6,

    recharging_animation =
    {
      filename = "__base__/graphics/entity/roboport/roboport-recharging.png",
      priority = "high",
      width = 37,
      height = 35,
      frame_count = 16,
      scale = 1.5,
      animation_speed = 0.5
    },
    recharging_light = {intensity = 0.4, size = 5},
    stationing_offset = {0, -0.6},
    charging_station_shift = {0, 0.5},
    charging_station_count = 4,
    charging_distance = 1.6,
    charging_threshold_distance = 5,
  }
}
)