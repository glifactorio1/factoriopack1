data.raw["battery-equipment"]["battery-mk2-equipment"].energy_source.buffer_capacity = "50MJ"
data.raw["battery-equipment"]["battery-mk2-equipment"].energy_source.input_flow_limit = "500MW"
data.raw["battery-equipment"]["battery-mk2-equipment"].energy_source.output_flow_limit = "500MW"

-- portable-battery-pack-mk3 --
data:extend(
{
  {
    type = "battery-equipment",
    name = "portable-battery-pack-mk3",
    categories = {"armor"},
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/battery-mk3-equipment.png",
      width = 32,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = 1,
      height = 2,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      buffer_capacity = "120MJ",
      input_flow_limit = "1200MW",
      output_flow_limit = "1200MW",
      usage_priority = "terciary"
    }
  },
}
)

-- portable-battery-pack-mk4 --
data:extend(
{
  {
    type = "battery-equipment",
    name = "portable-battery-pack-mk4",
    categories = {"armor"},
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/battery-mk4-equipment.png",
      width = 32,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = 1,
      height = 2,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      buffer_capacity = "300MJ",
      input_flow_limit = "3000MW",
      output_flow_limit = "3000MW",
      usage_priority = "terciary"
    }
  },
}
)

-- portable-battery-pack-mk5 --
data:extend(
{
  {
    type = "battery-equipment",
    name = "portable-battery-pack-mk5",
    categories = {"armor"},
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/battery-mk5-equipment.png",
      width = 32,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = 1,
      height = 2,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      buffer_capacity = "750MJ",
      input_flow_limit = "7500MW",
      output_flow_limit = "7500MW",
      usage_priority = "terciary"
    }
  },
}
)

-- portable-battery-pack-mk6 --
data:extend(
{
  {
    type = "battery-equipment",
    name = "portable-battery-pack-mk6",
    categories = {"armor"},
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/battery-mk6-equipment.png",
      width = 32,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = 1,
      height = 2,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      buffer_capacity = "1800MJ",
      input_flow_limit = "18000MW",
      output_flow_limit = "18000MW",
      usage_priority = "terciary"
    }
  },
}
)