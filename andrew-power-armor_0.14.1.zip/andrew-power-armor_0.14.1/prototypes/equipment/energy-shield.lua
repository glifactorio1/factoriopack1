data.raw["energy-shield-equipment"]["energy-shield-equipment"].max_shield_value = 75
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].energy_per_shield = "2kJ"
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].energy_source.input_flow_limit = "24kW"

-- energy-shield-mk3 --
data:extend(
{
  {
    type = "energy-shield-equipment",
    name = "energy-shield-mk3",
    categories = {"armor"},
    max_shield_value = 300,
    energy_per_shield = "20kJ",
    energy_source =
    {
      type = "electric",
      buffer_capacity = "240kJ",
      input_flow_limit = "480kW",
      usage_priority = "primary-input"
    },
    shape =
    {
      width = 2,
      height = 2,
      type = "full"
    },
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/energy-shield-mk3-equipment.png",
      width = 64,
      height = 64,
      priority = "medium"
    },
  },
}
)

-- energy-shield-mk4 --
data:extend(
{
  {
    type = "energy-shield-equipment",
    name = "energy-shield-mk4",
    categories = {"armor"},
    max_shield_value = 600,
    energy_per_shield = "20kJ",
    energy_source =
    {
      type = "electric",
      buffer_capacity = "300kJ",
      input_flow_limit = "600kW",
      usage_priority = "primary-input"
    },
    shape =
    {
      width = 2,
      height = 2,
      type = "full"
    },
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/energy-shield-mk4-equipment.png",
      width = 64,
      height = 64,
      priority = "medium"
    },
  },
}
)

-- energy-shield-mk5 --
data:extend(
{
  {
    type = "energy-shield-equipment",
    name = "energy-shield-mk5",
    categories = {"armor"},
    max_shield_value = 1200,
    energy_per_shield = "20kJ",
    energy_source =
    {
      type = "electric",
      buffer_capacity = "360kJ",
      input_flow_limit = "720kW",
      usage_priority = "primary-input"
    },
    shape =
    {
      width = 2,
      height = 2,
      type = "full"
    },
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/energy-shield-mk5-equipment.png",
      width = 64,
      height = 64,
      priority = "medium"
    },
  },
}
)

-- energy-shield-mk6 --
data:extend(
{
  {
    type = "energy-shield-equipment",
    name = "energy-shield-mk6",
    categories = {"armor"},
    max_shield_value = 2400,
    energy_per_shield = "20kJ",
    energy_source =
    {
      type = "electric",
      buffer_capacity = "420kJ",
      input_flow_limit = "840kW",
      usage_priority = "primary-input"
    },
    shape =
    {
      width = 2,
      height = 2,
      type = "full"
    },
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/energy-shield-mk6-equipment.png",
      width = 64,
      height = 64,
      priority = "medium"
    },
  },
}
)