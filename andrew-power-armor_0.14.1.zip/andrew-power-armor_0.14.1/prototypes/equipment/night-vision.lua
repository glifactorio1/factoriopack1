-- night-vision-2 --
data:extend(
{
  {
    type = "night-vision-equipment",
    name = "night-vision-2",
    categories = {"armor"},
    sprite = 
    {
      filename = "__base__/graphics/equipment/night-vision-equipment.png",
      width = 96,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = 3,
      height = 2,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      buffer_capacity = "180kJ",
      input_flow_limit = "360kW",
      usage_priority = "primary-input"
    },
    energy_input = "15kW",
    tint = {r = 0.1, g = 0.1, b = 0, a = 0.2}
  },
}
)

-- night-vision-3 --
data:extend(
{
  {
    type = "night-vision-equipment",
    name = "night-vision-3",
    categories = {"armor"},
    sprite = 
    {
      filename = "__base__/graphics/equipment/night-vision-equipment.png",
      width = 96,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = 3,
      height = 2,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      buffer_capacity = "240kJ",
      input_flow_limit = "480kW",
      usage_priority = "primary-input"
    },
    energy_input = "20kW",
    tint = {r = 0.1, g = 0.1, b = 0.1, a = 0.2}
  },
}
)