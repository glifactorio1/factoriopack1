-- portable-fusion-reactor-2 --
data:extend(
{
  {
    type = "generator-equipment",
    name = "portable-fusion-reactor-2",
    categories = {"armor"},
	power = "2000kW",
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/fusion-reactor-equipment-2.png",
      width = 128,
      height = 128,
      priority = "medium"
    },
    shape =
    {
      width = 4,
      height = 4,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "primary-output"
    },
  },
}
)

-- fusion-reactor-equipment-3 --
data:extend(
{
  {
    type = "generator-equipment",
    name = "portable-fusion-reactor-3",
    categories = {"armor"},
    power = "3000kW",
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/fusion-reactor-equipment-3.png",
      width = 128,
      height = 128,
      priority = "medium"
    },
    shape =
    {
      width = 4,
      height = 4,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "primary-output"
    },
  },
}
)

-- fusion-reactor-equipment-4 --
data:extend(
{
  {
    type = "generator-equipment",
    name = "portable-fusion-reactor-4",
    categories = {"armor"},
    power = "4000kW",
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/fusion-reactor-equipment-4.png",
      width = 128,
      height = 128,
      priority = "medium"
    },
    shape =
    {
      width = 4,
      height = 4,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "primary-output"
    },
  },
}
)
