-- exoskeleton-equipment-2 --
data:extend(
{
  {
    type = "movement-bonus-equipment",
    name = "exoskeleton-equipment-2",
    categories = {"armor"},
    energy_consumption = "300kW",
    movement_bonus = 0.45,
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/basic-exoskeleton-equipment.png",
      width = 64,
      height = 128,
      priority = "medium"
    },
    shape =
    {
      width = 2,
      height = 4,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      buffer_capacity = "240kJ",
      input_flow_limit = "480kW",
      usage_priority = "secondary-input"
    },
  },
}
)

-- exoskeleton-equipment-3 --
data:extend(
{
  {
    type = "movement-bonus-equipment",
    name = "exoskeleton-equipment-3",
    categories = {"armor"},
    energy_consumption = "400kW",
    movement_bonus = 0.6,	
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/basic-exoskeleton-equipment.png",
      width = 64,
      height = 128,
      priority = "medium"
    },
    shape =
    {
      width = 2,
      height = 4,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      buffer_capacity = "300kJ",
      input_flow_limit = "600kW",
      usage_priority = "secondary-input"
    },
  },
}
)