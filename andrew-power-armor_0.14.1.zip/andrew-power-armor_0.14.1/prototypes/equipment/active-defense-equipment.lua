function personal_laser_defense(name, sprite, buffer_capacity, energy_consumption, projectile, damage_modifier, cooldown, range)
return
  {
    type = "active-defense-equipment",
    name = name,
    categories = {"armor"},
    sprite = 
    {
      filename = sprite,
      width = 64,
      height = 96,
      priority = "medium"
    },
    shape =
    {
      width = 2,
      height = 3,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      buffer_capacity = buffer_capacity
    },
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "electric",
      cooldown = cooldown,
      damage_modifier = damage_modifier,
      projectile_center = {0, 0},
      projectile_creation_distance = 0.6,
      range = range,
      sound = make_laser_sounds(),
      ammo_type =
      {
        type = "projectile",
        category = "electric",
        energy_consumption = energy_consumption,
        projectile = projectile,
        speed = 1,
        action = 
        {
          {
            type = "direct",
            action_delivery =
            {
              {
                type = "projectile",
                projectile = projectile,
                starting_speed = 0.28
              }
            }
          }
        }
      }
    },
    automatic = true
  }
end

data:extend(
{
--  personal_laser_defense(name, sprite, buffer_capacity, energy_consumption, projectile, damage_modifier, cooldown, range)
  personal_laser_defense("personal-laser-defense-2", "__andrew-power-armor__/graphics/equipment/basic-laser-defense-equipment-2.png", "26kJ", "12500J", "green-laser", 1.5, 15, 16),
  personal_laser_defense("personal-laser-defense-3", "__andrew-power-armor__/graphics/equipment/basic-laser-defense-equipment-3.png", "46kJ", "15kJ", "blue-laser", 2.1, 12, 17),
  personal_laser_defense("personal-laser-defense-4", "__andrew-power-armor__/graphics/equipment/basic-laser-defense-equipment-4.png", "71kJ", "17500J", "purple-laser", 2.8, 10, 18),
  personal_laser_defense("personal-laser-defense-5", "__andrew-power-armor__/graphics/equipment/basic-laser-defense-equipment-5.png", "101kJ", "20kJ", "yellow-laser", 3.6, 8.5, 19),
  personal_laser_defense("personal-laser-defense-6", "__andrew-power-armor__/graphics/equipment/basic-laser-defense-equipment-6.png", "136kJ", "22500J", "white-laser", 4.5, 7.5, 20),
}
)
