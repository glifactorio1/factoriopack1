data:extend(
{
  {
    type = "equipment-grid",
    name = "1-equipment-grid",
    width = 12,
    height = 12,
    equipment_categories = {"armor"}
  },
  {
    type = "equipment-grid",
    name = "2-equipment-grid",
    width = 14,
    height = 14,
    equipment_categories = {"armor"}
  },
  {
    type = "equipment-grid",
    name = "3-equipment-grid",
    width = 16,
    height = 16,
    equipment_categories = {"armor"}
  },
  {
    type = "equipment-grid",
    name = "4-equipment-grid",
    width = 18,
    height = 18,
    equipment_categories = {"armor"}
  },
}
)
