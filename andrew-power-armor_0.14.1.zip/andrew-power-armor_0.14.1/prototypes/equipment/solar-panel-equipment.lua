-- portable-solar-panel-2 --
data:extend(
{
  {
    type = "solar-panel-equipment",
    name = "portable-solar-panel-2",
    categories = {"armor"},
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/solar-panel-equipment-2.png",
      width = 32,
      height = 32,
      priority = "medium"
    },
    shape =
    {
      width = 1,
      height = 1,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "primary-output"
    },
    power = "15kW"
  },
}
)

-- portable-solar-panel-3 --
data:extend(
{
  {
    type = "solar-panel-equipment",
    name = "portable-solar-panel-3",
    categories = {"armor"},
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/solar-panel-equipment-3.png",
      width = 32,
      height = 32,
      priority = "medium"
    },
    shape =
    {
      width = 1,
      height = 1,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "primary-output"
    },
    power = "25kW"
  },
}
)

-- portable-solar-panel-4 --
data:extend(
{
  {
    type = "solar-panel-equipment",
    name = "portable-solar-panel-4",
    categories = {"armor"},
    sprite = 
    {
      filename = "__andrew-power-armor__/graphics/equipment/solar-panel-equipment-4.png",
      width = 32,
      height = 32,
      priority = "medium"
    },
    shape =
    {
      width = 1,
      height = 1,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "primary-output"
    },
    power = "40kW"
  },
}
)
