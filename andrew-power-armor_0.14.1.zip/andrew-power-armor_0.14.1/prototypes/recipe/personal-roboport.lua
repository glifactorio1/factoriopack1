-- personal-roboport-mk2 --
data:extend(
{
  {
    type = "recipe",
    name = "personal-roboport-mk2",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "personal-roboport-mk2",
	result_count = 1,
    ingredients =
    {
      {"advanced-processing-unit", 10},
      {"steel-gear-wheel", 30},
	  {"steel-bearing", 20},
      {"steel-plate", 20},
      {"battery", 45},
    },
  },
}
)
