-- power-armor-mk3 --
data:extend(
{
   {
    type = "recipe",
    name = "power-armor-mk3",
    category = "crafting",
    enabled = false,
    energy_required = 30,
	result = "power-armor-mk3",
	result_count = 1,
    ingredients =
    {
      {"power-armor-mk2", 1},
	  {"advanced-processing-unit", 25},
	  {"speed-module-3", 5},
	  {"effectivity-module-3", 5},
	  {"productivity-module-3", 5}
    },
  },
}
)

-- power-armor-mk4 --
data:extend(
{
  {
    type = "recipe",
    name = "power-armor-mk4",
    category = "crafting",
    enabled = false,
    energy_required = 30,
	result = "power-armor-mk4",
	result_count = 1,
    ingredients =
    {
      {"power-armor-mk3", 1},
	  {"advanced-processing-unit", 25},
	  {"speed-module-3", 10},
	  {"effectivity-module-3", 10},
	  {"productivity-module-3", 10}
    },
  },
 }
)

-- iron-man-armor --
data:extend(
{
 {
    type = "recipe",
    name = "iron-man-armor",
    category = "crafting",
    enabled = false,
    energy_required = 30,
	result = "iron-man-armor",
	result_count = 1,
    ingredients =
    {
      {"power-armor-mk4", 1},
	  {"computer-chip", 20},
	  {"speed-module-3", 15},
	  {"effectivity-module-3", 15},
	  {"productivity-module-3", 15}
    },  
  },
}
)

-- iron-man-armor-mk2 --
data:extend(
{
 {
    type = "recipe",
    name = "iron-man-armor-mk2",
    category = "crafting",
    enabled = false,
    energy_required = 30,
	result = "iron-man-armor-mk2",
	result_count = 1,
    ingredients =
    {
      {"iron-man-armor", 1},
	  {"advanced-computer-chip", 30},
	  {"speed-module-3", 20},
	  {"effectivity-module-3", 20},
	  {"productivity-module-3", 20}
    },  
  },
}
)