-- portable-battery-pack-mk3 --
data:extend(
{
  {
    type = "recipe",
    name = "portable-battery-pack-mk3",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "portable-battery-pack-mk3",
    result_count = 1,
    ingredients =
    {
      {"battery-mk2-equipment", 2},
	  {"processing-unit", 5},
    },
  },
}
)

-- portable-battery-pack-mk4 --
data:extend(
{
  {
    type = "recipe",
    name = "portable-battery-pack-mk4",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "portable-battery-pack-mk4",
    ingredients =
    {
      {"portable-battery-pack-mk3", 2},
      {"advanced-processing-unit", 5},
    },
  },
}
)

-- portable-battery-pack-mk5 --
data:extend(
{
  {
    type = "recipe",
    name = "portable-battery-pack-mk5",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "portable-battery-pack-mk5",
    result_count = 1,
    ingredients =
    {
      {"portable-battery-pack-mk4", 2},
	  {"computer-chip", 5},
    },
  },
}
)

-- portable-battery-pack-mk6 --
data:extend(
{
  {
    type = "recipe",
    name = "portable-battery-pack-mk6",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "portable-battery-pack-mk6",
    result_count = 1,
    ingredients =
    {
      {"portable-battery-pack-mk5", 2},
      {"advanced-computer-chip", 5},
    },
  },
}
)
