-- night-vision-2 --
data:extend(
{
  {
    type = "recipe",
    name = "night-vision-2",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "night-vision-2",
    result_count = 1,
    ingredients =
    {
      {"night-vision-equipment", 1},
      {"processing-unit", 5},
    },
  },
}
)

-- night-vision-3 --
data:extend(
{
  {
    type = "recipe",
    name = "night-vision-3",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "night-vision-3",
    result_count = 1,
    ingredients =
    {
      {"night-vision-2", 1},
      {"advanced-processing-unit", 5},
      {"alien-artifact", 10},
    },
  },
}
)
