-- personal-laser-defense-2 --
data:extend(
{
  {
    type = "recipe",
    name = "personal-laser-defense-2",
    enabled = false,
    energy_required = 10,
	result = "personal-laser-defense-2",
    result_count = 1,
    ingredients =
    {
      {"personal-laser-defense-equipment", 1},
      {"steel-plate", 5},
      {"advanced-circuit", 5},
    },
  },
}
)

-- personal-laser-defense-3 --
data:extend(
{
  {
    type = "recipe",
    name = "personal-laser-defense-3",
    enabled = false,
    energy_required = 10,
	result = "personal-laser-defense-3",
    ingredients =
    {
      {"personal-laser-defense-2", 1},
      {"steel-plate", 5},
      {"processing-unit", 5},
    },
  },
}
)

-- personal-laser-defense-4 --
data:extend(
{
  {
    type = "recipe",
    name = "personal-laser-defense-4",
    enabled = false,
    energy_required = 10,
    result = "personal-laser-defense-4",
    result_count = 1,
    ingredients =
    {
      {"personal-laser-defense-3", 1},
      {"processing-unit", 5},
    },
  },
}
)

-- personal-laser-defense-5 --
data:extend(
{
  {
    type = "recipe",
    name = "personal-laser-defense-5",
    enabled = false,
    energy_required = 10,
    result = "personal-laser-defense-5",
    result_count = 1,
    ingredients =
    {
      {"personal-laser-defense-4", 1},
      {"advanced-processing-unit", 5},
    },
  },
}
)

-- personal-laser-defense-6 --
data:extend(
{
  {
    type = "recipe",
    name = "personal-laser-defense-6",
    enabled = false,
    energy_required = 10,
    result = "personal-laser-defense-6",
    result_count = 1,
    ingredients =
    {
      {"personal-laser-defense-5", 1},
      {"computer-chip", 5},
    },
  },
}
)
