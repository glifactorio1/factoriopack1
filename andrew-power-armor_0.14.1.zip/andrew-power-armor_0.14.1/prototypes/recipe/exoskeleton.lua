-- exoskeleton-equipment-2 --
data:extend(
{
  {
    type = "recipe",
    name = "exoskeleton-equipment-2",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "exoskeleton-equipment-2",
	result_count = 1,
    ingredients =
    {
      {"exoskeleton-equipment", 1},
      {"advanced-processing-unit", 10},
      {"steel-gear-wheel", 30},
      {"steel-bearing", 30},
      {"steel-plate", 20},
    },
  },
}
)

-- exoskeleton-equipment-3 --
data:extend(
{
  {
    type = "recipe",
    name = "exoskeleton-equipment-3",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "exoskeleton-equipment-3",	
	result_count = 1,
    ingredients =
    {
      {"exoskeleton-equipment-2", 1},
      {"advanced-processing-unit", 10},
      {"steel-gear-wheel", 30},
      {"steel-bearing", 30},
      {"alien-artifact", 10},
    },
  },
}
)