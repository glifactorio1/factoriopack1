-- portable-fusion-reactor-2 --
data:extend(
{
  {
    type = "recipe",
    name = "portable-fusion-reactor-2",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "portable-fusion-reactor-2",
	result_count = 1,
    ingredients =
    {
      {"fusion-reactor-equipment", 1},
      {"advanced-processing-unit", 50},
      {"effectivity-module-3", 2},
      {"speed-module-3", 2},
      {"productivity-module-3", 2},
    },
  },
}
)

-- portable-fusion-reactor-3 --
data:extend(
{
  {
    type = "recipe",
    name = "portable-fusion-reactor-3",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "portable-fusion-reactor-3",	
	result_count = 1,
    ingredients =
    {
      {"portable-fusion-reactor-2", 1},
      {"advanced-processing-unit", 50},
      {"effectivity-module-3", 2},
      {"speed-module-3", 2},
      {"productivity-module-3", 2},
    },
  },
}
)

-- portable-fusion-reactor-4 --
data:extend(
{
  {
    type = "recipe",
    name = "portable-fusion-reactor-4",
    category = "crafting",
    enabled = "false",
    energy_required = 10,
    result = "portable-fusion-reactor-4",	
	result_count = 1,
    ingredients =
    {
      {"portable-fusion-reactor-3", 1},
      {"advanced-processing-unit", 50},
      {"effectivity-module-3", 2},
      {"speed-module-3", 2},
      {"productivity-module-3", 2},
    },
  },
}
)