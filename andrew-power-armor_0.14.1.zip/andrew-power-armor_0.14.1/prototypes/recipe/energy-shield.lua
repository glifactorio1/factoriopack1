-- energy-shield-mk3 --
data:extend(
{
  {
    type = "recipe",
    name = "energy-shield-mk3",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "energy-shield-mk3",
    ingredients =
    {
      {"energy-shield-mk2-equipment", 2},
      {"advanced-processing-unit", 5},
      {"alien-artifact", 10},
      {"productivity-module-2", 1},
    },
  },
}
)

-- energy-shield-mk4 --
data:extend(
{
  {
    type = "recipe",
    name = "energy-shield-mk4",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "energy-shield-mk4",
    ingredients =
    {
      {"energy-shield-mk3", 2},
      {"advanced-processing-unit", 5},
      {"effectivity-module-3", 1},
      {"productivity-module-3", 1},

    },
  },
}
)

-- energy-shield-mk5 --
data:extend(
{
  {
    type = "recipe",
    name = "energy-shield-mk5",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "energy-shield-mk5",
    ingredients =
    {
      {"energy-shield-mk4", 2},
      {"advanced-processing-unit", 5},
      {"effectivity-module-3", 1},
      {"productivity-module-3", 1},
    },
  },
}
)

-- energy-shield-mk6 --
data:extend(
{
  {
    type = "recipe",
    name = "energy-shield-mk6",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "energy-shield-mk6",
    ingredients =
    {
      {"energy-shield-mk5", 2},
      {"advanced-processing-unit", 5},
      {"effectivity-module-3", 1},
      {"productivity-module-3", 1},
    },
  },
}
)
