-- portable-solar-panel-2 --
data:extend(
{
  {
    type = "recipe",
    name = "portable-solar-panel-2",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "portable-solar-panel-2",
    result_count = 1,
    ingredients =
    {
      {"solar-panel-equipment", 1},
      {"advanced-circuit", 5},
    },
  },
}
)

-- portable-solar-panel-3 --
data:extend(
{
  {
    type = "recipe",
    name = "portable-solar-panel-3",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "portable-solar-panel-3",
    result_count = 1,
    ingredients =
    {
      {"portable-solar-panel-2", 1},
      {"advanced-processing-unit", 5},
    },
  },
}
)

-- portable-solar-panel-4 --
data:extend(
{
  {
    type = "recipe",
    name = "portable-solar-panel-4",
    category = "crafting",
    enabled = false,
    energy_required = 10,
    result = "portable-solar-panel-4",
    result_count = 1,
    ingredients =
    {
      {"portable-solar-panel-3", 1},
      {"alien-artifact", 10},
      {"computer-chip", 5},
    },
  },
}
)