-- exoskeleton-equipment-2 --
data:extend(
{
  {
    type = "technology",
    name = "exoskeleton-equipment-2",
    icon = "__andrew-power-armor__/graphics/technology/basic-exoskeleton-equipment.png",
    upgrade = true,
    order = "g-h-b",
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "exoskeleton-equipment-2"
      }
    },
    prerequisites =
    {
	  "exoskeleton-equipment",
      "advanced-electronics-3"
    },
    unit =
    {
      count = 75,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- exoskeleton-equipment-3 --
data:extend(
{
  {
    type = "technology",
    name = "exoskeleton-equipment-3",
    icon = "__andrew-power-armor__/graphics/technology/basic-exoskeleton-equipment.png",
    upgrade = true,
    order = "g-h-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "exoskeleton-equipment-3"
      }
    },
    prerequisites =
    {
      "exoskeleton-equipment-2"
    },
    unit =
    {
      count = 100,
      time = 30,
      ingredients = science4()
    },
  },
}
)
