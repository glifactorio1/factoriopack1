data.raw.technology["battery-equipment"].icon = "__andrew-power-armor__/graphics/technology/battery-equipment.png"
data.raw.technology["battery-equipment"].icon_size = 128

data.raw.technology["battery-mk2-equipment"].icon = "__andrew-power-armor__/graphics/technology/battery-mk2-equipment.png"
data.raw.technology["battery-mk2-equipment"].icon_size = 128

-- portable-battery-pack-3 --
data:extend(
{
  {
    type = "technology",
    name = "portable-battery-pack-3",
    icon = "__andrew-power-armor__/graphics/technology/battery-mk3-equipment.png",
    upgrade = true,
	icon_size = 128,
    order = "g-i-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "portable-battery-pack-mk3"
      }
    },
    prerequisites =
    {
      "battery-mk2-equipment",
    },
    unit =
    {
      count = 150,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- portable-battery-pack-4 --
data:extend(
{
  {
    type = "technology",
    name = "portable-battery-pack-4",
    icon = "__andrew-power-armor__/graphics/technology/battery-mk4-equipment.png",
    upgrade = true,
	icon_size = 128,
    order = "g-i-d",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "portable-battery-pack-mk4"
      }
    },
    prerequisites =
    {
      "portable-battery-pack-3",
      "advanced-electronics-3"
    },
    unit =
    {
      count = 150,
      time = 45,
      ingredients = science4()
    },
  },
}
)

-- portable-battery-pack-5 --
data:extend(
{
  {
    type = "technology",
    name = "portable-battery-pack-5",
    icon = "__andrew-power-armor__/graphics/technology/battery-mk5-equipment.png",
    upgrade = true,
	icon_size = 128,
    order = "g-i-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "portable-battery-pack-mk5"
      }
    },
    prerequisites =
    {
      "portable-battery-pack-4",
    },
    unit =
    {
      count = 200,
      time = 45,
      ingredients = science4()
    },
  },
}
)

-- portable-battery-pack-6 --
data:extend(
{
  {
    type = "technology",
    name = "portable-battery-pack-6",
    icon = "__andrew-power-armor__/graphics/technology/battery-mk6-equipment.png",
    upgrade = true,
	icon_size = 128,
    order = "g-i-f",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "portable-battery-pack-mk6"
      }
    },
    prerequisites =
    {
      "portable-battery-pack-5"
    },
    unit =
    {
      count = 250,
      time = 45,
      ingredients = science4()
    },
  },
}
)