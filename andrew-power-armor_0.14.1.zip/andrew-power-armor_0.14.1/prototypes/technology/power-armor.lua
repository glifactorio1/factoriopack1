-- power-armor-3 --
data:extend(
{
   {
    type = "technology",
    name = "power-armor-3",
    icon = "__andrew-power-armor__/graphics/technology/power-armor-mk3.png",
    upgrade = true,
    order = "g-c-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "power-armor-mk3"
      }
    },
    prerequisites =
    {
      "power-armor-2",
    },
    unit =
    {
      count = 250,
	  time = 45,
      ingredients = science4()
    },
  },
}
)

-- power-armor-4 --
data:extend(
{
  {
    type = "technology",
    name = "power-armor-4",
    icon = "__andrew-power-armor__/graphics/technology/power-armor-mk4.png",
    upgrade = true,
    order = "g-c-d",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "power-armor-mk4"
      }
    },
    prerequisites =
    {
      "power-armor-3",
    },
    unit =
    {
      count = 300,
	  time = 45,
      ingredients = science4()
    },
  },
}
)

-- power-armor-5 --
data:extend(
{  
  {
    type = "technology",
    name = "power-armor-5",
    icon = "__andrew-power-armor__/graphics/technology/iron-man-armor.png",
    upgrade = true,
    order = "g-c-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "iron-man-armor"
      }
    },
    prerequisites =
    {
      "power-armor-4",
    },
    unit =
    {
      count = 500,
	  time = 60,
      ingredients = science4()
    },
  },
}
)

-- power-armor-5 --
data:extend(
{  
  {
    type = "technology",
    name = "power-armor-6",
    icon = "__andrew-power-armor__/graphics/technology/iron-man-armor-mk2.png",
    upgrade = true,
    order = "g-c-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "iron-man-armor-mk2"
      }
    },
    prerequisites =
    {
      "power-armor-5",
    },
    unit =
    {
      count = 600,
	  time = 60,
      ingredients = science4()
    },
  },
}
)

