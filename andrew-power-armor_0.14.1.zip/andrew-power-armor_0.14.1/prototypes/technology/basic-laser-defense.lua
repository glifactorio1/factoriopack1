-- personal-laser-defense-2 --
data:extend(
{
  {
    type = "technology",
    name = "personal-laser-defense-2",
    icon = "__andrew-power-armor__/graphics/technology/basic-laser-defense-equipment-2.png",
	upgrade = true,
    order = "g-m-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-laser-defense-2"
      }
    },
    prerequisites =
    {
      "personal-laser-defense-equipment",
    },
    unit =
    {
      count = 150,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- personal-laser-defense-3 --
data:extend(
{
  {
    type = "technology",
    name = "personal-laser-defense-3",
    icon = "__andrew-power-armor__/graphics/technology/basic-laser-defense-equipment-3.png",
	upgrade = true,
    order = "g-m-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-laser-defense-3"
      }
    },
    prerequisites =
    {
      "personal-laser-defense-2",
    },
    unit =
    {
      count = 250,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- personal-laser-defense-4 --
data:extend(
{

  {
    type = "technology",
    name = "personal-laser-defense-4",
    icon = "__andrew-power-armor__/graphics/technology/basic-laser-defense-equipment-4.png",
    order = "g-m-c",
    upgrade = true,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-laser-defense-4"
      }
    },
    prerequisites =
    {
      "personal-laser-defense-3",
    },
    unit =
    {
      count = 300,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- personal-laser-defense-5 --
data:extend(
{

  {
    type = "technology",
    name = "personal-laser-defense-5",
    icon = "__andrew-power-armor__/graphics/technology/basic-laser-defense-equipment-5.png",
    upgrade = true,
    order = "g-m-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-laser-defense-5"
      }
    },
    prerequisites =
    {
      "personal-laser-defense-4",
    },
    unit =
    {
      count = 300,
      time = 30,
      ingredients = science4()
    },
  },
}
)

-- personal-laser-defense-6 --
data:extend(
{

  {
    type = "technology",
    name = "personal-laser-defense-6",
    icon = "__andrew-power-armor__/graphics/technology/basic-laser-defense-equipment-6.png",
	upgrade = true,
    order = "g-m-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-laser-defense-6"
      }
    },
    prerequisites =
    {
      "personal-laser-defense-5",
      "advanced-electronics-3",
    },
    unit =
    {
      count = 350,
      time = 30,
      ingredients = science4()
    },
  },
}
)