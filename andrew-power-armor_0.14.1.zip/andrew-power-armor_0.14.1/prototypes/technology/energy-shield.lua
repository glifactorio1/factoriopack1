-- energy-shield-3 --
data:extend(
{
  {
    type = "technology",
    name = "energy-shield-3",
    icon = "__andrew-power-armor__/graphics/technology/energy-shield-mk3-equipment.png",
    upgrade = true,
    order = "g-e-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "energy-shield-mk3"
      }
    },
    prerequisites =
    {
      "energy-shield-mk2-equipment",
      "productivity-module-2",
      "advanced-electronics-3"
    },
    unit =
    {
      count = 150,
      time = 30,
      ingredients = science4()
    },
  },
}
)

-- energy-shield-4 --
data:extend(
{
  {
    type = "technology",
    name = "energy-shield-4",
    icon = "__andrew-power-armor__/graphics/technology/energy-shield-mk4-equipment.png",
    upgrade = true,
    order = "g-e-d",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "energy-shield-mk4"
      }
    },
    prerequisites =
    {
      "energy-shield-3"
    },
    unit =
    {
      count = 200,
      time = 45,
      ingredients = science4()
    },
  },
}
)

-- energy-shield-5 --
data:extend(
{
  {
    type = "technology",
    name = "energy-shield-5",
    icon = "__andrew-power-armor__/graphics/technology/energy-shield-mk5-equipment.png",
    upgrade = true,
    order = "g-e-e",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "energy-shield-mk5"
      }
    },
    prerequisites =
    {
      "energy-shield-4"
    },
    unit =
    {
      count = 250,
      time = 45,
      ingredients = science4()
    },
  },
}
)

-- energy-shield-6 --
data:extend(
{
  {
    type = "technology",
    name = "energy-shield-6",
    icon = "__andrew-power-armor__/graphics/technology/energy-shield-mk6-equipment.png",
    upgrade = true,
    order = "g-e-f",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "energy-shield-mk6"
      }
    },
    prerequisites =
    {
      "energy-shield-5"
    },
    unit =
    {
      count = 300,
      time = 45,
      ingredients = science4()
    },
  },
}
)