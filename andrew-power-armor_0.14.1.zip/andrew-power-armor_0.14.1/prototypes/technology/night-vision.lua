-- night-vision-2 --
data:extend(
{
  {
    type = "technology",
    name = "night-vision-2",
    icon = "__base__/graphics/technology/night-vision-equipment.png",
    upgrade = true,
    order = "g-g-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "night-vision-2"
      }
    },
    prerequisites =
    {
      "night-vision-equipment",
      "advanced-electronics-2",
    },
    unit =
    {
      count = 50,
      time = 30,
      ingredients = science3()
    },
  },
}
)

-- night-vision-3 --
data:extend(
{
  {
    type = "technology",
    name = "night-vision-3",
    icon = "__base__/graphics/technology/night-vision-equipment.png",
    upgrade = true,
    order = "g-g-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "night-vision-3"
      }
    },
    prerequisites =
    {
      "night-vision-2",
      "advanced-electronics-3",
    },
    unit =
    {
      count = 50,
      time = 45,
      ingredients = science4()
    },
  },
}
)