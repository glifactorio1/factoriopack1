-- personal-roboport-2 --
data:extend(
{
  {
    type = "technology",
    name = "personal-roboport-2",
    icon = "__base__/graphics/technology/personal-roboport-equipment.png",
	upgrade = true,
    order = "c-k-d-zz-2",	
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-roboport-mk2"
      },
    },
    prerequisites = 
	{ 
	  "personal-roboport-equipment", 
	},
    unit = {
      count = 75,
      time = 30, 
      ingredients = science3()
    },
  }
}
)