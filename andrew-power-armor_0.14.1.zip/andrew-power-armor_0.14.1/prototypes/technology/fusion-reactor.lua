-- portable-fusion-reactor-2 --
data:extend(
{
  {
    type = "technology",
    name = "portable-fusion-reactor-2",
    icon = "__andrew-power-armor__/graphics/technology/fusion-reactor-equipment-2.png",
    upgrade = true,
	icon_size = 128,
    order = "g-l-b",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "portable-fusion-reactor-2"
      }
    },
    prerequisites =
    {
      "fusion-reactor-equipment",
      "advanced-electronics-3",
    },
    unit =
    {
      count = 250,
      time = 45,
      ingredients = science4()
    },
  },
}
)

-- portable-fusion-reactor-3 --
data:extend(
{
  {
    type = "technology",
    name = "portable-fusion-reactor-3",
    icon = "__andrew-power-armor__/graphics/technology/fusion-reactor-equipment-3.png",
    upgrade = true,
	icon_size = 128,
    order = "g-l-c",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "portable-fusion-reactor-3"
      }
    },
    prerequisites = 
	{
	  "portable-fusion-reactor-2"
	},
    unit =
    {
      count = 300,
      time = 45,
      ingredients = science4()
    },
  },
}
)

-- portable-fusion-reactor-4 --
data:extend(
{
  {
    type = "technology",
    name = "portable-fusion-reactor-4",
    icon = "__andrew-power-armor__/graphics/technology/fusion-reactor-equipment-4.png",
    upgrade = true,
	icon_size = 128,
    order = "g-l-d",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "portable-fusion-reactor-4"
      }
    },
    prerequisites = 
	{
	 "portable-fusion-reactor-3"
	},
    unit =
    {
      count = 350,
      time = 45,
      ingredients = science4()
    },
  },
}
)
