function laseranimation(scale, tint)
  return
  {
    filename = "__andrew-power-armor__/graphics/entities/projectiles/laser.png",
    scale = scale,
    tint = tint,
    frame_count = 1,
    width = 7,
    height = 14,
    priority = "high"
  }
end

function laseraction(effectname, damage)
  return
  {
    type = "direct",
    action_delivery =
    {
      type = "instant",
      target_effects =
      {
        {
          type = "create-entity",
          entity_name = effectname
        },
        {
          type = "damage",
          damage = {amount = damage, type = "laser"}
        }
      }
    }
  }
end

function laserbubbleanimation(scale, tint)
  return
  {
    {
      filename = "__andrew-power-armor__/graphics/entities/laser-bubble.png",
      scale = scale,
      tint = tint,
      priority = "extra-high",
      width = 8,
      height = 8,
      frame_count = 5
    }
  }
end


data:extend(
{
  {
    type = "projectile",
    name = "blue-laser",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action = laseraction("laser-bubble-sapphire", 5),
    light = {intensity = 0.5, size = 10},
    animation = laseranimation(1, {r=0.2, g=0.6, b=1, a=1}),
    speed = 0.15
  },

  {
    type = "projectile",
    name = "green-laser",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action = laseraction("laser-bubble-emerald", 5),
    light = {intensity = 0.5, size = 10},
    animation = laseranimation(1, {r=0.3, g=1, b=0.3, a=1}),
    speed = 0.15
  },

  {
    type = "projectile",
    name = "purple-laser",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action = laseraction("laser-bubble-amethyst", 5),
    light = {intensity = 0.5, size = 10},
    animation = laseranimation(1, {r=0.8, g=0.2, b=1, a=1}),
    speed = 0.15
  },

  {
    type = "projectile",
    name = "yellow-laser",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action = laseraction("laser-bubble-topaz", 5),
    light = {intensity = 0.5, size = 10},
    animation = laseranimation(1, {r=1, g=0.8, b=0.2, a=1}),
    speed = 0.15
  },

  {
    type = "projectile",
    name = "white-laser",
    flags = {"not-on-map"},
    acceleration = 0.005,
    action = laseraction("laser-bubble-diamond", 5),
    light = {intensity = 0.5, size = 10},
    animation = laseranimation(1, {r=1, g=1, b=1, a=1}),
    speed = 0.15
  },
}
)



data:extend(
{
  {
    type = "explosion",
    name = "laser-bubble-sapphire",
    flags = {"not-on-map"},
    animation_speed = 1,
    animations = laserbubbleanimation(1, {r=0.2, g=0.6, b=1, a=1}),
    light = {intensity = 1, size = 10},
    smoke = "smoke-fast",
    smoke_count = 2,
    smoke_slow_down_factor = 1
  },

  {
    type = "explosion",
    name = "laser-bubble-emerald",
    flags = {"not-on-map"},
    animation_speed = 1,
    animations = laserbubbleanimation(1, {r=0.3, g=1, b=0.3, a=1}),
    light = {intensity = 1, size = 10},
    smoke = "smoke-fast",
    smoke_count = 2,
    smoke_slow_down_factor = 1
  },

  {
    type = "explosion",
    name = "laser-bubble-amethyst",
    flags = {"not-on-map"},
    animation_speed = 1,
    animations = laserbubbleanimation(1, {r=1, g=0.2, b=1, a=1}),
    light = {intensity = 1, size = 10},
    smoke = "smoke-fast",
    smoke_count = 2,
    smoke_slow_down_factor = 1
  },

  {
    type = "explosion",
    name = "laser-bubble-topaz",
    flags = {"not-on-map"},
    animation_speed = 1,
    animations = laserbubbleanimation(1, {r=1, g=0.6, b=0.2, a=1}),
    light = {intensity = 1, size = 10},
    smoke = "smoke-fast",
    smoke_count = 2,
    smoke_slow_down_factor = 1
  },

  {
    type = "explosion",
    name = "laser-bubble-diamond",
    flags = {"not-on-map"},
    animation_speed = 1,
    animations = laserbubbleanimation(1, {r=1, g=1, b=1, a=1}),
    light = {intensity = 1, size = 10},
    smoke = "smoke-fast",
    smoke_count = 2,
    smoke_slow_down_factor = 1
  },
}
)