-- exoskeleton-equipment-2 --
data:extend(
{
  {
    type = "item",
    name = "exoskeleton-equipment-2",
    icon = "__andrew-power-armor__/graphics/icons/basic-exoskeleton-equipment.png",
    placed_as_equipment_result = "exoskeleton-equipment-2",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-util",
    order = "a-b",
    stack_size = 10
  },
}
)

-- exoskeleton-equipment-3 --
data:extend(
{
  {
    type = "item",
    name = "exoskeleton-equipment-3",
    icon = "__andrew-power-armor__/graphics/icons/basic-exoskeleton-equipment.png",
    placed_as_equipment_result = "exoskeleton-equipment-3",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-util",
    order = "a-c",
    stack_size = 10
  },
}
)