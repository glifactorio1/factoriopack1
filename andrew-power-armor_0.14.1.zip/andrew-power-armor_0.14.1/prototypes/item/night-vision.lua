-- night-vision-2 --
data:extend(
{
  {
    type = "item",
    name = "night-vision-2",
    icon = "__base__/graphics/icons/night-vision-equipment.png",
    placed_as_equipment_result = "night-vision-2",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-util",
    order = "c-b",
    stack_size = 20
  },
}
)

-- night-vision-3 --
data:extend(
{
  {
    type = "item",
    name = "night-vision-3",
    icon = "__base__/graphics/icons/night-vision-equipment.png",
    placed_as_equipment_result = "night-vision-3",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-util",
    order = "c-c",
    stack_size = 20
  },
}
)