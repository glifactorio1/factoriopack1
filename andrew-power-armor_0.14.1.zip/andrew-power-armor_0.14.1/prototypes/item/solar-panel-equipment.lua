-- portable-solar-panel-2 --
data:extend(
{
  {
    type = "item",
    name = "portable-solar-panel-2",
    icon = "__andrew-power-armor__/graphics/icons/solar-panel-equipment-2.png",
    placed_as_equipment_result = "portable-solar-panel-2",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-power",
    order = "a-b",
    stack_size = 20
  },
}
)

-- portable-solar-panel-3 --
data:extend(
{
  {
    type = "item",
    name = "portable-solar-panel-3",
    icon = "__andrew-power-armor__/graphics/icons/solar-panel-equipment-3.png",
    placed_as_equipment_result = "portable-solar-panel-3",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-power",
    order = "a-c",
    stack_size = 20
  },
}
)

-- portable-solar-panel-4 --
data:extend(
{
  {
    type = "item",
    name = "portable-solar-panel-4",
    icon = "__andrew-power-armor__/graphics/icons/solar-panel-equipment-4.png",
    placed_as_equipment_result = "portable-solar-panel-4",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-power",
    order = "a-d",
    stack_size = 20
  },
}
)