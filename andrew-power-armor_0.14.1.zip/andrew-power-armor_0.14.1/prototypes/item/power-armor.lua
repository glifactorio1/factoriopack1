-- power-armor-mk3 --
data:extend(
{
  {
    type = "armor",
    name = "power-armor-mk3",
    icon = "__andrew-power-armor__/graphics/icons/power-armor-mk3.png",
    flags = {"goes-to-main-inventory"},
    durability = 30000,
    subgroup = "armor-armor",
    order = "e[power-armor-mk3]",
    stack_size = 1,
    equipment_grid = "1-equipment-grid",
	inventory_size_bonus = 40,
    resistances = 
    {
      {
        type = "physical",
        decrease = 12,
        percent = 45
      },
      {
        type = "acid",
        decrease = 12,
        percent = 45
      },
      {
        type = "explosion",
        decrease = 20,
        percent = 50
      },
      {
        type = "fire",
        decrease = 10,
        percent = 30
      },
    },
  },
}
)

-- power-armor-mk4 --
data:extend(
{
  {
    type = "armor",
    name = "power-armor-mk4",
    icon = "__andrew-power-armor__/graphics/icons/power-armor-mk4.png",
    flags = {"goes-to-main-inventory"},
    durability = 40000,
    subgroup = "armor-armor",
    order = "f[power-armor-mk4]",
    stack_size = 1,
    equipment_grid = "2-equipment-grid",
	inventory_size_bonus = 50,
    resistances = 
    {
      {
        type = "physical",
        decrease = 15,
        percent = 50
      },
      {
        type = "acid",
        decrease = 15,
        percent = 50
      },
      {
        type = "explosion",
        decrease = 20,
        percent = 50
      },
      {
        type = "fire",
        decrease = 15,
        percent = 40
      },
    },
  },
}
)

-- iron-man-armor --
data:extend(
{
  {
    type = "armor",
    name = "iron-man-armor",
    icon = "__andrew-power-armor__/graphics/icons/iron-man-armor.png",
    flags = {"goes-to-main-inventory"},
    durability = 50000,
    subgroup = "armor-armor",
    order = "g[iron-man-armor]",
    stack_size = 1,
    equipment_grid = "3-equipment-grid",
	inventory_size_bonus = 60,
    resistances = 
    {
      {
        type = "physical",
        decrease = 20,
        percent = 50
      },
      {
        type = "acid",
        decrease = 20,
        percent = 50
      },
      {
        type = "explosion",
        decrease = 20,
        percent = 50
      },
      {
        type = "fire",
        decrease = 20,
        percent = 50
      },
    },
  },
}
)

-- iron-man-armor-mk2 --
data:extend(
{
  {
    type = "armor",
    name = "iron-man-armor-mk2",
    icon = "__andrew-power-armor__/graphics/icons/iron-man-armor-mk2.png",
    flags = {"goes-to-main-inventory"},
    durability = 55000,
    subgroup = "armor-armor",
    order = "h[iron-man-armor]",
    stack_size = 1,
    equipment_grid = "4-equipment-grid",
	inventory_size_bonus = 70,
    resistances = 
    {
      {
        type = "physical",
        decrease = 25,
        percent = 55
      },
      {
        type = "acid",
        decrease = 25,
        percent = 55
      },
      {
        type = "explosion",
        decrease = 25,
        percent = 55
      },
      {
        type = "fire",
        decrease = 25,
        percent = 55
      },
    },
  },
}
)