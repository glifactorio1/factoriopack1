-- energy-shield-mk3 --
data:extend(
{
  {
    type = "item",
    name = "energy-shield-mk3",
    icon = "__andrew-power-armor__/graphics/icons/energy-shield-mk3-equipment.png",
    placed_as_equipment_result = "energy-shield-mk3",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-dmg",
    order = "a-c",
    stack_size = 50,
    default_requiest_amount = 10
  },
}
)

-- energy-shield-mk4 --
data:extend(
{
  {
    type = "item",
    name = "energy-shield-mk4",
    icon = "__andrew-power-armor__/graphics/icons/energy-shield-mk4-equipment.png",
    placed_as_equipment_result = "energy-shield-mk4",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-dmg",
    order = "a-d",
    stack_size = 50,
    default_requiest_amount = 10
  },
}
)

-- energy-shield-mk5 --
data:extend(
{
  {
    type = "item",
    name = "energy-shield-mk5",
    icon = "__andrew-power-armor__/graphics/icons/energy-shield-mk5-equipment.png",
    placed_as_equipment_result = "energy-shield-mk5",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-dmg",
    order = "a-e",
    stack_size = 50,
    default_requiest_amount = 10
  },
}
)

-- energy-shield-mk6 --
data:extend(
{
  {
    type = "item",
    name = "energy-shield-mk6",
    icon = "__andrew-power-armor__/graphics/icons/energy-shield-mk6-equipment.png",
    placed_as_equipment_result = "energy-shield-mk6",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-dmg",
    order = "a-f",
    stack_size = 50,
    default_requiest_amount = 10
  },
}
)