-- personal-roboport-mk2 --
data:extend(
{
  {
    type = "item",
    name = "personal-roboport-mk2",
    icon = "__andrew-power-armor__/graphics/icons/personal-roboport-equipment.png",
    placed_as_equipment_result = "personal-roboport-mk2",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-util",
    order = "b-b",
    stack_size = 5
  },
}
)