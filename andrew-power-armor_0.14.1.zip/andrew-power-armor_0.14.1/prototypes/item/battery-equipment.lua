-- portable-battery-pack-mk3 --
data:extend(
{
  {
    type = "item",
    name = "portable-battery-pack-mk3",
    icon = "__andrew-power-armor__/graphics/icons/battery-mk3-equipment.png",
    placed_as_equipment_result = "portable-battery-pack-mk3",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-power",
    order = "b-c",
    stack_size = 50,
    default_requiest_amount = 10
  },
}
)

-- portable-battery-pack-mk4 --
data:extend(
{
  {
    type = "item",
    name = "portable-battery-pack-mk4",
    icon = "__andrew-power-armor__/graphics/icons/battery-mk4-equipment.png",
    placed_as_equipment_result = "portable-battery-pack-mk4",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-power",
    order = "b-d",
    stack_size = 50,
    default_requiest_amount = 10
  },
}
)

-- portable-battery-pack-mk5 --
data:extend(
{
  {
    type = "item",
    name = "portable-battery-pack-mk5",
    icon = "__andrew-power-armor__/graphics/icons/battery-mk5-equipment.png",
    placed_as_equipment_result = "portable-battery-pack-mk5",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-power",
    order = "b-e",
    stack_size = 50,
    default_requiest_amount = 10
  },
}
)

-- portable-battery-pack-mk6 --
data:extend(
{
  {
    type = "item",
    name = "portable-battery-pack-mk6",
    icon = "__andrew-power-armor__/graphics/icons/battery-mk6-equipment.png",
    placed_as_equipment_result = "portable-battery-pack-mk6",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-power",
    order = "b-f",
    stack_size = 50,
    default_requiest_amount = 10
  },
}
)