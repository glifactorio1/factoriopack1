-- personal-laser-defense-2 --
data:extend(
{
  {
    type = "item",
    name = "personal-laser-defense-2",
    icon = "__andrew-power-armor__/graphics/icons/basic-laser-defense-equipment-2.png",
    placed_as_equipment_result = "personal-laser-defense-2",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-dmg",
    order = "b-b",
    stack_size = 20
  },
}
)

-- personal-laser-defense-3 --
data:extend(
{
  {
    type = "item",
    name = "personal-laser-defense-3",
    icon = "__andrew-power-armor__/graphics/icons/basic-laser-defense-equipment-3.png",
    placed_as_equipment_result = "personal-laser-defense-3",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-dmg",
    order = "b-c",
    stack_size = 20
  },
}
)

-- personal-laser-defense-4 --
data:extend(
{
  {
    type = "item",
    name = "personal-laser-defense-4",
    icon = "__andrew-power-armor__/graphics/icons/basic-laser-defense-equipment-4.png",
    placed_as_equipment_result = "personal-laser-defense-4",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-dmg",
    order = "b-d",
    stack_size = 20
  },
}
)

-- personal-laser-defense-5 --
data:extend(
{
  {
    type = "item",
    name = "personal-laser-defense-5",
    icon = "__andrew-power-armor__/graphics/icons/basic-laser-defense-equipment-5.png",
    placed_as_equipment_result = "personal-laser-defense-5",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-dmg",
    order = "b-e",
    stack_size = 20
  },
}
)

-- personal-laser-defense-6 --
data:extend(
{
  {
    type = "item",
    name = "personal-laser-defense-6",
    icon = "__andrew-power-armor__/graphics/icons/basic-laser-defense-equipment-6.png",
    placed_as_equipment_result = "personal-laser-defense-6",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-dmg",
    order = "b-f",
    stack_size = 20
  },
}
)



