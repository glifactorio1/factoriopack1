-- portable-fusion-reactor-2 --
data:extend(
{
  {
    type = "item",
    name = "portable-fusion-reactor-2",
    icon = "__andrew-power-armor__/graphics/icons/fusion-reactor-equipment-2.png",
    placed_as_equipment_result = "portable-fusion-reactor-2",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-power",
    order = "c-b",
    stack_size = 20
  },
}
)

-- portable-fusion-reactor-3 --
data:extend(
{
  {
    type = "item",
    name = "portable-fusion-reactor-3",
    icon = "__andrew-power-armor__/graphics/icons/fusion-reactor-equipment-3.png",
    placed_as_equipment_result = "portable-fusion-reactor-3",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-power",
    order = "c-c",
    stack_size = 20
  },
}
)

-- portable-fusion-reactor-4 --
data:extend(
{
  {
    type = "item",
    name = "portable-fusion-reactor-4",
    icon = "__andrew-power-armor__/graphics/icons/fusion-reactor-equipment-4.png",
    placed_as_equipment_result = "portable-fusion-reactor-4",
    flags = {"goes-to-main-inventory"},
    subgroup = "armor-power",
    order = "c-d",
    stack_size = 20
  },
}
)