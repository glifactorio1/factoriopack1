if data.raw.item["aluminium-plate"] then
ChangeRecipe("personal-roboport-mk2", "steel-plate", "aluminium-plate", 20)
ChangeRecipe("exoskeleton-equipment-2", "steel-plate", "aluminium-plate", 20)

end





