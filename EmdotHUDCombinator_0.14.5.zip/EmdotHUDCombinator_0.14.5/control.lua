require("config")
require("constants")
require("mdebug")
require("class")
require("classes.PlayerRecord")
require("classes.Alert")
require("classes.AlertConfigWindow")
require("classes.AlertCombinator")
require("classes.ButtonConfigWindow")
require("classes.ButtonCombinator")
require("classes.List")
require("classes.Set")
require("classes.EntitySet")
require("classes.RepeatingTimer")
require("classes.Mod")

function ___on_init()
	if DEBUG then
		game.surfaces[1].always_day = true
	end
	global.mod = Mod.new()
end
script.on_init(___on_init)

function ___on_load()
	-- Factorio doesn't save closures or metatables, so we need to manually restore them.
	attach_classes(global.mod)
end
script.on_load(___on_load)

function ___on_configuration_changed(data)
	if not global.mod then
		global.mod = Mod.new()
	end
	global.classes = nil   -- no longer used as of 0.14.5
	attach_classes(global.mod, true)
end
script.on_configuration_changed(___on_configuration_changed)

function ___on_tick()
	global.mod:update()
end
script.on_event(defines.events.on_tick, ___on_tick)

function ___on_player_joined_game(event)
	local player = game.players[event.player_index]
	if DEBUG then
		player.cheat_mode = true
		player.force.research_all_technologies();
		player.get_inventory(defines.inventory.player_main).clear()
		local quickbar = player.get_inventory(defines.inventory.player_quickbar)
		quickbar.clear()
		quickbar.insert "red-wire"
		quickbar.insert(ALERT_COMBINATOR_ENTITY_NAME)
		quickbar.insert "solar-panel"
		quickbar.insert "constant-combinator"
		quickbar.insert "medium-electric-pole"
	end
	global.mod:on_player_joined(player)
end
script.on_event(defines.events.on_player_joined_game, ___on_player_joined_game)

function __on_player_left_game(event)
	global.mod:on_player_left(event.player_index)
end
script.on_event(defines.events.on_player_left_game, __on_player_left_game)

function ___on_built_entity(event)
	global.mod:on_entity_created(event.created_entity)
end
script.on_event(defines.events.on_built_entity, ___on_built_entity)
script.on_event(defines.events.on_robot_built_entity, ___on_built_entity)

function __on_removed_entity(event)
	global.mod:on_removed_entity(event.entity)
end
script.on_event(defines.events.on_preplayer_mined_item, __on_removed_entity)
script.on_event(defines.events.on_robot_pre_mined, __on_removed_entity)
script.on_event(defines.events.on_entity_died, __on_removed_entity)

function ___on_gui_event(event)
	global.mod:on_gui_event(event.element, event.player_index)
end
script.on_event(defines.events.on_gui_click, ___on_gui_event)
script.on_event(defines.events.on_gui_text_changed, ___on_gui_event)
script.on_event(defines.events.on_gui_checked_state_changed, ___on_gui_event)

-- for i = 1,NUM_KEYS do
-- 	script.on_event(
-- 		BUTTON_EVENT_NAME_PREFIX .. i, 
-- 		function(event)
-- 			global.mod:on_button_combinator_key(event.player_index, i)
-- 		end) 
-- end