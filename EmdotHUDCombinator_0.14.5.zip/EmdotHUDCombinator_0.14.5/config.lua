DEBUG = false                               -- debug mode
NUM_KEYS = 10                               -- how many keybindings are available for button combinators 