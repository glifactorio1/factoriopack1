PREFIX = "emdot_hud_mod_"

ALERT_COMBINATOR_ENTITY_NAME = PREFIX .. "alert_combinator"
ALERT_COMBINATOR_ICON_PATH = "__EmdotHUDCombinator__/graphics/hud-combinator-icon.png"
ALERT_COMBINATOR_GRAPHICS_PATH = "__EmdotHUDCombinator__/graphics/hud-combinator-entities.png"
ALERT_NAME_PREFIX = PREFIX .. "alert_"

BUTTON_COMBINATOR_ENTITY_NAME = PREFIX .. "button_combinator"
BUTTON_COMBINATOR_ICON_PATH = "__EmdotHUDCombinator__/graphics/button-combinator-icon.png"
BUTTON_COMBINATOR_GRAPHICS_PATH = "__EmdotHUDCombinator__/graphics/button-combinator-entities.png"
BUTTON_EVENT_NAME_PREFIX = PREFIX .. "button_event:"