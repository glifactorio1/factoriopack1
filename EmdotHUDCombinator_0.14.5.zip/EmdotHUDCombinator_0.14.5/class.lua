local __classes = {}

function Class(name, proto)
	
	-- Default is empty class
	proto = proto or {}

	__classes[name] = proto
	
	proto.__index = proto;
	
	-- Create method to instantiate the class
	local function new(...)
		local instance = { _class_name = name }
		setmetatable(instance, proto)
		if proto.__ctor then 
			instance:__ctor(...)
		end
		return instance
	end
	proto.new = new
	
	return proto
end

function attach_classes(thing, config_changed)

	local objects = {}
	
	local function visit(it)
		if type(it) ~= "table" then return end
		if it == Mod then err("it == Mod") end
		if objects[it] then return end
		
		local class_name = rawget(it, "_class_name")    -- rawget so Factorio userdata objects don't throw an error
		if class_name then 
			objects[it] = class_name
		else
			objects[it] = nil
		end
		
		for k, v in pairs(it) do
			visit(k)
			visit(v)
		end

	end
	visit(thing)
	
	for k, v in pairs(objects) do
		if v then
			local class = __classes[v]
			setmetatable(k, class)
		end
	end
	
	if config_changed then
		for k, _ in pairs(objects) do
		if k and k.__on_config_changed then
			k:__on_config_changed()
		end
	end
	end
end