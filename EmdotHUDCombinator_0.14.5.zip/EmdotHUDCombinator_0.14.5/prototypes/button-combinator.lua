data:extend({
 {
    type = "item",
    name = BUTTON_COMBINATOR_ENTITY_NAME,
    icon = BUTTON_COMBINATOR_ICON_PATH,
    flags = { "goes-to-quickbar" },
    subgroup = "circuit-network",
    place_result = BUTTON_COMBINATOR_ENTITY_NAME,
    stack_size = 5,
	order = "b[combinators]-d[emdot-alert-combinator]",
  },
  
  {
	type = "recipe",
	name = BUTTON_COMBINATOR_ENTITY_NAME,
	enabled = true,
	ingredients =
    {
      {"copper-cable", 8},
      {"electronic-circuit", 6},
    },
	result = BUTTON_COMBINATOR_ENTITY_NAME
  },
  
  {
		type = "lamp",
		name =  BUTTON_COMBINATOR_ENTITY_NAME,
		icon = BUTTON_COMBINATOR_ICON_PATH,
		flags = {"placeable-neutral", "player-creation", "not-on-map"},
		order = "y",
		minable = {hardness = 0.2, mining_time = 0.5, result = BUTTON_COMBINATOR_ENTITY_NAME},
		max_health = 55,
		corpse = "small-remnants",
		render_layer = "lower-object",
		collision_box = {{-0.15, -0.15}, {0.15, 0.15}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
		energy_source =
		{
			type = "electric",
			usage_priority = "secondary-input"
		},
		energy_usage_per_tick = "5KW",
		light = {intensity = 0.0, size = 0},
		picture_off =
		{
			filename = BUTTON_COMBINATOR_GRAPHICS_PATH,
			x = 0,
			y = 0,
			width = 79,
			height = 63,
			frame_count = 1,
			shift = {0.140625, 0.140625}
		},
		picture_on =
		{
			filename = BUTTON_COMBINATOR_GRAPHICS_PATH,
			x = 0,
			y = 0,
			width = 79,
			height = 63,
			frame_count = 1,
			shift = {0.140625, 0.140625}
		},

		circuit_wire_connection_point =
		{
			shadow =
			{
				red = {0.4, 0.4},
				green = {-0.4, 0.4},
			},
			wire =
			{
				red = {0.4, 0.4},
				green = {-0.4, 0.4},
			}
		},

		circuit_wire_max_distance = 7.5
	},

})

local keys = {
	"PAD 1",
	"PAD 2",
	"PAD 3",
	"PAD 4",
	"PAD 5",
	"PAD 6",
	"PAD 7",
	"PAD 8",
	"PAD 9",
	"PAD 0",
}

for i = 1, NUM_KEYS do
	local key = keys[i] or ""
	data:extend({	
		{
			type = "custom-input",
			name = BUTTON_EVENT_NAME_PREFIX .. i,
			key_sequence = key,
			consuming = "game-only"
		},
	})
end
