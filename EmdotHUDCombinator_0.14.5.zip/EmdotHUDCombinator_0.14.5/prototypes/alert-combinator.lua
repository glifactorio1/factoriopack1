data:extend({

 {
    type = "item",
    name = ALERT_COMBINATOR_ENTITY_NAME,
    icon = ALERT_COMBINATOR_ICON_PATH,
    flags = { "goes-to-quickbar" },
    subgroup = "circuit-network",
    place_result = ALERT_COMBINATOR_ENTITY_NAME,
    stack_size = 5,
	order = "b[combinators]-d[emdot-alert-combinator]",
  },
  
  {
	type = "recipe",
	name = ALERT_COMBINATOR_ENTITY_NAME,
	enabled = true,
	ingredients =
    {
      {"copper-cable", 8},
      {"electronic-circuit", 6},
    },
	result = ALERT_COMBINATOR_ENTITY_NAME
  },
  
  {
		type = "lamp",
		name =  ALERT_COMBINATOR_ENTITY_NAME,
		icon = ALERT_COMBINATOR_ICON_PATH,
		flags = {"placeable-neutral", "player-creation", "not-on-map"},
		order = "y",
		minable = {hardness = 0.2, mining_time = 0.5, result = ALERT_COMBINATOR_ENTITY_NAME},
		max_health = 55,
		corpse = "small-remnants",
		render_layer = "lower-object",
		collision_box = {{-0.15, -0.15}, {0.15, 0.15}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
		energy_source =
		{
			type = "electric",
			usage_priority = "secondary-input"
		},
		energy_usage_per_tick = "5KW",
		light = {intensity = 0.0, size = 0},
		picture_off =
		{
			filename = ALERT_COMBINATOR_GRAPHICS_PATH,
			x = 0,
			y = 63,
			width = 79,
			height = 63,
			frame_count = 1,
			shift = {0.140625, 0.140625}
		},
		picture_on =
		{
			filename = ALERT_COMBINATOR_GRAPHICS_PATH,
			x = 0,
			y = 0,
			width = 79,
			height = 63,
			frame_count = 1,
			shift = {0.140625, 0.140625}
		},

		circuit_wire_connection_point =
		{
			shadow =
			{
				red = {0.4, 0.4},
				green = {-0.4, 0.4},
			},
			wire =
			{
				red = {0.4, 0.4},
				green = {-0.4, 0.4},
			}
		},

		circuit_wire_max_distance = 7.5
	},

})