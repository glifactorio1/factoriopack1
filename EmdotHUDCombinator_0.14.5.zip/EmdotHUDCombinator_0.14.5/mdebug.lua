function dump(thing)
	
	local supporting_tables = {}
	local supporting_functions = {}
	local any_supporting_tables = false
	local any_supporting_functions = false
	
	local function search(it)
		if type(it) == "table" then
			if supporting_tables[it] then return end
			if it ~= thing then any_supporting_tables = true end
			supporting_tables[it] = true
			for k,v in pairs(it) do
				search(k)
				search(v)
			end
			local meta = getmetatable(it)
			if meta then search(meta) end
		elseif type(it) == "function" then
			if it ~= thing then any_supporting_functions = true end
			supporting_functions[it] = true
		end
	end
	search(thing)

	local function escape_string(input)
		local output = ""
		local c
		for i = 1, string.len(input) do
			c = string.sub(input, i, i)
			if c == "\\" then
				output = output .. "\\\\"
			elseif c == "\"" then
				output = output .. "\\\""
			else
				output = output .. c
			end
		end
		return "\"" .. output .. "\""
	end
	
	local function show_value(it)
		if type(it) == "table" then return "<" .. tostring(it) .. ">" end
		if type(it) == "function" then return "<" .. tostring(it) .. ">" end
		if type(it) == "string" then return escape_string(it) end
		return tostring(it)
	end

	local function show_table(table)
		local output = tostring(table) .. ":"
		local any_keys = false
		for k, v in pairs(table) do
			any_keys = true
			output = output .. "\n\t\t"
			if type(k) == "string" then
				output = output .. k
			else
				output = output .. "[" .. show_value(k) .. "]"
			end
			output = output .. " = " .. show_value(v)
		end
		if not any_keys then output = output .. " empty" end
		meta = getmetatable(table)
		if meta then
			output = output .. "\n\t\t!meta = " .. show_value(meta)
		end
		return output
	end
	
	local function show_function(func)
		local info = debug.getinfo(func)
		local output = tostring(func) .. ":"
		output = output .. "\n\twhat = " .. info.what
		if info.namewhat == nil or info.namewhat == "" then
			output = output .. "\n\tno name, no namewhat"
		elseif info.name == nil or info.name == "" then
			output = output .. "\n\tnamewhat = " .. info.namewhat
			output = output .. "\n\tno name"
		else
			output = output .. "\n\tnamewhat = " .. info.namewhat
			output = output .. "\n\tname = " .. info.name
		end
		output = output .. "\n\tnups = " .. info.nups
		output = output .. "\n\tshort_src = " .. info.short_src
		output = output .. "\n\tlinedefined = " .. info.linedefined
		return output
	end
	
	local output = "Value = "
	if type(thing) == "table" then
		output = output .. show_table(thing)
	elseif type(thing) == "function" then
		output = output .. "TODO"
	else
		output = output .. show_value(thing)
	end
	
	if any_supporting_tables then
		output = output .. "\nSupporting tables:"
		for table, _ in pairs(supporting_tables) do
			if table ~= thing then
				output = output .. "\n\t" .. show_table(table)
			end
		end
	end
	
	if any_supporting_functions then
		output = output .. "\nSupporting functions:"
		for func, _ in pairs(supporting_functions) do
			if func ~= thing then
				output = output .. "\n\t" .. show_function(func)
			end
		end
	end
	
	return output
end

function say(text)
	if game and game.players and game.players[1] then
		game.players[1].print{ "", text }
	end
end

function err(text)
	error(text .. "\n" .. debug.traceback())
end

function mlog(data)
	if type(data) ~= "string" then
		data = dump(data)
	end
	if not game then
		error("Can't log: `game` is missing")
	end
	game.write_file("debug_log.txt", data, true)
end