Set = Class "Set"

function Set:__ctor()
	self._set = {}
	self._count = 0
end

function Set:add(value)
	if not self._set[value] then 
		self._set[value] = true
		self._count = self._count + 1
	end
end

function Set:remove(value)
	if self._set[value] then
		self._set[value] = nil
		self._count = self._count - 1
	end
end

function Set:is_empty()
	return self._count == 0
end

function Set:get_count()
	return self._count
end

function Set:find(func)
	for item, _ in pairs(self._set) do
		if func(item) then
			return item
		end
	end
	return nil
end

function List:values()
	return pairs(self._list)
end
