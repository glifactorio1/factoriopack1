Mod = Class "Mod"

function Mod:__ctor()
	self._players = {}
	self._alerts = {}
	self._alert_combinators = Set.new()
	self._button_combinators = Set.new()
end

function Mod:__on_config_changed()
	self._players = self._players or {}
	self._alerts = self._alerts or {}
	self._alert_combinators = self._alert_combinators or Set.new()
	self._button_combinators = self._button_combinators or Set.new()

	-- Add any existing players that aren't already in our list. This is needed when first adding the mod to an existing map.
	for index, entity in pairs(game.players) do
		if not self._players[index] then
			self:on_player_joined(entity)
		end
	end
end

function Mod:update()
	for i = 1, #self._alerts do
		if self._alerts[i] then
			self._alerts[i]:update()
		end
	end
	for _, player in pairs(self._players) do
		player:update()
	end
end

function Mod:on_player_joined(player_entity)
	local record = PlayerRecord.new(player_entity)
	self._players[player_entity.index] = record
end

function Mod:on_player_left(index)
	self._players[index] = nil
end

function Mod:on_entity_created(new_entity)
	if new_entity.name == ALERT_COMBINATOR_ENTITY_NAME then
	
		local player = self._players[new_entity.last_user.index]
		
		local record = AlertCombinator.new(new_entity)
		self._alert_combinators:add(record)
		
		local alert_id = #self._alerts + 1
		local alert = Alert.new(alert_id, player, record)
		self._alerts[alert_id] = alert
		
		record:set_alert(alert)
		player:register_alert_combinator(record)
	
	elseif new_entity.name == BUTTON_COMBINATOR_ENTITY_NAME then

		local record = ButtonCombinator.new(new_entity)
		self._button_combinators:add(record)

	end
end

function Mod:on_removed_entity(entity)
	if entity.name == ALERT_COMBINATOR_ENTITY_NAME then
		
		local player = self._players[entity.last_user.index]
		local record = self._alert_combinators:find(
			function(x) return x:get_entity() == entity end)
		local alert = record:get_alert()

		self._alerts[alert.id] = nil
		self._alert_combinators:remove(record)
		player:unregister_alert_combinator(record)		
	
	elseif entity.name == BUTTON_COMBINATOR_ENTITY_NAME then

		local player = self._players[entity.last_user.index]
		local record = self._button_combinators:find(
			function(x) return x:get_entity() == entity end)
		
		if not record then err("Couldnt't find button combinator") end
		
		self._button_combinators:remove(record)
		player:unregister_button_combinator(record)

	end
end

function Mod:on_gui_event(element, player_index)
	self._players[player_index]:on_gui_event(element)
end

function Mod:on_button_combinator_key(player_index, key_index)
	self._players[player_index]:on_button_combinator_key(key_index)
end