AlertConfigWindow = Class "AlertConfigWindow"

ALERT_CONFIG_WINDOW_TEXT_FIELD = PREFIX .. "alert_config_window_text" 

function AlertConfigWindow:__ctor(alert)
	if DEBUG and alert == nil then err("missing alert") end
	self._alert = alert
	self._main_element = nil
	self._text_field = nil
	self._player = nil
end

function AlertConfigWindow:get_alert()
	return self._alert;
end

function AlertConfigWindow:show(player)
	if self._main_element then err("AlertConfigWindow is already open") end
	
	self._player = player
	
	local form = player:get_entity().gui.left.add{ 
		type = "frame", 
		caption = "Alert Configuration", 
		direction = "vertical" }
	local layout = form.add{ type = "table", colspan = 2}
	layout.add{ type = "label", caption = "Message" }
	self._text_field = layout.add{ 
		type = "textfield", 
		text = self._alert:get_text_template(), 
		name = ALERT_CONFIG_WINDOW_TEXT_FIELD }
	
	self._main_element = form
	
	player:register_ui_element(ALERT_CONFIG_WINDOW_TEXT_FIELD, self)
end

function AlertConfigWindow:hide()
	if self._main_element ~= nil then 
		self._main_element.destroy()
		self._main_element = nil
	end
	
	self._player:unregister_ui_element(ALERT_CONFIG_WINDOW_TEXT_FIELD)
	self._player = nil    
end

function AlertConfigWindow:on_gui_event(element_name)
	if element_name == ALERT_CONFIG_WINDOW_TEXT_FIELD then
		self._alert:set_text_template(self._text_field.text)
	end
end
