ButtonConfigWindow = Class "ButtonConfigWindow"

function ButtonConfigWindow:__ctor(combinator)
    self._combinator = combinator
end

function ButtonConfigWindow:show(player)
    if self._main_element then err("ButtonConfigWindow is already open") end
	
	self._player = player
	
	local form = player:get_entity().gui.left.add{ 
		type = "frame", 
		caption = "Button Configuration", 
		direction = "vertical" }
	
    form.add{ type = "label", caption = "Which key triggers the output? (Options >> Controls >> Mods)" }
    local layout = form.add{ type = "flow", direction = "vertical" }
    for i = 1,NUM_KEYS do
        layout.add{ type = "radiobutton", caption = "Key " .. i, state = false }
    end

    layout = form.add{ type = "flow", direction = "vertical" }
    layout.add{ type = "label", caption = "What kind of trigger is this?" }
    layout.add{ type = "radiobutton", caption = "Toggle", state = true }
    layout.add{ type = "radiobutton", caption = "While Held", state = false }
    layout.add{ type = "radiobutton", caption = "Pulse", state = false }
	
	self._main_element = form
	
--	player:register_ui_element(ALERT_CONFIG_WINDOW_TEXT_FIELD, self)
end

function ButtonConfigWindow:hide()
    if self._main_element ~= nil then 
		self._main_element.destroy()
		self._main_element = nil
	end
	
	--self._player:unregister_ui_element(ALERT_CONFIG_WINDOW_TEXT_FIELD)
	self._player = nil
end
