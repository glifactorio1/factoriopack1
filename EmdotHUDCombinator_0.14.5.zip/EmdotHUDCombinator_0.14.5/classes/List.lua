List = Class "List"

function List:__ctor()
	self._list = {}
	self._count = 0
end

function List:add(index, item)
	self._list[index] = item
	self._count = self._count + 1
end

function List:remove(index)
	self._list[index] = nil
	self._count = self._count - 1
end

function List:get_item(index)
	return self._list[index]
end

function List:is_empty()
	return self._count == 0
end

function List:get_count()
	return self._count
end

function List:pairs()
	return pairs(self._list)
end

function List:values()
	local k,v
	return
		function()
			k, v = next(self._list, k)
			return v
		end
end

function List:keys()
	return next, self._list, nil
end

function List:find(condition)
	for v in self:values() do
		if condition(v) then return v end
	end
	return nil
end