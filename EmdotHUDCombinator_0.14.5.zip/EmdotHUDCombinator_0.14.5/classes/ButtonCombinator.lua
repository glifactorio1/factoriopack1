ButtonCombinator = Class "ButtonCombinator"

function ButtonCombinator:__ctor(entity)
    self._entity = entity
end

function ButtonCombinator:get_key_index()
end

function ButtonCombinator:get_entity()
    return self._entity
end

function ButtonCombinator.wants_config_window(entity)
    if not entity.valid then return false end
	if entity.name ~= BUTTON_COMBINATOR_ENTITY_NAME then return false end
	if not entity.get_circuit_network(defines.wire_type.red) and not entity.get_circuit_network(defines.wire_type.green) then return false end
	return true  
end