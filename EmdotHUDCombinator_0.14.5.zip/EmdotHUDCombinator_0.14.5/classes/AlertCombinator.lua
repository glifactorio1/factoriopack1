AlertCombinator = Class "AlertCombinator"

function AlertCombinator:__ctor(entity)
	self._entity = entity
	self._alert = null
end

function AlertCombinator:get_entity()
	return self._entity
end

function AlertCombinator:set_alert(alert) 
	self._alert = alert
end
function AlertCombinator:get_alert() return self._alert end

function AlertCombinator.wants_config_window(entity)
	if not entity.valid then return false end
	if entity.name ~= ALERT_COMBINATOR_ENTITY_NAME then return false end
	if not entity.get_circuit_network(defines.wire_type.red) and not entity.get_circuit_network(defines.wire_type.green) then return false end
	return true  
end

-- TODO: need to optimize this aggressively
function AlertCombinator:_should_show_alert()
	local entity = self._entity
	if not entity.active then return false end
	--TODO: false if energy needs aren't met
	--? if entity.to_be_deconstructed() then return false end
	if not entity.get_circuit_network(defines.wire_type.red) and not entity.get_circuit_network(defines.wire_type.green) then return false end
	
	local behavior = entity.get_control_behavior()
	if behavior.disabled then return false end
	
	local circuit_condition = behavior.circuit_condition
	if not circuit_condition then return false end
			
	return circuit_condition.fulfilled
end

function AlertCombinator:_get_total_signal(signal_id, net1, net2)
	local value = 0
	if net1 then
		value = value + net1.get_signal(signal_id)
	end
	if net2 then 
		value = value + net2.get_signal(signal_id)
	end
	return value
end

function AlertCombinator:_get_normal_circuit_signal(signal_id, net1, net2)
	return {
		self:_get_total_signal(signal_id, net1, net2),
		signal_id.name
	}
end

function AlertCombinator:_get_condition_test_function(net1, net2)
	local condition = self._entity.get_control_behavior().circuit_condition.condition
	
	local value, signal
	signal = condition.second_signal
	if signal then
		value = self:_get_total_signal(signal, net1, net2)
	else
		value = condition.constant or 0
	end
	
	local operator = condition.comparator or ">"
	if operator == ">" then 
		return function(x) return x > value end
	elseif operator == "=" then 
		return function(x) return x == value end
	elseif operator == "<" then
		return function(x) return x < value end
	else
		err("unexpected circuit condition operand \"" .. tostring(operator) .. "\"")
	end
end

function AlertCombinator:_get_anything_circuit_signal(net1, net2)
	
	-- make a list of signal IDs present on either network
	local signal_ids = {}
	if net1 then
		for _, signal in pairs(net1.signals) do	signal_ids[signal.signal] = true end
	end
	if net2 then
		for _, signal in pairs(net2.signals) do	signal_ids[signal.signal] = true end
	end
	
	-- get the circuit condition
	local test = self:_get_condition_test_function(net1, net2)
	
	-- loop over the signal IDs to find the first one that satisfies the condition
	for id in pairs(signal_ids) do
		local value = self:_get_total_signal(id, net1, net2)
		if test(value) then
			return { value, id.name }
		end
	end
	
	return nil
end

--TODO: optimize this further
function AlertCombinator:_get_circuit_signal()
	local signal_id = self._entity.get_control_behavior().circuit_condition.condition.first_signal
	
	local net1 = self._entity.get_circuit_network(defines.wire_type.red)
	local net2 = self._entity.get_circuit_network(defines.wire_type.green)
	
	if signal_id.name == "signal-anything" then
		return self:_get_anything_circuit_signal(net1, net2)
	elseif signal_id.name == "signal-everything" then
		return self:_get_anything_circuit_signal(net1, net2)  -- like "any", just return an arbitrary one of the signals that meet the condition
	else
		return self:_get_normal_circuit_signal(signal_id, net1, net2)
	end
end

function AlertCombinator:check_alert()
	if not self:_should_show_alert() then 
		return nil 
	else
		return self:_get_circuit_signal()
	end
end
