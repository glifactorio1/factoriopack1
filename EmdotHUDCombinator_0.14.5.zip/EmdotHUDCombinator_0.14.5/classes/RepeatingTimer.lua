RepeatingTimer = Class "RepeatingTimer"

function RepeatingTimer:__ctor(time)
	self._countdown = time
	self._repeat_from = time
end

function RepeatingTimer:tick()
	self._countdown = self._countdown - 1
	if self._countdown > 0 then return(false) end
	self._countdown = self._repeat_from
	return true
end
