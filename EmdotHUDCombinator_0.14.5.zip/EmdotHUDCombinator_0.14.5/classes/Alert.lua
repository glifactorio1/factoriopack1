Alert = Class "Alert"

function Alert:__ctor(id, owning_player, source)
	
	self.id = id
	self._template = "Signal {2} has value {1}"
	self._text = nil
	self._is_active = false
	self._owning_player = owning_player
	self._source = source
	self._template_data = {}
	
	if DEBUG then
		if type(source.check_alert) ~= "function" then err("`source` must have a function called `check_alert`") end
		if owning_player._class_name ~= "PlayerRecord" then err("`owning_player` is of type \"" .. owning_player._class_name .. "\"") end
	end
end

function Alert:is_active()
	return self._is_active
end

function Alert:update()
	
	local template_data = self._source:check_alert()
	
	if template_data == nil then
		if self._is_active then
			self._is_active = false
			self._owning_player:hide_alert(self)
		end
		return
	end
	
	if not self._is_active then
		self._is_active = true
		self._owning_player:show_alert(self)
		return
	end
	
	for i = 1, #template_data do
		if template_data[i] ~= self._template_data[i] then
			self._template_data = template_data
			self:_update_text()
			return
		end
	end
	
end

function Alert:_update_text()
	local text = self._template
	local data = self._template_data
	for i = 1, #data do
		text = string.gsub(text, "{" .. i .. "}", data[i])
	end
	if self._text ~= text then
		self._text = text
		if self._is_active then
			self._owning_player:update_alert(self)
		end
	end
end

function Alert:set_text_template(template)
	if template ~= self._template then
		self._template = template
		self:_update_text()
	end
end
function Alert:get_text_template() return self._template end

function Alert:get_text() return self._text end
