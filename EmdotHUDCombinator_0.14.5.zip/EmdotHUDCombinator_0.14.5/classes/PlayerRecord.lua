PlayerRecord = Class "PlayerRecord"

function PlayerRecord:__ctor(entity)
	self._entity = entity
	self._ui_elements = List.new()
	self._alerts = Set.new()
	self._alert_combinators = EntitySet.new()
	self._button_combinators_by_key = List.new()
	entity.gui.left.direction = "vertical"
end

function PlayerRecord:__on_config_changed()
	self._ui_elements = self._ui_elements or List.new()
	self._alerts = self._alerts or Set.new()
	self._alert_combinators = self._alert_combinators or EntitySet.new()
	self._button_combinators_by_key = self._button_combinators_by_key or List.new()
	self._entity.gui.left.direction = "vertical"
end

function PlayerRecord:get_entity()
	return self._entity
end

function PlayerRecord:update()

	local open_entity = self._entity.opened
	if not open_entity then
		self:_close_all_config_windows()
		return
	end
	
	if AlertCombinator.wants_config_window(open_entity) then
		self:_show_alert_config_window(open_entity) 
	elseif ButtonCombinator.wants_config_window(open_entity) then
		self:_show_button_config_window(open_entity)
	else
		self:_close_all_config_windows()
	end

end

function PlayerRecord:_show_alert_config_window(combinator_entity)
	
	-- If the window is already open, we're done.
	if self._alert_config_window then return end
	
	-- Get the record for the given combinator.
	local combinator_record = self._alert_combinators:find(
		function(x)
			return x._entity == combinator_entity 
		end)
	
	-- Create and display the config window
	local alert = combinator_record:get_alert()
	self._alert_config_window = AlertConfigWindow.new(alert)
	self._alert_config_window:show(self)
	
end

function PlayerRecord:_show_button_config_window(combinator_entity)
	
	-- If the window is already open, we're done.
	if self._button_config_window then return end
	
	-- Get the record for the given combinator.
	local combinator_record = self._button_combinators_by_key:find(
		function(x)
			return x._entity == combinator_entity 
		end)
	
	-- Create and display the config window
	self._button_config_window = ButtonConfigWindow.new(combinator_record)
	self._button_config_window:show(self)
	
end

function PlayerRecord:_close_all_config_windows()
	if self._alert_config_window then
		self._alert_config_window:hide()
		self._alert_config_window = nil
	end
	if self._button_config_window then
		self._button_config_window:hide()
		self._button_config_window = nil
	end
end

function PlayerRecord:on_gui_event(element)
	local owning_window_record = self._ui_elements:get_item(element.name)
	if not owning_window_record then
		return
	end
	owning_window_record:on_gui_event(element.name)
end

function PlayerRecord:register_ui_element(element_name, window)
	self._ui_elements:add(element_name, window)
end

function PlayerRecord:unregister_ui_element(element_name)
	self._ui_elements:remove(element_name)
end

function PlayerRecord:register_alert_combinator(record)
	self._alert_combinators:add(record)
end

function PlayerRecord:unregister_alert_combinator(record)
	local alert = record:get_alert()
	if self._alert_config_window and self._alert_config_window:get_alert() == alert then
		self:_close_all_config_windows()
	end
	if alert:is_active() then
		self:hide_alert(alert)
	end
	self._alert_combinators:remove(record)
end

function PlayerRecord:unregister_button_combinator(record)
	if self._button_config_window then
		self:_close_all_config_windows()
	end
	local key_index = record:get_key_index()
	if key_index then
		self._button_combinators_by_key:remove(key_index)
	end
end

function PlayerRecord:show_alert(alert)
	self._entity.gui.left.add{
		type = "label",
		caption = alert:get_text(),
		name = ALERT_NAME_PREFIX .. alert.id
	}
end

function PlayerRecord:hide_alert(alert)
	self._entity.gui.left[ALERT_NAME_PREFIX .. alert.id].destroy()
end

function PlayerRecord:update_alert(alert)
	local element = self._entity.gui.left[ALERT_NAME_PREFIX .. alert.id]
	local text = alert:get_text()
	element.caption = text
end

function PlayerRecord:on_button_combinator_key(key_index)
	local combinator = self._button_combinators_by_key[key_index]
	if not combinator then return end

	--TODO: set signal 
end