
EntitySet = Class "EntitySet"

function EntitySet:__ctor()
	self._set = {}
	self._count = 0
end

function EntitySet:add(value)
	table.insert(self._set, value)
	self._count = self._count + 1
end

function EntitySet:remove(value)
	for index, item in pairs(self._set) do
		if item == value then
			table.remove(self._set, index)
			self._count = self._count - 1
			return
		end
	end
end

function EntitySet:is_empty()
	return self._count == 0
end

function EntitySet:get_count()
	return self._count
end

function EntitySet:find(func)
	for _, item in pairs(self._set) do
		if func(item) then
			return item
		end
	end
	return nil
end

function EntitySet:pairs()
	return pairs(self._list)
end

function EntitySet:values()
	local k,v
	return
		function()
			k, v = next(self._list, k)
			return v
		end
end