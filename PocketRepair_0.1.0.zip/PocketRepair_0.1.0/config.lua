-- Don't mess with this bit
config = config or {}
config.packs = config.packs or {}
-----------------



-- Use repair packs for fuel
-- config.packs.enabled = true
-- How many points to take from a repair pack when a module repairs 1 point of health
-- config.packs.module_expense = 4

-- Amount of energy used by the repair module
-- Note: Due to limitations this currently only applies when moving
config.module_energy_consumption = "10kW"
