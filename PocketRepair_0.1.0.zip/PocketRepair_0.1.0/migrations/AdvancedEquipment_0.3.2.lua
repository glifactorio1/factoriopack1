game.player.force.reset_technologies()
game.player.force.reset_recipes()
game.reload_script()