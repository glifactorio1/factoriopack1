require "defines"
require "config"
--require "lib.printr"

local lists = {}

local function clear()
	lists.packs = {}
	lists.packs.player_main = {}
	lists.packs.player_quickbar = {}
	lists.damaged = {}
	lists.damaged.player_main = {}
	lists.damaged.player_quickbar = {}
end

local function repair_module_count(player)
	local armor = player.get_inventory(defines.inventory.player_armor)[1]
	local count = 0

	if armor.valid_for_read and armor.has_grid then
		for _, mod in pairs(armor.grid.equipment) do
			if mod.name == "repair-module" then
				count = count + 1
			end
		end
	end

	return count
end

local function scan_inventory(player, inv_label, ...)
	local arg = {...}
	local stack = nil
	local inv = player.get_inventory(defines.inventory[inv_label])

	for i = 1, #inv do
		stack = inv[i]

		if stack.valid_for_read then
			for _, func in pairs(arg) do
				func(player, stack, inv_label, i)
			end
		end
	end
end

local function find_packs(player, stack, inv_label, index)
	if stack.type == "repair-tool" then
		if not lists.packs[inv_label][player.index] then
			lists.packs[inv_label][player.index] = {}
		end

		lists.packs[inv_label][player.index][index] = stack
	end
end

local function find_damaged(player, stack, inv_label, index)
	if stack.health < 1 then
		if not lists.damaged[inv_label][player.index] then
			lists.damaged[inv_label][player.index] = {}
		end

		lists.damaged[inv_label][player.index][index] = stack
	end
end

local function build_lists()
	clear()

	for _, player in ipairs(game.players) do
		if player.controller_type == defines.controllers.character then
			scan_inventory(player, "player_quickbar", find_packs, find_damaged)
			scan_inventory(player, "player_main", find_packs, find_damaged)
		end
	end
end

local function handle_repair()
	for _, player in ipairs(game.players) do
		if player.controller_type == defines.controllers.character then
			local in_use = 0
			local num_modules = repair_module_count(player)

			if num_modules > 0 then
				if lists.damaged.player_quickbar[player.index] then
					for slot, stack in pairs(lists.damaged.player_quickbar[player.index]) do
						if stack.health < 1 then
							-- player.print("Repairing bar slot " .. slot)
							stack.health = stack.health + 0.01
							in_use = in_use + 1
						end

						if in_use >= num_modules then
							break
						end
					end
				end

				if lists.damaged.player_main[player.index] and in_use < num_modules then
					for slot, stack in pairs(lists.damaged.player_main[player.index]) do
						if stack.health < 1 then
							-- player.print("Repairing main slot " .. slot)
							stack.health = stack.health + 0.01
							in_use = in_use + 1
						end

						if in_use >= num_modules then
							break
						end
					end
				end
			end
		end
	end
end


script.on_init(clear)
script.on_load(clear)
script.on_event(defines.events.on_tick, function(event)
	--local lists_built = false
	if game.tick % 15 == 0 then
		build_lists()
		--lists_built = true
	end

	-- Schedule repairs one tick after list is rebuilt
	if (game.tick % 15 - 1) == 0 then
		handle_repair()
	end
end)





script.on_event(defines.events.on_built_entity,
handle_repair)
--[[
function(event)
	local count = 0
	for _, player in ipairs(game.players) do
		count = count + 1
	end

	for _, player in ipairs(game.players) do
		player.print("Player Count: " .. count)
		if player.controller_type == defines.controllers.character then
			local num_modules = repair_module_count(player)
			player.print("Module Count: " .. num_modules)
		end
	end
end)



local function prune(key)
	local player_good = false
	for player, _ in pairs(key) do
		for _, current_player in ipairs(game.players) do
			if player == current_player then
				player_good = true
				break
			end
		end

		if not player_good then
			key[player] = nil
		end
	end
end

local function clear()
	for _, player in ipairs(game.players) do
		global.packs.player_main[player] = {}
		global.packs.player_quickbar[player] = {}
		global.damaged.player_main[player] = {}
		global.damaged.player_quickbar[player] = {}
	end

	prune(global.packs.player_main)
	prune(global.packs.player_quickbar)
	prune(global.damaged.player_main)
	prune(global.damaged.player_quickbar)
end


]]--