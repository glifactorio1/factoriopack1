data:extend(
{
  {
    type = "item",
    name = "tungsten-wall-gate",
    icon = "__MAIN-DyTech-War__/graphics/gates/tungsten-gate.png",
    flags = {"goes-to-quickbar"},
    subgroup = "dytech-combat-gates",
    order = "b[tungsten]",
    place_result = "tungsten-wall-gate",
    stack_size = 50
  },
}
)