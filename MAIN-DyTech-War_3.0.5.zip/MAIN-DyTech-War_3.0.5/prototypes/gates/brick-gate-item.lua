data:extend(
{
  {
    type = "item",
    name = "brick-wall-gate",
    icon = "__MAIN-DyTech-War__/graphics/gates/brick-gate.png",
    flags = {"goes-to-quickbar"},
    subgroup = "dytech-combat-gates",
    order = "b[brick]",
    place_result = "brick-wall-gate",
    stack_size = 50
  },
}
)