data:extend(
{
  {
    type = "item",
    name = "chitin-wall-gate",
    icon = "__MAIN-DyTech-War__/graphics/gates/chitin-gate.png",
    flags = {"goes-to-quickbar"},
    subgroup = "dytech-combat-gates",
    order = "b[sandwall]",
    place_result = "chitin-wall-gate",
    stack_size = 50
  },
}
)