data:extend(
{
  {
    type = "item",
    name = "sand-wall-gate",
    icon = "__MAIN-DyTech-War__/graphics/gates/sand-gate.png",
    flags = {"goes-to-quickbar"},
    subgroup = "dytech-combat-gates",
    order = "b[sandwall]",
    place_result = "sand-wall-gate",
    stack_size = 50
  },
}
)