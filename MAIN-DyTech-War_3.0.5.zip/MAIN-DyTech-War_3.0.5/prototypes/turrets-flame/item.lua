data:extend(
{
  {
    type = "item",
    name = "flame-thrower-turret",
    icon = "__MAIN-DyTech-War__/graphics/turrets-flame/flame-thrower-turret.png",
    flags = {"goes-to-quickbar"},
    subgroup = "dytech-combat-turrets",
    order = "a[flamethrower]",
    place_result = "flame-thrower-turret",
    stack_size = 25
  },
}
)
