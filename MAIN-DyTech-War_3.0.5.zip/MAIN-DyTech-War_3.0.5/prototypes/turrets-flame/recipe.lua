data:extend(
{ 
  {
    type = "recipe",
    name = "flame-thrower-turret",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"flame-thrower", 1},
      {"gun-turret", 1},
      {"iron-gear-wheel", 20}
    },
    result = "flame-thrower-turret"
  },
}
)