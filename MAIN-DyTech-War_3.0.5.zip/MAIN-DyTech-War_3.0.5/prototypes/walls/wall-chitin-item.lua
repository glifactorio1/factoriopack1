data:extend(
{
  {
    type = "item",
    name = "chitin-wall",
    icon = "__MAIN-DyTech-War__/graphics/walls/chitin-wall.png",
    flags = {"goes-to-quickbar"},
    subgroup = "dytech-combat-walls",
    order = "g[chitin-wall]",
    place_result = "chitin-wall",
    stack_size = 50
  },

}
)