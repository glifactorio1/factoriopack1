data:extend(
{
  {
    type = "item",
    name = "brick-wall",
    icon = "__MAIN-DyTech-War__/graphics/walls/brickwall.png",
    flags = {"goes-to-quickbar"},
    subgroup = "dytech-combat-walls",
    order = "c[brickwall]",
    place_result = "brick-wall",
    stack_size = 50
  },
  
}
)