data:extend(
{
  {
    type = "item",
    name = "tungsten-wall",
    icon = "__MAIN-DyTech-War__/graphics/walls/tungsten-wall.png",
    flags = {"goes-to-quickbar"},
    subgroup = "dytech-combat-walls",
    order = "d[tungsten-wall]",
    place_result = "tungsten-wall",
    stack_size = 50
  },
}
)