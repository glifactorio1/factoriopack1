data:extend(
{
  {
    type = "item",
    name = "sand-wall",
    icon = "__MAIN-DyTech-War__/graphics/walls/sand-wall.png",
    flags = {"goes-to-quickbar"},
    subgroup = "dytech-combat-walls",
    order = "b[sandwall]",
    place_result = "sand-wall",
    stack_size = 50
  },
}
)