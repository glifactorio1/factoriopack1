table.insert(data.raw["technology"]["military-3"].effects,{type = "unlock-recipe",recipe = "poison-capsule-ammo-1"})
table.insert(data.raw["technology"]["poison-capsule-1"].effects,{type = "unlock-recipe",recipe = "poison-capsule-ammo-2"})
table.insert(data.raw["technology"]["poison-capsule-2"].effects,{type = "unlock-recipe",recipe = "poison-capsule-ammo-3"})

table.insert(data.raw["technology"]["acid-capsule-1"].effects,{type = "unlock-recipe",recipe = "acid-capsule-ammo-1"})
table.insert(data.raw["technology"]["acid-capsule-2"].effects,{type = "unlock-recipe",recipe = "acid-capsule-ammo-2"})
table.insert(data.raw["technology"]["acid-capsule-3"].effects,{type = "unlock-recipe",recipe = "acid-capsule-ammo-3"})

table.insert(data.raw["technology"]["napalm-capsule-1"].effects,{type = "unlock-recipe",recipe = "napalm-capsule-ammo-1"})
table.insert(data.raw["technology"]["napalm-capsule-2"].effects,{type = "unlock-recipe",recipe = "napalm-capsule-ammo-2"})
table.insert(data.raw["technology"]["napalm-capsule-3"].effects,{type = "unlock-recipe",recipe = "napalm-capsule-ammo-3"})

table.insert(data.raw["technology"]["firestorm-capsule-1"].effects,{type = "unlock-recipe",recipe = "firestorm-capsule-ammo-1"})
table.insert(data.raw["technology"]["firestorm-capsule-2"].effects,{type = "unlock-recipe",recipe = "firestorm-capsule-ammo-2"})
table.insert(data.raw["technology"]["firestorm-capsule-3"].effects,{type = "unlock-recipe",recipe = "firestorm-capsule-ammo-3"})

table.insert(data.raw["technology"]["radiation-capsule-1"].effects,{type = "unlock-recipe",recipe = "radiation-capsule-ammo-1"})
table.insert(data.raw["technology"]["radiation-capsule-2"].effects,{type = "unlock-recipe",recipe = "radiation-capsule-ammo-2"})
table.insert(data.raw["technology"]["radiation-capsule-3"].effects,{type = "unlock-recipe",recipe = "radiation-capsule-ammo-3"})