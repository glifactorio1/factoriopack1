# boblocale
A localization mod for Bob's Mods for Factorio.

Forum Thread: https://forums.factorio.com/viewtopic.php?f=51&t=17367
