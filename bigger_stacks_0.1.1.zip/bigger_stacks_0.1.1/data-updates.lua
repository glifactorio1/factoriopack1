local resourceSize = 200
data.raw.item["stone"].stack_size = resourceSize * 3
data.raw.item["coal"].stack_size = resourceSize * 3
data.raw.item["iron-ore"].stack_size = resourceSize
data.raw.item["copper-ore"].stack_size = resourceSize
data.raw.item["raw-wood"].stack_size = resourceSize * 2
data.raw.item["wood"].stack_size = resourceSize * 2

local plateSize = 600
data.raw.item["iron-plate"].stack_size = plateSize
data.raw.item["copper-plate"].stack_size = plateSize
data.raw.item["steel-plate"].stack_size = plateSize

local cableSize = 200
data.raw.item["copper-cable"].stack_size = cableSize
data.raw.item["red-wire"].stack_size = cableSize
data.raw.item["green-wire"].stack_size = cableSize

data.raw.item["offshore-pump"].stack_size = 5
data.raw.item["boiler"].stack_size = 50
data.raw.item["steam-engine"].stack_size = 10

local circuitSize = 200
data.raw.item["electronic-circuit"].stack_size = circuitSize
data.raw.item["advanced-circuit"].stack_size = circuitSize
data.raw.item["processing-unit"].stack_size = circuitSize

local beltSize = 100
data.raw.item["transport-belt"].stack_size = beltSize
data.raw.item["underground-belt"].stack_size = beltSize * 2
data.raw.item["splitter"].stack_size = beltSize
data.raw.item["fast-transport-belt"].stack_size = beltSize
data.raw.item["fast-underground-belt"].stack_size = beltSize * 2
data.raw.item["fast-splitter"].stack_size = beltSize
data.raw.item["express-transport-belt"].stack_size = beltSize
data.raw.item["express-underground-belt"].stack_size = beltSize * 2
data.raw.item["express-splitter"].stack_size = beltSize

local pipeSize = 100
data.raw.item["pipe"].stack_size = pipeSize
data.raw.item["pipe-to-ground"].stack_size = pipeSize * 2
data.raw.item["small-pump"].stack_size = pipeSize

local inserterSize = 100
data.raw.item["burner-inserter"].stack_size = inserterSize
data.raw.item["inserter"].stack_size = inserterSize
data.raw.item["long-handed-inserter"].stack_size = inserterSize
data.raw.item["fast-inserter"].stack_size = inserterSize
data.raw.item["filter-inserter"].stack_size = inserterSize
data.raw.item["stack-inserter"].stack_size = inserterSize
data.raw.item["stack-filter-inserter"].stack_size = inserterSize

local drillSize = 50
data.raw.item["burner-mining-drill"].stack_size = drillSize
data.raw.item["electric-mining-drill"].stack_size = drillSize

local furnaceSize = 50
data.raw.item["stone-furnace"].stack_size = furnaceSize
data.raw.item["steel-furnace"].stack_size = furnaceSize
data.raw.item["electric-furnace"].stack_size = furnaceSize

local assemblySize = 50
data.raw.item["assembling-machine-1"].stack_size = assemblySize
data.raw.item["assembling-machine-2"].stack_size = assemblySize
data.raw.item["assembling-machine-3"].stack_size = assemblySize
data.raw.item["chemical-plant"].stack_size = assemblySize / 5
data.raw.item["oil-refinery"].stack_size = assemblySize / 5

data.raw.item["lab"].stack_size = 10

data.raw.item["pumpjack"].stack_size = 20
data.raw.item["storage-tank"].stack_size = 50

local chestSize = 50
data.raw.item["wooden-chest"].stack_size = chestSize
data.raw.item["iron-chest"].stack_size = chestSize
data.raw.item["steel-chest"].stack_size = chestSize
data.raw.item["logistic-chest-active-provider"].stack_size = chestSize
data.raw.item["logistic-chest-passive-provider"].stack_size = chestSize
data.raw.item["logistic-chest-requester"].stack_size = chestSize
data.raw.item["logistic-chest-storage"].stack_size = chestSize

local poleSize = 50
data.raw.item["small-electric-pole"].stack_size = poleSize
data.raw.item["medium-electric-pole"].stack_size = poleSize
data.raw.item["big-electric-pole"].stack_size = poleSize
data.raw.item["substation"].stack_size = poleSize / 2

local scienceSize = 100
data.raw.tool["science-pack-1"].stack_size = scienceSize
data.raw.tool["science-pack-2"].stack_size = scienceSize
data.raw.tool["science-pack-3"].stack_size = scienceSize
data.raw.tool["alien-science-pack"].stack_size = scienceSize

local fuelSize = 100
-- data.raw.item["coal"].stack_size = fuelSize
data.raw.item["solid-fuel"].stack_size = fuelSize
data.raw.item["rocket-fuel"].stack_size = fuelSize

local circuitNetworkSize = 50
data.raw.item["arithmetic-combinator"].stack_size = circuitNetworkSize
data.raw.item["decider-combinator"].stack_size = circuitNetworkSize
data.raw.item["constant-combinator"].stack_size = circuitNetworkSize
data.raw.item["power-switch"].stack_size = circuitNetworkSize

data.raw["rail-planner"]["rail"].stack_size = 200
data.raw.item["train-stop"].stack_size = 10
data.raw.item["rail-signal"].stack_size = 50
data.raw.item["rail-chain-signal"].stack_size = 50

local robotSize = 200
data.raw.item["logistic-robot"].stack_size = robotSize
data.raw.item["construction-robot"].stack_size = robotSize
data.raw.item["roboport"].stack_size = 5

local solarSize = 50
data.raw.item["solar-panel"].stack_size = solarSize
data.raw.item["accumulator"].stack_size = solarSize

local moduleSize = 20
data.raw.module["effectivity-module"].stack_size = moduleSize
data.raw.module["effectivity-module-2"].stack_size = moduleSize
data.raw.module["effectivity-module-3"].stack_size = moduleSize
data.raw.module["speed-module"].stack_size = moduleSize
data.raw.module["speed-module-2"].stack_size = moduleSize
data.raw.module["speed-module-3"].stack_size = moduleSize
data.raw.module["productivity-module"].stack_size = moduleSize
data.raw.module["productivity-module-2"].stack_size = moduleSize
data.raw.module["productivity-module-3"].stack_size = moduleSize
data.raw.item["beacon"].stack_size = 10

data.raw.item["radar"].stack_size = 50

local ammoSize = 600
data.raw.ammo["firearm-magazine"].stack_size = ammoSize
data.raw.ammo["piercing-rounds-magazine"].stack_size = ammoSize
data.raw.ammo["shotgun-shell"].stack_size = ammoSize
data.raw.ammo["piercing-shotgun-shell"].stack_size = ammoSize
data.raw.ammo["flame-thrower-ammo"].stack_size = ammoSize / 2
data.raw.ammo["rocket"].stack_size = ammoSize
data.raw.ammo["explosive-rocket"].stack_size = ammoSize / 3
data.raw.ammo["cannon-shell"].stack_size = ammoSize / 6
data.raw.ammo["explosive-cannon-shell"].stack_size = ammoSize / 6

local capsuleSize = 100
data.raw.capsule["grenade"].stack_size = capsuleSize
data.raw.capsule["cluster-grenade"].stack_size = capsuleSize
data.raw.capsule["poison-capsule"].stack_size = capsuleSize
data.raw.capsule["slowdown-capsule"].stack_size = capsuleSize
data.raw.capsule["defender-capsule"].stack_size = capsuleSize
data.raw.capsule["distractor-capsule"].stack_size = capsuleSize
data.raw.capsule["destroyer-capsule"].stack_size = capsuleSize
data.raw.capsule["discharge-defense-remote"].stack_size = capsuleSize

local turretSize = 50
data.raw.item["gun-turret"].stack_size = turretSize
data.raw.item["laser-turret"].stack_size = turretSize
data.raw.item["flamethrower-turret"].stack_size = turretSize

local wallSize = 100
data.raw.item["stone-wall"].stack_size = wallSize
data.raw.item["gate"].stack_size = wallSize

local terraSize = 1000
data.raw.item["stone-brick"].stack_size = terraSize
data.raw.item["concrete"].stack_size = terraSize
data.raw.item["hazard-concrete"].stack_size = terraSize
data.raw.item["landfill"].stack_size = terraSize

data.raw["repair-tool"]["repair-pack"].stack_size = 100

data.raw.item["small-lamp"].stack_size = 50
