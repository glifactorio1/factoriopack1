Mod_Name = "__VersepellesAquaFarm__"

verbose = true						-- Whether to output messages to the player
aquafarm_period = 60 * 4			-- How often to perform fishing, in ticks
fish_rate = 1						-- How many fish produces each period
aquafarm_pollution = 0.005 * 60		-- How much pollution is produced per period