data:extend(
{
  {
    type = "recipe",
    name = "aquafarm",
	enabled = "true",
    energy_required = 5,
	ingredients = 
    {
		{"raw-wood", 10},
		{"iron-plate", 20},
	},
	result = "aquafarm",
	result_count = 1,
  },
})