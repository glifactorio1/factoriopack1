require "prototypes/recipe"
require "prototypes/item"
require "prototypes/entity"
require "prototypes/technology"
