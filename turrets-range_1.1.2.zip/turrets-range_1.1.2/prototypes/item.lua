data:extend({
    {
        type = "item",
        name = "turret-probe",
        icon = "__turrets-range__/graphics/turret-probe.png",
        flags = { "goes-to-quickbar" },
        subgroup = "tool",
        order = "k[probing]-a[turret-probe]",
        stack_size = 1,
        place_result = "turret-probe"
    }
})

