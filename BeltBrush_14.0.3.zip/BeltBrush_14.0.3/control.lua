local function oppositedirection(direction)
  if direction == defines.direction.north then return defines.direction.south end
  if direction == defines.direction.south then return defines.direction.north end
  if direction == defines.direction.east then return defines.direction.west end
  if direction == defines.direction.west then return defines.direction.east end
end

--local Game = require("stdlib.game")

--get item count from inventory and vehicle
local function get_item_count(player, item)
  if player.cheat_mode then
    player.insert({name=item, count=1})
    return 10000
  end

  local count = 0 -- we start with 1!
  if player.vehicle and player.vehicle.get_inventory(defines.inventory.car_trunk) then
    count = count + player.vehicle.get_inventory(defines.inventory.car_trunk).get_item_count(item)
  end
  count = count + player.get_item_count(item)
  return count
end


--remove items from cursor_stack, then vehicle inventory, then inventory, then quickbar
local function remove_items(player, stack)
  if player.cheat_mode then return end -- cheat mode enabled don't remove items because!
  -- local stack_count = 0
  -- if player.cursor_stack.valid_for_read then stack_count = player.cursor_stack.count end
  local count = player.remove_item(stack)
  local vehicle_inv
  if player.vehicle and player.vehicle.get_inventory(defines.inventory.car_trunk)
  and player.vehicle.get_inventory(defines.inventory.car_trunk).get_item_count(stack.name) > 0 then
    vehicle_inv = player.vehicle.get_inventory(defines.inventory.car_trunk)
    player.insert({name = stack.name, count = vehicle_inv.remove({name=stack.name, count = count})})
  end
end

--Return true if placeable or fast placeable.
local function is_placeable(entity, position, ghost)
  ghost = ghost or false
  local name, type
  local dir, force = entity.direction, entity.force
  if ghost then
    name=entity.ghost_name
    type=entity.ghost_type
  else
    name=entity.name
    type=entity.type
  end

  local placeable = entity.surface.can_place_entity{name=name, position=position, direction=dir, force=force} or false
  if ghost and placeable then --remove all existing ghosts from position
    local list = entity.surface.find_entities_filtered{position=position, type="entity-ghost"}
    for _, ghosts in pairs(list) do
      ghosts.destroy()
    end
    return true
  end

  --Game.print_all("placeable: ".. tostring(placeable) .. " Ghost: " .. tostring(ghost) .. " type: " .. tostring(type))
  if placeable == false and ghost == false and type ~= "pipe-to-ground" then --is it fast replaceable? --Ignore pipes for now
    local list = entity.surface.find_entities_filtered{position=position, type=type, force=force, limit=1}
    if list and list[1] and list[1].prototype.fast_replaceable_group == entity.prototype.fast_replaceable_group then
      return true
    end
  end
  return placeable
end

local function brush_build(belt, player_index, ghost)
	--if ghost then return end -- exit on ghost for now

	local player = game.players[player_index]
	local brush_lanes = global[player_index].count
  --local belt_count = player.get_item_count(name) or 0
	local x, y, f, dir = belt.position.x, belt.position.y ,belt.force, belt.direction
	local name, type

	if ghost then
		name=belt.ghost_name
		type=belt.ghost_type
	else
		name=belt.name
		type=belt.type
		local belt_count = get_item_count(player, name)
		if belt_count < brush_lanes then
			brush_lanes = belt_count
		end
	end

	if brush_lanes <= 1 then return end -- We have no belts so don't do anything or only 1 lane

	local ug_dir
	if type == "underground-belt" and not ghost then ug_dir = belt.belt_to_ground_type end
	for _=2, brush_lanes do --start at 2 since it is the second one!
		if type == "transport-belt" then --ug-pipe and belt-to-ground are handled differntly!
			if     dir == defines.direction.north then x = x + 1
			elseif dir == defines.direction.south then x = x - 1
			elseif dir == defines.direction.east then y = y + 1
			elseif dir == defines.direction.west then y = y - 1
			end
		else -- underground items will always be placed down and right due to the way they work
			if     dir == defines.direction.north or dir == defines.direction.south then x = x + 1
			elseif dir == defines.direction.east or dir == defines.direction.west then y = y + 1
			end
		end
		--TODO reverse belt placement!

		if not ghost and is_placeable(belt, {x,y}, false) then
      local _player, _fast_replace, _spill = player, true, true
      if player.cheat_mode then
        _player, _fast_replace, _spill = nil, true, false
      end
      local placed = player.surface.create_entity{name=name, position={x=x,y=y}, direction=dir,force=f, player=_player, fast_replace=_fast_replace, spill=_spill}
			if placed then
        remove_items(player, {name=name, count=1})

        -- if not player.cheat_mode then player.remove_item({name=name, count=1}) end

        --Flip direction for underground-belt if needed
        if ug_dir and ug_dir ~= placed.belt_to_ground_type then
			      placed.direction=oppositedirection(dir)
		    end
      end

		elseif ghost and is_placeable(belt, {x, y}, true) then
		  --TODO GHOST checking bug
			--placeable = player.surface.can_place_entity{name=name, --[[inner_name=name,]] position={x=x,y=y}, direction=dir,force=f}
			--if placeable then
				_ = player.surface.create_entity{name="entity-ghost", inner_name=name, position={x=x,y=y}, direction=dir,force=f}
			--end
		--  player.print("couldn't build! ".. tostring(i))
		end
	end
end

local function init_player(player)
	--Destroy the old version of the Gui
	if player.gui.left["BB_flow_main"] then player.gui.left["BB_flow_main"].destroy() end

	if not global[player.index] then
		global[player.index] = {}
		global[player.index].count = 1
		global[player.index].script = false
	else
		global[player.index].count = global[player.index].count or 1
	end
	return global[player.index]
end

local function draw_gui(player) -- return gui
  --Destroy the GUI here
	if player.gui.left["BB_frame_main"] then player.gui.left["BB_frame_main"].destroy() end

  local gui =  player.gui.left.add{type = "frame", name = "BB_frame_main", direction = "horizontal", style="BB_frame_style"}
	local _ = gui.add{type="label", name="BB_label", caption={"frame.label-caption"}, tooltip={"tooltip.label"}, style="BB_label_style"}
	local _ =	gui.add{type="textfield", name = "BB_text_box", text=global[player.index].count, tooltip={"tooltip.textfield"}, style="BB_text_style"}
	local table = gui.add{type="table", name = "BB_table", colspan=1, style="BB_table_style"}
	local _ = table.add{type="button", name="BB_btn_up", style="BB_btn_up"}
	local _ = table.add{type="button", name="BB_btn_down", style="BB_btn_dn"}

end

local function on_built_entity(event)
	if global[event.player_index].count > 1 then
		local result = event.created_entity.type
		if result == "transport-belt" or result == "pipe-to-ground" or result == "underground-belt" then
			brush_build(event.created_entity, event.player_index)
		elseif result == "entity-ghost" then
			result = event.created_entity.ghost_type
			if result == "transport-belt" or result == "pipe-to-ground" or result == "underground-belt" then
				brush_build(event.created_entity, event.player_index, true)
  		end
		end
	end
end

script.on_load(function()
	--Instant BP workaround only register event when we need it!
	script.on_event(defines.events.on_built_entity, on_built_entity)
end)

script.on_event(defines.events.on_player_cursor_stack_changed, function(event)
    local player, data = game.players[event.player_index], global[event.player_index]

		if not data then data=init_player(player) end
    if game.players[event.player_index].cursor_stack.valid_for_read then
      if player.cursor_stack.prototype and player.cursor_stack.prototype.place_result then
				local result = player.cursor_stack.prototype.place_result.type
				if result == "transport-belt" or result == "pipe-to-ground" or result == "underground-belt" then
	        --Player is holding a transport-belt, ug-belt, or pipe-to-ground, draw ui and register event if needed
	        if not player.gui.left["BB_frame_main"] then draw_gui(player) end
					if not data.script then
						script.on_event(defines.events.on_built_entity, on_built_entity)
						data.script = true
					end
				else
					if player.gui.left["BB_frame_main"] then player.gui.left["BB_frame_main"].destroy() end
					script.on_event(defines.events.on_built_entity, nil)
					data.script=false
				end
			end
		else
			if player.gui.left["BB_frame_main"] then player.gui.left["BB_frame_main"].destroy() end
			script.on_event(defines.events.on_built_entity, nil)
			data.script=false
		end
  end)

script.on_event(defines.events.on_gui_text_changed, function(event)
	if event.element.name == "BB_text_box" then
		if tonumber(event.element.text) then
			global[event.player_index].count = tonumber(event.element.text)
			local gui = game.players[event.player_index].gui.left["BB_frame_main"]
			--gui["BB_label"].caption = {"frame.label-caption"}
			gui["BB_label"].style.font_color = {r=1, g=1, b=1}
			gui["BB_text_box"].tooltip = {"tooltip.textfield"}
			--game.players[event.player_index].print("Now belting "..tostring(event.element.text) .. " lanes")
		else
			global[event.player_index].count = 1
			--local player = game.players[event.player_index]
			local gui = game.players[event.player_index].gui.left["BB_frame_main"]
			--gui["BB_label"].caption = {"frame.label-caption-error"}
			gui["BB_label"].style.font_color = {r=1, g=0, b=0}
			gui["BB_text_box"].tooltip = {"tooltip.notnumber"}
			--event.element.text=1
			--game.players[event.player_index].print("Belt Brush Error: must be number ".. tostring(event.element.text))
		end
	end
end)

script.on_event( "BB_IP_PU", function(event)
	if game.players[event.player_index].gui.left["BB_frame_main"] then
		local fakedata = {}
		fakedata.element = {}
		fakedata.element.name = "BB_btn_up"
		fakedata.player_index = event.player_index
		IncreaseDecreaseBeltNumber(fakedata)
	end
end)

script.on_event( "BB_IP_PD", function(event)
	if game.players[event.player_index].gui.left["BB_frame_main"] then
		local fakedata = {}
		fakedata.element = {}
		fakedata.element.name = "BB_btn_down"
		fakedata.player_index = event.player_index
		IncreaseDecreaseBeltNumber(fakedata)
	end
end)

script.on_event(defines.events.on_gui_click, function(event)
	IncreaseDecreaseBeltNumber(event)
end)

function IncreaseDecreaseBeltNumber(event)

	if event.element.name == "BB_btn_up" or event.element.name == "BB_btn_down" then
		local pdata = global[event.player_index]
		pdata.count = pdata.count or 1
		local textf=game.players[event.player_index].gui.left["BB_frame_main"]["BB_text_box"]
		if event.element.name == "BB_btn_up" then
			pdata.count = pdata.count + 1
		end
		if event.element.name == "BB_btn_down" and pdata.count >1 then
			pdata.count = pdata.count - 1
		end
		textf.text=pdata.count
	end

end